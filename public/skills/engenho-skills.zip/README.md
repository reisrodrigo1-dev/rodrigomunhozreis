# Engenho — Suíte de Skills do Rodrigo Munhoz Reis

> *Vibecoding com engenharia.* Cada skill encarna o método (P.R.O.M.P.T.E.R. + Protocolo de 5 Camadas) e o diferencial: rigor de engenheiro + segurança, sem hype.

**"Engenho"** é a coleção. Cada skill tem nome próprio.
Legenda: 🔨 **construir** (conteúdo nosso) · ♻️ **usar skill existente** (a original + rebrand opcional)

---

## 🔒 Segurança *(o fosso)*
| Nome | id | O que é | |
|---|---|---|---|
| **Bastião** | `bastiao` | Inteligência de vibecoding seguro (vulns, padrões por stack, LGPD, prioridade) | 🔨 |
| **Cofre** | `cofre` | Auditor das regras do Firebase | 🔨 |
| **Faro** | `faro` | Caçador de segredos vazados | 🔨 |
| **Quarentena** | `quarentena` | Auditor de dependências / supply-chain | 🔨 |
| **Crivo** | `crivo` | Revisor de código (Protocolo de 5 Camadas) | 🔨 |

## 💻 Construção & Desenvolvimento
| Nome | id | O que é | |
|---|---|---|---|
| **Bússola** | `bussola` | Inteligência de stack/arquitetura | 🔨 |
| **Planta** | `planta` | Planejador de MVP (plano antes do código) | 🔨 |
| **Canteiro** | `canteiro` | Scaffold de projeto já blindado | 🔨 |
| **Lupa** | `lupa` | Caçador de bugs (F12 → IA) | 🔨 |
| **Prova** | `prova` | Gerador de testes (edge cases primeiro) | 🔨 |
| **Atelier** | `atelier` | Geração de UI de alta fidelidade | ♻️ base: frontend-design |
| **Cânone** | `canone` | Inteligência de design | ♻️ base: ui-ux-pro-max |
| **Garimpo** | `garimpo` | Pesquisa profunda com citações | ♻️ base: deep-research |

## ✍️ Método & Prompts
| Nome | id | O que é | |
|---|---|---|---|
| **Forja** | `forja` | Inteligência + gerador de prompts P.R.O.M.P.T.E.R. | 🔨 |
| **Alicerce** | `alicerce` | Instruções iniciais / memória do projeto | 🔨 |

## 📣 Marketing & Criação
| Nome | id | O que é | |
|---|---|---|---|
| **Alavanca** | `alavanca` | Inteligência de marketing e funil | 🔨 |
| **Claquete** | `claquete` | Roteiros e vídeo programático | ♻️ base: remotion |

## 📚 Conteúdo & Criação
| Nome | id | O que é | |
|---|---|---|---|
| **Tomo** | `tomo` | Criador de e-books/guias no padrão editorial da casa | 🔨 |
| **Vitrine** | `vitrine` | Landing pages de conversão (oferta única) | 🔨 |
| **Correio** | `correio` | E-mails e newsletter de nutrição | 🔨 |
| **Pena** | `pena` | Posts de blog / artigos com SEO | 🔨 |
| **Palco** | `palco` | Palestras e apresentações | 🔨 base: slides |

## 💼 Negócio
| Nome | id | O que é | |
|---|---|---|---|
| **Decolagem** | `decolagem` | Inteligência de lançamento | 🔨 |
| **Salvaguarda** | `salvaguarda` | Conformidade LGPD | 🔨 |
| **Termômetro** | `termometro` | Estimador de custos | 🔨 |

**20 skills.** As ♻️ usam skills já existentes (não reinventar — instalar a original; rebrand opcional).

---

## Status: ✅ 25/25 criadas
Todas as skills estão completas (SKILL.md + base de conhecimento + scripts/templates).
- **21 🔨 próprias** — conteúdo original (segurança, método, dev, marketing, negócio, criação de conteúdo).
- **4 ♻️ wrappers** — apontam para a skill base e adicionam a camada de marca:
  - `atelier` → base **frontend-design** · `canone` → base **ui-ux-pro-max**
  - `garimpo` → base **deep-research** · `claquete` → base **remotion**

## Como ativar (Claude Code)
Cada skill é uma pasta com `SKILL.md`. Para usar:
1. Copie a pasta da skill para `~/.claude/skills/` (ex.: `~/.claude/skills/bastiao/`).
2. Para os 4 wrappers (♻️), instale também a **skill base** correspondente (frontend-design, ui-ux-pro-max, deep-research, remotion).
3. A skill é acionada sozinha quando o pedido casa com a `description`, ou invoque pelo nome.

## Distribuição (produto)
Para a área do aluno: empacotar cada pasta como download + um guia de instalação. Comece publicando as 2–3 flagship (Bastião, Forja, Crivo).
