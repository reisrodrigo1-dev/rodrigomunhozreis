---
name: atelier
description: Gera interfaces de alta fidelidade na identidade visual do Rodrigo (escuro premium + âmbar), com acessibilidade e segurança de fábrica — foge do visual genérico de protótipo. Use ao criar telas, páginas ou componentes de UI.
---

# Atelier — UI de alta fidelidade com a marca da casa

Atelier **não reinventa** geração de UI: ele se apoia em duas bases e adiciona o padrão da casa.

- **Motor de geração:** a skill **`frontend-design`** (instale-a — é ela que produz código de interface de alta qualidade, fugindo do genérico).
- **Inteligência de design:** a skill **`canone`** (estilos, paletas, tipografia, regras de UX).
- **Camada Atelier:** aplica a **identidade visual do Rodrigo** + defaults de **acessibilidade** e **segurança** em cima do que as duas geram.

## Quando usar
Ao criar qualquer interface: landing, página, componente, dashboard, e-mail. Sempre que o pedido envolver "como deve ficar na tela".

## Procedimento
1. **Consulte a Cânone** para o estilo e as regras de UX certas pro tipo de produto.
2. **Gere com o frontend-design**, pedindo alta fidelidade (nada de cinza-genérico de teste).
3. **Aplique a marca** (`reference/marca.md`): cores, tipografia, efeitos e voz.
4. **Garanta os não-negociáveis:** contraste ≥ 4.5:1, foco visível, alvos de toque ≥ 44px, `alt` em imagens, e nada de `dangerouslySetInnerHTML` sem sanitizar (segurança é parte do acabamento).
5. **Entregue** o código + 1 nota curta do que pode ajustar. A decisão é sua.

## Princípio
Interface profissional não é enfeite — é **clareza com acabamento**. Premium, escuro, âmbar como destaque, hierarquia forte. Sem robôzinho azul de banco de imagem.
