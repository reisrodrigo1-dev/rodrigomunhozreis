# Sistema de marca — Rodrigo Munhoz Reis

Identidade: **escuro premium + âmbar**, editorial, sofisticada, técnica. Sem hype visual.

## Cores
| Token | Hex | Uso |
|---|---|---|
| ink | `#070608` | Fundo (quase preto) |
| paper | `#F4EFE6` | Texto principal |
| amber | `#E8A33D` | Destaque, CTA, números-gancho |
| amber-deep | `#C07F1E` | Hover/variação escura do âmbar |
| amber-light | `#F0C070` | Texto de destaque sobre escuro |

Texto secundário: `paper` com opacidade (ex.: `text-paper/55`, `/40`).

## Tipografia
- **Títulos:** serifada de alto contraste (**Fraunces**), pesos 500–700.
- **Corpo:** sans (**Inter**), 400–600.
- **Acento/itálico:** **Instrument Serif** (itálico) para realces editoriais.
- Mínimo 16px no corpo; entrelinha ~1.5.

## Efeitos / utilitários (Tailwind do projeto)
- `glass` / `glass-hover` — cartão de vidro fosco com borda sutil.
- `text-grad` — gradiente sutil no texto de título.
- `accent` — aplica a fonte de acento + cor âmbar.
- `kicker-d` — "kicker" (rótulo pequeno, caixa alta, âmbar, tracking largo).
- `btn-glow` — botão âmbar com brilho (CTA principal).
- `btn-dark-ghost` — botão fantasma sobre fundo escuro (CTA secundário).
- Bordas suaves: `rounded-xl`/`rounded-2xl`. Sombras discretas.

## Voz (microcopy)
Direta, sem hype, sem promessa milagrosa. "A decisão é sua." Português do Brasil. Frases curtas. Especificidade > adjetivo.

## Não fazer
- Robôs/ícones azuis genéricos de IA.
- Cinza-de-protótipo, lorem ipsum entregue como final.
- Gradiente arco-íris, excesso de sombra, "glassmorphism" gratuito.
- Texto cinza-sobre-cinza (contraste baixo).
