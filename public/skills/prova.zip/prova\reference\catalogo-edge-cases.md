# Catálogo de casos de borda

Use como checklist. Para cada entrada do contrato, percorra o tipo correspondente e pergunte: **o que acontece se...?** Não precisa testar todos — escolha os que quebram *neste* contexto. Mas leia todos antes de decidir o que cortar.

A regra geral: **o caminho feliz é um caso; as bordas são vários.** A maioria dos bugs mora aqui.

---

## Strings

O que testar:

- **Vazia** (`""`) — muitos validadores tratam vazio como "presente". É?
- **Só espaços** (`"   "`) — passa em `if (str)` mas é vazio semântico. Faz `trim`?
- **`null` / `undefined`** — campo ausente vs. campo nulo são coisas diferentes.
- **Muito longa** — limite de coluna no banco, limite de UI, custo de processamento. String de 1 MB quebra?
- **Unicode / acentos / emoji** — `"José"`, `"日本語"`, `"👨‍👩‍👧"`. `.length` mente com emoji composto.
- **Caracteres especiais** — aspas, `<script>`, `'; DROP TABLE`, quebras de linha, `\0`. Injeção, XSS, parsing.
- **Espaços nas pontas** — `" email@x.com "`. Normaliza antes de comparar/salvar?
- **Case** — `"ADMIN"` vs `"admin"`. Comparação sensível a caixa onde não deveria?
- **Formato inválido** — email sem `@`, CPF com letra, URL malformada, JSON quebrado.

---

## Números

- **Zero** — divisão por zero, `0` como "ausente" (`if (qtd)` ignora zero válido).
- **Negativo** — preço negativo, idade negativa, índice negativo, quantidade negativa.
- **Limites** — mínimo, máximo, **máximo + 1**, mínimo − 1. O off-by-one mora aqui.
- **Ponto flutuante** — `0.1 + 0.2 !== 0.3`. Dinheiro em float é bug; use centavos inteiros.
- **Muito grande** — estouro de `Number.MAX_SAFE_INTEGER`, `Infinity`, overflow no banco.
- **NaN** — resultado de parse falho. `NaN === NaN` é `false`; propaga silencioso.
- **Tipo string** — `"5"` vindo de query param ou form. Soma vira concatenação?
- **Casas decimais** — arredondamento de moeda, juros, percentual.

---

## Listas / arrays

- **Vazia** (`[]`) — `reduce` sem valor inicial estoura; `[0]` é `undefined`; média divide por zero.
- **Um item** — caminhos que assumem "primeiro e último são diferentes".
- **Muitos itens** — performance, paginação, timeout, limite de memória, limite de batch do Firestore (500).
- **Duplicados** — `dedupe` funciona? Chave única é respeitada?
- **`null`/`undefined` dentro** — `[1, null, 3].map(x => x.id)` quebra.
- **Ordem** — depende de ordenação? Vem ordenado? Ordenação estável?
- **Mutação** — a função altera o array original sem querer?
- **Tipos mistos** — `[1, "2", null]` num array que deveria ser homogêneo.

---

## Datas e tempo

- **Fuso horário** — servidor em UTC, usuário em GMT-3. "Hoje" de quem?
- **Horário de verão** — hora que não existe ou existe duas vezes.
- **Fim de mês / ano** — 31 de janeiro + 1 mês = ? Ano bissexto (29/fev)?
- **Formato** — ISO vs `DD/MM/YYYY` vs timestamp. Parsing ambíguo (`01/02` é jan ou fev?).
- **Data inválida** — `new Date("xpto")` vira `Invalid Date`, não lança.
- **Passado / futuro** — agendamento no passado, expiração já vencida, `createdAt > updatedAt`.
- **Limites de range** — início == fim, início > fim, intervalo de zero segundos.
- **Precisão** — segundos vs milissegundos (Unix em s ou ms?). Firestore `Timestamp` vs `Date`.

---

## Async / rede

- **Sucesso** — o caminho óbvio.
- **Falha da dependência** — 500, 503, conexão recusada, DNS. O erro é tratado ou vaza?
- **Timeout** — a request nunca volta. Tem timeout? O que acontece quando estoura?
- **Resposta lenta** — chega, mas tarde. UI travou? Usuário clicou de novo?
- **Resposta malformada** — JSON inválido, campo faltando, contrato mudou no backend.
- **Rede offline** — sem conexão nenhuma. Mensagem clara ou tela branca?
- **Race condition** — duas requests concorrentes; a mais lenta sobrescreve a mais nova.
- **Retry / idempotência** — reenviar duplica o efeito? Pagamento cobrado duas vezes?
- **Cancelamento** — componente desmonta antes da resposta; `setState` em unmounted.
- **Ordem de resolução** — `Promise.all` vs sequencial; uma falha derruba todas?

---

## Auth / permissão

- **Sem token** — request anônima onde exige login.
- **Token inválido / malformado** — assinatura errada, base64 quebrado.
- **Token expirado** — válido ontem, vencido agora. Refresh funciona?
- **Permissão insuficiente** — usuário logado mas sem role (user tentando rota de admin).
- **Dono vs. não-dono** — usuário A acessando recurso do usuário B (IDOR). **Sempre teste isto.**
- **Sessão revogada** — logout em outro device, conta desativada.
- **Escalonamento** — alterar `role` no body, forjar `uid`, passar `isAdmin: true`.
- **Firebase Security Rules** — teste as regras, não só o client. Client confia; servidor verifica.

---

## Formulários / input de usuário

- **Campo obrigatório vazio** — submit sem preencher.
- **Submit duplo** — clicar duas vezes rápido. Debounce? Botão desabilita?
- **Valores limítrofes** — string no limite de caracteres, número no teto.
- **Colar conteúdo** — texto com formatação, quebras de linha, conteúdo gigante.
- **Caracteres perigosos** — `<`, `>`, aspas, `&`, emoji nos campos.
- **Validação client x server** — o que passa no client mas o server precisa rejeitar.
- **Estado intermediário** — submit enquanto carrega, navegar com form sujo.
- **Acessibilidade do erro** — erro aparece, é lido por leitor de tela, foco vai pro campo?
- **Autofill / autocomplete** — preenchimento do navegador dispara os handlers certos?

---

## Combinações que pegam (a fila do caos)

Os piores bugs são **combinações**: lista vazia + falha de rede; usuário sem permissão + token expirado; número grande + fuso horário na virada do mês. Quando um caso de borda parecer coberto, pergunte se ele se combina com outro. É aí que mora o bug que ninguém reproduz.
