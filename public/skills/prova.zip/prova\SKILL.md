---
name: prova
description: Escreve testes para uma função ou feature, começando pelos casos de borda, antes de confiar que está pronto. Use ao querer testar um código, garantir que algo funciona, cobrir um bug, ou antes de subir uma feature crítica para produção.
---

# Prova

> Camada 4 do Protocolo de 5 Camadas — **prova antes de confiar**.
> Funcionou na tela não é estar pronto. Pronto é quando você tem prova de que funciona — e de que não quebra quando o input é feio.

## Visão geral

A maior parte do código quebra não no caminho feliz, mas nas bordas: o input vazio, o `null` que ninguém esperava, a lista com 10 mil itens, a rede que caiu no meio da request, os dois cliques no mesmo botão. Testar o caminho feliz primeiro dá uma falsa sensação de segurança — passa verde e você sobe achando que está pronto.

`prova` inverte a ordem. Você mapeia o contrato, **lista os casos de borda PRIMEIRO**, e só depois escreve o caminho feliz. O objetivo não é cobertura de 100% — é cobrir **o que quebra em produção**.

Esta skill não escreve teste por escrever. Ela prioriza o que dá prejuízo: o que corrompe dado, o que vaza, o que derruba o fluxo de pagamento, o que deixa o usuário travado.

## Quando usar

- Você terminou uma função ou feature e quer **prova** de que funciona antes de confiar.
- Vai subir algo crítico (auth, pagamento, escrita no banco, fluxo de onboarding).
- Pegou um bug em produção e quer travar a regressão com um teste antes de corrigir.
- Está refatorando e precisa de uma rede de segurança.
- Recebeu código (seu ou de IA) e quer saber se ele aguenta input real.

Se o pedido for "testa isso", "garante que funciona", "será que aguenta", "antes de subir" — é aqui.

## Procedimento

Siga na ordem. A ordem é o ponto.

### 1. Mapeie o comportamento esperado e os contratos

Antes de escrever qualquer `expect`, descreva em uma frase o que a unidade faz. Depois explicite o contrato:

- **Entradas**: tipos, formatos, faixas válidas. O que é obrigatório? O que é opcional? Qual o range?
- **Saídas**: o que retorna em sucesso? O que retorna/lança em erro?
- **Efeitos colaterais**: escreve no banco? Chama API externa? Emite evento? Muda estado global?
- **Pré e pós-condições**: o que precisa ser verdade antes? O que fica garantido depois?

Se você não consegue descrever o contrato, não consegue testar direito. Pare e descubra primeiro.

### 2. Liste os casos de BORDA primeiro

Antes do caminho feliz. Para cada entrada do contrato, pergunte o que acontece com:

- **Vazio**: string `""`, array `[]`, objeto `{}`, `0`.
- **Nulo/ausente**: `null`, `undefined`, campo faltando, chave inexistente.
- **Limites**: o mínimo, o máximo, máximo + 1, negativo, número muito grande, string muito longa.
- **Tipo errado**: número onde espera string, array onde espera objeto (especialmente em fronteiras sem tipo: body de request, query param, JSON externo).
- **Erro**: a dependência falha (API 500, banco fora, timeout), o input é inválido, a permissão é negada.
- **Concorrência/duplicação**: chamada duas vezes, clique duplo, race condition, ordem inesperada de eventos.

Escreva essa lista como comentários ou `test.todo` ANTES de implementar os testes. Veja `reference/catalogo-edge-cases.md` para o catálogo completo por tipo de dado.

### 3. Escreva os testes na ferramenta do projeto

Use o que o projeto já usa — não introduza um runner novo sem motivo.

- **Unit / integração**: Vitest ou Jest.
- **E2E**: Playwright.

Estruture cada teste em **AAA — Arrange, Act, Assert** (ver `reference/padroes-de-teste.md`). Um comportamento por teste. Nome do teste descreve o caso, não a função: `retorna 400 quando o email está vazio`, não `testa createUser`.

Comece pelos testes de borda da lista do passo 2. O caminho feliz vem por último e costuma ser o mais curto.

Exemplos prontos por framework no Next.js em `reference/por-framework.md`.

### 4. Rode e cubra os caminhos críticos

Rode os testes. Verde não basta — confirme que os testes **falham quando deveriam** (quebre a implementação de propósito e veja o teste apontar).

Priorize cobrir os **caminhos críticos**: o que move dinheiro, o que escreve no banco, o que decide acesso, o que o usuário faz toda hora. Cobertura de linha é métrica secundária — cobertura dos caminhos que dão prejuízo é o que importa.

Se um teste de borda revela um bug: ótimo, foi exatamente o trabalho. Corrija o código, não o teste.

### 5. Saiba o que NÃO testar

Teste demais é tão ruim quanto teste de menos — vira manutenção morta e gera ruído. **Não** escreva teste para:

- **Getters/setters triviais** e código que só repassa valor sem lógica.
- **A linguagem / o framework / a lib**: você não testa se o `Array.map` funciona, se o Firestore salva, se o Next roteia. Confie nas dependências (e teste a sua *integração* com elas, não elas).
- **Detalhes de implementação**: testar que um método privado foi chamado, ou a estrutura interna de um objeto. Teste comportamento observável, não como ele foi alcançado — senão o teste quebra a cada refactor legítimo.
- **Mocks testando mocks**: se o teste só verifica que o mock que você configurou retornou o que você mandou, ele não prova nada.
- **Configuração estática** sem lógica.

A régua: **vale a pena se este teste te avisa de uma quebra real antes do usuário ver.** Se não, corta.

## Princípio

> Priorize o que quebra em produção. Um teste de borda que pega o `null` que derruba o checkout vale mais que cem testes de getter verde. Prova é sobre confiança merecida — não sobre número bonito de cobertura.

## Referências

- `reference/catalogo-edge-cases.md` — catálogo de casos de borda por tipo (strings, números, listas, datas, async/rede, auth, formulários).
- `reference/padroes-de-teste.md` — AAA, testes bons x frágeis, o que mockar, pirâmide de testes.
- `reference/por-framework.md` — Vitest/Jest e Playwright no contexto Next.js, com estrutura mínima e exemplos.
