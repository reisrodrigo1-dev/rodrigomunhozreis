# Por framework — Vitest/Jest e Playwright no Next.js

Noções práticas e estrutura mínima. Use a ferramenta que o projeto **já tem**. Em projeto novo Next.js + TypeScript, a combinação que costuma render é **Vitest** (unit/integração) + **Playwright** (e2e).

---

## Vitest (unit / integração) — recomendado em Next.js novo

Rápido, ESM nativo, API compatível com Jest. Boa escolha default.

### Instalação mínima

```bash
npm i -D vitest @vitejs/plugin-react jsdom @testing-library/react @testing-library/jest-dom
```

### `vitest.config.ts`

```ts
import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  test: {
    environment: 'jsdom',       // 'node' para lógica pura / API
    globals: true,              // describe/test/expect sem import
    setupFiles: ['./vitest.setup.ts'],
  },
});
```

`vitest.setup.ts`:

```ts
import '@testing-library/jest-dom/vitest';
```

`package.json`:

```json
{ "scripts": { "test": "vitest", "test:run": "vitest run", "coverage": "vitest run --coverage" } }
```

### Exemplo — lógica pura (bordas primeiro)

`src/lib/desconto.test.ts`:

```ts
import { describe, test, expect } from 'vitest';
import { calcularDesconto } from './desconto';

describe('calcularDesconto', () => {
  // bordas primeiro
  test('lança quando o preço é negativo', () => {
    expect(() => calcularDesconto(-1, 10)).toThrow('PRECO_INVALIDO');
  });

  test('retorna o preço cheio quando o desconto é 0', () => {
    expect(calcularDesconto(100, 0)).toBe(100);
  });

  test('não permite desconto acima de 100%', () => {
    expect(() => calcularDesconto(100, 120)).toThrow('DESCONTO_INVALIDO');
  });

  test('trata centavos sem erro de float', () => {
    expect(calcularDesconto(1990, 10)).toBe(1791); // em centavos, inteiro
  });

  // caminho feliz por último
  test('aplica 10% sobre 100', () => {
    expect(calcularDesconto(100, 10)).toBe(90);
  });
});
```

### Exemplo — componente React

```ts
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { describe, test, expect, vi } from 'vitest';
import { FormLogin } from './FormLogin';

describe('FormLogin', () => {
  test('mostra erro quando o email está vazio', async () => {
    render(<FormLogin onSubmit={vi.fn()} />);
    await userEvent.click(screen.getByRole('button', { name: /entrar/i }));
    expect(screen.getByText(/email obrigatório/i)).toBeInTheDocument();
  });

  test('não chama onSubmit em duplo clique enquanto envia', async () => {
    const onSubmit = vi.fn();
    render(<FormLogin onSubmit={onSubmit} />);
    // ... preenche campos válidos ...
    const btn = screen.getByRole('button', { name: /entrar/i });
    await userEvent.dblClick(btn);
    expect(onSubmit).toHaveBeenCalledTimes(1);
  });
});
```

### Mock de módulo / fetch

```ts
import { vi } from 'vitest';

// mock de um módulo inteiro
vi.mock('@/lib/firebase', () => ({
  db: {/* fake */},
}));

// fixar o relógio (não-determinismo)
vi.useFakeTimers();
vi.setSystemTime(new Date('2026-01-01T00:00:00Z'));
```

---

## Jest (unit / integração) — quando o projeto já usa

Jest funciona bem em Next.js; o próprio Next oferece config pronta. Se o projeto já tem Jest, fique nele — não troque sem motivo.

### Setup com Next

```bash
npm i -D jest @testing-library/react @testing-library/jest-dom jest-environment-jsdom
```

`jest.config.ts`:

```ts
import nextJest from 'next/jest.js';
const createJestConfig = nextJest({ dir: './' });

export default createJestConfig({
  testEnvironment: 'jest-environment-jsdom',
  setupFilesAfterEnv: ['<rootDir>/jest.setup.ts'],
});
```

A API de teste é quase idêntica à do Vitest — troque `vi` por `jest` (`jest.fn()`, `jest.mock()`, `jest.useFakeTimers()`). Os exemplos acima valem mudando esse detalhe.

---

## Playwright (e2e) — fluxos críticos no navegador

Para os 3–5 fluxos que não podem quebrar: login, checkout, onboarding. Roda no navegador real contra a app de pé.

### Instalação

```bash
npm init playwright@latest
```

### `playwright.config.ts` (sobe o Next antes dos testes)

```ts
import { defineConfig } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  use: { baseURL: 'http://localhost:3000' },
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
});
```

### Exemplo — fluxo de login (bordas + caminho crítico)

`e2e/login.spec.ts`:

```ts
import { test, expect } from '@playwright/test';

test.describe('login', () => {
  test('bloqueia com senha errada', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill('user@x.com');
    await page.getByLabel('Senha').fill('senha-errada');
    await page.getByRole('button', { name: 'Entrar' }).click();
    await expect(page.getByText('Credenciais inválidas')).toBeVisible();
    await expect(page).toHaveURL('/login'); // não avançou
  });

  test('entra e cai no dashboard com credenciais válidas', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill('user@x.com');
    await page.getByLabel('Senha').fill('senha-correta');
    await page.getByRole('button', { name: 'Entrar' }).click();
    await expect(page).toHaveURL('/dashboard');
  });
});
```

Boas práticas Playwright:

- **Selecione por papel/label** (`getByRole`, `getByLabel`), não por classe CSS — resiste a refactor de estilo.
- **Use auto-wait** do `expect(...).toBeVisible()`; evite `waitForTimeout` fixo (flaky).
- **Isole estado** — cada teste cria/limpa seus dados; não dependa da ordem.
- **Poucos e2e.** Cada um é caro e instável. Borda fina vai pro unit, não pro e2e.

---

## Firebase no Next.js — teste contra o emulador

Não mocke o SDK do Firestore para validar query/regra — passa verde com query que quebra de verdade. Use o **Firebase Emulator Suite**.

```bash
firebase emulators:start --only firestore,auth
```

- **Regras de segurança**: teste com `@firebase/rules-unit-testing` — dono x não-dono (IDOR), sem token, role insuficiente. O client confia; as **Security Rules** são a fronteira real.
- **Integração de route handler + Firestore**: aponte o SDK para o emulador no ambiente de teste e rode contra dados reais efêmeros.
- Para lógica pura que só transforma dados vindos do Firestore, isole a transformação numa função sem I/O e teste com unit (sem emulador).

---

## Estrutura de pastas (sugestão)

```
src/
  lib/desconto.ts
  lib/desconto.test.ts        # unit ao lado do código
  components/FormLogin.tsx
  components/FormLogin.test.tsx
e2e/
  login.spec.ts               # e2e separado
  checkout.spec.ts
vitest.config.ts
playwright.config.ts
```

Unit/integração **ao lado** do código (`*.test.ts`) — perto do que testa, fácil de achar. E2e em pasta própria (`e2e/`) — runner e ciclo de vida diferentes.
