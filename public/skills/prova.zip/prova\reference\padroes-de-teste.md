# Padrões de teste

Como escrever testes que provam algo e não viram peso morto.

---

## AAA — Arrange, Act, Assert

Todo teste tem três blocos, nesta ordem:

1. **Arrange** — prepara o cenário: dados de entrada, mocks, estado inicial.
2. **Act** — executa **uma** ação: chama a função, dispara o evento, faz a request.
3. **Assert** — verifica **um** comportamento esperado.

```ts
test('retorna 400 quando o email está vazio', () => {
  // Arrange
  const input = { email: '', senha: '123456' };

  // Act
  const resultado = validarCadastro(input);

  // Assert
  expect(resultado.ok).toBe(false);
  expect(resultado.erro).toBe('EMAIL_OBRIGATORIO');
});
```

Regras:

- **Um comportamento por teste.** Se precisa de "e" no nome (`testa email e senha`), são dois testes.
- **Sem lógica no teste.** Nada de `if`, `for` ou cálculo dentro do `test`. Teste com `if` esconde bug e você acaba testando o teste.
- **Nome descreve o caso, não a função.** `retorna 400 quando o email está vazio` > `testa validarCadastro`. O nome deve se ler como uma frase do contrato.
- **Falha legível.** Quando quebrar, o nome + a asserção devem dizer o que estava errado sem abrir o código.

---

## Testes bons x testes frágeis

Um teste **bom** falha quando o comportamento quebra e **só** então. Um teste **frágil** falha quando você refatora sem mudar comportamento — vira ruído e treina o time a ignorar vermelho.

| Bom (testa comportamento) | Frágil (testa implementação) |
|---|---|
| Verifica a **saída** / efeito observável | Verifica **como** o resultado foi calculado |
| `expect(total).toBe(150)` | `expect(calcularDesconto).toHaveBeenCalledTimes(2)` |
| Sobrevive a refactor que preserva comportamento | Quebra a cada renomeação de método interno |
| Usa a API pública da unidade | Espia métodos privados / estado interno |
| Asserção sobre o que o usuário/chamador vê | Asserção sobre detalhe que ninguém de fora percebe |

Sinais de teste frágil:

- Você muda o nome de uma variável interna e três testes quebram.
- O teste sabe a ordem exata em que funções internas foram chamadas.
- O teste replica o cálculo da implementação no `expect` (se a conta está errada nos dois, passa errado).
- Mais mock do que asserção real.

**Regra:** teste o **contrato**, não a fiação. Se o refactor preserva o que entra e o que sai, os testes têm que continuar verdes.

---

## O que mockar e o que não

Mock é tesoura: corta dependência real para o teste ficar rápido e determinístico. Cortar demais e você testa o vazio.

**Mocke:**

- **I/O externo** — chamadas HTTP a terceiros, APIs pagas, e-mail/SMS.
- **Não-determinismo** — relógio (`Date.now`), `Math.random`, `uuid`. Fixe para o teste ser repetível.
- **Efeitos caros ou irreversíveis** — cobrar cartão, enviar push, deletar produção.
- **O que ainda não existe** — dependência de um serviço em construção.

**Não mocke:**

- **A unidade que você está testando.** Óbvio, mas acontece.
- **Lógica pura sua** — funções de cálculo, validação, formatação. Use de verdade.
- **A linguagem / o framework** — não mocke `Array`, `JSON`, o roteador.
- **Tudo de uma vez.** Se o teste só confirma que o mock retornou o que você configurou, ele não prova nada — está testando o mock.

**Prefira o real quando der.** Banco em memória ou emulador (ex.: Firebase Emulator) > mock do SDK do Firestore. Mock do banco passa verde com query que quebraria de verdade. Quanto mais perto do real, mais a prova vale.

---

## Pirâmide de testes

Distribua o esforço. Muitos testes baratos e rápidos na base, poucos caros e lentos no topo.

```
        /\
       /e2e\        poucos  — fluxos críticos ponta a ponta (Playwright)
      /------\               lento, frágil, caro de manter
     /  integ \     alguns — unidades reais juntas: API + banco, componente + hook
    /----------\            médio
   /    unit     \  muitos — função/regra isolada, sem I/O (Vitest/Jest)
  /--------------\          rápido, estável, barato
```

- **Unit (base, maioria)** — lógica pura, regras de negócio, validações, formatação. Milissegundos. Sem rede, sem banco. É onde os casos de borda do catálogo mais rendem.
- **Integração (meio)** — peças reais conversando: route handler + Firestore (emulador), componente + hook + estado. Pega o bug que o mock esconde: contrato entre módulos.
- **E2E (topo, poucos)** — o usuário de verdade no fluxo que não pode quebrar: login, checkout, onboarding. Caro e instável; reserve para os 3–5 fluxos que dão prejuízo se caírem.

**Anti-pirâmide (evite):** muito e2e, pouco unit. Fica lento, instável e difícil de saber *onde* quebrou quando fica vermelho. Se um bug de regra de negócio só é pego no e2e, faltou um unit.

**A régua de prioridade:** cubra primeiro com unit o que tem lógica e borda; suba pra integração no que cruza fronteira (banco, API interna); reserve e2e pro caminho crítico do usuário.
