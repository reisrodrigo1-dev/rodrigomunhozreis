# Otimizações: como cortar a conta

> Cada otimização ataca um gatilho de explosão. Priorize pela linha que mais cresce na sua projeção — não otimize o que é barato. Ordem prática: **leituras de banco → tokens de IA → egress de banda → o resto.**

---

## 1. Leituras de banco (Firestore e afins) 🌡️🔥

O assassino número 1. Atacar leitura quase sempre é o corte de maior impacto.

- **Paginar.** Nunca `collection().get()` numa coleção que cresce. Use `limit()` + cursor (`startAfter`). Carregue 20 itens, não 2.000.
- **Matar o N+1.** O padrão "busca lista, depois 1 leitura por item" multiplica leituras por N. Soluções:
  - **Desnormalizar**: guarde no próprio documento o que a tela precisa (ex.: nome e avatar do autor dentro do post), evitando a segunda leitura.
  - Buscar em lote (`in` / batched gets) quando der.
- **Cachear no cliente.** Dados que mudam pouco (perfil, config, catálogo) não precisam ser relidos a cada sessão. Cache local + TTL. SDK do Firestore já tem cache offline — use-o.
- **Agregar contadores.** Para "quantos likes/comentários", **não conte lendo todos os documentos**. Mantenha um campo contador (incremento atômico) ou use aggregation queries (`count()`), que custam muito menos que ler N docs.
- **Trocar polling por evento.** Refresh a cada X segundos = leitura contínua. Prefira atualizar sob ação do usuário ou via push.
- **Cuidado com `onSnapshot` (listeners em tempo real).** Listener aberto em coleção movimentada lê continuamente. Use só onde tempo real é requisito real; feche o listener quando a tela sai de foco; restrinja com `where`/`limit`.

**Impacto típico:** paginação + fim do N+1 + cache cortam leituras em **5–20×**.

---

## 2. Tokens de IA 🌡️🔥

O custo de IA = comprimento do prompt × número de chamadas, com output 3–5× mais caro que input.

- **Modelo certo para a tarefa.** Não use o topo de linha para classificar, extrair um campo, ou rotear. Modelo pequeno/rápido faz isso por **10–50× menos**. Reserve o modelo caro para raciocínio de verdade. (Cascata: modelo pequeno primeiro, escala para o grande só se necessário.)
- **Prompt curto.** Corte instrução repetida, exemplos desnecessários, contexto que o modelo não usa. Cada token de input é pago em **toda** chamada.
- **Prompt caching.** Se você reenvia o mesmo bloco grande (system prompt, documentos, few-shot) em muitas chamadas, o cache de prompt dá **desconto grande** na parte repetida. Estruture o prompt com o conteúdo estável no começo (parte cacheável) e o variável no fim.
- **Truncar histórico.** Em chat, não reenvie a conversa inteira a cada turno — o input cresce de forma quase quadrática. Use janela deslizante, ou **resuma** o histórico antigo em poucos tokens.
- **Limitar a saída.** Defina `max_tokens` realista. Output é o lado caro; pedir "explique em detalhe" em escala sangra.
- **RAG enxuto.** Recupere menos chunks e mais relevantes; chunks menores; não injete documento inteiro quando um trecho resolve.
- **Batch e dedupe.** Agrupe tarefas; não chame o modelo duas vezes para a mesma entrada; cacheie respostas de entradas repetidas.
- **Cuidado com loops de agente/retry.** Limite tentativas; um agente mal-amarrado pode chamar o modelo dezenas de vezes por tarefa.

**Impacto típico:** modelo certo + prompt curto + caching + truncar histórico cortam a conta de IA em **5–15×**.

---

## 3. Egress de banda (Storage, CDN, Vercel) 🌡️🔥

Armazenar é barato; **servir** é caro. Egress é quase sempre subestimado.

- **CDN + cache na frente de tudo.** Sirva mídia e assets por CDN com cache agressivo (TTL longo, headers corretos). Asset cacheado na borda não conta egress de origem a cada hit.
- **Otimizar imagem.** Formatos modernos (**WebP/AVIF**), redimensionar para o tamanho real exibido, qualidade adequada. Uma imagem de 1,5 MB vira ~150 KB sem perda visível → **10× menos egress**.
- **Escolher o provedor pela política de egress.** Em projeto com muito download, prefira storage com **egress grátis** (ex.: Cloudflare R2) em vez de cobrança por GB. Isso muda a conta em **ordem de grandeza**.
- **Lazy-load e responsive images.** Não baixe o que não está na tela; sirva o tamanho certo por dispositivo.
- **Comprimir respostas** (gzip/brotli) para JSON/HTML/JS.
- **Vídeo:** streaming adaptativo e player com cache, nunca servir o arquivo bruto direto do bucket.

**Impacto típico:** CDN + WebP/AVIF + provedor com egress grátis cortam egress em **10× ou mais**.

---

## 4. Compute / funções (Vercel, Cloud Functions)

- **Cache de resposta** (CDN, ISR estático) para conteúdo que não muda por requisição — evita rodar a função.
- **Edge/estático** onde der; reserve SSR caro para o que realmente precisa.
- **Cortar polling e crons agressivos.** Cron de 1 em 1 minuto = ~43k invocações/mês por instância. Reduza a frequência ao necessário.
- **Funções rápidas.** Tempo de execução é cobrado (GB-s). Otimize chamadas externas e evite trabalho desnecessário.

---

## 5. Storage que só cresce

- **Lifecycle/expiração.** Defina regras para expirar logs, temporários, versões antigas, uploads abandonados.
- **Comprimir** antes de guardar; **deduplicar** arquivos idênticos.
- **Tiering** para classes de armazenamento mais baratas (arquivamento) o que é raramente acessado.

---

## 6. E-mail e SMS

- **Digest em vez de e-mail por evento.** Em vez de um e-mail por notificação, agregue num resumo. Corta volume em fan-out.
- **Preferir push/in-app** a SMS sempre que possível — SMS é o canal mais caro e variável por país.
- **Proteger fluxos de SMS** contra abuso/bot (rate limit, captcha) — abuso de SMS vira fatura inesperada.

---

## Checklist de corte (em ordem de impacto)

1. 🌡️🔥 Paginar listas e matar N+1 de leitura.
2. 🌡️🔥 Cachear leituras estáveis; agregar contadores; revisar listeners em tempo real.
3. 🌡️🔥 Usar o modelo de IA certo por tarefa; encurtar prompt; ativar prompt caching; truncar histórico; limitar output.
4. 🌡️🔥 CDN + cache + WebP/AVIF; escolher storage com egress barato/grátis.
5. 🌡️ Cache de resposta / edge; reduzir crons e polling.
6. 🌡️ Lifecycle de storage; comprimir; deduplicar.
7. 🌡️ Digest de e-mail; evitar SMS; proteger fluxos.

> Otimize pela linha que mais cresce na **sua** projeção, não pela que é mais fácil de mexer. E lembre: cortar custo cedo é barato; cortar depois que explodiu é refatoração. A decisão é sua.
