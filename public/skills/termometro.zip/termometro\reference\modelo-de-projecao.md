# Modelo de projeção: do uso ao custo

> Como sair de "não sei quanto custa" para "custa entre X e Y por faixa, e o item Z é quem explode". Números **ilustrativos**.

## A fórmula base

Todo custo de uso segue a mesma forma:

```
unidades_totais = uso_por_usuario_por_sessao × sessoes_por_usuario_por_mes × usuarios

custo = max(0, unidades_totais − free_tier) × preco_por_unidade
```

Três entradas que você precisa estimar para cada serviço:
1. **uso por usuário por sessão** (ex.: 80 leituras de Firestore por sessão).
2. **sessões por usuário por mês** (ex.: 8 sessões).
3. **usuários** — projete em **faixas: 1k / 10k / 100k**.

Sempre projete dois cenários:
- **Esperado** — usuário médio.
- **Ruim** — usuário pesado, polling, retry, loop. É o cenário ruim que revela a explosão.

---

## Passo a passo

### 1. Quebre cada feature em unidades

Para cada tela/ação, conte as unidades que ela consome:

- Tela de feed: lê 30 posts + 30 autores (N+1) = **60 leituras** por abertura.
- Enviar mensagem no chat com IA: prompt de 2.000 tokens in + 500 tokens out.
- Abrir página com 5 imagens de 300 KB = **1,5 MB de egress** por abertura.

### 2. Multiplique por sessão e por usuário

uso por sessão × sessões/mês × usuários = unidades/mês.

### 3. Subtraia o free tier e aplique o preço

Cuidado: free tiers de Firestore costumam ser **por dia**, não por mês. Converta antes (free tier mensal ≈ free diário × 30).

### 4. Monte a tabela por faixa

Uma linha por serviço, três colunas de faixa, e o total. O total não importa tanto quanto **qual linha cresce mais rápido** — essa é a que vai explodir.

---

## Exemplo numérico 1 — App social com Firestore

**Premissas (cenário esperado):**
- Cada sessão abre o feed e lê 30 posts + 30 autores = **60 leituras**.
- Mais 20 leituras de navegação = **80 leituras/sessão**.
- **8 sessões/usuário/mês**.
- Leituras por usuário/mês = 80 × 8 = **640 leituras**.

| Faixa        | Leituras/mês | Acima do free (~1,5M/mês) | Custo (~$0,04/100k) |
|--------------|--------------|----------------------------|----------------------|
| 1k usuários  | 640.000      | 0 (dentro do free)         | **grátis**           |
| 10k usuários | 6.400.000    | ~4,9M                       | **~$2/mês**          |
| 100k usuários| 64.000.000   | ~62,5M                      | **~$25/mês**         |

Parece tranquilo. Agora o **cenário ruim**: a tela tem um `onSnapshot` (listener em tempo real) num feed movimentado que recarrega 60 docs a cada atualização, e o usuário deixa o app aberto. Suponha 10 recarregamentos por sessão:

- 60 × 10 = **600 leituras só do listener** + 200 de navegação = **800/sessão**, 10× mais.

| Faixa        | Leituras/mês (ruim) | Custo (~$0,04/100k) |
|--------------|----------------------|----------------------|
| 100k usuários| ~640.000.000         | **~$256/mês**        |

🌡️🔥 **Mesmo app, mesma feature, 10× na conta — só pela forma de ler.** É aqui que o Termômetro ganha o dinheiro dele: o gatilho é o **N+1 + listener**, não o número de usuários.

---

## Exemplo numérico 2 — Chat com IA

**Premissas:**
- Conversa média: 6 turnos.
- A cada turno reenvia o histórico acumulado (sem truncar). Input médio cresce: ~1k, 2k, 3k, 4k, 5k, 6k tokens → **soma ~21k tokens de input** por conversa.
- Output ~500 tokens/turno × 6 = **3k tokens de output** por conversa.
- **3 conversas/usuário/mês**.

Por usuário/mês: input ~63k tokens, output ~9k tokens.

**Com modelo topo de linha** (~$3/1M in, ~$15/1M out):

| Faixa        | Input ($3/1M)   | Output ($15/1M) | Total IA/mês |
|--------------|------------------|------------------|--------------|
| 1k usuários  | 63M tok → ~$0,19 | 9M tok → ~$0,14  | **~$0,33**   |
| 10k usuários | 630M → ~$1,9     | 90M → ~$1,35     | **~$3,2**    |
| 100k usuários| 6,3B → ~$19      | 900M → ~$13,5    | **~$32**     |

**Com modelo pequeno** (~$0,25/1M in, ~$1,25/1M out), para a parte da tarefa que não exige raciocínio:

| Faixa        | Total IA/mês |
|--------------|--------------|
| 100k usuários| **~$2,8**    |

🌡️🔥 **Trocar o modelo na tarefa certa cortou ~10× a conta de IA.** E o gatilho escondido é o **histórico não truncado**: o input cresce a cada turno (custo quase quadrático na conversa). Truncar/cachear o histórico reduz a coluna de input drasticamente.

---

## Exemplo numérico 3 — Egress de mídia (Storage/CDN)

**Premissas:**
- Página inicial carrega 1,5 MB de imagens.
- 12 páginas vistas/usuário/mês.
- Egress/usuário/mês = 1,5 MB × 12 = **18 MB**.

| Faixa        | Egress/mês | S3 (~$0,09/GB) | R2/Cloudflare (egress $0) |
|--------------|------------|-----------------|----------------------------|
| 1k usuários  | 18 GB      | ~$1,6           | **$0**                     |
| 10k usuários | 180 GB     | ~$16            | **$0**                     |
| 100k usuários| 1.800 GB   | ~$162           | **$0**                     |

🌡️🔥 Sem CDN/cache e com imagens não otimizadas, multiplique por 3–5×. **Escolha do provedor de storage e otimização de imagem mudam a conta em ordem de grandeza.**

---

## Montando a saída final

Junte os serviços numa tabela única:

| Serviço            | 1k     | 10k    | 100k   |
|--------------------|--------|--------|--------|
| Firestore (reads)  | grátis | ~$2    | ~$25   |
| IA (tokens)        | ~$0,33 | ~$3,2  | ~$32   |
| Egress (S3)        | ~$1,6  | ~$16   | ~$162  |
| **Total esperado** | **~$2**| **~$21** | **~$219** |

E o **cenário ruim** ao lado (listener + histórico longo + sem CDN) pode levar o total de 100k de ~$219 para **mais de $1.000/mês**. A diferença entre os dois cenários **é exatamente a sua lista de otimizações prioritárias**.

> Lembre: o objetivo não é acertar o centavo. É saber **a forma da curva** e **qual linha dispara primeiro** — para você decidir o que cortar antes de escalar. A decisão é sua.
