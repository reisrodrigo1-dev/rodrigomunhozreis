---
name: termometro
description: Estima o custo de infraestrutura e IA de um projeto por faixa de uso e sinaliza onde a conta explode antes de escalar. Use ao planejar custos, antes de escalar, ao avaliar se um projeto é sustentável, ou quando alguém pergunta "quanto isso vai custar com X usuários".
---

# Termômetro

Estimador de custos para projetos modernos: mostra **onde a conta esquenta e onde ela explode** antes de você escalar.

> Princípio: **saiba onde a conta explode antes de escalar — não terceirize o custo às cegas.**
> Quase tudo começa de graça. A conta cresce com o uso, e quase sempre cresce de forma não-linear: um número que parece inofensivo na faixa de teste vira o item dominante da fatura em produção. A decisão é sua — mas decida com o número na frente.

## Visão geral

A maioria dos serviços de stack moderno (Firebase, Vercel, APIs de IA, storage/CDN, e-mail) tem um free tier generoso e cobra por **unidade de uso**: leitura, escrita, GB armazenado, GB trafegado, token, invocação, e-mail enviado. O custo total não é "o plano" — é **uso por usuário × número de usuários × frequência**.

O Termômetro faz três coisas:

1. **Mapeia** quais serviços o projeto usa e qual a unidade de cobrança de cada um.
2. **Projeta** o custo em faixas (1k / 10k / 100k usuários ou requisições), não em um número único.
3. **Sinaliza os gatilhos de explosão** — os pontos onde a conta deixa de ser linear e dispara — e sugere otimizações.

A saída nunca é "vai custar X". É **uma faixa por cenário + os alertas de onde mora o risco**.

## Quando usar

- Planejando o custo de um projeto novo antes de construir.
- Antes de escalar (saiu de 1k para 10k usuários, ou vai rodar uma campanha).
- Avaliando se um projeto é **sustentável** no preço atual (o unit economics fecha?).
- Quando alguém pergunta "quanto isso custa com 100k usuários?".
- Ao escolher entre serviços/modelos de IA pelo custo.
- Quando uma fatura veio maior que o esperado e você quer achar o item que explodiu.

## Procedimento

### 1. Identificar os serviços usados

Liste cada serviço do projeto e a **unidade de cobrança** de cada um. Use `reference/precos-servicos.md` para os perfis de preço, free tiers e o gatilho de explosão de cada serviço.

Categorias comuns:
- **Banco / Firestore** — cobra por leitura, escrita, delete e GB armazenado. (Atenção: leitura é a unidade traiçoeira.)
- **Compute / Vercel / Functions** — cobra por invocação, tempo de execução (GB-s) e **bandwidth (egress)**.
- **APIs de IA (Claude / GPT / Gemini)** — cobram por **token** de entrada e de saída, com preços diferentes por modelo.
- **Storage / CDN** — cobra por GB armazenado e, principalmente, por GB **trafegado** (egress).
- **E-mail transacional** — cobra por e-mail enviado (após o free tier).
- **Auth** — geralmente barato/grátis, mas atenção a SMS/MFA e MAUs em alguns provedores.

Para cada serviço anote: unidade de cobrança, free tier, preço por unidade acima do free tier.

### 2. Estimar uso por faixa

Para cada serviço, estime **uso por usuário por sessão** e multiplique pelas faixas. Use `reference/modelo-de-projecao.md` para as fórmulas e exemplos numéricos.

Modelo base:

```
custo_do_servico = (uso_por_usuario_por_sessao × sessoes_por_usuario × usuarios) − free_tier
                   ----------------------------------------------------------------------------
                                       × preço_por_unidade
```

Projete sempre em três faixas. Exemplo de tabela de saída:

| Serviço            | 1k usuários | 10k usuários | 100k usuários |
|--------------------|-------------|--------------|---------------|
| Firestore (reads)  | grátis      | $X           | $XX           |
| Vercel (bandwidth) | grátis      | $X           | $XX           |
| IA (tokens)        | $X          | $XX          | $XXX          |
| **Total estimado** | **$X**      | **$XX**      | **$XXX**      |

Sempre projete um **cenário esperado** e um **cenário ruim** (usuário pesado, retry, loop). O cenário ruim é onde a explosão aparece.

### 3. Sinalizar os gatilhos de explosão

Marque com termômetro os pontos de risco. Os clássicos:

- 🌡️🔥 **Leituras no Firestore** — listar uma coleção sem paginar, N+1 de leitura, polling/refresh agressivo, listeners em tempo real abertos. 1 tela que lê 100 docs × 100k usuários × 5 sessões = 50M leituras. Esse é o assassino silencioso número 1.
- 🌡️🔥 **Tokens de IA** — prompts longos, contexto inteiro reenviado a cada turno, saída longa, modelo caro para tarefa simples, retry em loop. O custo de IA cresce com o **comprimento do prompt × número de chamadas**, e o output costuma ser 3–5× mais caro que o input.
- 🌡️🔥 **Egress / bandwidth** — servir imagens, vídeo ou assets pesados direto, sem CDN/cache, em alto volume. Egress é caro e quase sempre subestimado.
- 🌡️ **Storage que só cresce** — uploads de usuário, logs, backups que nunca expiram.
- 🌡️ **Invocações de função** — funções chamadas em loop ou por cron muito frequente.

Para cada gatilho ativo, diga **em qual faixa ele começa a doer** (ex.: "ok até 10k, dói em 100k").

### 4. Sugerir otimizações e alternativas

Para cada gatilho sinalizado, proponha o corte. Use `reference/otimizacoes.md`. Resumo:

- **Leituras:** cache, paginação, evitar N+1, desnormalizar/agregar contadores, trocar polling por evento.
- **IA:** modelo certo para a tarefa (não use o topo de linha para classificar), prompt curto, cache de contexto, truncar histórico, batch.
- **Egress:** CDN + cache, comprimir, formatos modernos (WebP/AVIF), lazy-load.
- **Storage:** lifecycle/expiração, comprimir, deduplicar.
- Quando fizer sentido, aponte **alternativa mais barata** (ex.: outro modelo, outro provedor de storage, mover trabalho do servidor para o cliente/edge).

## Saída

Entregue sempre:

1. **Tabela de estimativa por faixa** (1k / 10k / 100k), por serviço e total.
2. **Alertas de explosão** — os 1–3 gatilhos que dominam a conta, com a faixa em que começam a doer.
3. **Cortes recomendados** — o que fazer primeiro para maior impacto.
4. Uma linha de **veredito**: o projeto é sustentável no preço atual? A decisão é sua.

> Lembre o usuário: números aqui são **ilustrativos** para decisão. Preços de serviços mudam — confirme na página oficial antes de fechar contrato. O valor do Termômetro está em mostrar **a forma da curva e onde ela vira**, não em precisão de centavos.
