# Perfil de preço e free tier dos serviços comuns

> Números **ilustrativos** para decisão (referência ~2025/2026, USD). Servem para mostrar a **forma da curva** e **onde a conta explode** — não para precisão de fatura. Confirme sempre na página oficial antes de fechar contrato. A decisão é sua.

Para cada serviço: **unidade de cobrança**, **free tier**, **preço acima do free tier** e **onde explode**.

---

## Firebase Firestore

Unidade de cobrança: **documento lido, escrito, deletado** + **GB armazenado** + egress.

| Item                | Free tier (por dia / mês) | Preço acima do free tier (ilustrativo) |
|---------------------|----------------------------|----------------------------------------|
| Leituras (reads)    | ~50.000/dia                | ~$0,03–0,06 / 100k leituras            |
| Escritas (writes)   | ~20.000/dia                | ~$0,09–0,18 / 100k escritas            |
| Deletes             | ~20.000/dia                | ~$0,01–0,02 / 100k deletes             |
| Storage             | ~1 GB                      | ~$0,15–0,18 / GB/mês                   |
| Egress de rede      | pequeno                    | cobrado por GB trafegado               |

**Como ler os números:** leitura é barata por unidade, mas você consome leitura **por documento**, não por query. Uma tela que mostra 50 itens custa 50 leituras. Multiplicado por usuários e sessões, vira dezenas de milhões.

**Onde explode 🌡️🔥:**
- **Leituras.** É o item mais perigoso do Firestore. `collection().get()` sem paginar, N+1 (busca lista e depois 1 doc por item), polling/refresh, e **listeners em tempo real** (`onSnapshot`) que recarregam tudo a cada mudança. Listener aberto em coleção movimentada = leituras contínuas mesmo sem o usuário fazer nada.
- **Escritas em fan-out** (1 ação grava em N lugares, ex.: feed que escreve no timeline de cada seguidor).
- Conta de leitura cresce com **telas × itens por tela × sessões × usuários**. Esse produto explode rápido.

**Corte rápido:** paginar, cachear, agregar contadores em vez de contar lendo, trocar listener por leitura sob demanda. (Ver `otimizacoes.md`.)

---

## Firebase Authentication

Unidade de cobrança: geralmente **grátis** para e-mail/senha e provedores sociais (OAuth). Cobrança aparece em **SMS/telefone** e, no tier Identity Platform, em **MAU** acima de um limite alto.

| Item                          | Free tier         | Acima |
|-------------------------------|-------------------|-------|
| Login e-mail/senha, OAuth     | ilimitado/grátis  | grátis |
| MFA por SMS / verificação SMS | muito baixo       | **por SMS, caro** (centavos a dezenas de centavos por mensagem, varia por país) |
| MAU (Identity Platform)       | dezenas de milhares grátis | por MAU acima |

**Onde explode 🌡️:** **SMS**. Verificação por SMS e MFA por SMS custam por mensagem e variam muito por país — abuso/bots em fluxo de SMS vira fatura inesperada rápido. Auth em si raramente é o problema de custo.

---

## Firebase Storage / Cloud Storage

Unidade de cobrança: **GB armazenado** + **GB de download (egress)** + operações.

| Item               | Free tier (ilustrativo) | Acima |
|--------------------|--------------------------|-------|
| Storage            | ~5 GB                    | ~$0,026 / GB/mês |
| Download (egress)  | ~1 GB/dia                | ~$0,12 / GB (varia por região/destino) |
| Operações          | cota diária              | por 10k operações |

**Onde explode 🌡️🔥:** **egress (download)**. Armazenar é barato; **servir** é caro. Servir imagens/vídeo direto do storage, sem CDN/cache, em volume, é onde a conta dispara. Storage que **só cresce** (uploads de usuário sem expiração) também sangra ao longo do tempo.

---

## Vercel

Unidade de cobrança: **bandwidth (egress)** + **compute** (invocações / GB-horas de função) + builds.

| Item                        | Free / incluído (Hobby/Pro, ilustrativo) | Acima |
|-----------------------------|-------------------------------------------|-------|
| Bandwidth                   | ~100 GB (Hobby) / ~1 TB (Pro)             | ~$0,15 / GB extra (varia) |
| Invocações de função        | cota generosa                             | por milhão de invocações |
| Tempo de função (GB-horas)  | cota incluída                             | por GB-hora |
| Build minutes               | cota incluída                             | por minuto extra |

**Onde explode 🌡️🔥:**
- **Bandwidth**: servir assets pesados, imagens não otimizadas, vídeo, ou tráfego alto sem cache de CDN.
- **Compute de função**: SSR caro, funções lentas, ou funções chamadas em loop/polling. Edge/cache reduz drasticamente.
- Cron jobs frequentes e revalidação agressiva (ISR) multiplicam invocações.

**Corte rápido:** otimização de imagem, cache/CDN agressivo, mover lógica para edge/static, reduzir SSR onde der.

---

## APIs de IA (Claude / GPT / Gemini)

Unidade de cobrança: **token** — separado por **input** (prompt) e **output** (resposta). Output costuma ser **3–5× mais caro** que input. Preço varia muito por **modelo** (topo de linha vs. modelo pequeno/rápido).

Ordens de grandeza **ilustrativas** (USD por **1 milhão de tokens**; sempre confira a tabela oficial do provedor):

| Faixa de modelo                 | Input (por 1M tokens) | Output (por 1M tokens) |
|---------------------------------|------------------------|-------------------------|
| **Topo de linha** (raciocínio)  | ~$3–15                 | ~$15–75                 |
| **Intermediário** (equilíbrio)  | ~$1–5                  | ~$5–15                  |
| **Pequeno/rápido** (classificar, extrair) | ~$0,10–0,50  | ~$0,30–1,50             |

Regra de bolso: **1 token ≈ 0,75 palavra** (~4 caracteres em inglês; em PT-BR conte um pouco mais de tokens por palavra). 1.000 tokens ≈ 750 palavras ≈ ~1,5 página.

**Onde explode 🌡️🔥:**
- **Comprimento do prompt × número de chamadas.** Reenviar todo o histórico/contexto a cada turno de chat faz o input crescer a cada mensagem (custo quadrático numa conversa longa).
- **Output longo** (3–5× o preço do input). Pedir "explique em detalhe" em escala custa caro.
- **Modelo caro para tarefa simples.** Usar topo de linha para classificar sentimento ou extrair um campo é desperdício de 10–50×.
- **Retry em loop / agentes** que chamam o modelo muitas vezes por tarefa.
- **RAG com chunks grandes** injetando muito contexto por chamada.

**Corte rápido:** modelo certo por tarefa, prompt curto, **prompt caching** (desconto grande em contexto repetido), truncar histórico, limitar `max_tokens` de saída, batch. (Ver `otimizacoes.md`.)

---

## Storage / CDN dedicado (S3, R2, Cloudflare, Bunny, etc.)

Unidade de cobrança: **GB armazenado** + **GB de egress** + operações/requests.

| Item              | Perfil de preço (ilustrativo) |
|-------------------|-------------------------------|
| Storage           | ~$0,015–0,025 / GB/mês        |
| Egress            | de **$0 (R2/Cloudflare)** a ~$0,05–0,12 / GB (S3) |
| Requests          | por 10k–1M operações          |

**Onde explode 🌡️🔥:** **egress**, de novo. A maior diferença entre provedores de storage é a política de egress: alguns (ex.: Cloudflare R2) têm **egress grátis**, outros cobram caro por GB. Em projeto com muito download, **a escolha do provedor de storage muda a conta em ordem de grandeza**.

---

## E-mail transacional (Resend, SendGrid, SES, Postmark)

Unidade de cobrança: **e-mail enviado**.

| Provedor (perfil)     | Free tier (ilustrativo)        | Acima |
|-----------------------|---------------------------------|-------|
| SES (AWS)             | barato, ~$0,10 / 1.000 e-mails  | por mil e-mails |
| Resend / SendGrid     | ~3.000/mês grátis (varia)       | por mil e-mails / plano por volume |
| Postmark              | free tier menor, foco em entrega | por mil e-mails |

**Onde explode 🌡️:** **volume transacional** (notificações, digests, "alguém comentou") e, principalmente, **e-mail por evento em fan-out** (notificar todos os seguidores). E-mail por usuário ativo × frequência cresce rápido, mas em geral é dos itens mais previsíveis e baratos da stack.

---

## Resumo: onde cada serviço explode

| Serviço            | Unidade        | Explode em 🌡️🔥                          |
|--------------------|----------------|------------------------------------------|
| Firestore          | leitura/escrita| **leituras** (listas, N+1, listeners)    |
| Auth               | login/SMS      | **SMS/MFA**                              |
| Cloud Storage      | GB + egress    | **egress** (servir mídia sem CDN)        |
| Vercel             | bandwidth+compute | **bandwidth** e **SSR/loops**         |
| APIs de IA         | token          | **prompt longo × nº de chamadas, output**|
| Storage/CDN        | GB + egress    | **egress** (escolha do provedor importa) |
| E-mail             | e-mail enviado | **fan-out / volume**                     |

A maioria das explosões mora em **três lugares: leituras de banco, tokens de IA e egress de banda.** Comece olhando por eles.
