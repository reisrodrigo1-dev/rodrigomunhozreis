# Persona / ICP — [nome do retrato]

> Preencha com evidência. Onde for chute, escreva **[hipótese]** na frente — pra você lembrar que ainda falta validar. Persona boa não é a mais detalhada; é a mais ancorada na realidade.

---

## Identificação

- **Nome / apelido do retrato:** (ex.: "Marina, founder solo")
- **Uma linha:** (ex.: fundadora de SaaS B2B no 2º ano, sem time de marketing, faz tudo)
- **É ICP, persona, ou os dois?** (veja `reference/icp-vs-persona.md`)
- **Baseado em quem:** (clientes/conversas reais que sustentam este retrato — liste)

## Contexto — quem é e onde está

- **Cargo / papel:**
- **Tipo e tamanho de empresa:**
- **Momento atual:** (começando / escalando / em crise / outro)
- **Rotina e pressões:** (como é o dia, o que mais consome tempo)
- **Nível de maturidade no tema:** (leigo / sabe o básico / avançado)

## Dor — o que incomoda de verdade

- **Dor principal (com as palavras dela):**
- **Situação concreta em que a dor aparece:**
- **Custo de não resolver:** (tempo / dinheiro / estresse / status)
- **O que já tentou e por que não resolveu:**

## Objetivo — o trabalho a ser feito

- **O que ela quer alcançar (acima do produto):**
- **Como seria o "deu certo" pra ela:**

## Gatilho de compra

- **O evento que dispara a busca:** (a "gota d'água")
- **Quando isso aperta mais:** (época / fase)

## Objeções — o que trava a compra

| Objeção (o que ela pensa) | Resposta honesta sua |
|---|---|
| (ex.: "será que funciona pro meu caso?") | (a prova/argumento que desarma) |
| | |
| | |

## Quem decide

- **Quem usa:**
- **Quem paga:**
- **Quem aprova / pode vetar:**
- **O que o aprovador precisa ver:**

## Onde encontrá-lo — canal

- **Onde busca ativamente quando tem o problema:** (Google, comunidade, indicação)
- **Onde só navega / passa o tempo:** (feed, plataforma)
- **Em quem confia:** (perfis, veículos, comunidades — nomes concretos)
- **Canal 1 e 2 pra testar primeiro:**

> Daqui pra frente é trabalho da **Alavanca**: transformar este canal em funil (isca → e-mail → nutrição), campanha, copy e métricas.

## A frase que ela diria

> Escreva uma frase que esta pessoa falaria sobre o problema dela, em voz alta, do jeito dela. Se não soar como gente real, você ainda está inventando — volte pras conversas.

"____________________________________________"

---

## Anti-cliente (pra quem você NÃO fala)

- **Perfil que dá trabalho / paga pouco / não fica:**
- **Por que excluir:**
