# ICP vs. Persona — a diferença prática

Os dois termos vivem misturados, e essa confusão faz gente desenhar a coisa errada na hora errada. Eles não competem; resolvem problemas diferentes.

## O que é cada um

### ICP — Ideal Customer Profile (perfil do cliente ideal)

É a **descrição do tipo de cliente** que mais se beneficia do que você faz e que dá o melhor resultado pro negócio (paga bem, fica, indica, dá pouco trabalho). É um filtro, não uma pessoa.

O ICP responde: *que tipo de cliente eu quero atrair e atender?*

Pensa em categorias e critérios:

- Setor / segmento (ex.: SaaS B2B, e-commerce de moda, clínica odontológica)
- Tamanho (faturamento, número de funcionários, número de clientes)
- Momento (começando, escalando, em reestruturação)
- Cargo de quem compra / quem usa
- Problema que o produto resolve melhor pra esse perfil
- Critérios de exclusão (quem NÃO é cliente ideal)

O ICP é especialmente útil em **B2B** e sempre que a venda envolve qualificar lead, definir mercado-alvo, escolher em que nicho atacar.

### Persona — o personagem que humaniza o ICP

É um **personagem semi-fictício, mas baseado em gente real**, que dá rosto, voz e rotina ao ICP. Ela transforma critérios frios ("SaaS B2B, 5-20 funcionários") numa pessoa que você consegue imaginar falando.

A persona responde: *como essa pessoa pensa, sente e fala — pra eu escrever e desenhar pra ela?*

Pensa em:

- Nome e um retrato curto ("Marina, 34, fundadora de uma fintech no segundo ano")
- Dia a dia, pressões, o que tira o sono
- Como ela fala sobre o problema (frases reais)
- Onde ela busca informação e em quem confia
- Objeções e medos na hora de comprar

A persona é especialmente útil pra **copy, design, conteúdo e onboarding** — qualquer trabalho que precise de empatia e linguagem.

## Resumo da diferença

| | ICP | Persona |
|---|---|---|
| O que é | Perfil/tipo de cliente | Personagem que humaniza |
| Nível | Empresa/segmento (ou perfil) | Pessoa |
| Pergunta | Quem eu quero atrair? | Como ela pensa e fala? |
| Linguagem | Critérios, filtros | Narrativa, frases reais |
| Mais útil pra | Definir mercado, qualificar lead, mirar canal | Escrever copy, desenhar produto, criar conteúdo |

## Quando cada um ajuda

- **Só ICP basta** quando você está decidindo *mercado e qualificação*: em que nicho atacar, quem é lead bom, onde anunciar. Comum no começo do B2B.
- **Persona ajuda** assim que você vai *comunicar*: escrever a landing, gravar o anúncio, montar o onboarding. Aí você precisa de uma voz, não de uma planilha.
- **Os dois juntos** é o ideal num produto que já roda: o ICP filtra quem você persegue, a persona te diz como falar com ele. Um não substitui o outro — a persona é o ICP com rosto.

Regra prática: comece pelo ICP (mais fácil de tirar dos dados), e só vire persona quando for produzir algo que uma pessoa vai ler ou usar.

## Por que NÃO inventar

A maior armadilha é criar persona "de imaginação": sentar numa sala, chutar um nome, dar um cachorro pra ela e um hobby de fim de semana. Isso parece produtivo e é quase sempre lixo, por três motivos.

1. **Você decide com base em ficção.** Toda escolha de produto, preço e copy que sai de uma persona inventada herda o chute. Erro na base, erro em tudo que vem depois.
2. **Você projeta a si mesmo.** Persona chutada quase sempre vira um espelho do criador — os medos e gostos *dele*, não do cliente. Você acaba vendendo pra você mesmo.
3. **Detalhe fofo não é detalhe útil.** O nome do cachorro não muda nenhuma decisão. A frase exata que o cliente usa pra descrever a dor muda a headline inteira. Persona inventada é rica em detalhe inútil e pobre em detalhe acionável.

O antídoto é simples e está no procedimento da skill: **parta de quem já compra ou se beneficia, e converse com gente real.** Cada campo da persona deveria ter atrás dele uma evidência — um cliente, uma conversa, um print, uma reclamação. Se um campo só tem chute, marque como hipótese a validar, não como verdade.

> Persona boa não é a mais detalhada. É a mais ancorada em realidade.
