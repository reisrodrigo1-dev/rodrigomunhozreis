---
name: espelho
description: define a persona e o cliente ideal (ICP) — dor, contexto, objeções e onde encontrá-lo; use ao definir público-alvo, criar persona, ou afinar pra quem o produto/copy fala
---

# Espelho

> Pra quem você fala e vende. Antes de escolher canal, escrever copy ou cortar feature, você precisa saber pra quem.

Espelho serve pra você enxergar com clareza o seu cliente ideal — não um avatar inventado em workshop, mas a pessoa real que já tira a carteira do bolso ou que mais se beneficia do que você faz.

## Visão geral

Falar com "todo mundo" é falar com ninguém. Quando você tenta agradar qualquer um, a mensagem fica genérica, o produto fica inchado e o anúncio não para o dedo de ninguém. O contrário também é verdade: quando você sabe exatamente pra quem fala, três coisas afinam de uma vez.

- **Produto afina.** Você corta o que o cliente ideal não usa e dobra no que ele precisa.
- **Copy afina.** Você fala a dor dele com as palavras dele — e ele sente que você leu a mente.
- **Canal afina.** Você para de queimar verba onde ele não está e investe onde ele já passa o dia.

O ICP (Ideal Customer Profile) não é uma camisa de força. É uma lente. Você ainda vai vender pra quem chegar — mas você vai *construir e comunicar* mirando uma pessoa específica. Mirar em uma pessoa específica é o que faz milhares se reconhecerem.

A regra de ouro do Espelho: **não invente.** Persona chutada vira ficção que você usa pra justificar decisões ruins. Espelho parte de evidência — de quem já compra, já usa, já elogia, já reclama.

## Lugar na suíte Engenho

- **Decolagem** decide o modelo de negócio, preço e go-to-market. Espelho responde *pra quem* esse negócio existe.
- **Espelho** (aqui) define o cliente ideal: dor, contexto, objeções e onde encontrá-lo.
- **Alavanca** pega esse cliente e monta o funil — canal, campanha, copy, métricas. Quando chegar em "onde encontrá-lo", a ponte é com a Alavanca.
- **Espião** olha pra fora: o que os concorrentes prometem pra esse mesmo cliente e onde há brecha.

Ordem natural: Decolagem → **Espelho** → Alavanca. Espião alimenta os três.

## Quando usar

- Você vai escrever copy (landing, anúncio, e-mail) e não sabe que tom usar nem que dor atacar.
- Você está decidindo features e tudo parece igualmente importante (sinal de que não há um cliente no centro).
- Seu anúncio tem clique mas não converte — talvez você esteja falando com a pessoa errada.
- Você vai escolher canal e está chutando entre Instagram, LinkedIn, Google.
- Alguém pergunta "qual é o seu público?" e você responde "ah, qualquer empreendedor" — isso é um alerta.
- Você tem clientes, mas não sabe dizer o que os melhores têm em comum.

## Procedimento

Siga na ordem. Cada passo alimenta o próximo. Use os arquivos de apoio onde indicado.

### 1. Parta de quem JÁ compra ou se beneficia (não invente)

Antes de imaginar, olhe os dados que você já tem.

- Se você já vende: liste seus clientes e marque os **melhores** — os que pagam sem reclamar, usam mais, indicam, renovam. O que eles têm em comum? Setor, tamanho, cargo, momento, problema?
- Se ainda não vende: olhe quem te procura, quem curte/comenta, quem pediu pra entrar na lista de espera, quem você atende informalmente. Conversas reais valem mais que suposição.
- Identifique o **anti-cliente**: quem dá trabalho, paga pouco, reclama, churna. Saber pra quem você NÃO fala afina tanto quanto saber pra quem fala.

> Se você não tem nenhum cliente nem conversa real ainda, não pule pra ficção. Vá conversar com 5 a 10 pessoas do perfil que você imagina. Espelho funciona com evidência; sem evidência, o passo é coletar evidência.

Veja `reference/icp-vs-persona.md` pra decidir se você precisa de um ICP, de uma persona, ou dos dois — e por que inventar é perigoso.

### 2. Mapeie a dor real e o "trabalho a ser feito"

As pessoas não compram um produto; elas "contratam" o produto pra resolver um problema ou progredir numa situação (o *job to be done*).

- Qual é a **dor concreta** que faz a pessoa procurar uma solução? Não a dor genérica ("quero crescer"), mas a situação específica ("perco 3 horas por semana montando relatório na mão").
- Qual é o **trabalho a ser feito**? O que a pessoa está tentando fazer progredir na vida ou no negócio dela quando te contrata?
- Qual é o **custo de não resolver**? Dinheiro, tempo, estresse, status. A intensidade da dor é o que abre a carteira.

Use as perguntas de `reference/mapa-do-cliente.md`, seção Dor e Objetivo. Escreva a dor com as palavras que o cliente usa — não com as suas.

### 3. Levante o contexto (quem é, onde está, como decide)

A mesma dor muda completamente dependendo de quem a sente.

- **Quem é**: cargo, tipo de empresa, tamanho, momento (começando, escalando, em crise).
- **Onde está**: que canais frequenta, que pessoas escuta, onde busca informação quando tem o problema.
- **Como decide**: decide sozinho ou precisa convencer alguém (chefe, sócio, financeiro)? Quanto tempo leva? Que provas pede antes de comprar?

Quanto mais específico o contexto, mais a copy e o canal acertam. Use `reference/mapa-do-cliente.md`, seções Contexto e Quem decide.

### 4. Liste as objeções (o que impede de comprar)

A pessoa sentiu a dor, entendeu a oferta — e mesmo assim não comprou. Por quê? Esse "por quê" é ouro de copy.

- **Objeções clássicas**: preço ("caro"), confiança ("será que funciona pra mim?"), esforço ("dá trabalho implantar?"), prioridade ("agora não é a hora"), autoridade ("preciso pedir pra alguém").
- Pra cada objeção, anote a **resposta honesta** — não um truque de venda, mas o argumento ou a prova que realmente desarma a dúvida.
- Objeção que você não consegue responder com honestidade é sinal de que o produto, o preço ou o público estão errados. Volte um passo.

Use `reference/mapa-do-cliente.md`, seção Objeções.

### 5. Defina onde encontrá-lo (canal) — ponte com Alavanca

Você agora sabe quem é, o que dói e o que trava. Falta saber onde alcançá-lo.

- Liste os **canais onde o cliente ideal já passa o tempo** quando tem o problema (não onde *você* gosta de postar).
- Distinga **onde ele busca ativamente** uma solução (Google, comunidades, indicação) de **onde ele só está navegando** (feed social) — isso muda a abordagem.
- Marque 1 ou 2 canais pra testar primeiro. Foco antes de espalhar.

Daqui em diante, o trabalho de transformar isso em funil, campanha e copy é da **Alavanca**: estrutura de canal, isca → e-mail → nutrição, métricas (CPL, CAC, conversão). Espelho entrega o retrato; Alavanca move a pessoa pelo funil.

## Entregável

Ao fim, preencha `templates/persona.md` com tudo que você levantou. O template força você a escrever a dor, o contexto, as objeções, o canal e uma **frase que o cliente diria** — a frase é o teste final: se ela não soa como uma pessoa real falando, você ainda está inventando.

## Princípios

- **Evidência antes de imaginação.** Comece por quem já existe.
- **Específico vende, genérico afunda.** "Founder de SaaS B2B no primeiro ano, sem time de marketing" > "empreendedor".
- **A palavra é dele, não sua.** Copie a linguagem real do cliente.
- **Um ICP por vez.** Se você tem dois clientes muito diferentes, faça dois retratos — não uma média que não existe.
- **A decisão é sua.** Espelho mostra o que os dados sugerem; você escolhe em quem mirar.
