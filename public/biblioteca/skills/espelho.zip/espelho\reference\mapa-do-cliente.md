# Mapa do cliente — o que descobrir e como perguntar

Este é o roteiro de investigação do Espelho. São seis frentes. Pra cada uma: o que você precisa descobrir e perguntas que arrancam a resposta — em entrevista, em pesquisa, ou lendo conversas/avaliações que já existem.

Princípio em todas: **pergunte sobre o passado e o concreto, não sobre o futuro e o hipotético.** "O que você fez da última vez?" vale ouro; "Você compraria?" vale nada.

---

## 1. Dor — o que incomoda de verdade

**Descobrir:** o problema específico que faz a pessoa procurar uma solução, com as palavras dela, e o quanto isso pesa.

Perguntas:
- Me conta a última vez que esse problema te atrapalhou. O que aconteceu?
- Qual é a parte mais irritante / mais cara desse problema hoje?
- O que você já tentou pra resolver? Por que não resolveu?
- Se esse problema sumisse amanhã, o que mudaria no seu dia?
- Quanto isso te custa — em tempo, dinheiro ou cabeça?

Sinal de boa resposta: a pessoa esquenta, dá exemplo concreto, usa uma frase forte. Anote a frase literal.

---

## 2. Objetivo — o "trabalho a ser feito"

**Descobrir:** o que a pessoa está realmente tentando alcançar quando contrata uma solução como a sua. A dor empurra; o objetivo puxa.

Perguntas:
- Quando você procura algo assim, o que você quer que aconteça no fim?
- Como seria o "deu certo" pra você? Como você saberia?
- Esse problema atrapalha que objetivo maior seu?
- Se você resolvesse isso, qual seria o próximo passo que destrava?

Sinal de boa resposta: o objetivo aparece num nível acima do produto (ex.: não "quero a planilha", mas "quero parar de trabalhar sábado").

---

## 3. Objeções — o que trava a compra

**Descobrir:** as dúvidas e medos que seguram a pessoa mesmo quando a dor e a oferta estão claras.

Perguntas:
- O que te faria desistir de comprar uma solução dessas?
- Quando você viu o preço, o que passou pela sua cabeça?
- O que você precisaria ver ou saber pra confiar que funciona pra você?
- Já se decepcionou com algo parecido antes? O quê?
- Tem alguém que precisa aprovar essa decisão além de você?

Sinal de boa resposta: hesitação, "é que...", ressalvas. Cada objeção pede uma resposta honesta sua — anote as duas.

---

## 4. Gatilho de compra — o que dispara a busca

**Descobrir:** o evento ou momento que faz a pessoa sair da inércia e ir procurar solução. Sem gatilho, não há venda — só interesse.

Perguntas:
- O que aconteceu que te fez começar a procurar isso agora (e não meses atrás)?
- Teve uma "gota d'água"? O quê?
- Tem uma época do ano / fase do negócio em que isso aperta mais?
- O que mudou pra esse problema virar prioridade?

Sinal de boa resposta: um evento datável (perdi um cliente, contratei alguém, bati uma meta, levei um susto). Esse evento é o melhor momento pra sua mensagem aparecer.

---

## 5. Onde busca informação — o canal

**Descobrir:** onde a pessoa vai quando tem o problema e em quem ela confia. Isso aponta o canal real (e alimenta a Alavanca).

Perguntas:
- Quando bateu esse problema, onde você foi procurar resposta primeiro?
- Que pessoas, perfis ou veículos você acompanha sobre esse assunto?
- Em quem você confia quando precisa de uma recomendação?
- Onde você passa mais tempo durante o dia de trabalho?
- Como você descobriu a última ferramenta/serviço parecido que usou?

Sinal de boa resposta: nomes concretos (uma comunidade, um YouTuber, "pergunto no grupo do WhatsApp", "jogo no Google"). Distinga busca ativa (Google, comunidade) de navegação passiva (feed).

---

## 6. Quem decide — o mapa de poder

**Descobrir:** quem realmente bate o martelo, quem influencia e quem pode vetar. Em B2B isso costuma ser mais de uma pessoa.

Perguntas:
- Essa decisão é só sua ou tem mais gente envolvida?
- Quem precisa dizer sim? Quem pode dizer não?
- Quem vai *usar* é a mesma pessoa que *paga*?
- O que a pessoa que aprova o orçamento quer ver pra liberar?

Sinal de boa resposta: papéis claros (quem usa, quem compra, quem aprova, quem veta). A copy muda dependendo de pra qual desses você está falando.

---

## Como usar o mapa

1. Não precisa de tudo de cara. Comece por **Dor**, **Gatilho** e **Onde busca** — são os que mais mudam decisão.
2. Faça de 5 a 10 conversas reais antes de fechar conclusões. Padrões aparecem rápido.
3. Anote frases literais. Elas viram headline, assunto de e-mail e bullet de landing.
4. Jogue tudo no `templates/persona.md`. O que ainda for chute, marque como hipótese a validar.
