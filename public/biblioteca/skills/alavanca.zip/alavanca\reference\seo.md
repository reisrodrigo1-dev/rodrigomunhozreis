# SEO: tráfego orgânico que alimenta o funil

O SEO é o motor **orgânico** de longo prazo. Não dá resultado em uma semana, mas é o ativo que reduz o CAC com o tempo: o blog rankeia, traz tráfego grátis e — com captura embutida — joga gente nova na nutrição (`funil.md`). Alinhado ao que o **Google recomenda oficialmente** (Search Essentials / guia de conteúdo útil): faça conteúdo para pessoas, não para enganar o algoritmo.

## Princípio que rege tudo: conteúdo útil para pessoas

O Google premia conteúdo **útil, confiável e feito para gente** (people-first), não conteúdo produzido só para rankear (search-engine-first). Perguntas que o próprio Google sugere para avaliar seu conteúdo:

- O conteúdo entrega informação original, profundidade ou análise — ou só repete o que já existe?
- Depois de ler, a pessoa sai com a sensação de que aprendeu o suficiente para resolver o problema?
- Você escreveria isso se não existisse mecanismo de busca?
- Demonstra **experiência e expertise reais** (E-E-A-T: Experiência, Expertise, Autoridade, Confiabilidade)?

Para "vibecoding com engenharia", isso significa: conteúdo de quem **faz de verdade**, com método, não texto genérico inflado.

## Boas práticas (alinhadas ao guia do Google)

### Títulos (`<title>`)
- Um `<title>` único e descritivo por página.
- Diga o assunto da página de forma clara e específica. Evite títulos vagos ("Início", "Página 1") ou repetidos no site todo.
- Coloque o termo importante no começo, de forma natural. Não empilhe palavras-chave.

### Meta description
- Resumo curto e atraente do conteúdo da página (não é fator de ranqueamento direto, mas influencia o CTR no resultado de busca).
- Uma por página, descrevendo aquele conteúdo específico. Evite a mesma meta description em todas as páginas.
- Escreva como um convite honesto ao clique — sem clickbait que a página não cumpre.

### Estrutura de conteúdo
- Use **headings** (`<h1>`, `<h2>`, `<h3>`) para organizar o texto em hierarquia lógica, como um sumário. Um `<h1>` por página.
- Texto escaneável: parágrafos curtos, listas, subtítulos.
- URLs descritivas e legíveis (`/blog/vibecoding-funil` em vez de `/p?id=8472`).

### Sitemap
- Tenha um **sitemap.xml** listando as URLs que você quer indexadas e envie no **Google Search Console**.
- Ajuda o Google a descobrir e entender a estrutura do site, principalmente em sites novos ou grandes.

### Canonical (conteúdo duplicado)
- Quando o mesmo conteúdo existe em mais de uma URL (parâmetros, versões), use a tag **`rel="canonical"`** apontando para a versão preferida.
- Evita que o Google divida sinais entre duplicatas e escolha a URL errada. Cada conteúdo "vive" numa URL canônica.

### Links internos
- Conecte suas páginas com **links internos** usando texto âncora descritivo (o texto do link diz para onde leva).
- Distribui autoridade entre páginas, ajuda o Google a entender relações e mantém o leitor no site.
- Do blog, linke para a página de isca/captura e para posts relacionados — é assim que o orgânico alimenta o funil.

### Performance e mobile
- Página rápida e que funciona bem no celular. Lentidão derruba ranqueamento e conversão.
- Core Web Vitals (carregamento, interatividade, estabilidade visual) contam para a experiência.

## Erros a evitar

- **Keyword stuffing (empilhar palavras-chave):** repetir o termo de forma artificial ("curso de marketing, melhor curso de marketing, curso de marketing online...") **prejudica** o ranqueamento e é considerado spam pelo Google. Escreva natural; a palavra aparece sozinha quando o conteúdo é bom.
- **Conteúdo fino / feito só para rankear:** texto genérico, sem profundidade, sem experiência real. O Google despromove.
- **Títulos e metas duplicados** em massa.
- **Texto escondido**, links comprados em esquema, redirecionamentos enganosos — violações que geram punição.
- **Prometer no título o que a página não entrega** (clickbait): aumenta a taxa de rejeição e derruba o resultado.

## Como o SEO se encaixa no motor pago -> e-book -> e-mail -> blog

- O **blog** é o destino legítimo do tráfego **orgânico** (ao contrário do pago, que vai para a landing).
- Cada post deve ter **captura de e-mail embutida** (isca contextual no meio/fim do post) para transformar leitor orgânico em lead.
- Cada post vira também **e-mail de nutrição** para a base.
- Com o tempo, o orgânico traz leads a custo de mídia zero, derrubando o **CAC médio** (`metricas.md`).

## Checklist rápido de SEO on-page

- [ ] `<title>` único, descritivo, termo no começo, sem stuffing
- [ ] Meta description única e honesta
- [ ] Um `<h1>` + hierarquia de headings lógica
- [ ] URL legível e descritiva
- [ ] Conteúdo útil, original, com experiência real (E-E-A-T)
- [ ] Links internos com âncora descritiva (inclusive para a isca)
- [ ] Canonical onde houver duplicação
- [ ] Sitemap.xml enviado ao Search Console
- [ ] Página rápida e boa no mobile
- [ ] Captura de e-mail embutida no post
