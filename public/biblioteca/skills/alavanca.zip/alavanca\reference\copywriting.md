# Copywriting: fórmulas, headlines e voz anti-hype

Copy é vendedor escrito. Aqui o objetivo é fazer a pessoa **clicar no anúncio**, **deixar o e-mail na landing** e **abrir/agir no e-mail de nutrição** — sem promessa milagrosa. A voz é "vibecoding com engenharia": direta, com método, honesta. A decisão é sempre do leitor.

## A voz anti-hype

O que **NÃO** fazer:
- Promessa milagrosa ("fique rico em 7 dias", "método infalível", "garantido 100%").
- Urgência falsa ("só hoje!" quando não é).
- Superlativo vazio ("o melhor curso do mundo", "revolucionário").
- Esconder o que a pessoa vai receber para forçar o clique.

O que fazer:
- Falar de um **problema real** e de um **método concreto**.
- Ser **específico** (número, passo, exemplo) em vez de adjetivo.
- Mostrar competência **entregando valor**, não se autoelogiando.
- Deixar claro o que a pessoa leva — e devolver a decisão a ela ("a decisão é sua").

Princípio: **especificidade vende mais que adjetivo.** "Checklist de 12 itens para tirar seu protótipo do ar de teste" > "o guia definitivo e revolucionário".

## Fórmula 1 — PAS (Problema, Agitação, Solução)

A mais útil para anúncio e topo de funil. Estrutura:

1. **Problema:** nomeie a dor que a pessoa sente. Ela precisa pensar "é isso".
2. **Agitação:** mostre a consequência de não resolver / o custo de continuar assim. Sem terror, com realidade.
3. **Solução:** apresente o caminho (sua isca/produto) como a saída.

Exemplo (bom):
> **Problema:** Você vibecoda rápido, mas na hora de divulgar joga dinheiro em anúncio e não vê retorno.
> **Agitação:** O clique é caro, manda pro site, a pessoa some e você não fica nem com o e-mail. Queimou orçamento e não aprendeu nada.
> **Solução:** O e-book "Pago -> E-book -> E-mail" mostra o funil que transforma clique pago em base de e-mail. Baixe grátis.

## Fórmula 2 — AIDA (Atenção, Interesse, Desejo, Ação)

Boa para landing e e-mail mais longos.

1. **Atenção:** headline que para o scroll (a dor ou a promessa específica).
2. **Interesse:** desenvolva — por que isso importa para a pessoa agora.
3. **Desejo:** mostre o resultado concreto, prova leve, o que tem dentro.
4. **Ação:** um CTA claro e único ("Baixar o e-book grátis").

## Headlines

A headline faz 80% do trabalho — é o que decide se a pessoa continua. Padrões que funcionam (sem hype):

- **Como [resultado específico] sem [dor comum]**
  → "Como conseguir leads com R$30/dia sem aparecer no seu perfil"
- **[Número] [coisas] para [resultado]**
  → "5 erros de anúncio que queimam seu orçamento (e como evitar)"
- **A forma certa de [tarefa] quando você [contexto]**
  → "A forma certa de divulgar quando você constrói sozinho com IA"
- **Pergunta que nomeia a dor**
  → "Cansado de pagar por clique e não ficar com nada?"

Regras de headline:
- Específica > genérica. Número e detalhe ganham de adjetivo.
- Promete só o que a página/isca entrega (continuidade de promessa; quebrar isso mata conversão e SEO).
- Uma ideia por headline. Não tente dizer tudo.

## CTA (chamada para ação)

- **Um por página.** Verbo + benefício: "Baixar o e-book grátis", "Receber o checklist".
- Diga o que acontece ao clicar. Reduza o medo ("grátis", "sem cartão").
- Não use CTA vago ("Enviar", "Clique aqui") quando pode dizer o ganho.

## Exemplos: bom x ruim

| Ruim (hype/vago) | Bom (específico/anti-hype) |
|---|---|
| "O método REVOLUCIONÁRIO que vai mudar sua vida!" | "O funil de 4 etapas que transforma clique pago em e-mail" |
| "Garanta resultados milagrosos hoje!" | "Baixe o checklist e monte sua primeira campanha em 1 dia" |
| "O melhor e-book de marketing do Brasil" | "E-book grátis: por que mandar tráfego pago pro blog queima dinheiro" |
| "Clique aqui" | "Baixar o e-book grátis (só e-mail)" |
| "Aumente suas vendas em 1000%!" | "Como ler CPL e CAC para saber quando parar um anúncio" |
| "Não perca essa oportunidade ÚNICA!" | "A decisão é sua. O método está aqui." |

## Copy por etapa do funil

- **Anúncio:** PAS curto. Dor + promessa da isca + CTA. Sem rodeio. (Ver `trafego-pago.md`.)
- **Landing da isca:** AIDA. Headline com benefício, bullets do que tem dentro, prova leve, um CTA, sem fuga. (Ver `funil.md`.)
- **E-mail de boas-vindas:** entregue a isca primeiro, depois construa relacionamento com história e método. Venda só depois de entregar valor.
- **E-mail de nutrição:** um assunto curioso e honesto, um conteúdo útil, um CTA. Não venda em todo e-mail.

## Checklist de copy

- [ ] A headline é específica (tem número/detalhe) e não é hype?
- [ ] A promessa do anúncio bate com a da landing?
- [ ] Usou PAS (anúncio) ou AIDA (landing/e-mail) de forma clara?
- [ ] Tem UM CTA claro com verbo + benefício?
- [ ] Trocou adjetivos vazios por fatos concretos?
- [ ] Nenhuma promessa milagrosa, urgência falsa ou superlativo vazio?
- [ ] A decisão fica com o leitor (sem pressão manipulativa)?
