# Tráfego pago: Meta, Google e Native

Regra que vale para todos: **o tráfego pago vai para a landing da isca, nunca para a home ou o blog** (ver `funil.md`). E você só sabe se um anúncio presta lendo as métricas (ver `metricas.md`).

---

## Meta Ads (Instagram / Facebook)

O canal mais rápido para validar mensagem e público com orçamento pequeno. Bom para topo de funil com isca.

### Estrutura da conta (3 níveis)

```
Campanha   -> define o OBJETIVO
  Conjunto -> define PÚBLICO, ORÇAMENTO, posicionamento, otimização
    Anúncio -> o CRIATIVO (imagem/vídeo + copy + CTA)
```

### Passo a passo de uma campanha de captura de leads

1. **Objetivo da campanha:** escolha **Tráfego** ou **Leads**. Para mandar a pessoa para a sua landing e capturar na sua ferramenta de e-mail, use **Tráfego** (ou Leads com destino "site").
   - Evite "Engajamento" ou "Alcance" para captura — eles otimizam por curtida/visualização barata, não por gente que clica e converte.

2. **Otimização do conjunto:** otimize por **"visualizações da página de destino"** (landing page views), não por "cliques no link".
   - "Cliques no link" conta quem clicou mesmo que a página não tenha carregado / a pessoa tenha desistido. Você paga por cliques fantasma.
   - "Visualizações da página de destino" conta quem **clicou E a página carregou**. O Meta passa a entregar para quem realmente chega na landing — leads mais qualificados, CPL mais honesto.

3. **Público (topo de funil):** comece por **interesses**.
   - Combine interesses relacionados à dor/tema do seu produto. Ex.: para "vibecoding com engenharia" — interesses em desenvolvimento de software, no-code/low-code, ferramentas de IA, empreendedorismo digital.
   - Tamanho de público amplo o bastante para o orçamento entregar (não mire em 5 mil pessoas com R$30/dia).
   - Deixe **Advantage+ / segmentação automática** ajudar quando o público inicial for pequeno; em teste, prefira controlar para aprender.
   - Depois que tiver tráfego e base, evolua para **lookalike** (semelhantes a quem converteu) e **retargeting** (quem visitou e não converteu).

4. **Dark post (anúncio sem aparecer no perfil):** use um anúncio que **não fica publicado no feed do seu perfil/página** — ele só aparece para o público pago.
   - Para que serve: testar várias versões de copy/criativo sem poluir o perfil, e rodar oferta direta sem que ela vire post permanente.
   - Como: ao criar o anúncio no conjunto, você cria um criativo novo direto no Gerenciador de Anúncios (em vez de "usar publicação existente"). Esse criativo é um "post não publicado" / dark post — roda como anúncio mas não aparece organicamente no perfil.
   - Vantagem extra: pode rodar 3-5 variações ao mesmo tempo sem encher o feed dos seguidores.

5. **Orçamento de teste:** comece pequeno e fixo. Faixa prática: **R$ 20 a R$ 50/dia** por conjunto.
   - Rode **3 a 7 dias** antes de julgar. Os primeiros 1-2 dias são "aprendizado" do algoritmo — não decida nesse período.
   - Teste **um eixo por vez**: ou variações de criativo (mesmo público) ou variações de público (mesmo criativo). Mudar tudo de uma vez impede aprender o que funcionou.
   - Não pulverize R$30/dia em 5 conjuntos. Concentre para sair do aprendizado.

### Como ler os resultados (Meta)

| Sinal | Leitura | Ação |
|---|---|---|
| CTR baixo (link) | O criativo/headline não chama | Troque imagem/headline (problema de anúncio, não de público) |
| CTR ok, mas poucos chegam na landing | Pode ser velocidade da página ou disconexão anúncio↔landing | Verifique carregamento e continuidade de promessa |
| Muitas visitas, poucos leads | A **landing** não converte | Conserte a landing (headline, formulário, fricção) antes de mexer no anúncio |
| CPL acima da meta com CTR baixo | Problema de criativo | Novo criativo/copy |
| CPL alto com CTR alto | Anúncio atrai, mas público errado ou oferta fraca | Ajuste público / oferta |

Benchmarks e contas de CTR/CPL: `metricas.md`.

---

## Google Ads (Search)

Diferente do Meta: no Meta você **interrompe** alguém com uma oferta; no Google a pessoa **já está procurando** a solução. A intenção é maior, o lead é mais quente, mas só funciona se existir demanda de busca para o seu tema.

### Quando usar
- Quando as pessoas **digitam o problema** no Google. Se ninguém busca pelo que você resolve, Search não tem volume — vá de Meta/Native primeiro para criar demanda.

### Passo a passo
1. **Campanha de Rede de Pesquisa (Search)**, não Display nem Performance Max para começar — você quer controle e intenção.
2. **Palavras-chave por intenção:** escolha termos que indicam que a pessoa quer resolver/comprar.
   - Intenção alta: "como [resolver problema]", "[ferramenta] para [objetivo]", "[produto] preço/plano".
   - Use **correspondência de frase** ou **exata** no início para não gastar com buscas irrelevantes. Correspondência ampla queima orçamento em termos soltos.
3. **Palavras-chave negativas:** adicione termos que NÃO são seu público (ex.: "grátis", "vaga", "curso gratuito") para não pagar por clique que nunca compra.
4. **Anúncio:** a headline deve repetir o termo que a pessoa buscou (relevância aumenta o Índice de Qualidade e baixa o CPC).
5. **Destino:** uma landing alinhada à busca — de novo, oferta única / isca, não a home.
6. **Orçamento:** comece controlado, observe **CPC** e **custo por conversão**. Search tende a ter CPC maior que Meta, mas conversão melhor por intenção.

### Como ler
- **CPC alto + poucas conversões:** termo competitivo ou landing fraca. Refine palavra-chave/negativas ou conserte a landing.
- **Muitos cliques, zero conversão:** quase sempre é a landing ou descasamento busca↔oferta.
- **Índice de Qualidade baixo:** melhore a relevância anúncio↔palavra↔landing.

---

## Native Ads (Taboola / Outbrain)

Anúncios que aparecem como "conteúdo recomendado" em portais e sites de notícia. Tráfego **frio e barato em volume**, formato de "matéria"/conteúdo.

### Quando usar
- Quando o **pago no Meta/Google já funciona** e você quer **escalar volume de topo de funil a custo de clique baixo**.
- Para iscas de **conteúdo** (e-book, artigo, "descubra como...") que casam com a mentalidade de quem está lendo notícia.
- **Não** é o primeiro canal para validar oferta — o tráfego é mais frio e menos qualificado que Meta/Google. Exige **nutrição forte** depois da captura, porque a pessoa estava distraída lendo outra coisa.

### Como rodar
1. Criativo em formato editorial (título de "matéria" + thumbnail), não cara de anúncio agressivo.
2. Sempre mandando para landing de isca com captura.
3. Comece pequeno, espere CPL pior que Meta e compense com volume + nutrição.
4. Vigie qualidade: native traz cliques acidentais. Olhe **taxa de conversão da landing** e **CPL real**, não só o CPC barato.

### Como ler
- **CPC baixo mas CPL alto:** clique barato porém frio — normal em native. Avalie se o volume compensa e se a nutrição converte depois.
- **Tráfego que entra e sai em segundos:** descasamento entre o "título matéria" e a oferta. Alinhe a promessa.

---

## Resumo de escolha rápida

- **Validar rápido, verba pequena, criar demanda:** Meta Ads (Tráfego, otimizar por visualizações da página de destino, interesses, dark post, R$20-50/dia).
- **Já existe gente buscando a solução:** Google Ads Search (intenção, palavras-chave + negativas).
- **Escalar volume barato no topo, com nutrição forte:** Native Ads (Taboola/Outbrain).

Em todos: destino = landing da isca. Decisão de continuar/parar = `metricas.md`.
