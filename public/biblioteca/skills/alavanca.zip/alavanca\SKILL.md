---
name: alavanca
description: Inteligência de marketing e funil para quem constrói com IA: recomenda canal, estrutura de campanha, copy e métricas, com o método isca->e-mail->nutrição. Use ao planejar divulgação, criar anúncios, montar funil, escrever copy de anúncio/landing/e-mail, definir orçamento de teste, escolher entre Meta/Google/Native/SEO ou melhorar conversão/CTR/CPL/CAC.
---

# Alavanca

Inteligência de marketing e aquisição para produtos construídos com IA. Não é hype, é método. A Alavanca recomenda **qual canal usar primeiro**, **como estruturar a campanha**, **o que escrever** e **quais métricas olhar para decidir continuar ou parar** — sempre dentro do motor que dá ROI de verdade: **pago -> e-book -> e-mail -> blog**.

A voz é PT-BR, direta, sem promessa milagrosa. A skill recomenda, explica o porquê e devolve a decisão para quem está no comando: a decisão é sua.

## Visão geral

O erro mais comum de quem vibecoda um produto e quer "divulgar" é jogar dinheiro em anúncio mandando tráfego direto para o site/blog/home. O clique é caro, a pessoa não te conhece, vai embora, e você não fica com nada — nem o e-mail. Queimou o orçamento sem aprender nada.

A Alavanca organiza tudo em torno de um funil simples e comprovado:

```
anúncio (pago ou orgânico)
   -> landing de OFERTA ÚNICA (uma página, uma ação)
   -> ISCA: e-book / checklist / mini-curso grátis
   -> CAPTURA do e-mail (só e-mail; nada de pedir telefone numa isca grátis)
   -> NUTRIÇÃO por e-mail + blog (relacionamento, autoridade, venda)
```

O dinheiro pago compra o **clique**. A isca transforma o clique em **e-mail** (um ativo que você possui). A nutrição transforma o e-mail em **confiança** e a confiança em **venda**. O blog sustenta o SEO orgânico e alimenta a nutrição. Esse é o motor com ROI: **pago -> e-book -> e-mail -> blog.**

## Quando usar esta skill

Use a Alavanca quando o usuário quiser:

- **Planejar divulgação / lançamento** de um produto, curso, SaaS ou e-book.
- **Escolher canal** (Meta Ads, Google Ads, Native Ads, LinkedIn orgânico, SEO) com orçamento X e objetivo Y.
- **Montar ou auditar um funil** de aquisição (isca, captura, nutrição).
- **Criar anúncios**: estrutura de campanha, públicos, objetivo de otimização, orçamento de teste, dark post.
- **Escrever copy**: headline de anúncio, página de oferta/landing, e-mail de nutrição, com fórmulas (PAS, AIDA) e voz anti-hype.
- **Melhorar conversão**: CTR baixo, CPL alto, landing que não converte, anúncio que não roda.
- **Definir e ler métricas**: CTR, CPL, CAC, LTV, taxa de conversão — o que é bom e quando matar um anúncio.
- **SEO**: estruturar conteúdo, títulos, meta description, sitemap, canonical, links internos.

Não use para: design visual de criativos (use uma skill de design), código de implementação de tracking, ou copy de redes sociais orgânicas sem objetivo de aquisição.

## Como usar a base

Esta skill é uma **base pesquisável**. Antes de responder qualquer pergunta de marketing/funil, leia o(s) arquivo(s) de `reference/` relevantes — eles têm o conteúdo completo, com passo a passo, números de referência e exemplos.

| Arquivo | Use quando o assunto for |
|---|---|
| `reference/funil.md` | Estratégia geral, isca, captura, nutrição, fricção, por que NÃO mandar pago pro blog. Leia este PRIMEIRO em quase todo planejamento. |
| `reference/trafego-pago.md` | Meta Ads, Google Ads, Native Ads: objetivo, público, dark post, estrutura de campanha, orçamento de teste, como ler resultados. |
| `reference/seo.md` | Tráfego orgânico, blog, conteúdo útil, títulos/meta, sitemap, canonical, links internos, erros (keyword stuffing). |
| `reference/copywriting.md` | Headlines, fórmulas (PAS, AIDA), copy de anúncio/landing/e-mail, voz anti-hype, exemplos bons e ruins. |
| `reference/metricas.md` | CTR, CPL, CAC, LTV, taxa de conversão: o que é, como calcular, benchmarks, quando continuar/parar um anúncio. |

Fluxo recomendado de resposta:
1. Entenda **objetivo** (o que quer: leads? vendas? autoridade?) e **orçamento** (quanto tem para testar).
2. Aplique as **regras de prioridade** abaixo para escolher o caminho.
3. Abra os arquivos de referência relevantes e monte a recomendação com passo a passo concreto.
4. Devolva números de referência reais (das métricas) e deixe a decisão final para o usuário.

## Regras de prioridade

Dado objetivo e orçamento, qual caminho recomendar PRIMEIRO. Use como árvore de decisão.

### 1. Antes de qualquer mídia paga: existe uma isca e uma captura?
Se **não** existe e-book/isca + landing de captura funcionando, **essa é a prioridade zero**. Mandar pago sem ter onde capturar e-mail é queimar dinheiro. Construa o funil primeiro (`funil.md`).

### 2. Por objetivo

- **Validar oferta rápido / quer leads já (tem verba):** comece por **Meta Ads** com objetivo de Leads/Tráfego otimizado por "visualizações da página de destino", mandando para a **landing da isca**. É o jeito mais rápido de testar mensagem e público com orçamento pequeno. (`trafego-pago.md`)
- **Tem demanda existente / pessoas já buscam a solução:** **Google Ads (Search)**. Se o público digita o problema no Google, a intenção é alta e o lead é mais quente. Exige palavra-chave com intenção. (`trafego-pago.md`)
- **Quer autoridade e custo zero de mídia / horizonte longo:** **SEO + blog** e **LinkedIn orgânico**. Não dá resultado em 1 semana, mas é o ativo que reduz o CAC ao longo do tempo e alimenta a nutrição. (`seo.md`)
- **Pago já funciona e quer escalar volume barato:** considere **Native Ads (Taboola/Outbrain)** para topo de funil com isca, sabendo que o tráfego é mais frio e exige nutrição forte. (`trafego-pago.md`)

### 3. Por orçamento

- **Orçamento baixo (teste, ~R$ 20-50/dia):** UM canal só (geralmente Meta), UM público, UMA isca, UMA landing. Não pulverize. Rode 3-7 dias, leia CPL e CTR, decida. (`metricas.md`)
- **Orçamento médio:** Meta para volume de leads + Google Search para captar intenção. Mantenha SEO/blog rodando em paralelo (custo de tempo, não de mídia).
- **Sem orçamento de mídia:** SEO + blog + LinkedIn orgânico + nutrição da base que já tem. Mais lento, mas é o motor orgânico.

### 4. Regra de ouro do destino do tráfego
Tráfego **pago** vai para **landing de oferta única (isca)** — nunca para a home ou o blog. Tráfego **orgânico/SEO** pode chegar no **blog**, e o blog deve ter captura de e-mail embutida para puxar a pessoa para a nutrição. (`funil.md`)

### 5. Quando parar um anúncio
Não decida no susto. Espere volume mínimo de dados (regra prática: ~50 cliques ou ~3 dias). Se o **CPL** está muito acima da meta e o **CTR** está baixo, o problema costuma ser **criativo/copy** (mude o anúncio) antes de ser público. Detalhes e benchmarks em `metricas.md`.

---

A Alavanca recomenda com método e mostra o porquê. A decisão é sua.
