# Funil: isca -> captura -> nutrição

O motor que dá ROI de verdade: **pago -> e-book -> e-mail -> blog**. O dinheiro compra o clique; a isca converte o clique em e-mail; a nutrição converte o e-mail em confiança; a confiança em venda. O blog sustenta o orgânico e alimenta a nutrição.

```
anúncio (pago ou orgânico)
   -> landing de OFERTA ÚNICA
   -> ISCA grátis (e-book / checklist / mini-curso)
   -> CAPTURA do e-mail (só e-mail)
   -> NUTRIÇÃO por e-mail + blog
   -> OFERTA do produto pago
```

## O erro número 1: mandar tráfego pago direto para o blog (ou home)

É o erro mais caro e mais comum. Por quê não funciona:

- **O clique pago é caro.** Você paga por cada visita. Se a pessoa entra no blog, lê (ou não) e vai embora, você pagou por uma visita e ficou com **nada** — nem o e-mail.
- **A pessoa não te conhece.** No primeiro contato, ninguém compra. Sem uma ação clara e um motivo para deixar o contato, ela some.
- **O blog não tem UMA ação.** Tem menu, posts relacionados, categorias, mil links. Atenção dispersa = conversão baixa.
- **Você não aprende nada.** Sem captura, você não consegue medir CPL nem construir base. O orçamento vira despesa, não investimento.

A regra: **tráfego pago vai para uma landing de oferta única (a isca)**. O blog é destino de tráfego **orgânico/SEO**, e mesmo o blog precisa ter captura de e-mail embutida para puxar o leitor para a nutrição.

## Etapa 1 — Anúncio / topo de funil

Papel: gerar o clique de quem tem o problema que a isca resolve.

- Pode ser **pago** (Meta, Google, Native) ou **orgânico** (SEO, LinkedIn, redes).
- A promessa do anúncio tem que casar com a promessa da isca (continuidade de mensagem). Anúncio fala de "checklist de X" -> landing entrega "checklist de X". Quebra de promessa mata a conversão.
- Topo de funil = público mais frio. A copy resolve uma dor específica e oferece algo grátis em troca do e-mail.

## Etapa 2 — Landing de oferta única (a isca)

Papel: trocar o e-mail da pessoa pela isca. **Uma página, uma oferta, uma ação.**

Anatomia de uma landing de captura que converte:

1. **Headline** clara com o benefício da isca (o que a pessoa leva e por quê importa).
2. **Sub-headline** com a promessa específica / para quem é.
3. **Bullets** com o que tem dentro da isca (3 a 5 pontos concretos).
4. **Prova** leve (quem é você, por que confiar) — sem exagero.
5. **Formulário curto** e **um único CTA**.
6. **Sem menu, sem links de saída, sem rodapé cheio.** Tudo que não leva à conversão é fuga.

A isca boa: e-book, checklist, planilha, mini-curso, template — algo de valor real, consumível rápido, que resolve um pedaço da dor e demonstra competência. "Vibecoding com engenharia" entrega isca útil de verdade, não um PDF vazio.

## Etapa 3 — Captura do e-mail (e a regra da fricção)

Papel: pegar o contato com o **mínimo de atrito**. Cada campo a mais derruba a conversão.

**Numa isca grátis, peça só o e-mail.** No máximo nome + e-mail.

- **NÃO peça telefone numa isca grátis.** Telefone é fricção alta e sinal de "vão me ligar para vender" — a conversão despenca. Telefone só se faz sentido no fundo do funil (ex.: agendar demo de um produto caro), nunca na troca por um e-book grátis.
- Não peça empresa, cargo, faturamento, etc. numa isca de topo. Cada campo extra = menos cadastros.
- Quanto menor o compromisso percebido, maior a conversão. A isca é grátis; o "preço" que a pessoa paga é o e-mail. Mantenha esse preço baixo.

Regra de fricção: **só peça o dado que você vai usar AGORA e que a etapa justifica.** Topo grátis = e-mail. Fundo de funil = aí sim você pode pedir mais, porque o compromisso é maior.

## Etapa 4 — Nutrição (e-mail + blog)

Papel: transformar um e-mail frio em alguém que confia em você e está pronto para comprar. É aqui que o ROI aparece — porque o e-mail é grátis de enviar e você já pagou pelo lead uma vez só.

- **Sequência de boas-vindas:** entregue a isca no primeiro e-mail, depois 3-7 e-mails que aprofundam o tema, contam história, mostram método e constroem autoridade. Sem vender ainda — primeiro entrega valor.
- **Cadência contínua:** e-mails regulares (semanal é um bom começo) misturando conteúdo útil, bastidores e ofertas. O blog alimenta isso: cada post novo vira um e-mail.
- **Blog como base orgânica:** posts rankeiam no Google (SEO), trazem tráfego grátis e têm captura embutida para jogar gente nova na nutrição. O blog é o ativo de longo prazo que reduz o CAC.
- **Oferta do produto pago:** só depois de entregar valor. Quem foi nutrido compra mais barato (CAC menor) porque já confia.

## Por que o motor tem ROI

- O **pago** custa caro por clique, mas você só paga **uma vez** para capturar o e-mail.
- O **e-mail** é um ativo seu: enviar custa quase nada e você pode ofertar quantas vezes precisar.
- O **blog/SEO** traz tráfego orgânico contínuo sem custo de mídia, alimentando a base.
- Resultado: o custo de aquisição se dilui ao longo do relacionamento. Um lead que entrou por R$ X pode comprar várias vezes ao longo de meses. É isso que faz o LTV superar o CAC (ver `metricas.md`).

## Checklist de auditoria de funil

- [ ] Existe uma isca de valor real (não um PDF vazio)?
- [ ] Existe uma landing de oferta única (sem menu, sem fuga, um CTA)?
- [ ] A captura pede só o e-mail (sem telefone numa isca grátis)?
- [ ] A promessa do anúncio bate com a promessa da landing?
- [ ] Tráfego pago vai para a landing — e NÃO para a home/blog?
- [ ] Existe sequência de e-mails de boas-vindas que entrega a isca e nutre?
- [ ] O blog tem captura de e-mail embutida?
- [ ] Você consegue medir CPL (lead capturado / custo)?

Se algum item está faltando, conserte o funil **antes** de aumentar o orçamento de mídia.
