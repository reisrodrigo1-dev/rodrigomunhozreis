# Métricas: CTR, CPL, CAC, LTV e conversão

Anúncio não se decide no susto nem no "achismo". Se decide no número. Aqui está o que cada métrica significa, como calcular, o que é "bom" (benchmark de referência — varia por nicho, use como ponto de partida) e o que olhar para **continuar ou parar** um anúncio.

> Os benchmarks abaixo são faixas de referência gerais. O que importa de verdade é a sua **meta**: o CPL que ainda é lucrativo dado o seu LTV. Compare sempre contra a sua própria conta.

---

## CTR — Click-Through Rate (taxa de cliques)

**O que é:** de quem viu o anúncio, quantos clicaram. Mede se o criativo/headline chama atenção.

**Como calcular:**
```
CTR = (cliques / impressões) x 100
```
Ex.: 10.000 impressões, 150 cliques -> CTR = 1,5%.

**Referência:**
- Meta (link CTR): ~0,9%-1,5% é mediano; acima de ~2% é bom.
- Google Search: bem mais alto (intenção) — 3%-6%+ é comum.

**O que diz:** CTR baixo = **problema de anúncio** (criativo/headline/oferta), quase nunca de público. É o primeiro sinal a olhar.

---

## Custo por visita / clique (CPC)

**O que é:** quanto você paga por cada clique (ou por visita à página de destino, que é a métrica que importa no Meta).

**Como calcular:**
```
CPC = investimento / cliques
```
Ex.: R$ 100 gastos, 80 cliques -> CPC = R$ 1,25.

**O que diz:** CPC sobe quando o CTR é baixo (plataforma cobra mais de anúncio pouco relevante) ou o público é muito disputado. Olhe junto com o CTR, mas o **CPC sozinho não decide nada** — o que importa é o custo por lead.

---

## CPL — Custo por Lead

**A métrica central do funil de captura.** Quanto custou cada e-mail capturado.

**Como calcular:**
```
CPL = investimento / leads capturados
```
Ex.: R$ 200 gastos, 40 leads -> CPL = R$ 5,00.

**O que diz:** é o termômetro da campanha de topo. Junta a qualidade do anúncio (CTR/CPC) **e** a conversão da landing. CPL alto pode vir de:
- anúncio fraco (CTR baixo) -> conserte o **criativo/copy**;
- landing fraca (muita visita, poucos leads) -> conserte a **landing**;
- público errado -> ajuste segmentação.

**Meta de CPL:** depende do seu LTV. Se um lead vale (em média, ao longo do tempo) R$ 100 e você converte 5% deles em compra, dá para pagar bem mais por lead do que se o produto for barato. Defina o CPL máximo aceitável **a partir do LTV**, não por achismo.

---

## Taxa de conversão da landing

**O que é:** de quem chegou na landing, quantos viraram lead (deixaram o e-mail).

**Como calcular:**
```
Conversão = (leads / visitantes da landing) x 100
```
Ex.: 400 visitas, 80 leads -> 20%.

**Referência:** landing de isca grátis bem feita costuma converter **20%-40%+** (é grátis e pede só e-mail). Abaixo de ~10% acende alerta na landing.

**O que diz:** se o anúncio traz visita mas a conversão é baixa, o problema é a **landing** (headline, fricção, formulário, descasamento de promessa), não o anúncio. Não troque o público se a landing é o gargalo.

---

## CAC — Custo de Aquisição de Cliente

**O que é:** quanto custa, em média, conquistar um **cliente pagante** (não só um lead).

**Como calcular:**
```
CAC = total investido em marketing+vendas / nº de clientes novos
```
Ex.: R$ 1.000 investidos, 10 clientes -> CAC = R$ 100.

**Relação com CPL:** se o CPL é R$ 5 e 5% dos leads compram, então cada cliente custou ~R$ 100 em mídia (R$5 / 0,05). O funil + nutrição existem justamente para **derrubar o CAC**: nutrir o lead barato converte mais, e o orgânico (blog/SEO) traz leads a custo de mídia zero.

---

## LTV — Lifetime Value (valor do cliente no tempo)

**O que é:** quanto um cliente gera de receita ao longo de todo o relacionamento.

**Como calcular (simplificado):**
```
LTV = ticket médio x nº de compras por cliente x tempo de relacionamento
```
Ex.: assinatura de R$ 50/mês mantida 12 meses -> LTV = R$ 600.

**O que diz:** o LTV é o que **autoriza** o seu CAC. A regra de saúde clássica:
```
LTV / CAC >= 3
```
- LTV/CAC ~3 ou mais: saudável, dá para escalar.
- LTV/CAC ~1: você empata (paga para adquirir o que o cliente gasta) — insustentável.
- LTV/CAC < 1: cada cliente dá prejuízo.

É por isso que o motor **pago -> e-book -> e-mail -> blog** funciona: ele aumenta o LTV (nutrição vende de novo) e reduz o CAC (orgânico + conversão melhor), empurrando o ratio para cima.

---

## Como decidir: continuar ou parar um anúncio

**1. Espere volume mínimo de dados.** Não julgue nos primeiros cliques nem nas primeiras horas (período de aprendizado do algoritmo). Regra prática: **~50 cliques OU ~3 dias** de veiculação antes de decidir. Decidir antes disso é decidir no ruído.

**2. Diagnostique pela cascata (de cima para baixo):**

| Onde está o problema | Sintoma | Conserte |
|---|---|---|
| Anúncio | CTR baixo | Criativo / headline / copy |
| Landing | CTR ok, mas conversão baixa | Headline da landing, fricção, formulário, promessa |
| Público/oferta | CTR alto + CPL alto | Segmentação ou a oferta em si |
| Tudo ok, escala | CPL dentro da meta, LTV/CAC saudável | **Aumente o orçamento devagar** |

**3. Regra de bolso para matar/manter:**
- **CPL acima da meta + CTR baixo** -> problema de **criativo**. Troque o anúncio antes de mexer no público.
- **CPL acima da meta + CTR bom, mas conversão baixa** -> problema de **landing**. Mexa na landing.
- **CPL dentro da meta** -> **mantenha e escale** o orçamento gradualmente (não dobre de uma vez; +20-30% por vez para não reiniciar o aprendizado).
- **CPL muito acima e nada melhora após testes de criativo e landing** -> **pause** e reavalie oferta/público/canal.

**4. Ao escalar, vigie a degradação.** Aumentar orçamento pode subir o CPL (público satura). Acompanhe e, se o CPL passar da meta, segure.

---

## Painel mínimo para acompanhar

- **CTR** — o anúncio chama? (problema de criativo)
- **CPC / custo por visita** — quanto custa o clique
- **Taxa de conversão da landing** — a landing converte? (problema de landing)
- **CPL** — custo por e-mail capturado (a métrica-chave do topo)
- **CAC** — custo por cliente pagante
- **LTV** e **LTV/CAC** — a campanha é sustentável? (>= 3 é o alvo)

Decida sempre comparando contra a **sua meta de CPL derivada do LTV** — não contra benchmark genérico. A decisão é sua; o número só te dá a clareza para tomá-la.
