# Tipos de resumo

Cada tipo de fonte pede uma estrutura. Use a que serve ao objetivo (passo 1 do procedimento), não a mais bonita.

---

## 1. Reunião / call → Ata

**Quando:** transcrição de reunião, call, daily, alinhamento, áudio de conversa de trabalho.

**Pra quê serve:** registrar o que foi decidido e garantir que ações tenham dono e prazo. Ata sem responsável não é ata — é anotação.

**Estrutura:**

```
# Ata — [assunto] — [data]
Participantes: [quem estava]

## Decisões
- [o que foi decidido]
- [...]

## Ações
| O quê | Responsável | Prazo |
|---|---|---|
| [ação] | [nome] | [data] |

## Pontos em aberto
- [o que ficou sem definição — quem decide, quando]

## Observações
- [contexto relevante que não é decisão nem ação]
```

**Exemplo:**

```
# Ata — Lançamento do app v2 — 12/06/2026
Participantes: Rodrigo, Marina, Téo

## Decisões
- Lançamento adiado de 20/06 para 04/07 para incluir login social.
- Stack de pagamento fechada: Stripe (descartado Mercado Pago por causa do payout).

## Ações
| O quê | Responsável | Prazo |
|---|---|---|
| Integrar login Google/Apple | Téo | 27/06 |
| Revisar copy da landing | Marina | 25/06 |
| Aprovar orçamento de tráfego | Rodrigo | 18/06 |

## Pontos em aberto
- Preço do plano anual: discutido, não fechado. Rodrigo decide até 20/06.

## Observações
- Marina sinalizou risco de a Apple demorar na aprovação da loja.
```

> Regra: se a transcrição não disse o prazo de uma ação, escreva "Prazo: a definir" — não chute uma data.

---

## 2. Artigo / relatório → Pontos-chave

**Quando:** artigo, paper, relatório, post longo, ou qualquer texto que argumenta ou informa.

**Pra quê serve:** captar a tese e os argumentos sem reler o original. Bom para repassar, estudar ou decidir se vale ler o inteiro.

**Estrutura:**

```
# [Título do material] — pontos-chave

**Tese / ideia central:** [uma frase]

**Pontos principais:**
- [argumento ou achado 1]
- [argumento ou achado 2]
- [...]

**Dados que sustentam:**
- [número, fonte, métrica citada no texto]

**Conclusão / recomendação do autor:**
- [a que ponto o texto chega]

**Ressalvas:**
- [limitações ou condições que o próprio texto aponta]
```

**Exemplo:**

```
# "IA não substitui engenharia" (relatório interno) — pontos-chave

**Tese:** ferramentas de IA aceleram código, mas erram em segurança e não dispensam revisão humana.

**Pontos principais:**
- 41% do código gerado por IA tinha pelo menos uma falha de segurança (amostra do estudo citado).
- Os erros mais comuns foram validação ausente e exposição de segredos.
- Revisão humana derrubou as falhas críticas para perto de zero.

**Dados que sustentam:**
- Amostra de 400 trechos, período de 6 meses (segundo o relatório).

**Conclusão do autor:** adotar IA com protocolo de revisão obrigatório antes de produção.

**Ressalvas:**
- O relatório não informa quais modelos foram testados.
```

---

## 3. Transcrição de vídeo → Roteiro ou post

**Quando:** transcrição de aula, palestra, podcast, Reels, YouTube — material falado que vira conteúdo escrito.

**Pra quê serve:** transformar fala (que é dispersa e cheia de muleta) em texto aproveitável: um roteiro reorganizado ou um post.

**Estrutura (post):**

```
# [Tema do vídeo]

**Gancho:** [a frase ou ideia mais forte do vídeo]

**Desenvolvimento:**
- [ponto 1 dito no vídeo]
- [ponto 2]
- [...]

**Fechamento:** [a conclusão ou call do vídeo]
```

**Estrutura (roteiro reorganizado):**

```
# Roteiro — [tema]
1. [bloco de abertura — qual ideia abre]
2. [bloco de desenvolvimento]
3. [bloco de fechamento]
(cada bloco com a ideia central, na ordem que faz sentido — não na ordem em que foi falado)
```

**Exemplo (post):**

```
# Por que "rápido com IA" não é "pronto com IA"

**Gancho:** velocidade da IA esconde o custo de revisar o que ela escreveu.

**Desenvolvimento:**
- A IA entrega em minutos o que levava horas — isso é real.
- Mas entrega também o erro em minutos, e com cara de certo.
- Quem aceita sem ler troca tempo de digitação por tempo de debug.

**Fechamento:** a IA é o estagiário mais rápido do mundo; a revisão continua sua.
```

> A fala tem repetição e "né, tipo, então". O roteiro/post corta isso e mantém só a ideia. Mas não inventa uma frase de efeito que o autor não disse — reorganizar ≠ criar.

---

## 4. Documento / contrato / proposta → Resumo executivo

**Quando:** documento longo e formal — contrato, proposta comercial, brief, política, edital.

**Pra quê serve:** dar a quem decide o suficiente para decidir, sem ler 20 páginas. Curto, factual, com os números e as condições.

**Estrutura:**

```
# Resumo executivo — [nome do documento]

**Do que se trata:** [1-2 frases]

**Pontos principais:**
- [cláusula / termo / valor relevante]
- [...]

**Números:** [valores, prazos, percentuais]

**Condições e ressalvas:** [o que está condicionado, exceções, multas]

**O que exige decisão / atenção:** [o que o leitor precisa aprovar, recusar ou questionar]
```

**Exemplo:**

```
# Resumo executivo — Proposta Fornecedor X

**Do que se trata:** desenvolvimento de app mobile, 4 meses, entrega em fases.

**Pontos principais:**
- Escopo: iOS + Android, backend incluso, design não incluso.
- Pagamento: 30% entrada, 40% no MVP, 30% na entrega.

**Números:** R$ 120 mil total. Prazo: 16 semanas. Garantia: 90 dias.

**Condições e ressalvas:**
- Multa de 20% por cancelamento após o início.
- Design contratado à parte (não incluso no valor).

**O que exige decisão:**
- Aprovar ou não o pagamento de 30% adiantado.
- Definir quem entrega o design (ponto não coberto pela proposta).
```

> Resumo executivo é o tipo mais perigoso para alucinação: quem lê toma decisão de dinheiro em cima dele. Todo número tem que bater com o documento. Na dúvida, cite a página/cláusula.
