# O que nunca cortar

Resumir é cortar. Mas existe um núcleo que, se sai, o resumo deixa de ser útil — ou pior, engana. Este é o checklist do que sempre preservar e do que pode ir embora.

## Sempre preservar

### 1. Decisões
O que foi decidido, aprovado, recusado, adiado ou descartado. Inclui o que **não** foi feito de propósito ("descartamos o Mercado Pago"). Uma decisão omitida faz o leitor refazer a discussão.

### 2. Números
Valores, prazos, datas, percentuais, métricas, quantidades. Número é o que menos tolera paráfrase: "vários" não substitui "41%", "logo" não substitui "até 27/06". Copie o número como está na fonte.

### 3. Ações e responsáveis
Quem faz o quê, até quando. Ação sem dono não acontece; prazo sem dono não cobra ninguém. Se a fonte cita a ação mas não o responsável, preserve a ação **e marque** que o responsável não foi definido.

### 4. Ressalvas, condições e exceções
"Desde que", "exceto", "só se", "mas", "no entanto", "salvo". São poucas palavras que invertem o sentido. "Aprovado" e "aprovado se o orçamento sair" são decisões diferentes. Cortar a condição é distorcer.

### 5. Riscos e divergências
O risco que alguém levantou, a discordância que não foi resolvida, o "isso pode dar problema". Some o sinal de alerta e o leitor anda sem ele.

### 6. Nomes próprios que ancoram responsabilidade ou fonte
Quem decidiu, quem se opôs, qual fornecedor, qual cláusula. São o que torna o resumo auditável contra a fonte.

## Pode sair

- **Small talk e cortesia** — saudações, agradecimentos, "bom te ver".
- **Repetição** — a mesma ideia dita três vezes vira uma linha.
- **Muletas de fala** — "né", "tipo", "então", "é... ", hesitações.
- **Tangentes mortas** — assuntos que surgiram e não viraram decisão nem ação.
- **Processo sem efeito** — "vamos marcar outra call", a menos que isso *seja* a ação.
- **Exemplos redundantes** — mantenha o mais claro, corte os demais.
- **Detalhe de implementação irrelevante para o leitor** — depende do público (passo 1).

## A regra de ouro

> Na dúvida entre cortar e manter algo que **muda o sentido ou a decisão**, mantenha.

Resumo enxuto demais que omite uma ressalva é pior que resumo um pouco mais longo que a preserva. O custo de uma linha a mais é baixo; o custo de uma decisão tomada com informação faltando é alto.

## Teste rápido antes de entregar

Pergunte de cada item que você **cortou**: "se o leitor soubesse só do resumo, ele decidiria diferente do que decidiria com a fonte inteira?" Se sim, você cortou demais.
