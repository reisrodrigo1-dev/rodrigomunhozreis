# Anti-alucinação

Num resumo, inventar é o pior erro possível — pior que cortar demais. O leitor confia que tudo ali veio da fonte. Se você preenche uma lacuna com suposição, ele toma decisão em cima de algo que ninguém disse, e não tem como saber.

A regra única: **só entra no resumo o que estava na fonte.**

## Por que resumir tende a alucinar

- A fonte deixou algo implícito e você "completa" o raciocínio.
- A fonte foi ambígua e você escolhe a interpretação mais provável — e some a dúvida.
- Falta um dado (um prazo, um responsável) e o vazio incomoda, então você preenche.
- Você parafraseia um número e ele muda no caminho.
- Você junta dois pontos distantes e cria uma relação de causa que a fonte não afirmou.

Todos têm a mesma raiz: trocar "o que foi dito" por "o que provavelmente quis dizer". Não faça isso.

## Técnicas

### 1. Cite a fonte, não a memória
Resuma a partir do texto à frente, não do que você acha que o texto dizia. Para números, decisões e citações, volte ao trecho e copie. Quando útil (documentos formais, contratos), referencie: "(cláusula 4)", "(min. 12 da call)".

### 2. Marque a lacuna em vez de preencher
Faltou um dado que deveria estar? Diga que faltou. Não invente um valor plausível.

- ✅ "A fonte não define o prazo da entrega."
- ✅ "Ação registrada, mas sem responsável atribuído."
- ❌ "Entrega provavelmente em 30 dias." (ninguém disse isso)

Uma seção **Lacunas / a confirmar** no fim do resumo é melhor que um resumo que finge estar completo.

### 3. Sinalize incerteza, não a esconda
A fonte foi ambígua? Mantenha a ambiguidade visível.

- ✅ "Não ficou claro se o desconto vale para o plano anual ou só o mensal."
- ❌ Escolher uma das versões e apresentar como fato.

### 4. Separe o que a fonte diz do que você infere
Se uma inferência for realmente útil, marque-a como sua e à parte do resumo.

- ✅ "A fonte não conclui isso, mas os dois pontos sugerem [X] — vale confirmar."
- ❌ Embutir a inferência no meio dos fatos como se fosse da fonte.

### 5. Não crie causa nem relação que a fonte não afirma
"A foi dito" e "B foi dito" não viram "A causou B". Junte pontos só quando a fonte fez a ligação.

### 6. Preserve a força original
Não suba nem desça o tom. "Talvez a gente considere" não vira "decidimos". "Está aprovado" não vira "provavelmente aprovado". O verbo da fonte é o verbo do resumo.

### 7. Número é literal
Copie valores como estão. Não arredonde, não converta, não troque por adjetivo ("muito", "pouco", "alto") a menos que a fonte tenha usado o adjetivo.

## Frases-modelo para lacuna e incerteza

- "A fonte não informa [X]."
- "Não ficou claro [X]; a fonte permite duas leituras."
- "Ação sem responsável definido."
- "Prazo: a definir (não consta na fonte)."
- "O documento menciona [X], mas não detalha."
- "[X] foi citado, mas não confirmado na reunião."

## Checagem final

Antes de entregar, releia cada afirmação do resumo e pergunte: **"onde, na fonte, está isso?"** Se você não consegue apontar o trecho, a frase sai do resumo ou vira uma lacuna marcada.

A decisão final é de quem conhece o contexto. O resumo entrega o essencial e é honesto sobre o que faltou — quem decide é o usuário.
