---
name: sintese
description: Resume conteúdo longo preservando o essencial e sem inventar; use ao resumir transcrição, reunião, artigo, documento ou converter algo longo em pontos-chave.
---

# Síntese

Resumir não é encurtar. É **decidir o que importa**.

Qualquer um corta texto pela metade. O trabalho real é separar o que sustenta uma decisão do que é só preenchimento — e fazer isso sem distorcer nem inventar. Um resumo ruim não é o longo demais; é o que omite a única coisa que o leitor precisava saber, ou o que afirma algo que a fonte nunca disse.

Esta skill faz parte da suíte **Engenho** (vibecoding com engenharia). Irmãs:
- **Forja** — constrói prompts.
- **Pena** — escreve posts de autoridade.
- **Garimpo** — pesquisa na web com fontes.

Síntese cuida do oposto da pesquisa: você já tem o material (longo demais) e precisa do que importa.

## Princípio

Um resumo tem dono e tem propósito. Antes de cortar uma linha, saiba **pra quê** e **pra quem** ele serve. O mesmo arquivo de uma hora de reunião vira coisas diferentes dependendo de quem lê: pro time, vira ata com ações; pra diretoria, vira três bullets de decisão; pro histórico, vira registro neutro. Resumir sem objetivo é só apertar texto — e aperta as coisas erradas.

A regra inegociável: **só entra no resumo o que estava na fonte.** Se faltou, marca a lacuna. Não preenche com suposição. (Detalhe em `reference/anti-alucinacao.md`.)

## Quando usar

- Transcrição de reunião, call ou áudio → vira ata ou pontos-chave.
- Artigo, relatório ou paper longo → vira pontos-chave ou resumo executivo.
- Transcrição de vídeo/aula → vira roteiro, post ou resumo.
- Documento extenso (contrato, proposta, brief) → vira resumo executivo.
- Qualquer "li/assisti/recebi algo grande e preciso do que importa".

Não use para: criar conteúdo novo (isso é Pena ou Forja), ou pesquisar fora do material dado (isso é Garimpo).

## Procedimento

### 1. Definir o objetivo

Antes de ler a fonte inteira, responda:
- **Pra quê serve o resumo?** Decidir algo, registrar, divulgar, estudar, repassar pra alguém?
- **Pra quem?** Quem lê define o nível de detalhe e a linguagem. Diretoria quer decisão e número; time de execução quer ação e prazo.
- **Qual o tamanho aceitável?** Três bullets, uma página, uma ata? Defina o teto antes — senão o resumo cresce sozinho.

Se o usuário não disse, **pergunte**. Resumir sem objetivo gera retrabalho.

### 2. Extrair o essencial

Leia a fonte caçando estes elementos (e só estes, por enquanto):

- **Decisões** — o que foi decidido, fechado, aprovado, descartado.
- **Ações e responsáveis** — quem faz o quê, até quando.
- **Dados e números** — valores, prazos, métricas, percentuais, nomes próprios.
- **Conclusões e recomendações** — a que ponto a fonte chegou.
- **Ressalvas e riscos** — condições, exceções, "desde que", "exceto", divergências.

Marque cada um conforme encontra. O que não cai em nenhuma dessas categorias é candidato a ruído.

Detalhe do que nunca pode sair: `reference/o-que-nunca-cortar.md`.

### 3. Descartar o ruído

Pode sair, em geral:
- Saudações, small talk, agradecimentos, repetições.
- Tangentes que não viraram decisão nem ação.
- Exemplos redundantes (mantenha um, corte os demais).
- Discussão de processo que não mudou a conclusão ("vamos marcar outra call").

Cuidado: cortar ruído ≠ cortar nuance. Uma ressalva curta ("aprovado, mas só se o orçamento sair") não é ruído — é o que muda a decisão. Na dúvida entre cortar e manter algo que altera o sentido, mantenha.

### 4. Escolher o formato de saída

O formato segue o objetivo (passo 1) e o tipo de fonte. Tabela rápida:

| Fonte | Saída padrão |
|---|---|
| Reunião / call | Ata: decisões + ações + responsáveis + prazos |
| Artigo / relatório | Pontos-chave |
| Transcrição de vídeo | Roteiro ou post |
| Documento / contrato / proposta | Resumo executivo |

Estruturas e exemplos prontos de cada um: `reference/tipos-de-resumo.md`.

### 5. Regra anti-alucinação

Antes de entregar, revise contra a fonte:
- Toda afirmação do resumo está na fonte? Se não, **corte**.
- Faltou dado que deveria estar (um prazo, um responsável)? **Marque a lacuna** — não invente.
- Alguma coisa estava ambígua na fonte? **Sinalize a incerteza**, não escolha uma versão e finja certeza.

Frases-modelo: "A fonte não define o prazo." / "Não ficou claro quem assume X." / "O documento menciona Y, mas não detalha."

Técnicas completas: `reference/anti-alucinacao.md`.

## Entrega

Entregue o resumo no formato escolhido e, quando houver, uma seção curta **Lacunas / a confirmar** listando o que faltou na fonte. Feche lembrando que a revisão final é de quem conhece o contexto: **a decisão é sua.**
