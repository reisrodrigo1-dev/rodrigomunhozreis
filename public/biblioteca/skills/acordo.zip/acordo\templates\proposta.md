# Proposta — [Nome do projeto] para [Cliente]

> Modelo preenchível. Substitua tudo entre `[colchetes]`. Apague os comentários em _itálico cinza_ antes de enviar. Mantenha a ordem: problema → solução → escopo → investimento → próximos passos. O preço só aparece depois do valor.

---

**Para:** [Nome do cliente / empresa]
**De:** [Seu nome / sua marca]
**Data:** [dd/mm/aaaa]
**Validade:** esta proposta vale por [15] dias, até [dd/mm/aaaa].

---

## 1. O que você precisa resolver

_(Reafirme o problema e o objetivo do cliente, na língua dele. Mostre que você entendeu. Esta é a seção mais importante.)_

Hoje, [descreva o problema com as palavras do cliente — o que dói, no dia a dia]. Na prática, isso custa [tempo/dinheiro/clientes — o custo do problema, se você souber].

O que você quer alcançar é [o objetivo: onde ele quer chegar]. É disso que esta proposta trata.

---

## 2. O caminho que eu proponho

_(A solução e, principalmente, o resultado. Lidere pelo resultado; tecnologia em uma frase.)_

Com o que está descrito aqui, você passa a [resultado principal — o destino, em linguagem de cliente].

Como isso acontece:

- **[Resultado 1]** — [o que muda para ele]. _(o "como"/ferramenta em uma frase, se útil)_
- **[Resultado 2]** — [o que muda para ele].
- **[Resultado 3]** — [o que muda para ele].

_(Honestidade aumenta confiança:)_ O que esta solução **não** se propõe a resolver agora: [limite claro — fica para uma fase 2, ou está fora].

---

## 3. Escopo — o que está incluído

_(Entregáveis concretos, com quantidades. Não atividades vagas.)_

**Inclui:**

- [Entregável 1 — concreto e quantificado, ex.: "3 páginas: home, serviços, contato"]
- [Entregável 2]
- [Entregável 3]
- [Até X rodadas de ajustes]

**NÃO inclui** _(o que evita briga depois — liste o que o cliente pode estar imaginando que vem junto):_

- [Item fora, ex.: produção de textos]
- [Item fora, ex.: fotos / banco de imagens]
- [Item fora, ex.: manutenção mensal após a entrega]
- [Item fora, ex.: integrações além das listadas]

_(Itens de fora podem virar uma fase 2 ou um orçamento à parte — combinamos quando fizer sentido.)_

**O que preciso de você** _(responsabilidades do cliente — atraso aqui adia a entrega):_

- [Ex.: textos e logo enviados até dd/mm]
- [Ex.: aprovação de cada etapa em até X dias úteis]
- [Ex.: acessos necessários (domínio, hospedagem, etc.)]

---

## 4. Investimento

_(O preço só aqui, depois do valor. Ancore no custo do problema. Escolha UMA das opções abaixo e apague a outra.)_

**Lembrando:** hoje [retome o custo do problema — ex.: "esse processo manual te custa ~10h por semana"]. O investimento para resolver isso:

### Opção A — valor fechado

**[R$ X.XXX]** pelo escopo completo descrito acima.
**Condição:** [ex.: 50% no aceite, 50% na entrega] · [formas de pagamento aceitas].

### Opção B — três opções _(use quando fizer sentido oferecer tiers; destaque a do meio)_

| | **Essencial** | **Recomendado** ⭐ | **Completo** |
|---|---|---|---|
| **Entrega** | [o núcleo que resolve] | [Essencial + o que importa] | [Recomendado + extras] |
| **Inclui** | [itens] | [itens] | [itens] |
| **Investimento** | [R$ X] | **[R$ Y]** | [R$ Z] |

**Condição de pagamento:** [ex.: 50% no aceite, 50% na entrega] · [formas aceitas].

---

## 5. Prazo e como funciona

- **Prazo de entrega:** [X dias/semanas], contados a partir de [o aceite / o recebimento dos materiais].
- **Como caminha:**
  1. [Kickoff / alinhamento]
  2. [Primeira entrega]
  3. [Ajustes — até X rodadas]
  4. [Publicação / entrega final]

---

## 6. Próximos passos

Para começarmos, é simples:

> **[Responda este e-mail com "fechado"]** e eu te envio [o contrato + a primeira fatura / o link de pagamento]. _(Um passo só, fácil.)_

Qualquer ponto desta proposta pode ser ajustado — me chame que conversamos. Esta proposta vale até **[dd/mm/aaaa]**.

---

## Sobre mim

_(Curto, no fim. Só o que importa para este cliente e este problema.)_

[2 a 4 linhas: quem você é, por que confiar, e — se tiver — um resultado de cliente parecido.]

---

_[Seu nome] · [contato] · [site/portfólio]_
