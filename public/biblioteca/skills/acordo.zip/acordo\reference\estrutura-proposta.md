# Estrutura de uma proposta que fecha

Uma proposta não é um documento burocrático nem uma tabela de preço com cabeçalho bonito. É uma **peça de venda** com um trabalho claro: levar o cliente do "me conta o que você faz" até o "fechado". Cada seção existe para mover ele um passo nessa direção. Seção que não move, corta.

A ordem importa tanto quanto o conteúdo. A regra que rege tudo: **o valor vem antes do preço.** Quem inverte isso transforma a proposta num susto.

Abaixo, as seções na ordem em que aparecem, o que vai em cada uma e — o mais importante — **por que** ela está ali.

---

## A ordem das seções (resumo)

1. Capa / abertura
2. O problema e o objetivo (do cliente)
3. A solução e o resultado esperado
4. Escopo: o que inclui e o que NÃO inclui
5. Investimento (preço)
6. Prazo e como funciona
7. Próximos passos + validade
8. Sobre você (curto, no fim)

A ossatura: **entendo você → tenho o caminho → aqui está o que entrego → quanto custa → como funciona → o que fazer agora.** Tudo o que não serve a essa sequência é gordura.

---

## 1. Capa / abertura

**O que vai:** nome do cliente, nome do projeto, sua marca, data. Uma frase de abertura que já é sobre ele, não sobre você.

**Por quê:** a primeira impressão é de profissionalismo e de foco no cliente. Personalizar com o nome dele e do projeto sinaliza, já na capa, que isto foi feito *para ele* — não um modelo genérico colado às pressas.

**Cuidado:** nada de "Proposta Comercial nº 0042". Prefira "Proposta — Novo site para a [Cliente]". Humano vende mais que protocolo.

---

## 2. O problema e o objetivo (do cliente)

**O que vai:** o resumo, na língua do cliente, do problema que ele tem hoje e do objetivo que ele quer alcançar. Dois a três parágrafos curtos. Use as palavras que *ele* usou na reunião.

**Por quê:** esta é a seção mais importante e a que quase ninguém faz direito. Quando o cliente lê o próprio problema descrito com precisão, ele pensa "esse aqui me entendeu" — e a confiança que faz a venda nasce ali, antes de qualquer preço. Você não vende a solução; vende a sensação de ter sido compreendido.

**Como fazer bem:**
- Separe **problema** (o que dói agora) de **objetivo** (onde ele quer chegar). Ex.: *problema:* "cada orçamento toma 2 horas e sai com cara amadora"; *objetivo:* "fechar mais rápido e passar profissionalismo".
- Sempre que possível, dê o **custo do problema**: "isso são ~10h por semana e alguns clientes que desistem na demora". Isso prepara a ancoragem do preço lá na frente.
- Não invente. Se você não consegue escrever esta seção com convicção, você não entendeu o problema — volte e pergunte.

**Cuidado:** não pule para a solução aqui. Esta seção é 100% sobre a dor e o destino dele.

---

## 3. A solução e o resultado esperado

**O que vai:** o caminho que você propõe e, principalmente, **onde ele chega** com isso. Lidere pelo resultado; a tecnologia entra em uma frase.

**Por quê:** o cliente compra o destino, não a estrada. "Você passa a gerar orçamento em 5 minutos, com a sua identidade, e o cliente recebe na hora" vende. "Sistema em Next.js com banco Firestore" não vende — assusta ou entedia.

**Como fazer bem:**
- Comece cada bloco pelo resultado, não pela entrega. *Resultado primeiro, mecanismo depois.*
- Amarre cada parte da solução a um pedaço do problema da seção 2. Nada de funcionalidade que não resolve nada que ele citou.
- Seja honesto sobre limites: "isto resolve a geração e o envio; relatórios avançados ficam para uma fase 2". Honestidade sobre o que *não* faz aumenta a credibilidade do que faz.

**Cuidado:** não vire um catálogo de features. Três a cinco blocos de resultado bastam.

---

## 4. Escopo: o que inclui e o que NÃO inclui

**O que vai:** duas listas. **Inclui** (entregáveis concretos) e **Não inclui** (o que fica de fora). Mais as **premissas / responsabilidades do cliente**.

**Por quê:** esta seção evita 90% das brigas pós-venda. A maior parte do atrito em projeto não vem do que foi combinado — vem do que **cada lado imaginou** sem combinar. Escrever o "não inclui" hoje é mais barato que discutir depois.

**Como fazer bem:**
- **Inclui:** entregáveis, não atividades. "3 páginas: home, serviços, contato" e não "desenvolvimento de páginas". Conte itens e quantidades — número fecha porta.
- **Não inclui:** liste justamente o que o cliente pode estar supondo que vem junto: redação dos textos, fotos, manutenção mensal, integrações extras, treinamento, hospedagem. Cada item de fora vira um possível upsell — não uma surpresa.
- **Responsabilidades do cliente:** "você fornece os textos e logo até [data]". Atraso de cliente é a causa nº 1 de projeto estourado; deixe escrito de quem é a bola.
- **Rodadas de revisão:** diga quantas estão inclusas (ex.: "até 2 rodadas de ajustes"). Sem isso, "só mais um ajustezinho" vira infinito.

**Cuidado:** este escopo é a base do contrato no **Pacto**. Quanto mais claro aqui, mais simples e mais protetor lá.

---

## 5. Investimento (preço)

**O que vai:** o valor. Uma opção fechada ou os tiers (essencial / recomendado / completo). Detalhe completo de *como apresentar* está em `precificacao-na-proposta.md`.

**Por quê:** aparece só agora, **depois** de o cliente já ter visto problema, caminho e escopo. Nessa posição, o número é a consequência lógica do valor — não um susto no início.

**Como fazer bem (resumo — veja a referência de preço):**
- Ligue o número ao **resultado**, nunca a "X horas".
- Quando der, retome o **custo do problema** logo antes do preço, para ancorar.
- Ofereça **opções** quando couber, e destaque a recomendada.
- Inclua o que está incluso no valor, em uma linha, para reforçar a entrega.

**Cuidado:** não dilua o preço em uma planilha de itens com valor unitário a menos que o cliente exija — isso convida a negociar item por item e some com a percepção de valor.

---

## 6. Prazo e como funciona

**O que vai:** prazo de entrega (ou as fases, com marcos), e o passo a passo de como o trabalho acontece (ex.: kickoff → primeira entrega → ajustes → publicação).

**Por quê:** reduz a ansiedade do "e depois que eu pagar, o que acontece?". Mostrar o processo passa controle e profissionalismo, e baliza expectativa de tempo antes de virar reclamação.

**Como fazer bem:**
- Dê prazos por **fase** quando o projeto é grande; um prazo único quando é pequeno.
- Amarre prazo às **premissas** da seção 4 ("contado a partir do recebimento dos textos").
- Seja realista. Prazo apertado para impressionar vira promessa quebrada — e cliente lembra mais do atraso que da agilidade prometida.

---

## 7. Próximos passos + validade

**O que vai:** o que o cliente faz para fechar (um passo só), a forma de pagamento, e a validade da proposta.

**Por quê:** uma proposta sem próximo passo morre na caixa de entrada. O cliente fica com a boa impressão e... não faz nada, porque não sabe o que fazer. Você precisa dizer.

**Como fazer bem:**
- **Um próximo passo, fácil:** "responda 'fechado' e eu envio o contrato e a primeira fatura" ou "agende 15 min aqui [link]". Um caminho, não três.
- **Validade real:** "esta proposta vale por 15 dias". Cria urgência honesta e te protege de honrar o mesmo preço meses depois. Nunca urgência falsa.
- **Pagamento:** condição (ex.: 50% no início, 50% na entrega), formas aceitas.
- Ofereça-se para ajustar: a proposta é começo de conversa, não ultimato.

---

## 8. Sobre você (curto, no fim)

**O que vai:** três a cinco linhas sobre quem você é e por que confiar em você. Prova social, se tiver (resultado de cliente anterior, número que importe).

**Por quê:** importa, mas **não na frente.** Ninguém compra do seu "quem somos" — compra de quem entendeu o problema. Por isso a bio vai no fim, depois de você já ter provado valor. Vai antes só se a confiança ainda for o maior obstáculo da venda.

**Como fazer bem:** foco no que é relevante para *este* cliente e *este* problema. Um case parecido vale mais que dez anos de história.

---

## Erros comuns que derrubam a proposta

- **Virar tabela de preço.** Abrir pelo número, sem problema nem valor antes. O cliente rola até o preço, assusta, fecha.
- **Começar por "quem somos".** Três parágrafos sobre você antes de uma palavra sobre o cliente. Ele não está procurando você — está procurando resolver o problema dele.
- **Escopo só de "inclui".** Sem o "não inclui", todo desentendimento futuro joga contra você.
- **Solução em tecnês.** Listar stack e features em vez de resultado. Vende o destino, não o motor.
- **Sem próximo passo.** Termina com "qualquer dúvida estou à disposição" e morre ali. Diga o que fazer.
- **Sem validade.** Proposta eterna não cria movimento e te prende a um preço velho.
- **Genérica.** O mesmo PDF para todo cliente, sem o nome e o problema dele. Dá pra sentir, e mata a confiança.

---

A proposta que fecha tem uma só lógica por trás de toda seção: **entendo você, tenho o caminho, aqui está o que entrego, quanto custa, e o que fazer agora.** Nessa ordem. A decisão é do cliente — o seu trabalho é deixar o sim fácil e o valor claro.
