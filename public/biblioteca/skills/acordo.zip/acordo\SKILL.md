---
name: acordo
description: cria propostas comerciais e orçamentos — problema, solução, escopo, preço e próximos passos; use ao montar uma proposta, orçamento ou apresentação comercial para um cliente.
---

# Acordo

O Acordo monta **propostas comerciais e orçamentos que fecham** — na voz do Rodrigo Munhoz Reis, autor da linha "vibecoding com engenharia". O público é founder ou prestador que vende serviço ou produto e precisa transformar uma conversa de venda em um documento que o cliente lê, entende e aprova.

A voz é PT-BR, direta, sem hype. Trata o cliente como adulto inteligente, mostra que você entendeu o problema dele e oferece um caminho. Sem promessa mágica, sem encher linguiça. A decisão é sempre do cliente.

## Visão geral

A maioria das propostas perde a venda por um erro só: **viram tabela de preço cedo demais.** O cliente abre, rola até o número, leva um susto e fecha o PDF. Não comprou porque nunca entendeu o que estava comprando.

Uma proposta que fecha faz o contrário. Ela primeiro **prova que você entendeu o problema** — repete na sua própria língua o que o cliente te contou, e ele pensa "esse cara me entendeu". Depois mostra **o caminho e o resultado** que vem dele. Só então fala de preço — e a essa altura o preço já não é um susto, é a consequência lógica do valor que você acabou de mostrar.

Regra-mãe do Acordo: **foque no resultado, não nas horas.** O cliente não está comprando 40 horas de trabalho nem "um site". Está comprando o lugar onde ele quer chegar — mais clientes, menos retrabalho, um problema que para de doer. A proposta vende esse lugar. A hora é detalhe seu, não argumento de venda.

```
conversa de venda (o cliente te contou a dor)
   -> 1. você reafirma o problema/objetivo dele   (ele se sente entendido)
   -> 2. apresenta a solução e o resultado esperado (ele vê o destino)
   -> 3. delimita o escopo: o que inclui e o que NÃO (ninguém briga depois)
   -> 4. mostra o preço ancorado no valor          (o número faz sentido)
   -> 5. dá os próximos passos + validade           (ele sabe o que fazer agora)
```

## A suíte Engenho

O Acordo é a peça de **proposta comercial** da suíte Engenho. As irmãs:

- **Decolagem** — preço e modelo de negócio. *Quanto cobrar e por qual modelo* se decide lá. O Acordo só **apresenta** o preço; quem **define** o preço é a Decolagem. Se você ainda não sabe quanto vale o seu trabalho, resolva isso antes de montar a proposta.
- **Correio** — e-mails e nutrição. O e-mail que **acompanha** o envio da proposta, e o follow-up depois, é Correio.
- **Pacto** — contrato. Depois que a proposta é **aceita**, o Pacto formaliza juridicamente o que foi combinado. Proposta vende e alinha expectativa; contrato protege as duas partes. O escopo bem-feito no Acordo vira a base do contrato no Pacto.

Regra prática: **Decolagem decide o preço; Acordo apresenta a proposta; Pacto formaliza o acordo; Correio entrega e dá follow-up.**

## Quando usar esta skill

Use o Acordo quando o usuário quiser:

- **Montar uma proposta comercial** para um cliente (serviço, projeto, produto).
- **Fazer um orçamento** que não seja só um número solto num WhatsApp.
- **Estruturar uma apresentação comercial** depois de uma reunião de venda.
- **Reescrever uma proposta** que não está fechando (geralmente porque virou tabela de preço).
- **Criar opções/tiers** (básico / recomendado / completo) para deixar o cliente escolher.
- **Definir o escopo** do que entra e do que não entra, para evitar briga depois.

Não use para: definir **quanto** cobrar do zero (isso é Decolagem, `reference/monetizacao-e-preco.md`); escrever o **contrato** jurídico (isso é Pacto); ou escrever o **e-mail** que leva a proposta (isso é Correio).

## Como usar a base

Antes de montar a proposta, leia o arquivo de `reference/` relevante. Eles têm a estrutura, o raciocínio e os exemplos na voz do Rodrigo.

| Arquivo | Use quando for |
|---|---|
| `reference/estrutura-proposta.md` | Entender quais seções uma proposta que fecha tem, o que vai em cada uma e o porquê. Leia este PRIMEIRO. |
| `reference/precificacao-na-proposta.md` | Decidir **como apresentar** o preço: ancorar no valor (não nas horas), montar 3 opções/tiers, não cobrar de menos. Link com a Decolagem. |
| `templates/proposta.md` | Pegar o modelo preenchível e adaptar para o cliente. |

## PROCEDIMENTO

Cinco passos, nesta ordem. A ordem é o segredo — quase toda proposta ruim inverte os dois primeiros com o quarto (fala de preço antes de mostrar valor).

### 1. Reafirme o problema e o objetivo do cliente

Comece **pelo cliente, não por você.** Repita, na sua língua, o que ele te contou: a dor, o contexto, onde ele quer chegar. Isso faz duas coisas: prova que você ouviu (e ninguém compra de quem não entendeu o problema) e ancora o resto da proposta no que importa pra ele.

- Use as palavras dele. Se ele disse "tô perdendo cliente porque meu site é lento", a proposta diz isso — não "otimização de performance".
- Separe o **problema** (o que dói hoje) do **objetivo** (onde ele quer chegar). Ex.: problema = orçamentos feitos na mão tomam 2h cada; objetivo = fechar mais rápido e parecer profissional.
- Se você não consegue reafirmar o problema com clareza, **você ainda não entendeu** — volte e pergunte antes de propor. Proposta sobre problema mal entendido não fecha.

### 2. Apresente a solução e o resultado esperado

Agora mostre **o caminho** e, principalmente, **onde ele chega.** Não descreva a tecnologia — descreva o resultado.

- Lidere pelo resultado: "você passa a fechar orçamento em 5 minutos, com a sua cara, e o cliente recebe na hora". A *como* (a ferramenta, a stack) vem depois e em uma frase.
- Conecte cada parte da solução a um pedaço do problema do passo 1. Nada de solução órfã que não resolve nada que ele citou.
- Seja honesto sobre o que a solução **não** resolve. Isso aumenta a confiança, não diminui.

### 3. Delimite o escopo: o que inclui e o que NÃO inclui

Aqui se evita 90% das brigas pós-venda. Escreva o que está **dentro** e — igualmente importante — o que está **fora**.

- **Inclui:** liste entregáveis concretos, não atividades vagas. "3 páginas (home, serviços, contato)" e não "desenvolvimento web".
- **Não inclui:** liste o que o cliente pode estar imaginando que vem junto e não vem (ex.: produção de textos, fotos, manutenção mensal, integrações extras). O que fica de fora vira upsell ou um item negociável — não uma surpresa raivosa.
- Defina **premissas e responsabilidades do cliente** (ex.: "o conteúdo dos textos é fornecido por você até a data X"). Atraso de cliente é a causa nº 1 de projeto estourado.
- Esse escopo é a base do contrato no **Pacto**. Quanto melhor aqui, mais simples lá.

### 4. Apresente o preço, ancorado no valor

O preço só aparece **depois** que o valor já foi mostrado. Detalhe completo em `reference/precificacao-na-proposta.md`. O essencial:

- **Valor, não horas.** Apresente o investimento ligado ao resultado do passo 2, nunca como "X horas a R$ Y". O cliente compra o destino, não o cronômetro.
- **Ancore.** Quando fizer sentido, lembre o custo de *não* resolver (o que o problema custa por mês hoje) antes de mostrar o número. O preço passa a parecer pequeno perto do problema.
- **Opções/tiers quando couber.** Três opções (essencial / recomendado / completo) deixam o cliente decidir *o quê comprar* em vez de *se compra*. Destaque a do meio. Veja a referência para quando usar e quando não.
- **Não cobre de menos.** O erro nº 1 de quem vem da técnica. Quanto cobrar é decisão da **Decolagem** (`reference/monetizacao-e-preco.md`); o Acordo só garante que o número apareça com a moldura certa.
- Use a palavra **investimento** quando ela for honesta (há retorno claro); senão, "valor" ou "preço" mesmo. Sem eufemismo forçado.

### 5. Próximos passos + validade

Termine dizendo **o que fazer agora.** Uma proposta sem próximo passo morre na caixa de entrada.

- **Próximo passo único e fácil:** "responda este e-mail com 'fechado' e eu te mando o contrato e a primeira fatura" / "agende 15 min aqui [link]". Não dê três caminhos — dê um.
- **Validade:** dê um prazo real ("esta proposta vale por 15 dias"). Cria urgência honesta e te protege de ter que honrar um preço daqui a seis meses. Nada de urgência falsa.
- **Forma de pagamento e prazo de entrega:** deixe claro o "como paga" e o "quando fica pronto". Reduz a fricção do sim.
- Diga que você está disponível para ajustar. A proposta é um começo de conversa, não um ultimato.

## Regras

- **Comece pelo cliente, não por você.** A primeira seção é o problema dele, não o seu "quem somos". Bio fica no fim, curta.
- **Resultado acima de horas.** Venda o destino. Hora e tarefa são o seu custo interno, não o argumento do cliente.
- **Preço depois do valor.** Nunca abra a proposta pelo número. O preço é a última coisa, ancorada no que veio antes.
- **Escopo com "não inclui" explícito.** O que fica de fora, escrito, evita a briga depois. Silêncio no escopo é dívida futura.
- **Um próximo passo só.** Diga exatamente o que fazer para fechar. Um caminho, fácil.
- **Validade sempre.** Toda proposta tem prazo. Protege você e move o cliente.
- **Sem hype.** Sem "solução revolucionária", "transformação completa", "parceria de sucesso". Descreva o que entrega e o resultado real.
- **Não cobre de menos por insegurança.** Na dúvida, ancore no valor e defenda o número. (Preço se decide na Decolagem.)
- **A decisão é do cliente.** Mostre o problema, o caminho, o valor e o passo seguinte — e respeite o "não", o "vou pensar" e o pedido de ajuste.

---

O Acordo mostra que você entendeu o problema e tem o caminho — e só então fala de preço. Vende o resultado, delimita o escopo, dá o próximo passo. A decisão é do cliente.
