# Como apresentar o preço na proposta

Atenção ao recorte: este arquivo é sobre **como apresentar** o preço dentro da proposta. **Quanto** cobrar — a estratégia de precificação, o modelo, o número em si — é decisão da **Decolagem** (`reference/monetizacao-e-preco.md`). Defina o preço lá; apresente-o bem aqui.

A diferença entre uma proposta que fecha e uma que assusta muitas vezes não está no número — está na **moldura** do número. O mesmo R$ 8.000 pode soar como um roubo ou como uma pechincha, dependendo do que veio antes dele e de como ele é mostrado.

---

## Princípio 1 — Valor, não horas

O cliente não compra horas. Compra o **resultado** que as horas produzem. Precificar e apresentar por hora tem três problemas:

1. **Pune sua eficiência.** Quanto mais rápido e melhor você fica, *menos* você ganha pela mesma entrega. Absurdo.
2. **Convida o cliente a auditar seu tempo.** "Por que 40 horas e não 30?" vira a conversa — e você perde, porque ninguém tem como provar a hora.
3. **Some com o valor.** "R$ 200/h × 40h" faz o cliente pensar no seu *custo*. "Sistema que te faz fechar orçamento em 5 min em vez de 2h" faz ele pensar no *ganho dele*. Só um desses vende.

**Na proposta:** apresente um **valor fechado pelo resultado**. "Investimento: R$ 8.000 pelo sistema completo de orçamentos." Ponto. A quantidade de horas é o seu custo interno — não entra na conversa de venda.

Exceções legítimas: contratos de manutenção contínua ou consultoria avulsa às vezes pedem hora/mês. Mesmo aí, ancore num resultado ("X horas/mês de suporte que mantêm o sistema no ar e evoluindo"), nunca na hora seca.

---

## Princípio 2 — Ancoragem: mostre o custo do problema antes do preço

O cérebro avalia preço por **comparação**, não em absoluto. Se o primeiro número que o cliente vê é o seu, ele compara com zero — e tudo parece caro. Se antes ele lembrou quanto o problema custa, o seu preço compara com *isso* — e parece pequeno.

**Como ancorar na proposta:**
- Retome, logo antes do preço, o **custo de não resolver**, que você já levantou lá na seção do problema. "Hoje, cada orçamento toma 2h e alguns clientes desistem na demora — são umas 10h por semana e vendas que escorrem."
- *Depois* mostre o número: "O investimento para resolver isso de vez é R$ 8.000."
- Agora R$ 8.000 não compete com zero. Compete com "10h por semana para sempre" e "vendas perdidas". Fica barato.

A ancoragem não é truque sujo: você só está lembrando ao cliente o que ele já sabe mas tende a esquecer na hora de olhar o preço. O problema dele é real; o custo dele é real.

Quando usar tiers (próximo princípio), o **tier mais caro também ancora**: ver a opção completa primeiro faz a recomendada parecer razoável.

---

## Princípio 3 — Opções / tiers (quando fizer sentido)

Oferecer **três opções** muda a pergunta na cabeça do cliente de *"compro ou não?"* para *"qual delas?"*. É uma das alavancas mais fortes de uma proposta — quando cabe.

**O modelo clássico — três tiers:**

| Tier | Papel | Como montar |
|---|---|---|
| **Essencial** | Âncora baixa e porta de entrada | O mínimo que resolve o problema central. Faz o do meio parecer completo. |
| **Recomendado** (destaque) | É o que você quer vender | O equilíbrio: resolve bem, com o que importa. Marque visualmente como "recomendado". |
| **Completo** | Âncora alta | O recomendado + extras de quem quer o melhor. Faz o do meio parecer econômico. |

**Regras dos tiers:**
- **Destaque o do meio.** A maioria foge dos extremos e escolhe o central — desenhe os três para que o central seja o que você quer vender.
- **Diferencie por valor, não só por preço.** Cada tier entrega um resultado a mais, não "o mesmo com desconto". O cliente precisa enxergar o que ganha subindo de nível.
- **Três, no máximo.** Quatro ou mais paralisa. A escolha vira difícil e a difícil vira "vou pensar".
- **Faça o recomendado ser o óbvio.** Pequena diferença de preço para um salto grande de valor empurra para cima de forma honesta.

**Quando NÃO usar tiers:**
- Projeto pequeno e bem definido — uma opção fechada é mais limpa e fecha mais rápido.
- Quando os tiers seriam artificiais (você teria que *piorar* de propósito o essencial só para ter três). Cliente sente, e fica feio.
- Quando o cliente já sabe exatamente o que quer. Aí dar opção atrasa o sim.

---

## Princípio 4 — Não cobre de menos

Este é o erro nº 1 de quem vem da técnica, e merece seção própria. As causas:

- **Ancorar no próprio custo**, não no valor para o cliente. "Levei pouco tempo, então cobro pouco." Errado: o cliente paga pelo resultado, não pelo seu esforço. Se você resolve em 2h um problema que vale R$ 10.000 para ele, o preço se ancora nos R$ 10.000, não nas 2h.
- **Insegurança / síndrome do impostor.** "Quem sou eu para cobrar isso?" Você é quem resolve o problema. Esse é o preço.
- **Medo de ouvir não.** Cobrar barato para "garantir" a venda atrai o pior cliente (o que só quer barato), aperta sua margem e desvaloriza seu trabalho aos olhos do próprio cliente — preço baixo demais sinaliza pouca qualidade.

**Antídotos na hora de apresentar:**
- Na dúvida entre dois preços, comece pelo **mais alto que você defende com cara séria.** É muito mais fácil baixar do que subir.
- Ancore sempre no valor (Princípio 2). Defender o número fica fácil quando o custo do problema está na mesa.
- Lembre: alguns "nãos" por preço são **saudáveis.** Se *todo mundo* aceita na hora, você está barato demais. Um pouco de fricção no preço é sinal de que ele está no ponto.

> A definição do número é da **Decolagem**. Se a insegurança do preço persiste, o trabalho é lá — `reference/monetizacao-e-preco.md`. O Acordo só garante que, qualquer que seja o número, ele apareça com a moldura que faz justiça ao valor.

---

## Princípio 5 — A palavra e a forma

- **"Investimento" vs. "preço".** Use **investimento** quando há retorno claro e demonstrável (o cliente ganha/economiza com isso) — é honesto e reposiciona o gasto como aplicação. Quando o retorno não é tão direto, use "valor" ou "preço" mesmo. Não force eufemismo: cliente esperto sente, e soa a vendedor.
- **Não fatie o preço em planilha de itens** com valor unitário, a menos que o cliente exija. Detalhar item a item convida a negociar item a item ("tira isso aqui que economiza R$ 300") e dissolve a percepção de valor do conjunto.
- **Mostre a condição de pagamento** junto ao preço (ex.: 50% no aceite, 50% na entrega; ou 3x). Facilitar o "como paga" reduz a fricção do "sim".
- **Um número em destaque.** Mesmo com tiers, o olho precisa pousar em um valor por opção, claro e sem letra miúda escondendo taxa. Surpresa no preço mata confiança.

---

## Checklist rápido de apresentação de preço

- [ ] O preço aparece **depois** do problema, da solução e do escopo — nunca antes.
- [ ] Está ligado ao **resultado**, não a horas/tarefas.
- [ ] O **custo do problema** foi relembrado logo antes (ancoragem).
- [ ] Se usei tiers: são **três**, o do meio está em **destaque**, e cada um entrega valor a mais.
- [ ] O número é o **mais alto que eu defendo com tranquilidade** (não cobrei de menos por medo).
- [ ] A **condição de pagamento** está clara junto ao valor.
- [ ] "Investimento" só onde é honesto; senão, "valor/preço".
- [ ] Sem planilha de itens convidando a negociação miúda (a menos que pedida).

---

A moldura faz metade da venda. O mesmo número soa caro ou justo conforme o que vem antes dele. Apresente pelo valor, ancore no custo do problema, ofereça opções quando couber e não se cobre de menos. O número quem define é a Decolagem; a justiça do número quem faz é a apresentação. A decisão é do cliente.
