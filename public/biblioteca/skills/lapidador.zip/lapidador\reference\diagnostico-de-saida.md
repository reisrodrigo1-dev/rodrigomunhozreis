# Diagnóstico de saída — do sintoma à instrução de refino

Catálogo de referência. Você nomeia o que está ruim na resposta da IA e pega a instrução de refino pronta. Cada entrada tem: o **sintoma** (como você percebe), a **causa** (por que aconteceu), a **instrução de refino** (o que mandar), e um **exemplo pronto** para copiar e adaptar.

Regra que vale para todas: **ancore no que ficou bom antes de pedir a mudança.** O modelo tende a reescrever tudo se você não disser o que preservar. Comece a instrução com "Mantém [o que serve], mas...".

E ataque **um problema por vez**. Se a resposta tem três defeitos, escolha o pior, conserte, e volte a este catálogo para o próximo.

---

## 1. Genérico / vago demais

**Sintoma:** a resposta serve pra qualquer pessoa, qualquer empresa, qualquer caso. Cheia de "é importante", "depende", "varia muito". Você lê e não aprende nada novo.

**Causa:** o modelo não tinha contexto específico, então deu a média de tudo que já viu. Genérico é o estado padrão de uma IA sem ancoragem.

**Instrução de refino:** dê o contexto que faltou e/ou peça um exemplo concreto. Genérico quase sempre se conserta com **especificidade**, não com "seja mais específico" (isso também é genérico).

> Está na direção certa, mas ficou genérico — serve pra qualquer um. Refaz aplicando ao meu caso: [seu contexto concreto: quem é, o que vende, pra quem, qual a situação real]. Troca cada afirmação genérica por um exemplo do meu cenário.

Se você não tem mais contexto pra dar, force o concreto assim:

> Refaz isso com um exemplo concreto e inventado para cada ponto. Em vez de "use uma boa headline", mostra uma headline de exemplo. Prefiro um exemplo específico (mesmo que eu precise adaptar) a um conselho genérico.

---

## 2. Longo demais

**Sintoma:** a resposta tem três parágrafos onde cabia uma frase. Introdução que repete a pergunta, conclusão que repete a introdução, qualificações desnecessárias.

**Causa:** o modelo associa "completo" a "longo" e enche linguiça quando não tem limite.

**Instrução de refino:** dê um **limite numérico** (palavras, frases, bullets) — limite vago ("mais curto") gera corte tímido. E diga o que cortar.

> Bom conteúdo, mas longo demais. Corta pela metade. Tira a introdução e a conclusão, vai direto ao ponto, e deixa cada item em no máximo 1 frase.

> Resume isso em no máximo 5 bullets, um por linha, sem explicação. Só o essencial.

Se o tamanho está certo mas há *gordura*:

> O tamanho está ok, mas tem enrolação. Mantém os mesmos pontos e o mesmo tamanho, mas corta toda frase que não acrescenta informação ("é importante notar", "vale ressaltar", etc.).

---

## 3. Curto / raso demais

**Sintoma:** a resposta é uma lista de tópicos sem desenvolvimento. Você queria entender e ficou com mais perguntas.

**Causa:** o modelo entregou o esqueleto e parou. Falta o "como" e o "por quê".

**Instrução de refino:** peça desenvolvimento **onde** você quer, não em tudo.

> Esse esqueleto está bom, mas raso. Desenvolve cada item em um parágrafo: explica o porquê e dá um exemplo prático. Pode triplicar o tamanho.

> Pega só o item 3 e aprofunda: me explica passo a passo, como se eu nunca tivesse feito isso.

---

## 4. Tom errado

**Sintoma:** está formal demais (ou informal demais), corporativo, robótico, com hype ("revolucionário!", "incrível!"), infantil, ou simplesmente "não soa como eu".

**Causa:** você não especificou o tom, então o modelo usou o tom médio da internet — que costuma ser ou corporativo neutro ou empolgado de marketing.

**Instrução de refino:** especifique o **tom** E o **público**. Tom sem público é vago; público ancora o tom.

> O conteúdo está certo, mas o tom está corporativo demais. Reescreve como se você estivesse explicando pra um amigo inteligente que não é da área: direto, sem jargão, sem "soluções inovadoras". Pode usar "você".

> Tira todo o hype. Nada de "revolucionário", "incrível", exclamação. Tom seco e honesto, como um técnico que respeita o leitor. Se algo tem ressalva, diz a ressalva.

Dica forte: **dê um exemplo do tom que você quer.** "Escreve no tom *deste* texto: [cola um parágrafo que você gosta]." Exemplo de tom vale mais que adjetivo de tom.

---

## 5. Superficial — faltou profundidade ou o passo a passo

**Sintoma:** a resposta diz *o que* fazer mas não *como*. "Otimize seu funil" sem dizer como. Conselho de capa de revista.

**Causa:** o modelo ficou no nível da abstração que você usou. Pergunta abstrata, resposta abstrata.

**Instrução de refino:** peça o **passo a passo executável** — o teste é "consigo fazer isso lendo a resposta, sem pesquisar mais nada?".

> Isso está no nível do conselho. Transforma em um passo a passo que eu consiga executar: numerado, cada passo uma ação concreta, com o que fazer em cada um. Assume que eu nunca fiz isso.

> Aprofunda: para cada recomendação, me diz *como* fazer na prática e *como saber* se deu certo.

---

## 6. Formato errado

**Sintoma:** você queria tabela e veio texto corrido. Queria JSON e veio prosa com JSON no meio. Queria lista e veio um parágrafo.

**Causa:** você descreveu o conteúdo mas não travou o formato. Formato é a coisa que o modelo mais "esquece".

**Instrução de refino:** **defina o formato exato** — colunas da tabela, chaves do JSON, estrutura da lista. Mostre o esqueleto se puder.

> Mesmo conteúdo, outro formato. Põe em tabela com as colunas: [Coluna A] | [Coluna B] | [Coluna C]. Uma linha por item. Nada de texto antes ou depois da tabela.

> Devolve só JSON válido, sem nenhum texto fora do bloco, neste formato exato: {"campo1": "", "campo2": [], "campo3": 0}.

Se o formato quebra toda vez, **dê um exemplo preenchido** do formato — é o conserto mais confiável.

---

## 7. Alucinou / inventou / ignorou o que você deu

**Sintoma:** a resposta cita um fato, número, fonte, função ou citação que não existe — ou ignora o documento/dados que você forneceu e responde "de cabeça".

**Causa:** o modelo preenche lacunas com o que é plausível, não com o que é verdadeiro. E, sem instrução, ele prioriza o conhecimento geral dele sobre o material que você colou.

**Instrução de refino:** **ancore no material** e peça que marque incerteza. Esta é a correção mais importante — alucinação não é estilo, é defeito.

> Você inventou parte disso. Refaz usando SOMENTE o material que eu te dei acima. Se a resposta não estiver no material, escreve "não consta" em vez de preencher. Não use conhecimento externo.

> Para cada afirmação de fato (número, data, citação), aponta de onde ela veio no texto que te passei. Se você não consegue apontar a fonte, remove a afirmação.

Se foi código/biblioteca inventada:

> Você usou uma função/biblioteca que pode não existir. Reescreve usando só recursos que você tem certeza que existem em [linguagem/versão], e marca qualquer ponto que eu deva verificar antes de rodar.

---

## 8. Faltou uma parte do que você pediu

**Sintoma:** você pediu três coisas e veio duas. Ou a resposta cobre o tema mas pula o ângulo que mais importava.

**Causa:** pedidos com várias partes "perdem" itens, principalmente o último ou o do meio. Quanto mais coisas no mesmo prompt, mais cai.

**Instrução de refino:** não refaça tudo — **peça só o que faltou** e mande encaixar.

> A resposta ficou boa, mas faltou [a parte que faltou]. Não refaz o resto. Só acrescenta essa parte, no mesmo tom, e me diz onde ela encaixa.

---

## 9. Contradiz algo anterior / saiu do trilho

**Sintoma:** depois de algumas rodadas, a resposta começou a contradizer uma decisão que já estava fechada, ou voltou a um problema que você já tinha corrigido.

**Causa:** em conversas longas, o modelo dá mais peso à última mensagem e "esquece" restrições antigas.

**Instrução de refino:** **re-ancore** as decisões fechadas.

> Lembra das regras que valem o tempo todo: [lista curta das decisões fixas]. Mantém TODAS elas. Agora ajusta só [o ponto da vez].

Se a conversa virou um nó, é sinal de parar de remendar: pegue a melhor versão até aqui, comece um chat novo, cole essa versão como ponto de partida e siga do zero limpo.

---

## Tabela-resumo

| Sintoma | Instrução-chave |
|---|---|
| Genérico | Dê contexto específico / peça exemplo concreto |
| Longo | Limite numérico + diga o que cortar |
| Raso/curto | Peça desenvolvimento onde importa |
| Tom errado | Especifique tom + público (ou dê exemplo de tom) |
| Superficial | Peça passo a passo executável |
| Formato errado | Defina o formato exato (mostre o esqueleto) |
| Alucinou | "Use só o material; se não consta, diga que não consta" |
| Faltou parte | Peça só o que faltou, sem refazer o resto |
| Saiu do trilho | Re-ancore as decisões fixas; se piorou, recomece limpo |
