# Técnicas de refino

O `diagnostico-de-saida.md` te dá a instrução para cada problema específico. Este arquivo te dá as **técnicas** — formas mais espertas de conduzir a conversa de refino quando a instrução direta não basta, ou quando você não sabe exatamente o que pedir.

Todas seguem o mesmo princípio: **refinar é uma conversa, não um comando único.** Você guia, o modelo responde, você ajusta. Use a técnica certa para o momento.

---

## 1. Pedir variações (quando você não sabe o que quer)

Às vezes você sente que a resposta não está boa mas não consegue nomear o problema. Em vez de tentar consertar no escuro, peça **opções** e use a sua reação a elas como bússola.

> Me dá 3 versões disso com abordagens bem diferentes entre si. Não explica, só as três. Eu escolho qual seguir.

Por que funciona: é mais fácil reconhecer o que você quer do que descrever do zero. A versão que te agrada revela o critério que você não tinha verbalizado — aí você pede "segue na linha da 2, mas...".

Variações úteis de pedir: uma mais curta e uma mais longa; uma mais formal e uma mais solta; uma segura e uma ousada; uma que ataca o problema por outro ângulo.

**Quando usar:** no começo do refino, quando o diagnóstico está difícil. **Quando não usar:** quando você já sabe o problema — aí variação só adia a correção.

---

## 2. Mandar o modelo criticar a própria resposta

O modelo costuma ser melhor **avaliando** do que **acertando de primeira**. Use isso: peça que ele critique a própria saída antes de melhorá-la.

> Antes de melhorar: aponta os 3 pontos mais fracos dessa resposta que você acabou de dar. Depois reescreve corrigindo esses 3 pontos.

Variações fortes:

> Lê isso como se fosse [meu público / um cliente cético / meu chefe]. O que faria essa pessoa não gostar ou não acreditar? Corrige esses pontos.

> Que pergunta óbvia essa resposta deixou sem responder? Responde ela.

Por que funciona: força o modelo a sair do papel de "autor que defende o texto" para o de "revisor que ataca o texto" — e revisor encontra problemas que o autor não vê.

**Cuidado:** às vezes ele inventa "fraquezas" só para ter o que dizer e piora o que estava bom. Leia a crítica antes de aceitar a reescrita. Se a crítica for boba, ignore.

---

## 3. Refinar por partes (não a resposta inteira)

Quando a resposta é grande e só um pedaço está ruim, **não refaça tudo** — você perde o que estava bom e introduz novos defeitos. Isole o trecho.

> A resposta está boa. Mexe SÓ no terceiro parágrafo: ele está vago. Reescreve só ele com um exemplo concreto. Deixa o resto exatamente como está.

Para textos longos, refine em ordem de impacto: primeiro a estrutura geral, depois seção por seção, por último o acabamento (tom, palavras). Não lapide a frase de um parágrafo que talvez você vá cortar inteiro.

Por que funciona: cada rodada tem um alvo pequeno e verificável. É a diferença entre "melhora isso" (o modelo mexe em tudo) e "conserta essa peça" (cirurgia).

---

## 4. Dar um exemplo do que você quer

A instrução mais poderosa do refino não é um adjetivo — é um **exemplo**. "Mais profissional" é vago; um parágrafo que você considera profissional não é.

> Reescreve no estilo deste exemplo: "[cola aqui um trecho que você gosta, seu ou de outra fonte]". Quero esse tom e esse nível de detalhe.

> Aqui está uma resposta sua que ficou ótima numa outra vez: "[exemplo]". Refaz a atual no mesmo padrão.

Funciona para tom, formato, nível de detalhe, estrutura — quase tudo. O exemplo carrega dezenas de decisões implícitas que você nunca conseguiria escrever como regra.

**Quando usar:** sempre que tom ou formato estiverem "quase lá" e você tiver (ou conseguir achar) um modelo do que quer. É a técnica que mais economiza rodadas.

---

## 5. Ancorar no que funcionou

Toda boa instrução de refino tem duas metades: **o que manter** e **o que mudar**. A maioria das pessoas só escreve a segunda — e o modelo, livre, reescreve também a primeira.

> Está ótimo no tom e na estrutura — não mexe nisso. Só ajusta os números, que estão errados.

Quando uma rodada acertar algo difícil, **nomeie e fixe** antes de seguir:

> Perfeito esse parágrafo de abertura, congela ele. Agora trabalha só no resto mantendo a mesma energia da abertura.

Por que funciona: protege o progresso. Sem âncora, refino é dois passos à frente e um de lado — você conserta uma coisa e quebra outra que estava boa.

---

## 6. Refino por restrição (apertar o cerco)

Quando a resposta está "quase" mas escorregadia, adicione **uma restrição por rodada** e veja o efeito.

> Mesma resposta, mas agora sem usar a palavra "solução" nenhuma vez.

> Refaz cabendo em um print de celular — no máximo 6 linhas.

Cada restrição força o modelo a ser mais deliberado. É útil quando o conteúdo está certo mas a forma está frouxa.

---

## Como escolher a técnica

| Situação | Técnica |
|---|---|
| Não sei nomear o problema | Pedir variações (1) |
| Sei que tem algo errado, quero achar | Autocrítica (2) |
| Só um pedaço está ruim | Refinar por partes (3) |
| Tom/formato "quase lá" e tenho um modelo | Dar um exemplo (4) |
| Acertei algo e não quero perder | Ancorar no que funcionou (5) |
| Conteúdo certo, forma frouxa | Refino por restrição (6) |

Você pode combinar: o normal é **ancorar no que funcionou (5) + uma correção cirúrgica por partes (3)**. Esse par é o cavalo de batalha do refino.
