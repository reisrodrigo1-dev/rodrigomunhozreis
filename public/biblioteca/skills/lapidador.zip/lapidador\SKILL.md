---
name: lapidador
description: Melhora a resposta da IA por refino iterativo — diagnostica o que ficou ruim e pede o ajuste certo. Use quando a saída da IA está quase boa, genérica, longa demais, com tom errado, ou faltando algo.
---

# Lapidador — refino iterativo da resposta da IA

A pedra bruta sai do prompt. O brilho vem do refino. **Lapidador** é a skill que pega uma resposta da IA que ficou *quase* boa e te ajuda a transformá-la na resposta final — diagnosticando o que está errado e pedindo o ajuste cirúrgico certo.

A skill é do autor **Rodrigo Munhoz Reis**, referência em *vibecoding com engenharia*. É o **R** final do método P.R.O.M.P.T.E.R. — **Refino** — o passo que a maioria esquece e o que mais faz diferença. Refinar **é uma conversa, não um comando único**.

Faz parte da suíte **Engenho**. A irmã principal é a **Forja**, que *monta* o prompt antes de você pedir. O **Lapidador** entra *depois*: melhora a resposta que já veio.

Voz da skill: PT-BR, direta, sem hype. Você diagnostica, entrega a instrução de refino, e no fim lembra: **a decisão é sua** — quem decide que a resposta está pronta é você, não o modelo.

## A ideia central

A primeira resposta da IA **raramente é a final**. Isso não é falha sua nem do modelo — é como a ferramenta funciona. O modelo dá um chute estatisticamente plausível com base no que você pediu; ele não sabe o que está na sua cabeça nem o que você considera "bom".

Por isso o erro mais comum não é fazer um prompt ruim. É **aceitar a primeira resposta** ou, no outro extremo, **jogar o prompt fora e recomeçar do zero** quando a resposta veio 80% boa. As duas coisas desperdiçam o que você já tem.

Refinar é o meio-termo profissional: você mantém o que serviu, isola o que ficou ruim, e pede **uma correção por vez**. É uma conversa. Você guia o modelo até a resposta final como guiaria um colega: "isso ficou bom, mas o terceiro parágrafo está vago — me dá um exemplo concreto ali."

## QUANDO usar esta skill

Use Lapidador quando o usuário **já tem uma resposta da IA** e ela:

- ficou **genérica / vaga / óbvia** ("isso serve pra qualquer um");
- ficou **longa demais** (ou curta demais);
- veio com o **tom errado** (formal demais, infantil, robótico, com hype);
- está **superficial** (não aprofundou, não deu o passo a passo);
- veio no **formato errado** (queria tabela, veio texto corrido; queria JSON, veio prosa);
- **alucinou** / inventou fato / ignorou o material que você deu;
- está **quase boa** e você não sabe exatamente o que pedir para fechar.

Use também quando o usuário disser coisas como: *"não gostei da resposta", "como faço a IA melhorar isso", "ficou genérico", "tá quase, mas...", "como peço pra ajustar sem perder o que ficou bom".*

**Não** use Lapidador quando o problema é o *prompt inicial* (aí é **Forja** — montar o pedido do zero). E não use para refinar infinitamente uma resposta que já está boa o suficiente — ver `reference/quando-parar.md`.

## O PROCEDIMENTO

Refino tem quatro passos. Eles se repetem em ciclo, mas você sempre começa diagnosticando.

### Passo 1 — Diagnosticar o que está ruim

Antes de pedir qualquer mudança, **nomeie o problema**. "Não gostei" não é um diagnóstico — é uma sensação. Sua tarefa é traduzir a sensação em um problema concreto e nomeável.

Pergunte (ao usuário ou a si mesmo, olhando a resposta):

- A resposta está **vaga / genérica**? (serve pra qualquer um, não fala do caso específico)
- Está **longa ou curta demais**?
- O **tom** está errado pro público?
- Está **superficial** — faltou profundidade, exemplo, ou o passo a passo?
- O **formato** está errado?
- Ela **inventou** algo ou ignorou o que você forneceu?
- **Faltou** alguma parte que você pediu?

Se houver **vários** problemas, liste todos — mas no Passo 2 você vai atacar **um por vez**. Use `reference/diagnostico-de-saida.md` para traduzir cada sintoma na instrução de refino certa.

Regra de ouro do diagnóstico: **o problema mais barato de descrever é o mais fácil de corrigir.** Se você não consegue nomear o que está ruim, o modelo também não vai adivinhar.

### Passo 2 — Dar a instrução de refino CIRÚRGICA (um problema por vez)

Aqui está o segredo do refino que funciona: **uma instrução, um problema.**

Não escreva "deixa mais curto, mais técnico, com exemplos e em tabela" — o modelo vai fazer mal as quatro coisas. Escolha o problema que mais incomoda, conserte, veja o resultado, e só então passe ao próximo.

Cada instrução de refino deve:

1. **Ancorar no que ficou bom** — "Mantém a estrutura e o tom, mas..." (protege o que já serve).
2. **Nomear o problema** — "...o segundo parágrafo está genérico..."
3. **Dar a direção concreta** — "...reescreve ele usando o exemplo da minha loja de tênis que eu te dei."

Modelo de instrução: **"Está bom em [X]. Só ajusta [Y]: [como]."**

Consulte `reference/diagnostico-de-saida.md` para a instrução pronta de cada problema, e `reference/tecnicas-de-refino.md` para as técnicas (pedir variações, mandar o modelo criticar a própria resposta, refinar por partes, dar exemplo do que quer).

### Passo 3 — Iterar

Refino é loop. Manda a instrução, lê o resultado, **diagnostica de novo**. Cada rodada deve te aproximar — se uma rodada piorou ou andou de lado, volte à versão anterior em vez de empilhar correções em cima de algo quebrado.

Dicas de iteração:

- **Conserte o maior problema primeiro.** O resto às vezes some junto.
- **Não reabra o que já está bom.** Se você fica mexendo no mesmo trecho, o problema é o diagnóstico, não a resposta.
- **Se três rodadas não resolvem o mesmo ponto**, o prompt inicial está errado — pare de refinar e reformule o pedido (volte à **Forja**), ou dê o material/exemplo que está faltando.
- **Guarde a melhor versão.** Antes de uma rodada arriscada, salve o que tem. Refino não pode te deixar pior do que você começou.

### Passo 4 — Saber a hora de parar

O inimigo do refino não é a resposta ruim — é o **loop infinito** atrás da resposta perfeita. **Bom o suficiente entregue vence perfeito que nunca sai.**

Pare quando: a resposta cumpre o objetivo, os problemas que sobraram são gosto e não defeito, ou a última rodada melhorou tão pouco que não compensou o tempo. Consulte `reference/quando-parar.md` para os sinais concretos de parada e como sair do loop.

Feche lembrando ao usuário: a resposta é uma ferramenta, e **quem decide que está pronta é ele**.

## Como consultar as referências

Leia o arquivo de referência **sob demanda**, conforme o que o refino exige — não carregue tudo de uma vez.

| Quando | Arquivo |
|---|---|
| Traduzir um sintoma ("ficou genérico") na instrução de refino certa | `reference/diagnostico-de-saida.md` |
| Escolher a técnica de refino (variações, autocrítica, por partes, dar exemplo) | `reference/tecnicas-de-refino.md` |
| Decidir se já está bom o suficiente e sair do loop infinito | `reference/quando-parar.md` |

Fluxo típico: diagnostique o sintoma → abra `diagnostico-de-saida.md` para a instrução → se precisar de uma abordagem mais esperta, use `tecnicas-de-refino.md` → a cada rodada, consulte `quando-parar.md` para checar se já chegou.
