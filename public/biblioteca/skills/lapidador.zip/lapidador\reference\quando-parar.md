# Quando parar de refinar

O risco do refino não é a resposta ruim — é o **loop infinito** atrás da perfeita. Você refina, melhora 2%, refina de novo, melhora 1%, e gasta uma hora num texto que já estava pronto na terceira rodada. Pior: às vezes a rodada extra **piora**, porque você começa a trocar coisas boas por coisas "diferentes".

Esta é a regra que rege tudo: **bom o suficiente entregue vence perfeito que nunca sai.** Refinar é meio, não fim. O objetivo é a resposta cumprir o trabalho — não atingir um ideal que só existe na sua cabeça.

---

## O teste de "bom o suficiente"

Pare quando a resposta passar nestes três:

1. **Cumpre o objetivo.** Faz o que você precisava que fizesse. Se é um e-mail, dá pra enviar. Se é um plano, dá pra executar. Se é um código, roda.
2. **Não tem defeito, só tem gosto.** Os problemas que sobraram são preferências ("eu teria dito de outro jeito"), não erros (fato errado, parte faltando, tom impublicável). Gosto não é motivo pra mais uma rodada — é motivo pra você editar a mão em 30 segundos, se quiser.
3. **O custo de mais uma rodada não compensa.** Se o tempo de refinar de novo é maior que o tempo de só ajustar você mesmo, ou maior que o ganho real, acabou.

Se passou nos três: **está pronto.** Entregue.

---

## Sinais de que você deve parar AGORA

- **A última rodada melhorou pouco.** Duas rodadas seguidas com ganho marginal = curva achatou. O próximo refino quase não vai mudar nada.
- **Você está trocando, não melhorando.** As versões estão ficando *diferentes*, não *melhores*. Sinal claro de que você cruzou o ponto ótimo e está só remexendo.
- **Você já reescreveu o mesmo trecho 3+ vezes.** O problema não é a resposta — é o seu critério, que não está definido. Pare e decida o que você realmente quer antes de pedir de novo (ou aceite a melhor versão que já saiu).
- **Você não lembra mais por que começou a refinar.** Se você não consegue dizer em uma frase o que ainda falta, não falta nada de concreto.
- **Você está refinando por ansiedade, não por necessidade.** "Será que dá pra melhorar?" sempre dá. A pergunta certa é "isso já serve?". Quase sempre a resposta é sim antes de você achar.

---

## Quando NÃO é hora de parar (continue)

Para não confundir "bom o suficiente" com preguiça — não pare se:

- Ainda há um **defeito objetivo**: fato errado/inventado, parte do pedido faltando, formato que não serve, tom impublicável pro contexto.
- A resposta **ainda não cumpre o objetivo** (o e-mail não dá pra enviar, o código não roda). Isso é defeito, não gosto.
- Você **nunca chegou a uma versão boa** — está refinando uma base ruim. Aqui o conselho é o oposto: pare de refinar e **recomece** (veja abaixo).

---

## O loop infinito tem duas saídas — e refinar de novo nem sempre é uma delas

Se você está há várias rodadas e não chega lá, o problema raramente é "preciso de mais uma instrução". Provavelmente é uma destas duas situações:

**a) O prompt inicial estava errado.** Se três rodadas não consertam o mesmo ponto, o problema está na raiz, não nos detalhes. Pare de lapidar. Volte e reformule o pedido do zero — é trabalho da **Forja** (montar o prompt), não do Lapidador. Refinar uma base errada é polir uma pedra que não é a que você queria.

**b) Falta material, não instrução.** Se a resposta fica genérica por mais que você peça especificidade, o que falta não é um comando melhor — é **contexto / dado / exemplo** que só você tem. Dê o material e a resposta destrava sozinha. Nenhuma instrução substitui informação que o modelo não tem.

Em ambos os casos, **mais uma rodada de refino não resolve.** Saber distinguir "refina mais" de "recomeça" ou "dá mais material" é o que separa quem usa IA com método de quem fica preso no loop.

---

## A última palavra é sua

O modelo nunca vai te dizer "está bom, pode parar" — ele sempre topa mais uma rodada, sempre acha o que mudar. Por isso **quem decide que a resposta está pronta é você, não a IA.** Ele entrega a pedra lapidada; você decide se ela brilha o suficiente.

Defina o "bom o suficiente" **antes** de começar a refinar, se conseguir: "preciso que isso esteja pronto pra enviar pro cliente", "preciso de um rascunho que eu termino a mão". Critério definido na largada é o melhor antídoto contra o loop infinito.
