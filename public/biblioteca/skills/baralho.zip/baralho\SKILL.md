---
name: baralho
description: estrutura carrosséis para Instagram e LinkedIn — capa-gancho, slides de desenvolvimento e CTA, 1 ideia por slide; use ao criar um carrossel ou transformar um conteúdo em sequência de slides
---

# Baralho

Carrossel é a arte de distribuir UMA ideia em cartas. Cada slide é uma carta: vira, entrega uma coisa, e te faz virar a próxima. O Baralho cuida da estrutura — slide a slide — de carrosséis para Instagram e LinkedIn.

Faz parte da suíte **Engenho**, ao lado de **Praça** (post avulso), **Pena** (blog/autoridade), **Atelier/Cânone** (design e marca) e **Claquete** (vídeo). O Baralho é o irmão do **carrossel**: quando o conteúdo precisa ser arrastado, ele entra.

Autor: **Rodrigo Munhoz Reis** — "vibecoding com engenharia". Voz PT-BR, direta, sem hype. A skill estrutura; a decisão é sua.

## Visão geral

Duas verdades governam um carrossel:

1. **O carrossel vende pela CAPA.** Se a capa não faz o dedo parar, o resto não existe. A capa é 80% do resultado. Ela tem um único trabalho: fazer parar e arrastar.
2. **O carrossel segura pela promessa de valor a cada slide.** A pessoa só arrasta se o slide anterior provou que vale a pena. Cada carta tem que pagar a próxima virada.

Regras de fábrica:

- **1 ideia por slide.** Se o slide tem dois pontos, vira dois slides. Carrossel não é parágrafo fatiado.
- **Pouco texto.** O slide é lido em 2-3 segundos no celular. Frase curta, fonte grande, respiro. Se precisa apertar os olhos, está errado — isso é tarefa do Atelier/Cânone, mas a estrutura já tem que prever.
- **Progressão.** Slide 3 só faz sentido depois do 2. Há uma linha que cresce: do problema à solução, do passo 1 ao passo N, da dor ao alívio.
- **A capa promete e o miolo entrega.** Capa que promete o que o miolo não cumpre é clickbait — e o algoritmo (e a audiência) pune.

## Quando usar

- Transformar um conteúdo (post, artigo, ideia solta) em sequência de slides.
- Criar um carrossel do zero para Instagram ou LinkedIn.
- Ensinar algo em passos, listar dicas, desmontar um mito, mostrar um antes/depois.
- Quando a ideia é boa demais para um print só, mas não dá um artigo inteiro.

**Quando NÃO usar:** se é uma frase de efeito ou um aviso rápido, é **Praça** (post avulso). Se é aprofundamento com SEO, é **Pena** (blog). Se é roteiro falado, é **Claquete**.

## Procedimento

### 1. A UMA ideia e o ângulo

Antes de pensar em slide, defina a frase única que o carrossel defende. Uma só. Se você não consegue dizer em uma frase o que a pessoa leva ao final, ainda não há carrossel — há um amontoado.

Pergunte:
- **Qual a UMA coisa que a pessoa sai sabendo/sentindo?** (a tese)
- **Para quem?** (o vibecoder que quer engenharia, não o dev sênior nem o leigo total)
- **Qual o ângulo?** O mesmo tema rende vários ângulos. "Testar código de IA" pode virar *lista de 5 testes*, *o erro que todo mundo comete*, *antes/depois de uma função sem teste*. Escolha **um** ângulo — ele decide o formato (veja `reference/tipos-de-carrossel.md`).

Saída desta etapa: uma frase de tese + um ângulo + o formato escolhido.

### 2. A capa = gancho

A capa faz parar e arrastar. Não é título de slide — é isca. Trabalhe a capa até ela passar no teste: *"se eu estivesse rolando o feed sem nada a ver com isso, eu pararia?"*

- Prometa um ganho claro e específico ("5 erros que fazem a IA gerar código inseguro"), não um tema vago ("falando sobre IA").
- Crie tensão ou curiosidade que só o miolo resolve.
- Deixe explícito que há mais — uma seta, um "arrasta →", um "(salva esse)". O Instagram/LinkedIn não avisa que é carrossel; a capa avisa.
- Os padrões de capa que funcionam — e os que não — estão em `reference/ganchos-de-capa.md`.

A capa é a única carta que pode (e deve) ser trabalhada à exaustão. Escreva 5 versões, escolha 1.

### 3. Slides de desenvolvimento

O corpo: **5 a 8 slides**, cada um com um ponto, em progressão. Regras:

- **Um ponto por slide.** Título curto + 1 a 3 linhas de apoio. Nada de bloco de texto.
- **Progressão real.** Slide N prepara o N+1. Numere quando fizer sentido (passo 1, 2, 3…) — número é uma promessa visual de que há fim, e isso segura o arrasto.
- **A ponte.** O fim de um slide deve abrir uma pergunta que o próximo responde. É a "ponte" que faz arrastar (detalhada em `reference/estrutura-carrossel.md`). Sem ponte, a pessoa para no slide 2.
- **Concretude.** Exemplo, número, antes/depois. O abstrato não segura; o específico sim.

A anatomia completa (quantos slides, quanto texto por slide, como construir a ponte) está em `reference/estrutura-carrossel.md`.

### 4. Slide final = CTA

O último slide pede **uma** ação. Só uma. A pessoa que chegou até aqui está engajada — é o momento de converter, não de despedir.

- Escolha o objetivo: salvar, comentar, seguir, compartilhar, ir para o link/bio. Um por carrossel.
- Amarre com a tese: relembre em uma linha o que ela aprendeu, depois peça a ação.
- O CTA pode pedir engajamento que o algoritmo premia (comentário, salvamento) OU encaminhar para o funil (link, isca — aí conversa com **Ima** e **Vitrine**).
- Evite o CTA genérico "curta e compartilhe". Dê um motivo: "Salva pra consultar na próxima vez que a IA te entregar código sem teste."

### 5. Nota de design

A estrutura está pronta; o visual fecha. Aqui o Baralho passa o bastão para **Atelier/Cânone**, mas deixa as âncoras:

- **Contraste:** a capa precisa saltar no feed. Texto legível sobre fundo — nunca cinza sobre cinza.
- **Hierarquia:** uma informação dominante por slide. O olho tem que saber onde pousar primeiro.
- **Consistência de marca:** mesma fonte, cor e grid em todos os slides. O carrossel é uma sequência, não 8 imagens soltas — a marca costura.
- **Affordance de arraste:** seta, número de slide, ou borda cortada na lateral que sugere "tem mais". 
- Para definir paleta, tipografia e o layout fino, **chame o Atelier (UI) ou o Cânone (decisão de design)**.

## Arquivos de referência

- `reference/estrutura-carrossel.md` — anatomia do carrossel: capa, corpo, CTA, quantos slides, texto por slide e a ponte que faz arrastar.
- `reference/tipos-de-carrossel.md` — formatos que funcionam (lista, passo a passo, mito vs verdade, erro→conserto, antes/depois, história) e quando usar cada.
- `reference/ganchos-de-capa.md` — padrões de capa que param o dedo, exemplos no tema do Rodrigo, e o que não fazer.
