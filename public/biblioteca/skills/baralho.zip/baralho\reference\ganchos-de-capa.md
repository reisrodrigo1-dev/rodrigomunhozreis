# Ganchos de capa

A capa decide 80% do resultado. Ela tem um trabalho só: **fazer o dedo parar e o polegar arrastar.** Não ensina, não resume — promete e provoca.

O teste de qualquer capa: *"se eu estivesse rolando o feed sem nada a ver com isso, eu pararia?"* Se a resposta é "talvez", reescreva.

Escreva 5 versões da capa e escolha 1. A capa é a única carta que merece esse esforço.

---

## Padrões que param o dedo

### 1. Número + ganho específico
O número promete fim (dá pra "terminar"), e o ganho diz por que vale.

- **5 testes que a IA não faz pelo seu código**
- **3 erros de segurança que o ChatGPT coloca no seu app**
- **7 prompts que mudaram como eu programo**

Por que funciona: específico, finito, com benefício claro.

### 2. O erro / o que não fazer
A mente é fisgada por ameaça. Mostrar o erro faz parar mais que mostrar o acerto.

- **O erro que faz a IA gerar código inseguro (e quase ninguém vê)**
- **Pare de aceitar código de IA sem fazer isso antes**
- **O que a IA não te conta sobre o código que ela escreve**

Por que funciona: cria a dúvida "será que eu cometo esse erro?".

### 3. Pergunta que abre um loop
Uma pergunta que a pessoa quer ver respondida — e a resposta está no arrasto.

- **Seu código de IA está pronto pra produção? Faça este teste.**
- **Por que o código "funciona" e ainda assim quebra em produção?**

Por que funciona: pergunta sem resposta na capa força o arrasto.

### 4. Contraste / antes-depois na capa
Promessa de transformação, dita no choque entre dois estados.

- **A mesma função, antes e depois de aplicar engenharia**
- **De "rodou na minha máquina" a deploy sem medo**

Por que funciona: a pessoa quer ver a ponte entre os dois estados.

### 5. Contra o senso comum
Desafia o que a maioria pensa. Atrito gera atenção.

- **Vibecoding não é "deixar a IA fazer". É o contrário.**
- **Testar código de IA não é perda de tempo — é o que te salva**

Por que funciona: quem concorda quer confirmar; quem discorda quer rebater. Os dois arrastam.

### 6. História / abertura de cena
Começa uma cena que a pessoa precisa ver terminar.

- **A IA me entregou um código lindo. Quase me custou um cliente.**
- **Sexta, 18h, deploy pronto. Então eu li uma linha que gelou meu sangue.**

Por que funciona: narrativa aberta é o gancho mais forte que existe — o cérebro odeia história sem fim.

### 7. Promessa de atalho / economia
Promete poupar tempo, dinheiro ou dor.

- **O checklist de 5 passos que me evita retrabalho com IA**
- **Revise código de IA em 2 minutos com este método**

Por que funciona: ganho com esforço baixo é irresistível.

---

## Sinalizar que é carrossel

A capa também precisa avisar que há mais — Instagram e LinkedIn não deixam óbvio. Use:

- Seta ou "**arrasta →**"
- O número ("5 erros" já diz que há 5 slides)
- Borda cortada na lateral (truque visual — fica com o Atelier/Cânone)
- "**(salva esse)**" no canto

Sem esse sinal, muita gente lê a capa e rola — perdendo o carrossel inteiro.

---

## O que NÃO fazer

### Capa vaga
O maior assassino de carrossel. Tema sem promessa.

- ❌ **Falando sobre IA e programação**
- ❌ **Dicas de produtividade**
- ❌ **Reflexões sobre tecnologia**

Não há ganho, não há tensão, não há motivo para parar. Conserto: troque o tema por uma promessa específica. "Dicas de produtividade" → "3 atalhos que cortam 1h do meu dia de código."

### Capa bonita-mas-muda
Design lindo, palavra nenhuma que faça parar. A estética não substitui a promessa. Uma capa premium com texto vago continua sendo capa vaga — só que cara. O design amplifica uma boa mensagem; ele não cria uma.

- ❌ Foto estética + uma palavra solta ("Inovação")
- ✅ A mesma estética + "O erro de segurança que a IA coloca no seu código"

### Capa que entrega tudo
Se a capa já diz a resposta, não há motivo para arrastar.

- ❌ **Sempre teste o caminho de erro do seu código** (pronto, acabou)
- ✅ **O teste que separa código de amador de código de produção** (e qual é? → arrasta)

### Clickbait que o miolo não cumpre
Capa que promete o que o conteúdo não entrega. Funciona uma vez; depois a audiência aprende a não confiar — e o algoritmo mede o arrependimento (gente que sai rápido).

- ❌ **O segredo que vai te fazer programar 10x mais rápido** → e o miolo é "use atalhos do VS Code"
- ✅ Prometa o que você realmente entrega. Tese honesta segura mais que promessa inflada.

### Hype
Contra a voz do Rodrigo. "Revolucionário", "vai explodir sua mente", "ninguém te conta" usado à toa. Direto e específico vence sensacionalista.

- ❌ **Esse PROMPT SECRETO vai REVOLUCIONAR sua vida 🤯🚀**
- ✅ **O prompt que eu uso pra IA não inventar dado**

---

## Regra final

Boa capa = **promessa específica + tensão + sinal de arraste**, na voz direta e sem hype. Se a capa cumpre os três e você pararia no feed alheio, ela está pronta. O resto do carrossel só precisa pagar o que a capa prometeu.
