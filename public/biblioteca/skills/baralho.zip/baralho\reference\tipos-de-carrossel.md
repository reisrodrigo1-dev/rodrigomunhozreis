# Tipos de carrossel

O ângulo escolhido na etapa 1 do procedimento decide o formato. Cada formato tem uma estrutura natural de slides e um momento certo de usar. Escolha **um** — misturar formatos no mesmo carrossel confunde a progressão.

Abaixo, os seis que funcionam, com exemplos no tema do Rodrigo (vibecoding com engenharia).

---

## 1. Lista / N dicas

**O que é:** N pontos independentes sobre um tema. O formato mais usado — e por bom motivo: o número na capa é uma promessa de fim, e isso segura o arrasto.

**Estrutura:**
- Capa: "5 [coisas] que [ganho]"
- 1 slide por item (numerados)
- CTA: salvar

**Quando usar:** quando os pontos não dependem de ordem obrigatória. Tem flexibilidade — dá pra cortar ou somar itens.

**Exemplo (Rodrigo):**
> Capa: **5 testes que a IA não faz pelo seu código (e você precisa fazer)**
> Slide 2: 1 — Testar o caminho de erro, não só o feliz
> Slide 3: 2 — Validar a entrada do usuário
> … (até o 5)
> CTA: Salva pra rodar essa checklist antes do próximo deploy.

**Cuidado:** liste de 3 a 7. Acima de 7, vira fadiga. Ordene do mais forte ao mais fraco — o slide 2 tem que segurar.

---

## 2. Passo a passo

**O que é:** uma sequência obrigatória. Passo 2 só faz sentido depois do 1. Ensina a fazer algo do começo ao fim.

**Estrutura:**
- Capa: "Como [resultado] em N passos"
- 1 slide por passo, em ordem
- CTA: salvar ou comentar dúvida

**Quando usar:** tutorial, processo, método. Quando há um "antes" e um "depois" e o meio importa.

**Exemplo (Rodrigo):**
> Capa: **Como revisar código de IA em 5 passos (o Protocolo de 5 Camadas)**
> Slide 2: Passo 1 — Entender o que o código deveria fazer
> Slide 3: Passo 2 — Ler linha por linha
> … (Blindar, Testar, Versionar)
> CTA: Salva — é a checklist que eu uso antes de aceitar qualquer código gerado.

**Cuidado:** a ordem é sagrada. Se a pessoa pode pular passos, não é passo a passo — é lista.

---

## 3. Mito vs verdade

**O que é:** desmonta uma crença comum. Cada slide pega um mito e entrega a correção. Funciona porque cria atrito: a pessoa quer ver se acredita no que ela mesma pensa.

**Estrutura:**
- Capa: "X mitos sobre [tema] que te fazem [prejuízo]"
- 1 slide por mito → verdade
- CTA: comentar qual mito a pessoa acreditava

**Quando usar:** quando há equívocos disseminados que você pode corrigir com autoridade. Ótimo para posicionamento — mostra que você sabe mais que o senso comum.

**Exemplo (Rodrigo):**
> Capa: **3 mitos sobre vibecoding que vão te queimar em produção**
> Slide 2: Mito: "A IA já testa o código." → Verdade: ela gera o teste, mas não garante que ele cobre o que importa.
> Slide 3: Mito: "Se rodou, está certo." → Verdade: rodar é o mínimo, não a prova.
> CTA: Comenta qual desses você já acreditou.

**Cuidado:** o "mito" tem que ser algo que as pessoas realmente pensam. Mito de palha (que ninguém acredita) soa arrogante.

---

## 4. Erro → conserto

**O que é:** mostra um erro comum e o conserto. Parente do mito, mas mais prático e técnico. Cada slide: o erro, depois a correção.

**Estrutura:**
- Capa: "O erro que [público] comete em [contexto]"
- Slides: erro → por que dói → conserto (pode ser 1 erro destrinchado ou N erros)
- CTA: salvar ou seguir

**Quando usar:** conteúdo técnico, didático. Quando você quer ensinar pelo contraexemplo — mostrar o errado fixa o certo.

**Exemplo (Rodrigo):**
> Capa: **O erro de segurança que a IA coloca no seu código sem você pedir**
> Slide 2: O erro — chave de API hardcoded no front
> Slide 3: Por que dói — qualquer um lê o seu segredo no navegador
> Slide 4: O conserto — variável de ambiente no servidor (chama o Bastião/Faro)
> CTA: Salva e revisa seu código hoje.

**Cuidado:** sempre entregue o conserto. Carrossel que só aponta o erro e não resolve frustra — e quebra a promessa da capa.

---

## 5. Antes / depois

**O que é:** contraste entre dois estados. Mostra a transformação. Visualmente forte — funciona muito quando dá pra mostrar lado a lado (código, tela, número).

**Estrutura:**
- Capa: "Antes eu [estado ruim]. Hoje [estado bom]."
- Slides alternando antes/depois, ou um bloco antes + um bloco depois
- CTA: comentar ou seguir

**Quando usar:** prova de transformação, estudo de caso, evolução. Quando o impacto é visível e comparável.

**Exemplo (Rodrigo):**
> Capa: **A mesma função, antes e depois de aplicar engenharia ao vibecoding**
> Slide 2: ANTES — função sem validação, sem teste, segredo no código
> Slide 3: DEPOIS — entrada validada, teste de borda, segredo no .env
> Slide 4: O que mudou — 3 minutos a mais, zero incidente em produção
> CTA: Segue pra ver mais antes/depois reais.

**Cuidado:** o "depois" tem que ser crível. Transformação milagrosa cheira a hype — e hype é o oposto da voz.

---

## 6. História

**O que é:** narrativa. Situação → conflito → virada → lição. O formato que mais conecta, porque a pessoa se vê na história. Mais difícil de acertar, mais poderoso quando acerta.

**Estrutura:**
- Capa: o gancho da história ("Quase subi um código que vazava dados de cliente.")
- Slides: como começou → o problema → a virada → o que aprendi
- CTA: seguir ou comentar

**Quando usar:** quando há uma experiência real com lição. Para construir conexão e autoridade pela vulnerabilidade, não pela lista.

**Exemplo (Rodrigo):**
> Capa: **A IA me entregou um código lindo. Quase me custou um cliente.**
> Slide 2: O contexto — deploy de sexta, código gerado, tudo "funcionando"
> Slide 3: O problema — regra de banco aberta, dados expostos
> Slide 4: A virada — o Protocolo de 5 Camadas pegou antes de subir
> Slide 5: A lição — IA acelera, engenharia protege
> CTA: Segue — eu conto esses perrengues pra você não passar por eles.

**Cuidado:** história precisa ser verdadeira ou claramente ilustrativa. E precisa ter lição — história sem aprendizado é diário, não conteúdo.

---

## Tabela de decisão rápida

| Quero… | Formato |
|---|---|
| Entregar dicas soltas sobre um tema | Lista / N dicas |
| Ensinar a fazer algo em ordem | Passo a passo |
| Corrigir crenças erradas | Mito vs verdade |
| Ensinar pelo contraexemplo técnico | Erro → conserto |
| Provar uma transformação | Antes / depois |
| Conectar com uma experiência real | História |

Na dúvida entre dois, escolha o mais **concreto** para o seu material. Lista e passo a passo são os mais seguros; história e antes/depois são os mais memoráveis quando você tem o material certo.
