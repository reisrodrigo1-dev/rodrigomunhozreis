# Anatomia do carrossel

Um carrossel tem três partes: **capa**, **corpo** e **CTA**. Cada uma com um trabalho diferente. Confundir os trabalhos é o erro mais comum — capa que ensina, corpo que vende, CTA que continua explicando. Cada parte faz uma coisa.

```
[ CAPA ]  →  [ corpo: 5–8 slides ]  →  [ CTA ]
 gancho        um ponto por slide       uma ação
 fazer parar   entregar + fazer         converter
 e arrastar    arrastar (a ponte)
```

## A capa (slide 1)

**Trabalho:** fazer o dedo parar e o polegar arrastar. Só isso. A capa não ensina nada — ela promete.

- Uma frase dominante. Grande, legível no feed em miniatura.
- Promessa específica + sinal de que há mais ("arrasta →", "5 passos", "(salva)").
- Não cabe explicação na capa. Explicação é corpo.

Os padrões de capa estão detalhados em `ganchos-de-capa.md`. Aqui só fica a regra: **80% do resultado do carrossel se decide na capa.**

## O corpo (slides 2 a 7/9)

**Trabalho:** entregar a promessa, um ponto de cada vez, segurando o arrasto até o fim.

### Quantos slides

| Total (com capa e CTA) | Quando |
|---|---|
| **5 a 6** | Ideia simples, lista curta, dica rápida. O padrão seguro. |
| **7 a 8** | Passo a passo, tutorial, tema que precisa de progressão. |
| **9 a 10** | Só quando cada slide realmente paga sua virada. Acima disso, a taxa de conclusão despenca. |

Regra prática: **5 a 8 slides de corpo no máximo** (6 a 10 no total). Carrossel longo demais não é mais conteúdo — é mais gente parando no meio. Se sobra material, vira um segundo carrossel ou um post de blog (Pena).

### Um ponto por slide

Cada slide do corpo defende **uma** ideia. Estrutura interna de um slide:

```
TÍTULO CURTO          ← o ponto, em 3-6 palavras
linha de apoio        ← 1 a 3 linhas que explicam
(exemplo/número)      ← concretude, quando couber
```

Se você precisa de "e também…" dentro de um slide, esse "também" é o próximo slide. Não fatie parágrafo: cada slide é uma unidade fechada.

### Texto por slide

- **Título:** 3 a 6 palavras. É o que se lê de relance.
- **Corpo do slide:** 1 a 3 linhas, ~15 a 25 palavras. Tem que ser lido em 2-3 segundos.
- **Teste do celular:** abra no telefone, à distância de braço. Se você aperta os olhos, tem texto demais. Corta.
- Frase curta vence frase completa. "A IA não testa o código por você." vence "É importante lembrar que os modelos de inteligência artificial não realizam testes automatizados do código gerado."

### A progressão

O corpo tem uma direção. Não são pontos soltos — é uma escada:

- **Lista:** dica 1 → dica 2 → … (ordem do mais forte ou do mais simples ao mais avançado).
- **Passo a passo:** passo 1 → passo 2 → … (ordem obrigatória, é sequência).
- **Argumento:** problema → causa → solução → prova.
- **História:** situação → conflito → virada → lição.

Quem abre o slide 4 tem que sentir que veio do 3 e vai pro 5. Numerar ajuda: o número é uma barra de progresso disfarçada.

## A ponte (o que faz arrastar)

Esta é a peça que separa o carrossel que é lido inteiro do que morre no slide 2.

**A ponte é a tensão deixada no fim de um slide que só o próximo resolve.** Cada slide termina abrindo uma pequena pergunta na cabeça de quem lê. Arrastar é a resposta.

Formas de construir a ponte:

- **Pergunta aberta:** termina o slide com "Mas qual é o teste que ninguém faz?" → o próximo responde.
- **Promessa parcial:** "Esse é o erro mais comum. O segundo é pior." → tem que ver o segundo.
- **Numeração incompleta:** "Erro 1 de 5." → faltam 4, o cérebro quer fechar a conta.
- **Setup sem payoff:** monta a situação num slide, entrega a resolução no seguinte.
- **Conector explícito:** "Mas tem um detalhe →", "E é aqui que muda tudo →".

Regra da ponte: **nunca entregue tudo num slide.** Se o slide 3 é completo e autossuficiente demais, não há motivo para ir ao 4. Deixe sempre um fio puxando para o próximo.

A capa é a ponte zero: ela promete o todo. Cada slide do corpo é uma microponte para o seguinte. O CTA é onde as pontes acabam.

## O CTA (slide final)

**Trabalho:** converter a atenção em ação. Uma ação só.

Estrutura:

```
amarração da tese     ← "Agora você sabe os 5 testes que a IA não faz."
UMA ação clara        ← "Salva pra consultar antes do próximo deploy."
(opcional: marca/@)   ← assinatura, próximo passo
```

- **Uma ação por carrossel:** salvar, comentar, seguir, compartilhar ou ir ao link. Não peça três.
- **Dê um motivo:** "salva esse" é fraco; "salva pra não esquecer na hora do deploy" é forte.
- **Comentário e salvamento** alimentam alcance (o algoritmo gosta). **Link/bio** alimenta o funil (Ima, Vitrine, Correio).
- Não desperdice o slide mais engajado do carrossel com "curtiu? compartilha". Quem chegou aqui está pronto para mais.

## Checklist de fechamento

- [ ] Uma tese clara, dita em uma frase.
- [ ] Capa que faz parar (passou no teste do feed alheio).
- [ ] Capa sinaliza que é carrossel (seta/número/"arrasta").
- [ ] 5 a 8 slides de corpo, um ponto cada.
- [ ] Cada slide legível em 2-3 segundos (teste do celular).
- [ ] Há uma progressão real, não pontos soltos.
- [ ] Cada slide deixa uma ponte para o próximo.
- [ ] A capa promete o que o miolo entrega (sem clickbait).
- [ ] CTA pede UMA ação, com motivo.
- [ ] Nota de design passada para Atelier/Cânone (contraste, hierarquia, marca).
