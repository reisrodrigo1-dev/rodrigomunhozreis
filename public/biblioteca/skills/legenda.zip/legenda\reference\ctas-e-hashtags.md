# CTAs e hashtags

Duas partes da legenda que parecem detalhe e definem resultado: o **CTA** (o que a pessoa faz depois de ler) e as **hashtags** (quem vai descobrir o post). As duas erram pelo excesso — CTA pedindo demais, hashtag espalhando demais. Critério ganha de quantidade.

---

## CTAs que funcionam

Regra base: **um CTA por legenda.** Dois pedidos competem e a pessoa não faz nenhum. Verbo + benefício. E escolha o CTA pelo **objetivo** da legenda — não cole o mesmo "comenta aí" em tudo.

### Os CTAs que mais funcionam

**1. Salvar — para conteúdo de referência**
- *Quando:* a legenda/post tem valor pra consultar depois (checklist, dica técnica, passo a passo, carrossel).
- *Por quê:* salvamento é um dos sinais mais fortes pro algoritmo — vale mais que curtida. E mantém o conteúdo "guardado" com a pessoa.
- *Exemplos:* "Salva pra revisar antes do próximo deploy." / "Salva esse checklist — você vai precisar dele." / "Guarda esse pra quando for integrar pagamento."

**2. Comentar uma palavra — para engajamento + gatilho de DM**
- *Quando:* você quer engajamento alto e/ou tem algo pra entregar por DM (e-book, link, material).
- *Por quê:* comentário pesa pro alcance, e "comente X que eu te mando Y" cria um motivo real pra comentar (não é favor, é troca).
- *Exemplos:* "Comenta ENGENHO que eu te mando o e-book no direct." / "Comenta a stack que você usa — quero ver onde a galera tá." 
- *Cuidado:* só funciona se a troca for honesta. "Comenta EU QUERO" sem entrega vira ruído.

**3. Link na bio — para tráfego pra fora**
- *Quando:* o objetivo é levar pra um artigo, landing, e-book, inscrição.
- *Por quê:* o Instagram **não deixa clicar em link no texto** da legenda. URL crua no corpo não vira clique e ainda polui. O caminho é "link na bio" (ou sticker de link no stories).
- *Exemplos:* "Link na bio pra ler o artigo completo." / "O e-book tá no link da bio — de graça."
- *Cuidado:* mantenha a bio apontando pro que a legenda promete. Promessa e destino têm que bater.

**4. Pergunta de verdade — para abrir conversa**
- *Quando:* o objetivo é relacionamento/discussão, não ação imediata.
- *Por quê:* uma pergunta genuína (não retórica) puxa resposta real e abre conversa nos comentários.
- *Exemplos:* "Qual erro de vibecoding você já cometeu sem perceber?" / "Você revisa o código que a IA escreve, ou aceita e segue?"
- *Cuidado:* tem que ser uma pergunta que você **realmente** responderia interesse — não "concorda? 👇".

### O que NÃO fazer no CTA

- "Marque 3 amigos" — engajamento vazio, o algoritmo já descontou isso.
- Urgência falsa: "ÚLTIMAS HORAS", "corre que acaba" sem ser verdade.
- Dois ou três CTAs juntos ("curte, salva, comenta e compartilha") — pede tudo, recebe nada.
- "Comente EU QUERO" sem nada pra entregar.

---

## Como escolher hashtags

Hashtag é descoberta, não decoração. O objetivo é aparecer pra **quem busca o seu nicho** — não pra todo mundo.

### Nicho > genérico

- **Genérica = oceano lotado.** `#tech`, `#instagood`, `#empreendedorismo` têm milhões de posts; o seu afunda em segundos e atrai público que não é seu.
- **Nicho = público certo.** `#vibecoding`, `#desenvolvimentodesoftware`, `#nextjs`, `#segurancadainformacao`, `#lowcode` têm menos volume mas atraem **exatamente** quem interessa.
- **Misture camadas:** algumas de nicho específico (poucas, certeiras), algumas de nicho médio (alcance um pouco maior), e talvez uma ou duas mais amplas — mas o peso fica no nicho.

### Quantidade: poucas e relevantes

- **3 a 8 hashtags relevantes** batem 30 aleatórias. O Instagram já desvalorizou a estratégia de "encher de hashtag".
- **30 hashtags genéricas sinalizam desespero** e podem reduzir alcance (parece tentativa de burlar). Pareça curador, não pescador de arrasto.
- Toda hashtag tem que ter **relação real** com o post. Hashtag fora do tema confunde o algoritmo sobre pra quem mostrar.

### Sem spam

- Não repita o mesmo bloco de hashtags em todo post — varie conforme o tema.
- Não use hashtag-isca sem relação ("#fyp" não existe pra Instagram do jeito que existe no TikTok).
- Não invente hashtag que ninguém busca achando que vai "fundar" uma — a não ser que seja a sua marca (`#vibecodingcomengenharia` faz sentido como assinatura, mesmo com pouco volume).

### Onde colocar

- **No fim da legenda** ou **no primeiro comentário** — as duas funcionam igual pro alcance.
- No primeiro comentário deixa a legenda mais limpa visualmente; no fim é mais prático. Escolha por estética.

### Exemplo de conjunto bom (post sobre revisar código de IA)

> #vibecoding #desenvolvimentodesoftware #programacao #inteligenciaartificial #seguranca #nextjs #vibecodingcomengenharia

Sete hashtags: nicho específico (vibecoding, a assinatura da marca), nicho médio (desenvolvimento, programação, segurança, nextjs) e uma mais ampla (IA). Todas com relação real com o post. Nenhum spam.

---

## Resumo

- **CTA:** um só, honesto, escolhido pelo objetivo. Salvar (referência), comentar palavra (engajamento/DM), link na bio (tráfego), pergunta de verdade (conversa).
- **Hashtags:** nicho > genérico, 3-8 relevantes, sem spam, no fim ou no 1º comentário.
- O Instagram não clica em link no texto — tráfego sempre via bio/stories.
