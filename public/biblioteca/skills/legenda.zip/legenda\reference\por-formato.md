# Legenda por formato

A mesma ideia rende legendas diferentes conforme o visual que ela acompanha. O motivo é simples: **cada formato dá um trabalho diferente pra legenda**. Na foto, a legenda muitas vezes É o conteúdo. No reel, ela é coadjuvante do vídeo. No carrossel, ela é o porteiro que convence a pessoa a arrastar.

Antes de escrever, saiba qual formato você está legendando — e pergunte ao Rodrigo se não estiver claro.

---

## Legenda de FOTO

A foto é estática. O olho absorve a imagem em um segundo e o resto da atenção sobra pra legenda. **Na foto, a legenda costuma ser o conteúdo de verdade** — a imagem é a porta de entrada.

**O trabalho da legenda:** dar o contexto, a história ou a lição que a foto sozinha não conta.

- **Pode ir mais fundo.** É o formato que mais aguenta legenda longa — desde que o gancho segure e o corpo seja escaneável.
- **Nunca descreva a foto.** "Eu na palestra de ontem" é desperdício. Conte o que aconteceu na palestra, o que você errou, o que aprendeu.
- **Gancho na primeira linha sempre.** A foto chama o olho; a primeira linha chama o dedo pro "mais".
- **CTA conforme o objetivo:** bastidor/lição → pergunta ou "salva"; divulgação → "link na bio".

**Exemplo (foto de um setup de trabalho):**
> Esse setup não me fez programar melhor.
>
> Por anos eu achei que o problema era a ferramenta. Comprei monitor, teclado, cadeira. O código continuou inseguro.
>
> O que mudou foi um hábito de 5 minutos: revisar o que a IA escreve antes de aceitar.
>
> Ferramenta nenhuma substitui isso. A decisão é sua.

---

## Legenda de REEL

O reel é vídeo. A atenção da pessoa está **no vídeo, não no texto**. A legenda do reel é coadjuvante: ela não compete com o vídeo, ela **reforça e direciona**.

**O trabalho da legenda:** chamar pra assistir (até o fim), reforçar a mensagem do vídeo e empurrar pro CTA (salvar, principalmente).

- **Curta.** 1 a 4 linhas. Ninguém lê legenda longa enquanto assiste vídeo. Se você tem muito a dizer, está no roteiro do vídeo (Claquete), não na legenda.
- **Primeira linha = continuação do gancho do vídeo**, ou um motivo pra assistir: "Assiste até o fim — o erro tá no segundo 12."
- **Reforça uma frase-chave** do vídeo pra fixar (o vídeo passa rápido; o texto fica).
- **CTA mais comum no reel: salvar** ("salva pra não esquecer") — porque reel é frequentemente conteúdo de referência rápida. Comentar palavra também funciona bem.
- **Não transcreva o vídeo.** A legenda não é a fala do reel escrita.

**Exemplo (reel ensinando uma técnica de prompt):**
> O prompt que a maioria erra está nos primeiros 5 segundos do vídeo.
>
> Assiste até o fim — a correção é simples e muda o resultado.
>
> Salva pra usar no seu próximo prompt. 👇

---

## Legenda de CARROSSEL

O carrossel são vários slides (Baralho). O conteúdo está **nos slides**. A legenda tem UM trabalho acima de todos: **fazer a pessoa arrastar**.

A maior parte das pessoas vê o primeiro slide e decide ali se arrasta. A legenda — e principalmente a primeira linha — é parte dessa decisão.

**O trabalho da legenda:** puxar pro arraste, dar o contexto que os slides não dão, e fechar com o CTA.

- **Curta a média.** Os slides carregam o conteúdo; a legenda não repete os slides.
- **Primeira linha = promessa do carrossel + convite pro arraste:** "Os 5 erros de segurança que eu já cometi vibecoding (arrasta →)."
- **Indique o arraste** com "→" ou "arrasta pro lado" — parece bobo, mas aumenta o swipe.
- **Não resuma os slides na legenda.** Se a legenda já entrega tudo, a pessoa não arrasta. Dê o porquê de arrastar, não o conteúdo.
- **CTA forte no fim: salvar** ("salva esse checklist") — carrossel é o formato mais salvável. Comentar palavra pra receber algo também converte bem.

**Exemplo (carrossel "5 erros de segurança"):**
> Eu já cometi os 5 erros desse carrossel. Cada um quase me custou caro.
>
> O 3 é o que mais vejo vibecoder fazer sem perceber.
>
> Arrasta → e me diz nos comentários qual deles você já cometeu.
>
> (Salva pra revisar antes do próximo deploy.)

---

## Resumo

| Formato | Tamanho da legenda | Trabalho principal | CTA típico |
|---|---|---|---|
| **Foto** | Curta a longa (a legenda é o conteúdo) | Dar contexto/história/lição | Pergunta, salvar, link na bio |
| **Reel** | Curta (1-4 linhas) | Chamar pra assistir + reforçar | Salvar, comentar palavra |
| **Carrossel** | Curta a média | Puxar pro arraste | Salvar, comentar palavra |

Regra que vale pros três: **a legenda agrega, não repete.** Não descreva a foto, não transcreva o reel, não resuma os slides.
