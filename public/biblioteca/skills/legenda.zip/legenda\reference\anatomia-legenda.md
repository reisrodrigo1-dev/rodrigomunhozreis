# Anatomia de uma legenda

Toda legenda tem quatro partes, e elas trabalham em ordem: **primeira linha (gancho) → corpo → CTA → hashtags**. Se a primeira linha falha, as outras três não existem — ninguém abre. Por isso a ordem de esforço é essa: gaste a maior parte do tempo na primeira linha.

---

## 1. Primeira linha (o gancho)

É o que aparece no feed **antes do "... mais"**. No Instagram, isso é mais ou menos as primeiras 1-2 linhas (~125 caracteres) — varia com o tamanho da tela, então pense em **uma frase forte que caiba na primeira linha**.

A primeira linha **não é título**. Não é "Reflexão sobre IA". É o gancho que faz o dedo tocar em "mais".

### O que NÃO fazer na primeira linha

- **Descrever o óbvio do visual:** "Foto da minha mesa de trabalho." O olho já viu. Você gastou o ouro descrevendo o que a imagem mostra sozinha.
- **Rodeio de aquecimento:** "Nos dias de hoje, com toda a evolução da tecnologia..." Morte instantânea.
- **Saudação genérica:** "Fala, galera! Tudo bem?" Ninguém abre "mais" por causa de um "bom dia".
- **Resumo do que vem:** "Nesse post eu vou falar sobre..." Não anuncie — entregue.

### Padrões de gancho que funcionam (com exemplos no tema do Rodrigo)

- **Número / dado:** "Levei 3 dias pra perceber que a IA tinha escrito um código inseguro que eu aprovei sem ler."
- **Contradição do senso comum:** "Vibecoding não é sobre escrever menos código. É sobre revisar melhor o que a IA escreve."
- **Confissão:** "Subi pra produção um app com a regra do Firestore aberta. Qualquer um podia ler o banco. Eu não tinha lido."
- **Pergunta que incomoda:** "Você aceitaria um código que você não consegue explicar?"
- **Antes/depois:** "Antes: eu copiava o que a IA cuspia. Depois do Protocolo de 5 Camadas: eu reviso em 5 minutos e durmo tranquilo."

A primeira linha **promete o que a legenda entrega**. Sem clickbait — clickbait pode ganhar o toque, mas perde a confiança, e confiança é o ativo.

---

## 2. Corpo

O corpo é onde a legenda **agrega ao visual**. Aqui vale a regra de ouro:

> **A legenda agrega, não descreve o óbvio.** O olho já viu a imagem. Sua legenda conta o que a imagem **não** conta: o contexto, a história, o "como cheguei aqui", a lição, o número por trás.

Exemplo da diferença:

- **Foto:** print de um dashboard com gráficos.
- **Legenda que descreve (ruim):** "Aqui está o dashboard que eu construí, com vários gráficos."
- **Legenda que agrega (boa):** "Esse painel levou 2 horas pra construir com IA — e 2 dias pra eu confiar nos números. A parte difícil de vibecoding nunca é gerar. É validar."

### Como escrever o corpo

- **Linhas curtas, muitas quebras.** No feed, parágrafo-bloco é um muro; a pessoa rola por cima. Uma ideia por linha ou parágrafo de 1-3 linhas. Espaço em branco respira.
- **Mantém a tensão:** cada linha puxa pra próxima. Comece pelo que mais interessa, não pelo aquecimento.
- **Uma ideia só.** Legenda que tenta dizer três coisas não diz nenhuma.
- **Sem markdown:** negrito e itálico não renderizam no Instagram. Não use `**` nem `_`. Para listas use "→", "—" ou quebras simples.
- **Prova antes de discurso:** caso real, número real, bastidor honesto. É o que dá verdade.

---

## 3. CTA (chamada pra ação)

Um convite só, no fim. Verbo + benefício. Escolhido pelo objetivo da legenda. Detalhe completo em `ctas-e-hashtags.md`. Em resumo: **salvar** (referência), **comentar uma palavra** (engajamento/DM), **link na bio** (tráfego), ou **pergunta de verdade** (conversa). Sem "marque 3 amigos", sem urgência falsa.

---

## 4. Hashtags

Vão no fim ou no primeiro comentário. **Nicho > genérico, 3-8 relevantes, sem spam.** Como montar o conjunto: `ctas-e-hashtags.md`.

---

## Tamanho ideal por objetivo

Não existe tamanho "certo" — existe tamanho **adequado ao objetivo**. Regra geral:

| Objetivo da legenda | Tamanho | Por quê |
|---|---|---|
| **Só dar contexto** ao visual (foto bonita, bastidor leve) | Curta — 1 a 3 linhas | A imagem é a estrela; a legenda só completa o sentido. Texto longo aqui cansa. |
| **Levar a uma ação rápida** (reel, "salva isso", "link na bio") | Curta a média — 2 a 5 linhas | A pessoa veio pelo visual/vídeo. A legenda reforça e empurra pro CTA. Não compita com o vídeo. |
| **Contar uma história / ensinar** (lição, confissão, caso) | Média a longa — pode ir fundo | Aqui a legenda **é** o conteúdo. Vale desenvolver, desde que o gancho segure e o corpo seja escaneável. |
| **Carrossel** (legenda que apoia os slides) | Curta a média | Os slides carregam o conteúdo; a legenda dá o contexto e empurra o arraste. Não repita os slides na legenda. |

Limite técnico do Instagram: 2.200 caracteres. Mas chegar perto disso raramente é necessário — quase nada bom precisa de 2.200 caracteres. Se a legenda ficou longa, pergunte: cada linha agrega, ou tem enchimento?

---

## Checklist rápido antes de entregar

- [ ] A primeira linha fisga **sem descrever o óbvio** e cabe antes do "... mais"?
- [ ] O corpo **agrega** ao visual em vez de narrá-lo?
- [ ] É **uma ideia só**, escaneável, com quebras?
- [ ] Tem **um** CTA, honesto, alinhado ao objetivo?
- [ ] Hashtags com critério (nicho, 3-8, sem spam)?
- [ ] Voz sem hype, prova antes de discurso, "a decisão é sua"?
