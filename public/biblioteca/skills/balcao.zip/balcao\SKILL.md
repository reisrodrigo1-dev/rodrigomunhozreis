---
name: balcao
description: Cria scripts de atendimento, vendas e suporte — primeiro contato, objeções, follow-up e reclamações — na voz da marca. Use ao escrever resposta para cliente, script de venda/atendimento ou tratamento de objeção/reclamação.
---

# Balcão

O Balcão escreve **scripts de atendimento, vendas e suporte** na voz do Rodrigo Munhoz Reis — autor da linha "vibecoding com engenharia". É o que você diz (ou escreve) quando tem um cliente do outro lado: o primeiro "oi" de um lead, a resposta a quem reclama, o follow-up de quem sumiu, a dúvida no suporte, a objeção de preço.

A voz é PT-BR, direta, honesta, sem hype. Trata o cliente como adulto. Resolve em vez de empurrar. Admite erro quando erra. E lembra sempre: **a decisão é do cliente.**

## Visão geral

Atender bem é três coisas, nessa ordem: **ouvir, resolver e não enrolar.** A maioria do mau atendimento falha numa delas — responde antes de ouvir, se defende em vez de resolver, ou enche de palavra para não dar a resposta que o cliente não quer.

Um script aqui é **roteiro, não robô.** Ele te dá a estrutura e o tom para não travar nem improvisar mal num momento tenso. Mas quem está do outro lado é uma pessoa, com pressa, raiva, dúvida ou interesse real. O script é o esqueleto; você adapta à carne do humano na sua frente. Decorar e recitar é pior do que não ter script — soa a call center, e o cliente sente.

```
situação (o que o cliente quer de verdade)
   -> tom (venda? suporte? reclamação?)
   -> estrutura: acolher -> resolver/encaminhar -> próximo passo claro
   -> objeção/reclamação tratada sem defensividade
   -> fechamento: o cliente sabe exatamente o que acontece agora
```

O Balcão é a voz da marca **na boca de quem fala com cliente.** Faz par com as irmãs da suíte Engenho:

- **Correio** cuida do e-mail e da newsletter de nutrição (a lista).
- **Decolagem** cuida da estratégia de vendas e negócio (modelo, preço, primeiros clientes).
- **Espelho** cuida de entender o cliente (quem é, o que dói).
- **Balcão** (esta) cuida do **script da conversa** — atendimento, venda e suporte, mensagem a mensagem.

Se a pergunta é "qual o meu preço?" ou "qual o meu modelo?", é Decolagem. Se é "o que eu respondo pra esse cliente que reclamou?", é Balcão.

## Quando usar esta skill

Use o Balcão quando o usuário quiser:

- **Escrever uma resposta para um cliente** (WhatsApp, e-mail de suporte, DM, chat) — qualquer mensagem direta.
- **Montar um script de venda** — primeiro contato com lead, apresentação de oferta, fechamento.
- **Tratar uma objeção** — preço, "vou pensar", "tô usando concorrente", "não tenho tempo agora".
- **Responder uma reclamação** ou acalmar um cliente irritado sem se defender nem se humilhar.
- **Escrever um follow-up** que retoma o contato sem ser chato nem desesperado.
- **Cobrar um cliente** de forma educada e firme.
- **Padronizar o atendimento** de uma equipe (criar os modelos que todo mundo usa).

Não use para: copy de anúncio ou landing (Alavanca/Vitrine), e-mail de nutrição para a lista (Correio), ou estratégia de preço/modelo (Decolagem). O Balcão é a **conversa um-a-um com o cliente**.

## Como usar a base

Esta skill é uma **base pesquisável**. Antes de escrever o script, leia o arquivo de `reference/` relevante — eles têm método, estrutura e exemplos completos na voz da casa.

| Arquivo | Use quando for |
|---|---|
| `reference/scripts-por-situacao.md` | Escrever qualquer mensagem para cliente. Tem modelo por situação (primeiro contato, oferta, objeção, follow-up, suporte, reclamação, cobrança), cada um com estrutura + exemplo pronto. Leia este PRIMEIRO. |
| `reference/principios-de-atendimento.md` | Decidir o tom e a postura. Os princípios que valem para tudo: ouvir antes de responder, resolver mais que ter razão, transparência, sem promessa que não cumpre, tempo de resposta. |
| `reference/tratar-objecao.md` | A conversa travou numa objeção. O método (acolher → entender a real → responder com valor/prova → não brigar) e respostas para as objeções mais comuns. |

## PROCEDIMENTO

Para qualquer script ou resposta, siga estes cinco passos. Eles valem para venda, suporte e reclamação — o que muda é o tom.

### 1. Entender a situação e o que o cliente quer de verdade

Antes de escrever uma palavra, responda:

- **O que o cliente disse?** (a mensagem literal)
- **O que ele quer de verdade?** (a necessidade por trás). Quem pergunta "quanto custa?" às vezes quer saber "isso resolve o meu problema?". Quem reclama do prazo às vezes quer só ser ouvido e ter uma data confiável.
- **Em que momento ele está?** (lead frio, cliente fiel, cliente irritado, alguém em dúvida)
- **Qual o resultado bom dessa conversa?** (uma venda? um problema resolvido? um cliente acalmado e ainda cliente?)

Se você não sabe o que o cliente quer, **pergunte antes de responder.** Chutar a necessidade é a causa nº 1 de atendimento ruim.

### 2. Escolher o tom (venda x suporte x reclamação)

O esqueleto é o mesmo; o tom muda tudo:

- **Venda** — curioso, útil, sem pressão. Você está ajudando a decidir, não empurrando. Mostra valor, dá o caminho, respeita o "não".
- **Suporte** — eficiente, claro, prestativo. O cliente quer a resposta, não papo. Resolva rápido e confirme que resolveu.
- **Reclamação** — calmo, humano, sem defensividade. Primeiro acolhe a emoção, depois resolve o problema. Nunca discute "quem tem razão" antes de baixar a temperatura.

Na dúvida do tom, leia `reference/principios-de-atendimento.md`. Regra geral: **mais quente que um robô, mais sóbrio que um vendedor de hype.**

### 3. Estrutura: acolher → resolver/encaminhar → próximo passo claro

Quase toda mensagem de atendimento cabe nesta estrutura de três tempos:

1. **Acolher** — mostre que entendeu. Uma linha que reconhece a pessoa e o que ela trouxe. ("Entendi, [nome] — você quer X." / "Poxa, sinto muito que isso aconteceu.") Sem acolhimento, o resto soa frio.
2. **Resolver ou encaminhar** — entregue a resposta, ou diga com clareza qual é o próximo passo e quem vai cuidar. Se não tem a resposta agora, diga isso — e diga *quando* terá. Não some, não enrola.
3. **Próximo passo claro** — toda mensagem termina sabendo-se o que acontece agora. ("Te mando o link em seguida." / "Pode confirmar o e-mail pra eu liberar?" / "Resolvido. Qualquer coisa, é só chamar.") Mensagem que termina no vácuo gera a próxima pergunta — e desgasta os dois lados.

### 4. Tratar objeção/reclamação sem defensividade

Objeção não é ataque — é dúvida ou medo com roupa de "não". Reclamação não é ofensa — é um cliente que se importa o bastante para falar.

A regra de ouro: **não brigue, não se defenda, não se humilhe.** Acolha primeiro ("faz sentido essa preocupação" / "você tem razão de estar chateado"), entenda a real (o "vou pensar" esconde o quê?), e só então responda — com valor, prova ou solução. Resolver vale mais do que ter razão. O método completo está em `reference/tratar-objecao.md`.

Se você errou, **admita.** Um "erramos, e vamos consertar assim" vale mais que dez parágrafos de justificativa. O cliente perdoa o erro; raramente perdoa a enrolação.

### 5. Fechar com clareza (o que acontece agora)

Nunca encerre sem deixar explícito o estado da coisa:

- O que foi decidido / resolvido.
- O que **você** vai fazer e até quando.
- O que **o cliente** precisa fazer, se algo.
- Como ele volta a falar com você se precisar.

Clareza no fechamento é o que separa o atendimento que tranquiliza do que deixa o cliente ansioso. Em venda, é o CTA. Em suporte, é a confirmação. Em reclamação, é o compromisso com prazo.

## Regras

- **Ouvir antes de responder.** Entenda o que o cliente quer de verdade. Na dúvida, pergunte — não chute.
- **Resolver > ter razão.** O objetivo é o problema resolvido e o cliente bem atendido, não ganhar a discussão.
- **Sem defensividade.** Reclamação e objeção se acolhe, não se rebate. Baixe a temperatura antes de explicar.
- **Transparência.** Se errou, admita e conserte. Se não sabe, diga que vai descobrir e quando volta. Se não dá, diga que não dá — com o porquê.
- **Sem hype, sem promessa que não cumpre.** É melhor prometer menos e entregar do que prometer demais e furar. Prazo só o que você bate.
- **Próximo passo sempre claro.** Nenhuma mensagem termina no ar. O cliente sai sabendo o que acontece agora.
- **Roteiro, não robô.** Adapte o script ao humano do outro lado. Personalize, use o nome, leia o tom. Recitar afasta.
- **A decisão é do cliente.** Mostre o valor, dê o caminho, e respeite o "não" e o "agora não". Vender empurrando queima o cliente.

---

O Balcão atende como gente que respeita o cliente: ouve, resolve e não enrola. Acolhe a reclamação sem se defender, vende sem mentir, e fecha deixando claro o que acontece agora. A decisão final é sempre do cliente.
