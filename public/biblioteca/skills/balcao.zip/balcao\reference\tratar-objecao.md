# Tratar objeção

Objeção não é um "não". É uma dúvida, um medo ou uma falta de informação com roupa de "não". Tratá-la bem não é convencer à força — é entender o que está realmente travando e responder a isso. Quem trata objeção brigando, perde. Quem trata acolhendo e esclarecendo, ou fecha, ou recebe um "não" limpo (que também é um bom resultado: libera os dois).

> Regra de ouro: **você não está vencendo o cliente, está ajudando ele a decidir.** Se no fim ele decidir que não, tudo bem. Empurrar quem não quer queima o cliente para sempre.

---

## O método (vale para qualquer objeção)

Quatro passos, sempre nesta ordem:

### 1. Acolher a objeção
A primeira reação do cliente que ouve "mas..." é fechar. Então não comece com "mas". Comece reconhecendo que a preocupação dele é legítima.

- "Faz total sentido você pensar nisso."
- "Boa que você levantou isso — é importante mesmo."
- "Entendo perfeitamente."

Acolher **não é concordar** que ele não deve comprar. É validar que a dúvida é razoável. Isso baixa a guarda e abre a conversa.

### 2. Entender a real
A objeção dita raramente é a verdadeira. "Tá caro" pode ser "não vi o valor". "Vou pensar" pode ser "tenho uma dúvida que não falei". O trabalho aqui é uma pergunta que destrava a objeção de verdade.

- "Tá caro comparado a quê?"
- "É o valor que pesa agora, ou é que ainda não ficou claro o retorno?"
- "É o preço, o momento, ou alguma dúvida sobre se isso resolve mesmo pra você?"

Sem este passo, você responde a objeção errada — e gasta argumento à toa.

### 3. Responder com valor ou prova
Agora, e só agora, você responde — à objeção real, não à de fachada. Use:

- **Valor:** ligue o preço/esforço ao que o problema custa hoje. "Não é gasto, é o que para de te custar."
- **Prova:** caso de outro cliente, número, garantia, demonstração. "Olha o que aconteceu com [cliente parecido]."
- **Reenquadramento:** mostre o ângulo que ele não viu. "Pensa que sem isso você continua [dor]."

Responda à dor específica dele, não com um discurso genérico de vendas.

### 4. Não brigar
Se mesmo assim ele hesita ou diz não, **pare.** Não insista, não pressione, não faça o cliente se sentir errado por não comprar.

- "Sem problema. Se mudar de ideia, é só me chamar — fica o convite aberto."
- "Respeito totalmente. Te aviso se surgir alguma condição, sem pressa."

Um "não" tratado com elegância deixa a porta aberta. Um "não" tratado com pressão fecha a porta com chave.

---

## As objeções mais comuns e como responder

### "Tá caro" / "não tenho esse valor"

**O que costuma estar por trás:** o cliente não enxergou o retorno, ou está comparando com a coisa errada, ou o valor realmente não cabe agora.

**Resposta:**
> Entendo, investimento importa mesmo. Só pra eu te ajudar: tá caro comparado a quê? É o valor que pesa no orçamento agora, ou é que ainda não ficou claro o que você ganha com isso?
>
> [Se for retorno:] Pensa assim: hoje [o problema] te custa [tempo/dinheiro/dor]. Isso aqui resolve por R$ [valor]. Não é um gasto a mais, é o que para de te custar.
>
> [Se realmente não couber:] Se não for a hora, eu entendo — e te aviso quando tiver alguma condição. Sem pressão.

**Não faça:** baixar o preço na hora por reflexo. Desconto automático ensina o cliente que seu preço é inflado e desvaloriza quem pagou cheio. Primeiro mostre o valor; desconto, se houver, é decisão consciente, não pânico.

---

### "Vou pensar"

**O que costuma estar por trás:** uma dúvida específica que ele não verbalizou, ou medo de decidir errado, ou só educação para dizer não.

**Resposta:**
> Claro, decisão boa é decisão pensada. Só me ajuda a entender: o que mais pesa pra pensar — é o preço, o momento, ou alguma dúvida sobre se isso resolve pra você?
>
> Porque se for dúvida, talvez eu já resolva agora e te poupe o trabalho. E se for o momento, a gente marca de eu te chamar [data], sem te encher no meio.

**Não faça:** aceitar o "vou pensar" no vazio e sumir. Sem um próximo passo concreto, "vou pensar" vira "nunca mais". Ofereça resolver a dúvida agora ou combinar um retorno datado.

---

### "Já uso [concorrente]"

**O que costuma estar por trás:** ou está satisfeito (e aí respeite), ou tem uma dor não resolvida que ele nem articula.

**Resposta:**
> Ótimo que você já resolve isso de algum jeito — mostra que o problema é real. O [concorrente] é bom mesmo.
>
> Me conta: tem algo nele que te incomoda hoje, ou que você queria diferente?
>
> [Conforme a dor:] É exatamente aí que a gente é diferente: [o ponto específico]. Não vou dizer que somos melhores em tudo — não somos. Mas nesse ponto, somos. Se quiser comparar de verdade um dia, te mostro sem compromisso.

**Não faça:** falar mal do concorrente. Atacar a escolha atual do cliente atinge o cliente, não o concorrente — e te faz parecer inseguro. Admitir os próprios limites ("não somos melhores em tudo") aumenta a credibilidade do ponto em que você é melhor.

---

### "Não tenho tempo agora"

**O que costuma estar por trás:** ou prioridade (não é urgente o bastante), ou medo de que implementar dê trabalho.

**Resposta:**
> Entendo, tempo é o que mais falta mesmo. Deixa eu só te perguntar: o trabalho que te preocupa é começar, ou usar no dia a dia?
>
> [Se for começar:] A parte chata é justamente a que a gente faz por você — você gasta [tempo real, honesto] e o resto é com a gente.
>
> [Se for prioridade:] Faz sentido. Quando [o problema] apertar de novo, me chama. Fica o convite.

---

### "Preciso falar com meu sócio / minha esposa / o chefe"

**O que costuma estar por trás:** ou é verdade (decisão compartilhada), ou é uma saída educada.

**Resposta:**
> Perfeito, decisão importante se decide junto mesmo. Pra facilitar pra você levar a conversa: o que o [sócio] vai querer saber? Posso te passar isso redondinho pra você não ter que decorar.
>
> E se ajudar, eu participo de uma call rápida com vocês dois — assim ele tira as dúvidas direto.

**Não faça:** ignorar o terceiro decisor. Arme o seu cliente com a informação para defender a compra, ou ofereça falar direto com quem decide.

---

### "Como sei que vai funcionar pra mim?"

**O que está por trás:** medo do risco. Resposta é prova + redução de risco.

**Resposta:**
> Pergunta justa — ninguém quer jogar dinheiro fora. Olha: [caso de cliente parecido + resultado]. E pra você entrar sem medo, [garantia / teste / primeira etapa reversível].
>
> Não vou te prometer milagre. Vou te dizer o que normalmente acontece e o que depende de você — e você decide com os olhos abertos.

---

## Quando parar

Tratar objeção é ajudar a decidir, não dobrar a pessoa. Pare e respeite o "não" quando:

- O cliente já disse não com clareza duas vezes.
- A objeção é real e legítima (não tem orçamento mesmo, não é a hora mesmo).
- Insistir começaria a custar o relacionamento.

Um "não" bem tratado hoje é um "sim" possível amanhã — e uma indicação, mesmo de quem não comprou. Empurrar até o constrangimento fecha as duas portas. **A decisão é do cliente.**
