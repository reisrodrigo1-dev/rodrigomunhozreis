# Scripts por situação

Modelos prontos para as situações mais comuns de atendimento, venda e suporte — cada um com a **estrutura** (para você adaptar) e um **exemplo na voz da casa** (direto, honesto, sem hype). Os exemplos são em tom de WhatsApp/chat, que é o canal mais comum; adapte para e-mail alongando um pouco e formalizando o cumprimento.

> Lembre: script é roteiro, não robô. Use o nome da pessoa, leia o tom dela, e corte qualquer linha que soe decorada. O esqueleto serve para você não travar — não para recitar.

---

## 1. Primeiro contato / lead novo

Alguém chegou: pediu informação, preencheu um formulário, mandou "oi, queria saber mais". O objetivo aqui **não é vender** — é entender o que a pessoa precisa e mostrar que tem gente competente do outro lado.

**Estrutura:**
1. Cumprimente pelo nome e agradeça o contato (1 linha).
2. Faça **uma** pergunta que descubra a necessidade real. Não despeje a oferta ainda.
3. Sinalize que você vai ajudar a resolver, não só vender.

**Exemplo (lead que pediu informação sobre o produto):**

> Oi, [nome]! Tudo bem? Aqui é o [seu nome], do [empresa]. Obrigado por chamar.
>
> Antes de te mandar preço e tudo mais (que eu mando, sem enrolação), me conta rápido: o que te fez procurar a gente agora? Qual o problema que você tá tentando resolver?
>
> Pergunto porque dependendo do seu caso a melhor saída muda — e eu prefiro te indicar o certo do que empurrar o que não serve.

**Por que funciona:** assume a iniciativa, não esconde o preço ("que eu mando"), e a pergunta posiciona você como quem resolve, não como quem vende. A última linha é a voz da casa: honestidade acima da venda fácil.

---

## 2. Apresentar a oferta

A pessoa já disse o que precisa. Agora você apresenta o que tem. O objetivo é **conectar o que você vende ao problema dela** — não listar features.

**Estrutura:**
1. Reconecte com o que ela disse ("você falou que precisa de X").
2. Apresente a solução ligada a esse X, em linguagem de resultado, não de funcionalidade.
3. Diga o preço com naturalidade — sem pedir desculpa, sem rodeio.
4. Dê o próximo passo claro (uma pergunta ou um link).

**Exemplo:**

> [nome], pelo que você me contou, o seu aperto é [problema dele, nas palavras dele]. É isso?
>
> Então o que faz sentido pra você é o [produto/plano]. Na prática ele resolve isso assim: [1-2 linhas de resultado concreto — o que muda no dia a dia dele].
>
> O investimento é R$ [valor] [condição: por mês / à vista / etc]. Sem fidelidade, sem letra miúda — você fica enquanto fizer sentido.
>
> Quer que eu já te mande o passo a passo pra começar, ou ficou alguma dúvida antes?

**Por que funciona:** confirma o problema antes de ofertar (e dá chance de corrigir), fala em resultado, diz o preço sem pedir desculpa (pedir desculpa pelo preço sinaliza que você acha caro), e fecha com uma pergunta que respeita a dúvida. Diga o preço de forma firme: insegurança no preço contamina a venda.

---

## 3. Tratar objeção

Detalhe completo e mais objeções em `tratar-objecao.md`. Aqui, os três casos mais comuns em formato de script.

### 3a. Objeção de preço ("tá caro" / "não tenho esse valor agora")

**Estrutura:** acolher → entender se é preço ou prioridade → responder com valor/comparação real → dar a opção, sem pressionar.

> Entendo, [nome]. Investimento importa mesmo — bom que você está olhando isso com cuidado.
>
> Só pra eu te ajudar direito: tá caro comparado a quê? É o valor que pesa no orçamento agora, ou é que ainda não ficou claro o retorno?
>
> [Se for retorno:] Faz sentido. Pensa assim: [problema] hoje te custa [tempo/dinheiro/dor concreta]. O [produto] resolve isso por R$ [valor]. Não é gasto, é o que para de te custar.
>
> Se mesmo assim não for a hora, tudo bem — eu te aviso quando tiver alguma condição, sem pressa.

### 3b. "Vou pensar"

**Estrutura:** acolher → descobrir a dúvida real por trás → resolver a dúvida → marcar um retorno concreto (não deixar no "vou pensar" infinito).

> Claro, decisão boa é decisão pensada. Só me ajuda a entender: é mais o preço, é o momento, ou é alguma dúvida sobre se isso resolve mesmo pra você?
>
> Pergunto porque, se for dúvida, talvez eu já resolva agora e te poupe o pensar. E se for o momento, a gente combina de eu te chamar [data concreta] — sem te encher no meio.

### 3c. "Já uso um concorrente"

**Estrutura:** não ataque o concorrente → pergunte o que falta no atual → mostre a diferença que importa pra ele → deixe a porta aberta.

> Ótimo que você já resolve isso de algum jeito — isso já diz que o problema é real. O [concorrente] é uma ferramenta de respeito.
>
> Me conta: tem alguma coisa nele que te incomoda hoje, ou que você queria que fosse diferente?
>
> [Conforme a resposta:] É justamente aí que a gente é diferente: [o ponto que resolve a dor dele]. Não vou dizer que somos melhores em tudo — não somos. Mas nisso aqui, somos. Se um dia quiser comparar de verdade, te mostro sem compromisso.

**Por que funciona:** nunca fala mal do concorrente (isso queima sua credibilidade), admite os próprios limites ("não somos melhores em tudo"), e foca na dor específica — a única coisa que move alguém a trocar.

---

## 4. Follow-up sem ser chato

A pessoa sumiu depois de demonstrar interesse. O follow-up retoma o contato **dando algo ou facilitando**, nunca cobrando ("e aí, decidiu?"). A diferença entre persistente e chato é: você traz valor ou só cobra resposta?

**Estrutura:**
1. Sem culpa, sem "sumiu, hein". Retome leve.
2. Traga um motivo novo para a mensagem (uma dúvida que talvez ele tenha, uma informação útil, uma condição real).
3. Facilite o "não": dê uma saída digna. Isso paradoxalmente aumenta a resposta.

**Exemplo (1º follow-up, 2-3 dias depois):**

> Oi, [nome]! Voltei aqui rápido. Fiquei pensando no que você me contou sobre [problema dele] e queria te deixar uma coisa que pode ajudar mesmo que você não feche com a gente: [dica/material/link útil].
>
> Se ainda fizer sentido conversar, tô por aqui. E se não for a hora, sem problema nenhum — é só me dizer e eu paro de te chamar. 🙂

**Exemplo (follow-up final, "fecho o ciclo"):**

> [nome], não quero te encher, então esse é o meu último toque por aqui. Se em algum momento você quiser retomar [assunto], é só me chamar — fica o convite aberto, sem prazo. Sucesso aí. 👊

**Por que funciona:** o primeiro traz valor mesmo sem venda e oferece a saída digna; o "último toque" tira a pressão e, na prática, costuma trazer respostas justamente porque o cliente sente que pode dizer não. Limite a 2-3 follow-ups. Insistir além disso vira ruído e queima a marca.

---

## 5. Suporte / dúvida

O cliente tem uma dúvida ou um problema de uso. Ele quer a resposta, não papo. Eficiência **é** atenção aqui.

**Estrutura:**
1. Confirme que entendeu a dúvida (em 1 linha — evita responder a pergunta errada).
2. Dê a resposta direta, em passos se for o caso.
3. Confirme que resolveu e abra a porta.

**Exemplo (dúvida simples):**

> Entendi, [nome] — você quer [reformula a dúvida dele]. Vamos lá:
>
> 1. [passo]
> 2. [passo]
> 3. [passo]
>
> Faz esse caminho e me diz se resolveu. Se travar em algum ponto, me manda um print que eu te ajudo na hora.

**Exemplo (não tem a resposta na hora):**

> Boa pergunta, [nome]. Pra te responder certo eu preciso confirmar uma coisa com o time — não quero te dar uma informação no chute.
>
> Te dou retorno até [prazo concreto: hoje às 17h / amanhã de manhã]. Pode deixar comigo.

**Por que funciona:** confirmar a dúvida evita o retrabalho de responder errado; o caso "não sei agora" mostra a regra de ouro do suporte honesto — **nunca chute uma resposta**, dê um prazo e cumpra. Voltar dentro do prazo prometido vale mais que uma resposta rápida e errada.

---

## 6. Reclamação / cliente irritado

O cliente está bravo. Algo falhou (ou ele acha que falhou). Aqui o objetivo nº 1 **não é resolver o problema técnico** — é **baixar a temperatura primeiro**. Cliente com raiva não escuta solução; escuta acolhimento. Solução vem depois.

**Estrutura:**
1. **Acolha a emoção, não o fato ainda.** Reconheça que ele tem razão de estar chateado. Não comece se defendendo nem explicando.
2. **Assuma o que for seu.** Se errou, admita reto. Se ainda não sabe, diga que vai apurar — sem terceirizar a culpa ("o sistema", "o outro setor").
3. **Resolva ou dê o caminho com prazo.**
4. **Feche com o compromisso concreto.**

**Exemplo (erro foi seu):**

> [nome], você tem toda razão de estar chateado, e eu não vou te enrolar: a gente errou aqui. [O que aconteceu, em uma linha honesta.]
>
> O que eu vou fazer agora: [ação concreta]. Isso fica resolvido até [prazo].
>
> E como o erro foi nosso, [reparação, se cabível: estorno / desconto / o que for justo]. Me desculpa pelo transtorno — de verdade.

**Exemplo (ainda não sei se o erro foi nosso):**

> Poxa, [nome], sinto muito que você tá passando por isso — entendo a frustração. Vou apurar o que aconteceu agora mesmo, sem empurrar pra ninguém.
>
> Me dá [prazo curto] que eu volto com a resposta certa e a solução. Não vou te deixar no escuro — qualquer coisa, eu te atualizo antes mesmo de resolver.

**O que NUNCA fazer numa reclamação:**
- Começar com "mas" ("Mas você concordou com os termos...").
- Explicar antes de acolher.
- Terceirizar ("foi o sistema", "não foi comigo").
- Prometer prazo que não vai bater (piora tudo).
- Discutir quem tem razão antes de resolver.

**Por que funciona:** o cliente quer, nessa ordem: ser ouvido, ser levado a sério, ter o problema resolvido. "Você tem razão de estar chateado" não admite culpa técnica — admite a emoção, que é o que destrava a conversa. Resolver vale mais que ter razão.

---

## 7. Cobrança educada

Cliente atrasou o pagamento. A cobrança precisa ser **firme e respeitosa** ao mesmo tempo — assume boa-fé (esquecimento acontece), facilita o pagamento, e não humilha. Tom de constrangimento ou ameaça queima o relacionamento e raramente acelera o pagamento.

**Estrutura:**
1. Aborde direto, sem rodeio constrangedor, assumindo boa-fé.
2. Dê a informação prática (valor, vencimento, como pagar).
3. Facilite ao máximo (link, segunda via, opção de parcelar se fizer sentido).
4. Abra espaço caso haja um problema real.

**Exemplo (1º aviso, amigável):**

> Oi, [nome]! Tudo certo? Passando só pra lembrar que a fatura de [referência], no valor de R$ [valor], venceu em [data] e consta em aberto por aqui.
>
> Deve ter passado batido — acontece. Segue a segunda via pra facilitar: [link].
>
> Qualquer coisa que tenha acontecido e você precise resolver de outro jeito (parcelar, adiar uns dias), me fala que a gente dá um jeito. 🙂

**Exemplo (2º aviso, mais firme, ainda respeitoso):**

> [nome], é o segundo toque sobre a fatura de [referência] (R$ [valor], vencida em [data]). Não quero te incomodar, mas preciso regularizar isso.
>
> Pra resolver hoje: [link]. Se tiver algum impedimento, me chama agora que a gente acha uma saída juntos — prefiro resolver conversando a deixar isso virar um problema maior pros dois lados.

**Por que funciona:** assume boa-fé ("deve ter passado batido"), facilita o pagamento na própria mensagem, e abre a porta para negociar — quem está com dificuldade real responde a isso, e quem esqueceu paga na hora. Firmeza sem agressividade: você cobra o que é seu sem destratar quem é cliente.

---

## Como adaptar qualquer um destes

1. Troque os `[colchetes]` por informação real e específica daquele cliente.
2. Leia em voz alta. Se soa a robô ou a vendedor de hype, reescreva mais humano.
3. Corte o que não precisa. Mensagem boa é a mais curta que ainda acolhe, resolve e dá o próximo passo.
4. Combine partes: um suporte que vira venda usa estrutura 5 + 2; uma reclamação que vira retenção usa 6 + uma oferta honesta de reparação.
