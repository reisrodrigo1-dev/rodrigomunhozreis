# Princípios de atendimento

A postura por trás de todo script. Antes de escolher um modelo em `scripts-por-situacao.md`, calibre o tom por estes princípios. Eles valem para venda, suporte e reclamação — são a voz da casa aplicada ao cliente.

A ideia-mãe é simples: **atender bem é ouvir, resolver e não enrolar.** Tudo abaixo desdobra isso.

---

## 1. Ouvir antes de responder

O erro mais comum do atendimento é responder à pergunta que veio escrita em vez da necessidade real por trás dela.

- Quem pergunta "quanto custa?" muitas vezes quer saber "isso resolve o meu problema?".
- Quem reclama do prazo muitas vezes quer só ser ouvido e ter uma data confiável.
- Quem diz "vou pensar" raramente vai pensar — tem uma dúvida específica não resolvida.

**Na prática:**
- Antes de responder, pergunte-se: *o que essa pessoa quer de verdade?*
- Se não souber, **pergunte** em vez de chutar. Uma boa pergunta vale mais que dez respostas certas para a coisa errada.
- Reformule o que o cliente disse antes de responder ("Entendi, você quer X — é isso?"). Confirma o entendimento e mostra que você ouviu.
- Ouvir não é demorar. É focar no que importa para o cliente em vez de no que você quer dizer.

---

## 2. Resolver vale mais que ter razão

Em quase toda fricção com cliente existe a tentação de "ganhar" — provar que ele leu errado, que estava nos termos, que a culpa é dele. Você pode ganhar a discussão e perder o cliente.

- O objetivo de qualquer atendimento é o **problema resolvido e o cliente bem atendido**, não a vitória no argumento.
- Mesmo quando o cliente está errado, comece resolvendo. A correção pode vir depois, com calma, e às vezes nem precisa vir.
- "Ter razão" é uma necessidade sua. "Ser atendido" é a necessidade dele. Atenda a dele.

**Teste rápido:** antes de mandar uma resposta defensiva, pergunte: *isso resolve o problema do cliente, ou só prova que eu estava certo?* Se for a segunda, reescreva.

---

## 3. Transparência — admitir erro é força, não fraqueza

A casa não enrola. Quando algo dá errado, o caminho é direto:

- **Errou? Admita.** "A gente errou aqui, e vou consertar assim" vale mais que dez parágrafos de justificativa. O cliente quase sempre perdoa o erro; raramente perdoa a enrolação ou a mentira.
- **Não sabe? Diga que vai descobrir — e quando.** Chutar uma resposta para parecer competente é o caminho mais curto para perder a confiança. "Não sei agora, te respondo até as 17h" é uma resposta profissional.
- **Não dá? Diga que não dá, com o porquê.** Cliente adulto entende um "não" honesto melhor do que um "vou ver" que nunca chega. Negue com clareza e ofereça o que dá, se houver.
- **Não terceirize a culpa.** "Foi o sistema", "foi o outro setor", "não fui eu" — para o cliente, você é a empresa. Assuma e resolva.

Transparência é o ativo mais barato e mais valioso do atendimento. Custa coragem uma vez; rende confiança sempre.

---

## 4. Sem hype, sem promessa que não cumpre

A voz da marca não vende ilusão. No atendimento, isso vira uma regra prática de sobrevivência:

- **Prometa menos e entregue.** É melhor dizer "fica pronto quinta" e entregar quarta do que prometer terça e furar.
- **Prazo é só o que você bate.** Cada prazo furado custa mais confiança do que o prazo honesto teria custado em ansiedade.
- **Nada de superlativo vazio.** "Resolve na hora", "o melhor do mercado", "satisfação garantida" sem lastro soam a vendedor que você não acredita. Descreva o que entrega; deixe o cliente concluir que é bom.
- **Não force a venda.** Empurrar quem disse não queima o cliente para sempre. Convide, mostre o valor, e respeite o "não" e o "agora não".

Hype dá uma venda hoje e custa a reputação amanhã. Honestidade constrói o cliente que volta e indica.

---

## 5. Tempo de resposta

Velocidade é atenção. Demora, mesmo com resposta perfeita, comunica descaso.

- **Responda rápido, nem que seja para dizer que vai demorar.** Um "recebi, te respondo certinho até [prazo]" em 5 minutos vale mais que a resposta completa em 5 horas de silêncio. O cliente tolera espera; não tolera o vácuo.
- **Defina e cumpra um padrão.** Se a equipe responde em até X horas no horário comercial, deixe isso claro e bata a meta. Previsibilidade tranquiliza.
- **Confirme o recebimento de coisas sensíveis** (reclamação, pagamento, pedido) na hora, mesmo que a solução demore.
- **Rápido não é atropelado.** Velocidade não justifica resposta seca ou errada. O equilíbrio é: acuse rápido, resolva certo.

Regra prática: **o pior tempo de resposta é o silêncio.** Entre uma resposta parcial agora e uma completa daqui a horas, dê a parcial agora.

---

## 6. Próximo passo sempre claro (princípio que costura tudo)

Nenhuma interação termina no ar. Ao fim de cada mensagem, o cliente precisa saber:

- O que ficou resolvido ou decidido.
- O que **você** vai fazer e até quando.
- O que **ele** precisa fazer, se algo.
- Como ele volta a falar com você.

Atendimento que fecha sem próximo passo gera a próxima pergunta, a ansiedade e o retrabalho. Clareza no fechamento é o que transforma um atendimento correto em um atendimento que tranquiliza.

---

## Como esses princípios viram tom

| Situação | Princípio que pesa mais | Como soa |
|---|---|---|
| Venda | Sem hype + ouvir | Curioso e útil, nunca empurrado. Mostra valor, respeita o "não". |
| Suporte | Tempo de resposta + transparência | Eficiente e direto. Resolve, ou diz quando resolve. Nunca chuta. |
| Reclamação | Resolver > ter razão + sem defensividade | Calmo e humano. Acolhe a emoção, assume o que é seu, conserta. |
| Cobrança | Transparência + resolver | Firme e respeitoso. Assume boa-fé, facilita, abre espaço pra negociar. |

A constante em todos: **a decisão é do cliente.** Você ouve, resolve e dá o caminho. Quem decide é ele.
