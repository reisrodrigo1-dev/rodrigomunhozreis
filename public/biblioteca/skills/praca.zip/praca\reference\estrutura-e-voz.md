# Estrutura e voz

O gancho prende. A estrutura sustenta. A voz convence. Aqui está como montar o corpo do post e como soar como o Rodrigo — não como uma IA genérica.

---

## A estrutura: gancho → tensão → valor → CTA

Quatro movimentos. Não precisam de subtítulos (rede social não usa heading) — são a lógica interna do post.

### 1. Gancho (1-2 linhas)
Para o scroll, abre o "ver mais". Detalhado em `ganchos.md`. Depois do gancho, uma **quebra de linha** — no LinkedIn é onde o feed corta, então o gancho fica sozinho, isolado, com tensão.

### 2. Tensão (2-5 linhas)
O gancho abriu uma pergunta ou um problema. Aqui você **aprofunda a dor** antes de resolver. Mostra o que está em jogo, por que isso importa, o custo de ignorar. É o que segura a pessoa lendo.

> Sem tensão, o post entrega a lição cedo demais e a pessoa sai. A tensão é o que faz a entrega valer.

### 3. Valor (o miolo)
A entrega. A lição, o passo, a história com desfecho, o número com contexto. **É por isso que a pessoa parou.** Aqui mora a verdade da voz da casa:
- Prova com nome/número (um projeto real, um caso, um dado).
- A lição concreta, não a platitude.
- Se é história: o desfecho e o que você aprendeu.

Mantenha escaneável: linhas curtas, quebras, uma ideia por bloco.

### 4. CTA suave (1-2 linhas)
Um convite só. Verbo + benefício, sem pressão. Pode ser:
- Uma **pergunta real** que abre conversa (ótimo no LinkedIn).
- Um **convite honesto** ("se quiser o passo a passo, link no primeiro comentário").
- Um **"a decisão é sua"** que devolve o comando.

Nunca dois CTAs. Nunca urgência falsa.

---

## A voz da casa — anti-hype

A voz do Rodrigo é PT-BR, direta, com história real e zero hype. As marcas:

### Sem hype
Corte do vocabulário: "revolucionário", "game changer", "vai explodir sua mente", "infalível", "segredo que ninguém te conta", "isso vai mudar tudo", "x100". Hype é o oposto de autoridade — quem tem prova não precisa gritar.

Troque adjetivo por especificidade:
- ❌ "Um resultado incrível e transformador."
- ✅ "Caiu de 2 horas pra 6 minutos."

### Prova antes do discurso
Mostra o caso real, com nome e número, antes de teorizar. "Funciona" não convence; "funcionou no projeto X, que fez Y" convence.

### História real / confissão
A virada da voz do Rodrigo. O que deu errado, o que custou caro, o que você aprendeu apanhando. Vulnerabilidade > vitrine. As pessoas confiam em quem admite erro.

### Frases curtas
Corta o enchimento. Uma ideia por frase. Ponto final é amigo. Frase longa só quando ela ganha algo — e nunca duas seguidas.

### "A decisão é sua"
Recomenda, explica o porquê, e devolve o comando ao leitor. Não empurra. Respeita a inteligência de quem lê.

---

## Quebrar a simetria — pra não soar como IA

Texto de IA tem uma assinatura: simétrico, equilibrado, previsível. Listas de três itens sempre. Frases do mesmo tamanho. Parágrafos do mesmo peso. "Não apenas X, mas também Y." Conclusões que começam com "Em resumo,". O leitor sente, mesmo sem saber nomear.

Pra soar humano, **quebre o padrão de propósito**:

- **Varie o tamanho das frases.** Uma longa, com vírgula e desvio. Depois uma curta. Seca.
- **Varie o tamanho dos blocos.** Um parágrafo de quatro linhas. Um de uma só.
- **Fuja da lista perfeitamente paralela.** Se todo item começa igual e tem o mesmo tamanho, parece máquina. Quebre o ritmo.
- **Use uma frase incompleta de propósito.** Às vezes. Pra dar respiro.
- **Tenha opinião.** IA hedge ("pode ser", "em alguns casos", "é importante considerar"). O Rodrigo crava: "isso está errado e eu explico por quê."
- **Use a linguagem falada do nicho** — gíria de dev, um palavrão pontual se couber, uma referência concreta. Sem caricatura.
- **Evite os clichês de IA:** "no mundo de hoje", "em constante evolução", "desbloquear o potencial", "mergulhe", "navegue por", "é importante notar que", emoji de foguete em tudo.

---

## O que NÃO fazer

### Engajamento-isca (engagement bait)
As plataformas **punem** ativamente:
- "Comente EU QUERO e te mando." → reduz alcance e é cara de spam.
- "Marque 3 amigos." → idem.
- "Curte se você concorda, ignora se discorda." → manipulação rasa.

Engajamento bom vem de **pergunta real** que a pessoa quer responder — não de tarefa forçada.

### Promessa milagrosa
- "Aprenda IA em 7 dias e largue o emprego." → queima a confiança que é o ativo do Rodrigo.
- "O método infalível que substitui anos de estudo." → ninguém sério promete isso.

A promessa honesta vende melhor pra quem você quer: "não é mágica, é método — e dá trabalho."

### Outros venenos
- **Link no corpo** → mata alcance (ver `por-plataforma.md`).
- **Muro de texto** → sem quebras, ninguém lê. Respira.
- **Dois ou mais CTAs** → confunde. Um convite só.
- **Hashtag-spam** → 30 hashtags genéricas = cara de spam.
- **Número inventado** → o tiro no pé mais rápido. Verdade sempre.
- **Falar pra "o público"** → escreva pra uma pessoa.

---

## Checklist antes de entregar

- [ ] Uma ideia só, e dá pra dizer em uma frase?
- [ ] As 1-2 primeiras linhas fazem você parar de rolar?
- [ ] O corpo é escaneável (linhas curtas, quebras)?
- [ ] Tem prova/história real — não só discurso?
- [ ] Zero hype, zero clichê de IA, simetria quebrada?
- [ ] Um CTA suave, sem engajamento-isca?
- [ ] Link no 1º comentário / bio — não no corpo?
- [ ] Adaptado pra plataforma certa (não copy-paste)?

Se tudo marcado: tá pronto pra praça.
