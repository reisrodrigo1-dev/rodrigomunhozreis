# Ganchos — as 1-2 primeiras linhas

O gancho é a linha que faz a pessoa parar de rolar e clicar em "ver mais". É 80% do trabalho. Um post excelente com gancho fraco morre em silêncio; um post mediano com gancho forte é lido.

Regra de ouro: **o gancho promete o que o post entrega.** Clickbait fisga uma vez e queima a confiança — e confiança é o ativo do Rodrigo. Sem hype no gancho também: "isso vai mudar sua vida" não é gancho, é alarme falso.

Abaixo, os padrões que funcionam, cada um com exemplos no tema do Rodrigo (vibecoding, IA, segurança, método, carreira em tech).

---

## 1. Número / dado

Um número concreto na primeira linha. Específico, não redondo demais. O cérebro para em número.

**Por que funciona:** específico = crível. Promete conteúdo mensurável, não papo.

Exemplos:
- "Subi um app pra produção com uma regra de banco aberta. Qualquer um conseguia ler os dados de qualquer usuário. Levou 3 dias até eu perceber."
- "Revisei 40 projetos feitos com IA no último mês. 31 tinham a chave de API exposta no front."
- "Gerei 600 linhas de código em 20 minutos com IA. Depois passei 2 horas entendendo por que metade não devia existir."

Cuidado: número inventado destrói a confiança na hora. Se não tem o dado, não usa esse padrão. (Verdade > efeito.)

---

## 2. Contradição do senso comum

Comece dizendo o oposto do que todo mundo repete. Cria atrito — a pessoa precisa saber por que você discorda.

**Por que funciona:** quebra o piloto automático. Promete um ponto de vista, não mais do mesmo.

Exemplos:
- "Programar com IA não te deixa mais rápido. Te deixa mais perigoso — se você não souber ler o que ela escreveu."
- "Ninguém precisa aprender a programar pra usar IA. Precisa aprender a desconfiar dela."
- "A parte difícil de vibecoding não é gerar o código. É ter coragem de apagar o que a IA gerou."

Cuidado: a contradição tem que se sustentar no corpo. Não é provocação vazia — é tese que você defende.

---

## 3. Confissão

Admita um erro, uma falha, uma vergonha real. Vulnerabilidade desarma — e é a marca da voz da casa (história real / confissão).

**Por que funciona:** honestidade é raro no feed (todo mundo posta vitrine). Confissão gera confiança e identificação na hora.

Exemplos:
- "Por meses eu copiava código da IA sem ler. Funcionava, então tava bom. Até o dia em que não estava — e eu não tinha ideia de por quê."
- "Já entreguei pro cliente um sistema que eu não entendia. Funcionava na minha máquina. Isso me deu uma noite sem dormir que eu mereci."
- "Achei que vibecoding era atalho pra pular a engenharia. Custou caro descobrir que era o contrário."

Cuidado: confissão real, não humblebrag ("meu maior defeito é trabalhar demais"). Tem que ser uma falha de verdade, com lição.

---

## 4. Pergunta que incomoda

Uma pergunta direta, que a pessoa não consegue ignorar porque ela já se fez (ou deveria ter se feito).

**Por que funciona:** ativa o leitor. Ele responde mentalmente e fica pra ver se você concorda.

Exemplos:
- "Você consegue explicar o que o último código que a IA gerou pra você realmente faz? Linha por linha?"
- "Se a IA que você usa saísse do ar amanhã, você ainda saberia construir o que construiu?"
- "Quantas chaves de API você já deixou hardcoded 'só pra testar' e esqueceu lá?"

Cuidado: pergunta tem que ter aresta. "Você quer aprender IA?" não incomoda ninguém — é genérica. A boa pergunta cutuca.

---

## 5. Antes / depois

Mostre dois estados — o de antes (ruim/ingênuo) e o sinal de que algo mudou. Cria curiosidade sobre a virada.

**Por que funciona:** narrativa. O cérebro quer saber o que aconteceu no meio.

Exemplos:
- "Há um ano eu tinha medo de IA tomar meu trabalho. Hoje ela faz 70% dele — e eu trabalho menos. O que mudou não foi a IA."
- "Antes: 'a IA escreve, eu colo, deploy'. Depois de um incidente em produção: 'a IA escreve, eu reviso em 5 camadas, depois deploy'."
- "Comecei achando que precisava decorar sintaxe. Hoje sei que precisava era aprender a fazer as perguntas certas."

Cuidado: o "depois" no gancho não entrega a lição inteira — só sinaliza a virada. A lição vem no corpo.

---

## Padrões bônus

- **Cena concreta:** abra dentro de um momento ("Eram 23h47 e o sistema acabava de cair em produção."). Específico e visual prende.
- **Lista anunciada:** "3 erros que eu cometi com IA e que você não precisa repetir." Promete entrega clara e escaneável.
- **Mini-história em uma linha:** "Um cliente me ligou em pânico. O 'app pronto' que outra pessoa fez com IA tinha vazado os dados de 2 mil usuários."

---

## O que NÃO é gancho

- **Rodeio:** "Nos dias de hoje, com o avanço da inteligência artificial..." — ninguém passa do "hoje".
- **Saudação:** "Fala, galera! Tudo bem?" — desperdiça a linha mais valiosa do post.
- **Hype:** "PREPARE-SE pra ter sua mente EXPLODIDA 🤯" — alarme falso, queima confiança.
- **Vago:** "Reflexões sobre tecnologia e o futuro." — não promete nada.
- **Contexto antes da fisgada:** "Esses dias eu estava pensando e resolvi escrever sobre..." — corta. Comece pela fisgada.

---

## Como escolher

Pra ideia ancorada em erro/aprendizado → **confissão** ou **antes/depois**.
Pra ideia com número/caso real → **número/dado**.
Pra opinião/tese → **contradição do senso comum**.
Pra abrir conversa → **pergunta que incomoda**.

Na dúvida, escreva **dois ganchos diferentes** pro mesmo post e escolha o que VOCÊ pararia pra ler.
