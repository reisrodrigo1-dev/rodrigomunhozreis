# Por plataforma — LinkedIn e Instagram

Mesma ideia, posts diferentes. LinkedIn e Instagram premiam coisas distintas e punem coisas distintas. Copy-paste de um pro outro é o erro nº 1. Aqui estão as diferenças práticas que mudam o resultado.

---

## A regra que vale nas duas: link no corpo mata o alcance

LinkedIn e Instagram **querem manter a pessoa dentro do app**. Qualquer post que mande a pessoa pra fora (link externo no corpo) tem o alcance segurado pelo algoritmo. Não é teoria — é comportamento observado e admitido pelas próprias plataformas.

O que fazer:

- **No corpo do post:** escreva "link no primeiro comentário" (LinkedIn) ou "link na bio" / "link nos stories" (Instagram).
- **No LinkedIn:** poste o link como **primeiro comentário**, logo após publicar. O comentário pode ter o link à vontade.
- **No Instagram:** o app não torna links clicáveis na legenda. Use "link na bio", um agregador (tipo Linktree) ou o link sticker nos stories.

Nunca cole o link no corpo só por preguiça. O custo é alcance.

---

## LinkedIn — post de autoridade

A praça profissional. Quem está lá quer aprender, contratar, ser visto como referência. O tom é profissional, mas **humano** — LinkedIn cansou de corporativês. História pessoal com lição performa muito.

### Formato e tamanho
- **Base texto.** Imagem/documento (carrossel PDF) ajuda, mas o texto carrega o post.
- **Cabe post longo:** ~1.300 a 1.500 caracteres rendem bem. Pode ir além se a ideia sustentar. Mas longo só se cada linha valer — não encha.
- **A primeira linha (até ~140 caracteres) decide o "ver mais".** É o que aparece antes do "...mais". Se não fisga, o resto não é lido. Trate a primeira linha como manchete.

### Estrutura que funciona no LinkedIn
- Gancho de 1-2 linhas (o "ver mais").
- Quebra de linha **logo depois do gancho** — pra criar o corte do "ver mais" num ponto de tensão.
- Corpo escaneável: linhas curtas, muito espaço em branco. Parágrafo de bloco afasta.
- Lição clara no meio.
- CTA suave no fim: uma pergunta real que abre conversa (comentário é o que o algoritmo ama) ou um convite honesto.
- "link no primeiro comentário" se houver material pra divulgar.

### Hashtags no LinkedIn
- **3 a 5 hashtags**, relevantes, no fim do post.
- Sem spam, sem hashtag genérica de 1 milhão de posts (#motivacao #sucesso). Prefira nicho: #vibecoding #desenvolvimentodesoftware #inteligenciaartificial.
- Hashtag não é o motor de alcance no LinkedIn (o engajamento inicial é). Use com parcimônia.

### Sem markdown
LinkedIn **não renderiza** `**negrito**` nem `*itálico*` nem `#` de heading. Escreva texto puro. Pra ênfase: linha isolada, CAPS pontual (raríssimo), ou emoji de marcador de lista (→, •) — sem exagero.

---

## Instagram — legenda + chamada visual

O Instagram é **visual primeiro**. O post é a imagem, o carrossel ou o Reel; a legenda **acompanha**. Mesmo um post de texto vira uma arte/foto. A legenda existe pra dar contexto, aprofundar e chamar pra ação.

### Formato e tamanho
- **A primeira linha aparece cortada** no feed (cerca de 1-2 linhas antes do "... mais"). Capricha igual ao LinkedIn — é o gancho que decide se a pessoa expande.
- Legenda pode ser curta (uma frase + CTA) ou longa (microartigo). As duas funcionam — depende da ideia e do visual.
- Tom **mais conversacional** que o LinkedIn. Emoji combina com Instagram (com critério, não confete).

### A chamada visual
A legenda tem que **conversar com a imagem**. Diga, ou ao menos saiba, qual é o visual:
- Post único (foto/arte com uma frase forte).
- Carrossel (aí o gancho está no slide 1 — e talvez seja caso de usar **Baralho**).
- Reel (aí o roteiro é com a **Claquete**; a Praça escreve só a legenda).

Na entrega, se o visual não veio definido, **sugira a chamada visual** ("imagem sugerida: ___" ou "frase do slide 1: ___").

### Hashtags no Instagram
- **Com critério: 3 a 8 hashtags relevantes.** Não 30 genéricas — isso parece spam e o alcance hoje vem mais do conteúdo e dos sinais (salvamento, compartilhamento, tempo de tela) do que do volume de hashtag.
- Misture: 1-2 amplas do nicho (#inteligenciaartificial), 2-3 médias (#vibecoding #desenvolvedor), 1-2 específicas/de marca (#vibecodingcomengenharia).
- Pode pôr as hashtags **no fim da legenda** ou **no primeiro comentário** (mantém a legenda limpa). As duas funcionam.

### Link
- Instagram **não clica** link na legenda. Use "link na bio", agregador ou o sticker de link nos stories.
- Salvamento e compartilhamento valem mais que curtida no Instagram. CTA que gera salvar ("salva pra não esquecer") é legítimo — desde que o conteúdo realmente valha ser salvo. Sem isca vazia.

---

## Tabela rápida — diferenças práticas

| | LinkedIn | Instagram |
|---|---|---|
| Motor | Texto + engajamento inicial | Visual + sinais (salvar, compartilhar) |
| Tom | Profissional e humano | Conversacional |
| Tamanho | Longo cabe (1.300-1.500+) | Curto ou longo, livre |
| Primeira linha | Decide o "ver mais" | Decide o "... mais" (cortada) |
| Link | 1º comentário | Bio / stories (não clica na legenda) |
| Hashtags | 3-5 nicho, no fim | 3-8 mistas, fim ou 1º comentário |
| Markdown | Não renderiza — texto puro | Não renderiza — texto puro |
| CTA que o algoritmo ama | Comentário (pergunta real) | Salvar / compartilhar |

---

## Uma ideia, duas versões

Quando o pedido for pras duas redes, **não entregue o mesmo texto duas vezes**. Adapte:
- LinkedIn: mais lição/autoridade, primeira linha-manchete, fecha com pergunta de conversa.
- Instagram: mais leve, conversa com o visual, fecha com convite a salvar/seguir.

A ideia é a mesma. A voz é a mesma. O formato muda.
