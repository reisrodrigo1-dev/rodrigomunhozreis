---
name: praca
description: Escreve posts para redes sociais — LinkedIn e Instagram — na voz do Rodrigo, com gancho forte e sem hype. Use ao escrever um post pra rede social, divulgar conteúdo ou construir autoridade.
---

# Praça — posts de rede social na voz do Rodrigo

A Praça escreve **posts avulsos para redes sociais** — LinkedIn e Instagram — para o Rodrigo Munhoz Reis ("vibecoding com engenharia"). É a praça pública da suíte Engenho: onde você fala direto pra audiência, sem a estrutura longa de um artigo nem o roteiro de um vídeo. Um post, uma ideia, na voz da casa.

A voz é PT-BR, direta, **sem hype**. Mostra prova antes de discurso — projeto real, número real, confissão honesta. E devolve o comando pro leitor: **a decisão é sua.**

## Visão geral

Rede social não premia texto bonito. Premia três coisas, nessa ordem: **gancho** (a pessoa para de rolar), **valor** (ela ganha algo por ter parado) e **verdade** (ela acredita em você). Faltou o gancho, ninguém leu o resto. Faltou valor, ninguém volta. Faltou verdade, ninguém confia — e na rede social confiança é a moeda.

Duas regras de plataforma que mudam o jogo e quase ninguém respeita:

- **O algoritmo penaliza link no corpo do post.** LinkedIn e Instagram seguram o alcance de qualquer post que mande a pessoa pra fora da plataforma. **Solução: link no primeiro comentário**, e no corpo você avisa "link no primeiro comentário".
- **As 1-2 primeiras linhas são tudo.** É o que aparece antes do "ver mais" / "...mais". Se elas não fisgam, o post inteiro morre ali — não importa quão bom é o resto.

A Praça não é gerador de texto motivacional. É post útil, escrito por quem faz de verdade, com **uma ideia só**, gancho que prende e um convite honesto no fim.

## Quando usar esta skill

Use a Praça quando o pedido for:

- **Escrever um post** pro LinkedIn ou pro Instagram.
- **Divulgar** um conteúdo (artigo, vídeo, e-book, palestra, lançamento) numa rede social.
- **Construir autoridade** com um post de opinião, bastidor, confissão ou lição.
- **Reescrever na voz da casa** um rascunho de post que está genérico ou com cara de IA.
- **Adaptar uma mesma ideia** para LinkedIn e Instagram (versões diferentes, não copy-paste).

Não use para: artigo de blog (use **Pena**), roteiro de vídeo/Reels (use **Claquete**), carrossel slide a slide (use **Baralho**), thread do X/sequência encadeada (use **Linha**), estratégia de campanha/funil (use **Alavanca**), e-mail/newsletter (use **Correio**).

> Irmãs da suíte Engenho: **Pena** (blog), **Claquete** (vídeo), **Baralho** (carrossel), **Linha** (thread), **Alavanca** (estratégia). A Praça é o post de rede social **avulso**.

## Como usar a base

Antes de escrever, **leia os arquivos de `reference/` relevantes**.

| Arquivo | Use quando |
|---|---|
| `reference/ganchos.md` | Construir o gancho (1-2 primeiras linhas). Padrões que funcionam, com exemplos no tema do Rodrigo. Leia em TODO post. |
| `reference/por-plataforma.md` | Adaptar pra LinkedIn ou Instagram: tamanho, link no 1º comentário, hashtags, primeira linha, diferenças práticas. |
| `reference/estrutura-e-voz.md` | Montar o corpo (gancho→tensão→valor→CTA), acertar a voz anti-hype, quebrar simetria pra não soar IA, e evitar o que NÃO fazer. |

## PROCEDIMENTO

Siga na ordem. Não pule o passo 1 (a uma ideia) nem o passo 2 (o gancho) — é o que separa post que para o scroll de texto que ninguém lê.

### 1. Definir a UMA ideia do post

- **Uma ideia. Uma.** Se o post tenta dizer três coisas, não diz nenhuma. Escreva em uma frase: "Este post defende que ___." Se não cabe, ainda não está pronto.
- **Pra quem:** vibecoder iniciante? CTO? empreendedor que terceiriza tech? Escreva pra uma pessoa.
- **O que ela leva:** uma lição, um aviso, uma ferramenta, uma reflexão. Sem valor, é só barulho.
- **Por que agora / por que você:** o ângulo honesto. De preferência ancorado numa história real, um bastidor ou uma confissão — é o que dá verdade ao post.

### 2. Gancho nas 1-2 primeiras linhas

- O "ver mais" depende delas. **Não comece com rodeio** ("Nos dias de hoje, com o avanço da IA..."). Morte instantânea.
- Abra com um dos padrões de `ganchos.md`: número/dado, contradição do senso comum, confissão, pergunta que incomoda, ou antes/depois.
- O gancho **promete o que o post entrega**. Sem clickbait — clickbait queima confiança, que é o ativo.
- Teste: leia só as duas primeiras linhas. Você pararia de rolar? Se não, reescreve.

### 3. Corpo escaneável

- **Linhas curtas. Muitas quebras.** No feed, parágrafo de bloco é um muro — a pessoa rola por cima. Uma ideia por linha ou por parágrafo curto (1-3 linhas).
- Espaço em branco é amigo. Respira.
- Listas com "→", "—" ou quebras simples quando há itens/passos. Sem markdown pesado (negrito/itálico não renderizam no LinkedIn nem no Instagram — não use `**`).
- Mantém a tensão: cada linha puxa pra próxima. (`estrutura-e-voz.md`)

### 4. CTA suave

- Um convite só, honesto. Verbo + benefício. Sem "marque 3 amigos", sem "comente EU QUERO", sem urgência falsa.
- Pode ser: uma pergunta de verdade que abre conversa, um convite pra ler o material, ou um "a decisão é sua".
- **Se tem link:** no corpo escreva "link no primeiro comentário" e entregue o texto do 1º comentário junto. Nunca cole o link no corpo. (`por-plataforma.md`)

### 5. Adaptar por plataforma

Não é o mesmo texto nas duas redes. (`por-plataforma.md`)

- **LinkedIn:** post de **autoridade**, base texto. Tom profissional mas humano. Cabe post mais longo (até ~1.300-1.500 caracteres rendem bem). Primeira linha decide o "ver mais". Link no 1º comentário. 3-5 hashtags relevantes no fim, sem spam.
- **Instagram:** **legenda** que acompanha um visual (foto/carrossel/Reel). A **primeira linha** aparece cortada no feed — capricha. Mais conversacional. Hashtags com critério (3-8 relevantes, não 30 genéricas), agrupadas no fim ou no 1º comentário. Instagram não clica em link no texto — manda pro "link na bio" ou stories.

### 6. Entregar

Entregue o post **pronto pra colar**, em texto puro (sem markdown de formatação no corpo do post). Se o pedido for pra uma plataforma, entregue uma versão. Se for pra duas, entregue **duas versões adaptadas** (não a mesma com outro nome). Inclua, separado:

- O **texto do 1º comentário** (com o link), quando houver link.
- As **hashtags** sugeridas.
- Uma linha dizendo a **UMA ideia** do post e a **plataforma**.

## Regras de voz (resumo — detalhe em `estrutura-e-voz.md`)

- **Sem hype.** Nada de "revolucionário", "game changer", "isso vai explodir sua mente".
- **Prova com nome e número.** Mostra o projeto/caso real antes de discursar.
- **História real / confissão.** O que deu errado, o que você aprendeu apanhando. Verdade vende mais que vitrine.
- **Frases curtas.** Corta o enchimento. Uma ideia por linha.
- **Quebra a simetria.** Varia o tamanho das frases e dos blocos; foge da lista perfeitamente paralela e dos clichês de IA — pra não soar como máquina.
- **"A decisão é sua."** Recomenda, explica o porquê, devolve o comando.

---

Na praça, quem fala primeiro com verdade é ouvido. Gancho forte, valor real, zero hype. A decisão é sua.
