# Template — Webhook handler seguro (Next.js App Router)

Modelo de route handler que faz o que **todo** webhook precisa: lê o raw body, **valida a assinatura** (tempo constante), garante **idempotência**, **falha fechado**, responde rápido, e **não vaza segredo no log**. Use como ponto de partida e troque a parte de validação pelo padrão do seu provedor.

> Princípios por trás de cada passo em `reference/seguranca-de-integracao.md`. Padrão por serviço (Stripe, Mercado Pago, WhatsApp) em `reference/integracoes-comuns.md`.

---

## Variáveis de ambiente necessárias

```bash
# .env.local (dev) / painel da Vercel (prod) — NUNCA com prefixo NEXT_PUBLIC_
WEBHOOK_SIGNING_SECRET=whsec_xxx   # o signing secret do provedor
```

---

## A) Genérico — assinatura HMAC-SHA256 + idempotência (Firestore)

```ts
// app/api/webhooks/[provedor]/route.ts
import crypto from "crypto";
import { db } from "@/lib/firebase-admin"; // Firebase Admin SDK, server-only

// Garante runtime Node (crypto + raw body). Edge não serve aqui.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const SECRET = process.env.WEBHOOK_SIGNING_SECRET!;

// 1) Validação de assinatura em tempo constante, sobre o RAW body
function assinaturaValida(raw: string, header: string | null): boolean {
  if (!header) return false;
  const esperado = "sha256=" + crypto.createHmac("sha256", SECRET).update(raw).digest("hex");
  const a = Buffer.from(header);
  const b = Buffer.from(esperado);
  // timingSafeEqual exige mesmo tamanho; checar antes evita exceção e vazamento por timing
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

// 2) Idempotência: registra o id do evento de forma atômica.
//    create() falha se o doc já existe → sinal claro de "já processei".
async function jaProcessado(eventId: string): Promise<boolean> {
  const ref = db.collection("webhook_events").doc(eventId);
  try {
    await ref.create({ recebidoEm: new Date() });
    return false; // criou agora → é a primeira vez
  } catch {
    return true; // já existia → duplicata, ignore
  }
}

export async function POST(req: Request) {
  // Leia os bytes exatos. NÃO use req.json() antes de validar.
  const raw = await req.text();
  const assinatura = req.headers.get("x-signature"); // ajuste ao header do seu provedor

  // Falha FECHADO: assinatura inválida → 401, não processa nada.
  if (!assinaturaValida(raw, assinatura)) {
    return new Response("assinatura inválida", { status: 401 });
  }

  // Só agora é seguro fazer parse.
  let evento: { id: string; type: string; data: unknown };
  try {
    evento = JSON.parse(raw);
  } catch {
    return new Response("payload inválido", { status: 400 });
  }

  // Idempotência — provedores reentregam o mesmo evento de propósito.
  if (await jaProcessado(evento.id)) {
    return new Response("ok (duplicado, ignorado)", { status: 200 });
  }

  // Processe. Mantenha leve; se for pesado, responda 200 e jogue para uma fila.
  try {
    switch (evento.type) {
      case "payment.approved":
        // libere o produto AQUI — esta é a fonte da verdade, não o redirect do front
        break;
      // outros casos...
      default:
        // tipo não tratado: aceite (200) para o provedor não ficar reenviando
        break;
    }
  } catch (err) {
    // Log SEM corpo cru / sem segredo. Retorne 5xx para o provedor reenviar.
    console.error("falha ao processar webhook", { eventId: evento.id, type: evento.type });
    return new Response("erro ao processar", { status: 500 });
  }

  // Responda rápido. O provedor espera 2xx em poucos segundos.
  return new Response("ok", { status: 200 });
}
```

---

## B) Stripe — usando o SDK (recomendado quando há SDK oficial)

O SDK já valida a assinatura em tempo constante; não reimplemente HMAC à mão.

```ts
// app/api/webhooks/stripe/route.ts
import Stripe from "stripe";
import { db } from "@/lib/firebase-admin";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);
const WEBHOOK_SECRET = process.env.STRIPE_WEBHOOK_SECRET!;

async function jaProcessado(eventId: string): Promise<boolean> {
  const ref = db.collection("webhook_events").doc(eventId);
  try {
    await ref.create({ recebidoEm: new Date() });
    return false;
  } catch {
    return true;
  }
}

export async function POST(req: Request) {
  const raw = await req.text(); // raw body obrigatório para a verificação
  const sig = req.headers.get("stripe-signature");

  let event: Stripe.Event;
  try {
    // Valida assinatura E faz o parse. Lança se for inválido → falha fechado.
    event = stripe.webhooks.constructEvent(raw, sig!, WEBHOOK_SECRET);
  } catch (err) {
    return new Response("assinatura inválida", { status: 400 });
  }

  if (await jaProcessado(event.id)) {
    return new Response("ok (duplicado)", { status: 200 });
  }

  try {
    switch (event.type) {
      case "checkout.session.completed":
      case "invoice.paid":
        // ATIVE a assinatura / libere o acesso aqui — fonte da verdade
        break;
      case "customer.subscription.deleted":
        // revogue o acesso
        break;
      default:
        break;
    }
  } catch {
    console.error("erro ao processar evento stripe", { eventId: event.id, type: event.type });
    return new Response("erro", { status: 500 }); // 5xx → Stripe reenvia
  }

  return new Response("ok", { status: 200 });
}
```

---

## Por que cada decisão (resumo)

| Decisão | Motivo |
|---|---|
| `runtime = "nodejs"` | Precisa de `crypto` e do raw body; Edge não cobre bem. |
| `await req.text()` (não `.json()`) | A assinatura é sobre os bytes exatos; re-serializar quebra a verificação. |
| Validar **antes** de parsear | O corpo é input hostil até a assinatura provar a origem. |
| `timingSafeEqual` (não `===`) | Comparar com `===` vaza a assinatura por timing attack. |
| Falhar com 401/400 e não processar | Falha fechado: na dúvida sobre a origem, recuse. |
| `create()` para idempotência | Operação atômica: se o id já existe, é duplicata — provedores reentregam. |
| 200 em tipo não tratado | Evita o provedor ficar reenviando um evento que você simplesmente ignora. |
| 5xx em erro de processamento | Sinaliza ao provedor para reentregar (e o id já registrado evita efeito duplo no retry — registre o efeito junto, idealmente transacional). |
| Log sem corpo cru | A resposta/headers podem conter token, PII, assinatura — não jogue no observability. |

---

## Como testar (antes de produção)

1. **Local:** use o encaminhamento do provedor para receber eventos de teste na sua máquina.
   ```bash
   # Stripe, por exemplo:
   stripe listen --forward-to localhost:3000/api/webhooks/stripe
   stripe trigger checkout.session.completed
   ```
2. **Assinatura inválida:** mande um POST com assinatura errada → tem que dar 401/400 e **não** processar.
3. **Duplicata:** dispare o **mesmo** evento duas vezes → o efeito (liberar produto) só pode acontecer **uma** vez.
4. **Erro de processamento:** force uma falha no handler → tem que retornar 5xx (provedor reenvia) sem deixar estado pela metade.
5. **Produção:** cadastre a URL de webhook de produção e o signing secret **de produção** no painel do provedor e na Vercel. Faça uma transação real pequena de ponta a ponta antes de anunciar.

> Skill **Prova** gera esses testes; **Crivo** revisa o handler pelo Protocolo de 5 Camadas antes do push.
