# Segurança de integração — princípios transversais

Estes são os cuidados que valem para **qualquer** integração, independente do provedor. Cada seção tem o porquê, o padrão, e código pronto (Next.js App Router + Node). Use junto com `integracoes-comuns.md` (padrão por serviço) e `templates/webhook-handler.md` (webhook pronto).

---

## 1. Segredos vivem no servidor

**Por quê:** o navegador é território hostil. Tudo que vai para o client (incluindo variáveis `NEXT_PUBLIC_*`) está visível para qualquer usuário no DevTools e no bundle. Uma secret key vazada = conta do provedor sequestrada, custo na sua conta, dados expostos.

**O padrão:**

- Secret key, access token, signing secret, service account → **variável de ambiente do servidor**. `.env.local` em dev, painel da Vercel (Environment Variables) em produção.
- **Nunca** prefixe um segredo com `NEXT_PUBLIC_`. Esse prefixo embute o valor no JavaScript que vai para o navegador.
- A chamada que usa o segredo roda em **route handler, Server Action, ou função serverless** — nunca em componente client, `useEffect`, ou código que o navegador baixa.
- `.env*` no `.gitignore`. Mantenha um `.env.example` com os **nomes** das variáveis (sem valores) para documentar.

**Público vs secreto — exemplo Stripe:**

| Chave | Vai para o client? | Variável |
|---|---|---|
| Publishable (`pk_...`) | Sim, é desenhada para isso | `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY` |
| Secret (`sk_...`) | **Nunca** | `STRIPE_SECRET_KEY` |
| Webhook signing secret (`whsec_...`) | **Nunca** | `STRIPE_WEBHOOK_SECRET` |

**Se uma chave já foi commitada:** ela vazou. Apagar o arquivo não basta — fica no histórico do Git. **Rotacione a chave no painel do provedor** e troque a env. (Skill **Faro** para caçar segredo no repositório.)

---

## 2. Validar assinatura de webhook

**Por quê:** a URL do seu webhook é pública. Qualquer pessoa na internet pode fazer POST nela fingindo ser o provedor. Sem validar a assinatura, você aceita "pagamento aprovado", "cancele a assinatura", "novo pedido" de um estranho.

**O padrão:**

1. **Leia o raw body** (`await req.text()`). A assinatura é calculada sobre os bytes exatos do corpo. Se você fizer `req.json()` antes e depois re-serializar, os bytes mudam e a verificação quebra.
2. **Recalcule a assinatura** com o signing secret do provedor (geralmente HMAC-SHA256) e compare com o header.
3. **Compare em tempo constante** (`crypto.timingSafeEqual`) para não vazar a assinatura por timing attack.
4. **Falhe fechado:** assinatura inválida → `401` e não processa nada.

```ts
import crypto from "crypto";

function assinaturaValida(raw: string, header: string, secret: string): boolean {
  const esperado = "sha256=" + crypto.createHmac("sha256", secret).update(raw).digest("hex");
  const a = Buffer.from(header);
  const b = Buffer.from(esperado);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}
```

Provedores com SDK (ex.: Stripe) já fazem isso por você — use `stripe.webhooks.constructEvent(raw, sig, secret)` em vez de reimplementar.

---

## 3. Retries e idempotência

**Por quê:** redes falham e provedores reentregam eventos de propósito. Sem idempotência, um retry vira cobrança dupla, dois e-mails, dois pedidos. Idempotência = "fazer de novo não causa efeito de novo".

**Dois lados:**

### a) Quando VOCÊ chama o terceiro

- **Retry só no que é seguro repetir.** Leituras (GET) são seguras. Escritas só com chave de idempotência.
- **Idempotency key:** muitos provedores aceitam um header (Stripe: `Idempotency-Key`). A mesma chave garante que a operação roda uma vez, mesmo se você reenviar.
- **Backoff:** espera crescente entre tentativas (1s, 2s, 4s) com um teto de tentativas. Não martele o provedor.

```ts
async function comRetry<T>(fn: () => Promise<T>, tentativas = 3): Promise<T> {
  let ultimoErro: unknown;
  for (let i = 0; i < tentativas; i++) {
    try {
      return await fn();
    } catch (err) {
      ultimoErro = err;
      await new Promise((r) => setTimeout(r, 2 ** i * 1000)); // backoff exponencial
    }
  }
  throw ultimoErro;
}
```

### b) Quando o terceiro chama VOCÊ (webhook)

- Registre o `id` do evento já processado (numa coleção do Firestore, por exemplo). Antes de processar, cheque: já vi esse id? Se sim, responda `200` e ignore.
- Faça o registro do id e o efeito numa operação que não deixe brecha (idealmente transacional), para não processar duas vezes em concorrência.

> Implementação de idempotência com Firestore em `templates/webhook-handler.md`.

---

## 4. Timeout — nunca espere para sempre

**Por quê:** uma chamada externa sem timeout pode pendurar sua função serverless até o limite de execução da Vercel estourar. Uma rota lenta vira uma rota derrubada, e o usuário fica girando.

**O padrão:** `AbortController` com um teto de tempo.

```ts
async function fetchComTimeout(url: string, opts: RequestInit = {}, ms = 8000) {
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), ms);
  try {
    const res = await fetch(url, { ...opts, signal: ctrl.signal });
    return res;
  } finally {
    clearTimeout(t);
  }
}
```

Ajuste o `ms` ao limite da sua função (na Vercel, fique bem abaixo do `maxDuration`). Trate o `AbortError` como falha do terceiro.

---

## 5. Rate limit

**Por quê:** dois riscos. (1) O terceiro tem limite — se você estourar, ele te bloqueia. (2) Endpoints seus que disparam ações externas (enviar e-mail, SMS, WhatsApp) viram vetor de abuso e de custo se um usuário malicioso os marteliza.

**O padrão:**

- **Respeite o limite do provedor:** leia a doc, espalhe chamadas, use fila para picos. Trate o `429 Too Many Requests` com backoff (respeite o header `Retry-After` quando vier).
- **Proteja seus endpoints que custam dinheiro:** limite por usuário/IP qualquer rota que dispare envio externo ou criação de cobrança. Sem isso, um loop malicioso esvazia sua conta de e-mail/SMS.
- Na Vercel, dá para usar um limitador com store externo (ex.: Upstash Redis) ou um contador no Firestore para casos simples.

> Profundidade de rate limiting (brute-force, scraping) na skill **Bastião**.

---

## 6. Tratar a falha do terceiro sem derrubar seu app

**Por quê:** o serviço externo é uma dependência que você não controla. Ele vai cair, ficar lento, ou mudar comportamento. Seu app precisa degradar com elegância, não quebrar junto.

**O padrão — decida a criticidade de cada chamada:**

- **Crítico** (sem isso a operação não faz sentido — ex.: cobrar o pagamento): se falhar, falhe a operação com erro claro ao usuário e registre para investigar. Não finja sucesso.
- **Auxiliar** (a operação principal vale mesmo sem isso — ex.: e-mail de boas-vindas, notificação): **isole**. Se falhar, registre e siga; a operação principal conclui. Idealmente joga numa fila para retry depois.

**Fail closed vs fail open:**

- Em **autorização/pagamento**, falhe **fechado**: na dúvida, negue. "Não consegui confirmar o pagamento" → não libera o produto.
- Em **funcionalidade auxiliar**, pode falhar **aberto** (degradar): "não consegui carregar as recomendações" → mostra a página sem elas.

**Não vaze segredo no log.** Ao registrar uma falha, logue status e id do evento — **não** o corpo cru da resposta nem os headers (podem conter token, PII, assinatura).

```ts
// auxiliar: isola a falha, app segue
try {
  await enviarEmailBoasVindas(usuario);
} catch (err) {
  logger.error("email boas-vindas falhou", { userId: usuario.id }); // sem corpo cru
  // não relança — o cadastro já concluiu
}
```

---

## Checklist rápida de integração segura

- [ ] Secret no servidor; nada sensível em `NEXT_PUBLIC_`; `.env` no `.gitignore`.
- [ ] Toda chamada externa tem timeout.
- [ ] Erro do terceiro é tratado (não há `catch {}` vazio); segredo não vai pro log.
- [ ] Idempotência onde há dinheiro/efeito (idempotency key + registro de id processado).
- [ ] Retry só no seguro, com backoff e teto.
- [ ] Webhook valida assinatura sobre o raw body, em tempo constante, e falha fechado.
- [ ] Endpoint que dispara ação externa custosa tem rate limit.
- [ ] Falha de função auxiliar não derruba o fluxo principal.
- [ ] Testado em sandbox: caminho feliz, caminho ruim, e evento duplicado.
