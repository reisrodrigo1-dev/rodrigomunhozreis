---
name: ponte
description: Integra APIs e serviços externos (pagamento, e-mail, WhatsApp, webhooks) com segurança — credenciais no servidor, tratamento de erro, idempotência e validação de assinatura. Use ao conectar ou integrar uma API externa, gateway de pagamento, serviço de e-mail/SMS/WhatsApp, webhook, ou qualquer serviço de terceiro à sua aplicação.
---

# Ponte — Integração Segura com Serviços Externos

> *Vibecoding com engenharia.* Toda integração é uma porta que você abre no seu sistema.
> A Ponte garante que essa porta tenha tranca: segredo no servidor, erro tratado, webhook verificado.
> Autor: Rodrigo Munhoz Reis. Voz: direta, sem hype. **A decisão é sua** — a Ponte aponta o caminho seguro; você atravessa.

## Visão geral

Conectar um serviço de terceiro (Stripe, Mercado Pago, Resend, Twilio, WhatsApp Cloud API, um webhook qualquer) parece simples: copia a chave, cola no código, chama o `fetch`, funcionou. É exatamente esse "funcionou" que vaza chave, cobra duas vezes o cliente, derruba seu app quando o terceiro cai, e aceita webhook falso de qualquer um na internet.

A **Ponte** é a base de conhecimento para integrar com segurança. Ela não escreve a integração no automático: ela te dá **o procedimento**, **os padrões seguros por tipo de serviço** e **os templates** para que cada porta que você abre fique trancada por padrão.

Três verdades que guiam tudo aqui:

1. **Credencial vive no servidor.** Chave de API nunca toca o navegador, nunca vira `NEXT_PUBLIC_`, nunca entra no Git.
2. **O terceiro vai falhar.** Vai dar timeout, vai retornar 500, vai duplicar evento. Sua integração precisa sobreviver a isso sem derrubar seu app nem cobrar o cliente duas vezes.
3. **Webhook é input não-confiável.** Qualquer um pode chamar a sua URL. Sem verificar a assinatura, você está confiando em estranho.

**Stack de referência:** Next.js (App Router), Firebase, Vercel, Node. Os princípios valem para qualquer stack; os exemplos são desses.

**O que a Ponte NÃO faz:**
- Não promete integração "à prova de tudo". Aponta o risco real e o padrão que o mitiga.
- Não decide o gateway/provedor por você — mostra o cuidado-chave de cada um.
- Não substitui a doc oficial. **Reforça** que você precisa lê-la (as APIs mudam).

## Quando usar (gatilhos de ativação)

Acione a Ponte quando o trabalho tocar **um serviço externo, dinheiro, ou uma URL que recebe chamada de fora**. Em especial:

### Deve usar
- Integrar **pagamento** — Stripe, Mercado Pago, Pagar.me, PayPal, assinatura/checkout.
- Integrar **e-mail transacional** — Resend, SendGrid, Postmark, SES, Mailgun.
- Integrar **WhatsApp / SMS / push** — WhatsApp Cloud API, Twilio, Z-API, OneSignal.
- Receber ou enviar **webhook** — confirmação de pagamento, evento de terceiro, callback.
- Chamar **qualquer API de terceiro** server-side (`fetch` para fora) que use credencial.
- Guardar **token/chave/secret** de um serviço externo.
- Conectar um **serviço de IA** com chave paga (custo por uso) — OpenAI, Anthropic, etc.

### Recomendado
- "Funcionou no teste, posso colocar a chave de produção?" — antes do go-live.
- Suspeita de **cobrança duplicada**, evento processado duas vezes, ou webhook ignorado.
- Decidir **como guardar a credencial** de um serviço novo desde o desenho.

### Pular
- Chamada a uma API pública **sem credencial e sem efeito colateral** (ex.: ler um CEP público no client). Mesmo assim, se vira fluxo de dado pessoal, veja LGPD.

**Critério de decisão:** se a mudança envolve **credencial de terceiro, dinheiro, ou uma URL que recebe POST de fora**, use a Ponte.

---

## Como usar a base de conhecimento

A inteligência está em `reference/` e `templates/`. Carregue **só o arquivo relevante** ao contexto:

| Arquivo | Use quando precisar de... |
|---|---|
| `reference/integracoes-comuns.md` | Padrão seguro pronto por tipo de serviço: pagamento (Stripe/Mercado Pago), e-mail transacional, WhatsApp API, webhook genérico — cada um com o cuidado-chave. |
| `reference/seguranca-de-integracao.md` | Os princípios transversais: segredo no server, validar assinatura, retries/idempotência, rate limit, e sobreviver à falha do terceiro. |
| `templates/webhook-handler.md` | Modelo de route handler (Next.js App Router) que valida assinatura e é idempotente — ponto de partida para qualquer webhook. |

**Fluxo recomendado:** siga o **PROCEDIMENTO** abaixo, na ordem. As cinco etapas existem porque cada uma assume a anterior resolvida — não adianta validar webhook (4) se a credencial (2) está no client.

---

## Princípios (a bússola da Ponte)

1. **Credencial é do servidor.** Segredo de terceiro nunca entra no bundle do client, em `NEXT_PUBLIC_*`, nem no Git. O navegador é território hostil.
2. **O terceiro é uma dependência instável.** Trate toda chamada externa como algo que pode demorar, falhar ou repetir. Timeout, retry e fallback não são luxo.
3. **Idempotência protege o cliente.** Processar o mesmo evento duas vezes não pode cobrar duas vezes, enviar dois e-mails, criar dois pedidos.
4. **Webhook é input hostil até provar o contrário.** Verifique a assinatura **antes** de confiar em qualquer byte do corpo.
5. **A fonte da verdade é o terceiro, não o navegador.** Pagamento se confirma pelo webhook/consulta server-side, nunca por um redirect de "sucesso" no front.
6. **Teste em sandbox antes de produção.** Cartão de teste, número de teste, chave de teste. Produção é o último passo, não o primeiro.
7. **A decisão é sua.** A Ponte recomenda e explica o trade-off; quem aceita o risco é o dono do produto.

---

## PROCEDIMENTO de integração

> Antes de começar: tenha claro **qual serviço**, **o que ele precisa fazer** no seu produto, e **quem dispara** (usuário, cron, outro sistema). Sem isso, você integra no escuro.

### Etapa 1 — Entender a integração e ler a doc oficial

**Meta:** saber o que você vai conectar antes de escrever uma linha.

1. **Defina o fluxo em uma frase.** "Usuário clica em assinar → cria sessão de checkout → paga no Stripe → webhook confirma → libero o acesso." Se você não consegue escrever isso, não está pronto para codar.
2. **Leia a doc oficial do provedor** — a versão atual. APIs mudam: endpoints, formato de assinatura de webhook, nomes de evento. Não confie em tutorial de blog de 2021 nem em código que a IA gerou "de memória"; confirme contra a doc.
3. **Identifique o que o serviço exige:** chave/secret, qual ambiente (test vs live), quais escopos/permissões, se tem webhook, qual o formato da assinatura do webhook, quais limites de rate.
4. **Mapeie a superfície:** o que você envia para fora (tem dado pessoal? pagamento?), o que recebe de volta, e quem pode disparar cada ponta. Dado pessoal → gatilho de LGPD (skill **Salvaguarda**).
5. **Decida a fonte da verdade.** Para pagamento e estados que valem dinheiro, a verdade é o evento confirmado server-side, nunca o front.

**Saída:** o fluxo em uma frase + a lista do que o provedor exige + onde mora a fonte da verdade.

### Etapa 2 — Credenciais no SERVIDOR (env, nunca no client)

**Meta:** a chave nunca sai do servidor.

1. **Toda credencial vai em variável de ambiente do servidor** (`.env.local` em dev, painel da Vercel em prod). Nunca hardcoded no código.
2. **Nunca prefixe segredo com `NEXT_PUBLIC_`.** Esse prefixo embute a variável no bundle que vai para o navegador — qualquer um lê. `NEXT_PUBLIC_` é só para o que pode ser público (ex.: a *publishable key* do Stripe, que é desenhada para ser pública).
3. **A chamada com a chave roda no servidor**: route handler (`app/api/.../route.ts`), Server Action, ou função serverless. Nunca em componente client nem em `useEffect`.
4. **`.env*` está no `.gitignore`.** Confirme. Se a chave já foi commitada alguma vez, ela vazou — **rotacione** no painel do provedor, não basta apagar o arquivo. (Skill **Faro** para caçar segredo vazado.)
5. **Separe ambientes:** chave de teste em dev/preview, chave de produção só em produção. Documente quais variáveis o projeto precisa (sem os valores) num `.env.example`.

> Padrão detalhado e armadilhas (publishable vs secret key, onde a Vercel expõe env, o que vaza no bundle) em `reference/seguranca-de-integracao.md`.

**Saída:** todas as credenciais em env do servidor, nenhuma em `NEXT_PUBLIC_` indevidamente, `.env` ignorado pelo Git.

### Etapa 3 — Implementar com tratamento de erro, timeout e idempotência

**Meta:** a integração sobrevive quando o terceiro tropeça.

1. **Timeout em toda chamada externa.** Sem timeout, uma requisição pendurada segura sua função serverless até estourar o limite da Vercel e derrubar a experiência. Use `AbortController` (veja template em `reference/seguranca-de-integracao.md`).
2. **Trate o erro de verdade.** Verifique `response.ok`, leia o corpo de erro do provedor, e decida: retornar erro claro ao usuário, registrar para investigar, ou seguir em fallback. Nunca engula o erro em `catch {}` vazio.
3. **Retry só no que é seguro repetir** (idempotente: leituras, ou escritas com chave de idempotência). Use backoff (espera crescente). Não dê retry cego em "criar cobrança" — pode cobrar duas vezes.
4. **Idempotência onde dinheiro/efeito importa.** Muitos provedores aceitam uma *idempotency key* (Stripe, por exemplo): a mesma chave garante que a operação roda uma vez só, mesmo que você reenvie. Do seu lado, registre o `id` do evento/operação já processado e ignore repetição.
5. **Falha do terceiro não derruba seu app.** Isole: se o e-mail de boas-vindas falhou, o cadastro ainda deve concluir. Decida o que é crítico (pagamento) e o que pode degradar com elegância (notificação).
6. **Não vaze segredo no log.** Logar a resposta inteira do provedor pode jogar token/PII no seu observability. Logue o necessário (status, id do evento), não o corpo cru.

> Padrões prontos de timeout, retry com backoff, idempotency key e *fail open vs fail closed* em `reference/seguranca-de-integracao.md`.

**Saída:** chamadas com timeout, erro tratado, idempotência onde importa, falha isolada.

### Etapa 4 — Validar webhooks (verificar assinatura, nunca confiar cego)

**Meta:** só processar webhook que comprovadamente veio do provedor.

1. **Verifique a assinatura ANTES de tudo.** O provedor assina o corpo com um *signing secret*; você recalcula e compara. Sem isso, qualquer um faz POST na sua URL fingindo ser o Stripe e "confirma" um pagamento que não aconteceu.
2. **Use o corpo CRU (raw body).** A verificação de assinatura é feita sobre os bytes exatos. Se você fizer `req.json()` antes, o re-serializar muda os bytes e a assinatura quebra. No App Route handler, leia `await req.text()`.
3. **Compare em tempo constante** (`crypto.timingSafeEqual`), não com `===`, para não vazar a assinatura por timing.
4. **Idempotência no webhook.** Provedores reenviam o mesmo evento (é o comportamento esperado deles). Registre o `event.id` processado e ignore duplicata — senão você libera o produto duas vezes.
5. **Responda rápido (2xx) e processe depois se for pesado.** O provedor espera resposta em poucos segundos; se demorar, ele reenvia. Confirme o recebimento e jogue o trabalho pesado para fora do caminho da resposta.
6. **A confirmação real mora aqui.** Estado que vale dinheiro (pagamento aprovado, assinatura ativa) muda no webhook verificado, **não** no redirect de "sucesso" do front — o usuário pode forjar essa URL.

> Modelo completo de route handler que valida assinatura e é idempotente em `templates/webhook-handler.md`.

**Saída:** webhook que verifica assinatura sobre raw body, compara em tempo constante, e ignora evento repetido.

### Etapa 5 — Testar com dados de teste antes de produção

**Meta:** provar que funciona sem mexer em dinheiro de verdade.

1. **Use o ambiente de sandbox/teste do provedor.** Chave de teste, cartão de teste (ex.: Stripe `4242 4242 4242 4242`), número de teste no WhatsApp. Nada de produção até o fluxo fechar.
2. **Teste o caminho de webhook localmente.** Use a CLI/encaminhamento do provedor (ex.: `stripe listen --forward-to localhost:3000/api/webhooks/stripe`) para receber eventos reais de teste na sua máquina.
3. **Exercite os caminhos ruins**, não só o feliz: pagamento recusado, timeout, webhook duplicado, assinatura inválida, terceiro retornando 500. Cada "e se..." sem teste é um buraco. (Skill **Prova** para gerar esses testes.)
4. **Confirme a idempotência:** dispare o mesmo evento duas vezes e verifique que o efeito acontece uma vez só.
5. **Só então promova para produção:** troque para a chave live no ambiente de produção (não no preview), cadastre a URL de webhook de produção e o signing secret de produção, e faça **uma** transação real pequena de ponta a ponta antes de anunciar.

**Saída:** fluxo testado em sandbox (feliz + ruim + duplicado), e uma transação real de validação antes do go-live.

---

## FORMATO DE SAÍDA

Ao orientar ou revisar uma integração, entregue nesta estrutura. Direto, PT-BR, sem hype.

```
Integração: <serviço> — <fluxo em uma frase>

1. Entender   — <status> · doc oficial conferida? fonte da verdade definida?
2. Credenciais — <status> · no server? nada em NEXT_PUBLIC_? .env ignorado?
3. Implementar — <status> · timeout? erro tratado? idempotência onde importa?
4. Webhook    — <status> · assinatura validada (raw body)? idempotente?
5. Testar     — <status> · sandbox + caminho ruim + transação real de validação?
```

Para cada ponto fora do lugar, entregue um achado com:
- **Onde:** `arquivo:linha` ou etapa.
- **Por que importa:** o impacto concreto ("qualquer um pode confirmar um pagamento falso", "pode cobrar o cliente duas vezes").
- **Como corrigir:** o passo + trecho de código seguro.

Feche com o veredicto:
- **PRONTO PARA PRODUÇÃO** — credencial no server, erro/idempotência tratados, webhook validado, testado em sandbox.
- **NÃO PRONTO** — liste os bloqueadores em uma frase. Segredo no client e webhook sem assinatura são bloqueadores críticos.

Sempre lembre: **o conserto e a decisão de subir são seus.** A Ponte aponta; você atravessa.

---

## Referências

- **`reference/integracoes-comuns.md`** — padrão seguro por tipo de serviço (pagamento, e-mail, WhatsApp, webhook genérico).
- **`reference/seguranca-de-integracao.md`** — princípios transversais: segredos, assinatura, idempotência, rate limit, falha do terceiro.
- **`templates/webhook-handler.md`** — modelo de route handler que valida assinatura e é idempotente.

## Skills que combinam com a Ponte (suíte Engenho)

- **Bastião** — inteligência de segurança por stack; encadeie ao desenhar a integração.
- **Cofre** — regras do Firebase, se a integração grava no Firestore/Storage.
- **Faro** — caça a segredos vazados; rode se desconfiar que uma chave foi commitada.
- **Crivo** — revisa o código da integração pelo Protocolo de 5 Camadas antes do push.
- **Salvaguarda** — LGPD, quando a integração trafega dado pessoal.
- **Prova** — gera os testes dos caminhos ruins que a Etapa 5 pede.
