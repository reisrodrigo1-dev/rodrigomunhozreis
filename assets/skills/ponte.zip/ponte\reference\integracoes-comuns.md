# Integrações comuns — padrão seguro por tipo de serviço

Cada seção tem: **o fluxo seguro**, **o cuidado-chave** (o erro que mais derruba gente no vibecoding), e um esqueleto de código. Os exemplos assumem Next.js (App Router) + Node. Sempre confirme contra a doc oficial atual do provedor — as APIs mudam.

> Regra que vale para todas: a credencial (secret key) roda no **servidor**, nunca no client. A confirmação de estado que vale dinheiro vem do **webhook verificado** ou de uma **consulta server-side**, nunca de um redirect de "sucesso" no front.

---

## 1. Pagamento

O tipo de integração onde errar custa literalmente dinheiro — do cliente ou seu. Dois cenários cobrem a maioria: **Stripe** (internacional) e **Mercado Pago** (Brasil). O padrão é o mesmo.

### Fluxo seguro (checkout no servidor + webhook de confirmação)

```
1. Front pede ao SEU servidor para iniciar o pagamento (não fala direto com o gateway).
2. SEU servidor cria a sessão de checkout / preferência usando a SECRET key.
   - Define preço e itens NO SERVIDOR (nunca aceite o valor vindo do front — o usuário edita).
3. Servidor devolve a URL/ID; o front redireciona o usuário para o checkout do gateway.
4. Usuário paga no ambiente do gateway (você não toca no cartão).
5. Gateway chama SEU webhook confirmando o pagamento.
6. Você VERIFICA a assinatura do webhook, confirma o evento, e SÓ ENTÃO libera o produto.
7. A página de "sucesso" do front é só UX — ela NÃO libera nada por si só.
```

### Cuidado-chave

**Nunca confie no valor vindo do front, nem no redirect de sucesso para liberar.** Se o preço vem do navegador, o usuário pode trocar R$ 100 por R$ 1. Se você libera o produto na página `/sucesso`, qualquer um acessa essa URL sem pagar. **O preço se define no servidor; a liberação acontece no webhook verificado.**

### Stripe — esqueleto

Criar a sessão (server):

```ts
// app/api/checkout/route.ts
import Stripe from "stripe";
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!); // secret, no server

export async function POST(req: Request) {
  const { plano } = await req.json();
  const precos = { mensal: "price_xxx", anual: "price_yyy" }; // preço definido AQUI, no server
  const priceId = precos[plano as keyof typeof precos];
  if (!priceId) return new Response("plano inválido", { status: 400 });

  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: `${process.env.APP_URL}/sucesso?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.APP_URL}/cancelado`,
  });
  return Response.json({ url: session.url });
}
```

Confirmar via webhook: veja `templates/webhook-handler.md` (Stripe usa `checkout.session.completed` / `invoice.paid`). A publishable key (`pk_...`) pode ir em `NEXT_PUBLIC_`; a secret key (`sk_...`) **jamais**.

### Mercado Pago — diferenças

- Você cria uma **preferência** de pagamento no servidor com o `ACCESS_TOKEN` (secret); o front usa a `PUBLIC_KEY` só para abrir o checkout (Checkout Pro/Bricks).
- A confirmação vem por **webhook de notificação (IPN/Webhooks)**: o Mercado Pago manda o `id` do pagamento; você consulta o pagamento pela API (`GET /v1/payments/{id}`) **com seu access token** para saber o status real — não confie só no payload da notificação.
- Valide a origem da notificação (assinatura `x-signature`, conforme a doc atual) antes de consultar.

> Regra de ouro nos dois: **o estado "pago" só muda no seu banco depois de confirmar server-side.** O resto é UX.

---

## 2. E-mail transacional

Confirmação de cadastro, recuperação de senha, recibo, notificação. Provedores: Resend, SendGrid, Postmark, SES, Mailgun.

### Fluxo seguro

```
1. O envio roda no SERVIDOR (route handler / Server Action), com a API key em env.
2. Você dispara o e-mail como efeito de uma ação (cadastro concluído, pedido pago).
3. O envio é ISOLADO do fluxo crítico: se o e-mail falhar, a ação principal não falha junto.
4. (Recebendo eventos de entrega/bounce) → webhook verificado, como qualquer outro.
```

### Cuidado-chave

**O e-mail não pode derrubar a ação principal, e não pode virar vetor de spam/abuso.** Dois pontos:

- **Isole a falha.** Se o e-mail de boas-vindas falha, o cadastro ainda conclui. Não coloque o envio no caminho que decide sucesso/erro do fluxo crítico — registre a falha e siga, ou jogue numa fila para retry.
- **Cuidado com endereço vindo do usuário.** Se o usuário informa o destinatário (ex.: "convide um amigo"), você tem um vetor de abuso: rate limit por usuário, e nunca deixe o usuário controlar o *conteúdo* livremente (open relay / injeção de header). Use templates fixos com variáveis.

### Esqueleto (Resend)

```ts
// dentro de uma Server Action ou route handler, no server
import { Resend } from "resend";
const resend = new Resend(process.env.RESEND_API_KEY!);

try {
  await resend.emails.send({
    from: "Equipe <no-reply@seudominio.com>",
    to: usuario.email,            // do seu banco, não cru do front sem validar
    subject: "Bem-vindo",
    react: EmailBoasVindas({ nome: usuario.nome }),
  });
} catch (err) {
  // NÃO derruba o cadastro — registra e segue
  logger.error("falha ao enviar boas-vindas", { userId: usuario.id });
}
```

> Configure SPF/DKIM/DMARC do domínio (no provedor) para não cair em spam — isso é entregabilidade, não opcional para e-mail transacional.

---

## 3. WhatsApp API

WhatsApp Cloud API (Meta) ou agregadores (Twilio, Z-API, 360dialog). Usado para notificação, confirmação, atendimento. Tem regras próprias: você só pode iniciar conversa com **templates aprovados**; fora da janela de 24h após o usuário falar, mensagem livre é bloqueada.

### Fluxo seguro

```
ENVIO (você → usuário):
1. Roda no SERVIDOR, com o token de acesso em env.
2. Fora da janela de 24h: só mensagem de TEMPLATE pré-aprovado pela Meta.
3. Rate limit + idempotência: não dispare a mesma notificação duas vezes.

RECEBIMENTO (usuário → você, via webhook):
4. A Meta chama seu webhook a cada mensagem/evento.
5. VERIFICAÇÃO inicial (GET): a Meta valida sua URL com hub.verify_token — devolva o challenge.
6. EVENTOS (POST): valide a assinatura (X-Hub-Signature-256, HMAC-SHA256 com o app secret).
7. Idempotência por message id — a Meta reentrega.
```

### Cuidado-chave

**Token de longa duração no servidor + assinatura no webhook + respeitar a janela/templates.** O erro clássico é botar o token no client (vaza a conta do WhatsApp Business inteira) ou aceitar o webhook sem validar `X-Hub-Signature-256` (qualquer um injeta mensagem falsa no seu fluxo de atendimento). E mandar mensagem livre fora da janela só gera erro e risco de bloqueio da conta.

### Esqueleto — verificação do webhook (GET) e assinatura (POST)

```ts
// app/api/webhooks/whatsapp/route.ts
import crypto from "crypto";

// 1) Verificação da URL pela Meta (uma vez, no cadastro)
export async function GET(req: Request) {
  const u = new URL(req.url);
  const mode = u.searchParams.get("hub.mode");
  const token = u.searchParams.get("hub.verify_token");
  const challenge = u.searchParams.get("hub.challenge");
  if (mode === "subscribe" && token === process.env.WHATSAPP_VERIFY_TOKEN) {
    return new Response(challenge, { status: 200 });
  }
  return new Response("forbidden", { status: 403 });
}

// 2) Eventos — valide a assinatura sobre o RAW body
export async function POST(req: Request) {
  const raw = await req.text();
  const sig = req.headers.get("x-hub-signature-256") ?? "";
  const esperado =
    "sha256=" +
    crypto.createHmac("sha256", process.env.WHATSAPP_APP_SECRET!).update(raw).digest("hex");
  const ok =
    sig.length === esperado.length &&
    crypto.timingSafeEqual(Buffer.from(sig), Buffer.from(esperado));
  if (!ok) return new Response("assinatura inválida", { status: 401 });

  const evento = JSON.parse(raw);
  // ... idempotência por message id, processa, responde 200 rápido
  return new Response("ok", { status: 200 });
}
```

> Modelo completo e idempotente em `templates/webhook-handler.md`.

---

## 4. Webhooks genéricos (qualquer terceiro chamando você)

Sempre que um serviço de fora faz POST numa URL sua (pagamento, GitHub, formulário externo, automação tipo n8n/Zapier, etc.), o padrão é o mesmo, independente do provedor.

### Fluxo seguro

```
1. Endpoint dedicado, idealmente com caminho difícil de adivinhar.
2. Leia o RAW body (await req.text()) — a assinatura é sobre os bytes exatos.
3. VALIDE a assinatura/segredo do provedor ANTES de fazer parse ou confiar em nada.
4. Compare em tempo constante (timingSafeEqual), não com ===.
5. IDEMPOTÊNCIA: registre o id do evento; se já processou, responda 200 e ignore.
6. Processe; se for pesado, responda 200 rápido e jogue o trabalho para fora do caminho.
7. Falhe FECHADO: assinatura inválida → 401 e não processa.
```

### Cuidado-chave

**A URL é pública — qualquer um na internet pode chamá-la.** A assinatura é a única prova de que o POST veio mesmo do provedor. Sem ela, você está aceitando comando de estranho: alguém pode forjar "pagamento aprovado", "assinatura cancelada", "novo pedido". **Validar assinatura sobre o raw body é inegociável; idempotência evita processar o mesmo evento duas vezes (provedores reentregam de propósito).**

### Onde fica o segredo de validação por provedor

| Provedor | Header da assinatura | Como validar |
|---|---|---|
| Stripe | `Stripe-Signature` | `stripe.webhooks.constructEvent(raw, sig, whSecret)` |
| WhatsApp / Meta | `X-Hub-Signature-256` | HMAC-SHA256 do raw com o app secret |
| GitHub | `X-Hub-Signature-256` | HMAC-SHA256 do raw com o webhook secret |
| Mercado Pago | `x-signature` | HMAC conforme doc; depois consulta o pagamento pela API |
| Genérico/caseiro | header customizado | HMAC-SHA256 do raw com um secret compartilhado |

> Implementação pronta (com timeout, idempotência via Firestore, e tempo constante) em `templates/webhook-handler.md`.

---

## Resumo dos cuidados-chave

| Integração | O erro que mais derruba | O padrão que corrige |
|---|---|---|
| Pagamento | Liberar pelo redirect de "sucesso" / aceitar preço do front | Preço no server; liberar só no webhook verificado |
| E-mail | Falha do e-mail derruba o fluxo principal | Isolar o envio; rate limit no envio disparado por usuário |
| WhatsApp | Token no client / webhook sem assinatura | Token no server; validar `X-Hub-Signature-256`; respeitar templates/janela |
| Webhook genérico | Confiar no POST sem verificar origem | Assinatura sobre raw body, tempo constante, idempotência |
