# Vaidade vs. decisão — como não se enganar com o próprio painel

Existe um teste único que separa toda métrica em dois grupos:

> **Se esse número mudasse a sua próxima ação, é uma métrica de decisão. Se a sua ação seria a mesma com ele subindo ou descendo, é uma métrica de vaidade.**

Vaidade não é o mesmo que "inútil". É "não decide nada **agora, para você**". A mesma métrica pode ser vaidade num contexto e decisão noutro (impressões importam para quem vende awareness de marca; são puro enfeite para quem precisa de venda neste mês). O que define não é a métrica — é a pergunta na mesa.

---

## As métricas de vaidade clássicas

São as que mais sobem, mais aparecem em destaque no painel, e mais dão sensação de progresso:

- **Impressões / Alcance** — quantas vezes apareceu, quanta gente viu. Sobe fácil (basta pagar mais), não diz se alguém agiu.
- **Seguidores** — número grande, ego inflado, correlação fraquíssima com receita. Conta cheia de seguidores que não compram é audiência, não negócio.
- **Curtidas / Comentários / Compartilhamentos** — engajamento social. Pode indicar ressonância de conteúdo, mas raramente paga conta.
- **Visualizações de vídeo** — especialmente "views de 3 segundos", que a plataforma conta generosamente.
- **Pageviews / Sessões / Usuários (soltos)** — tráfego total sem recorte de conversão. Muita visita que não converte é só custo.
- **Cliques totais** (sem custo nem conversão ao lado) — clique é meio, não fim.

O que todas têm em comum: **sobem mesmo quando o negócio não anda.** É por isso que viciam — entregam a sensação de vitória sem a vitória.

---

## As métricas de decisão

São as que respondem a uma pergunta de negócio e mudam o que você faz a seguir:

- **Taxa de conversão** — dos que chegaram, quantos agiram. Diz se a oferta/página funciona.
- **CPL (custo por lead)** — quanto custa capturar um contato. Diz se a captura é sustentável.
- **CAC (custo de aquisição de cliente)** — quanto custa ganhar quem **paga**. Diz se a aquisição fecha.
- **ROAS** — receita por real de anúncio. Diz se a campanha se paga.
- **Receita / Receita por canal** — o número que paga as contas.
- **LTV** e **churn** (lado da Decolagem) — quanto o cliente vale e quanto você perde. Fecham a conta do CAC.

O que todas têm em comum: têm **um cifrão por perto** ou respondem direto "valeu a pena / não valeu". Quando sobem, o negócio andou. Quando caem, você precisa agir.

---

## Tabela: a versão vaidosa e a versão que decide

Quase toda métrica de vaidade tem uma "irmã de decisão" — a pergunta certa para o mesmo assunto:

| Você está olhando (vaidade) | Pergunte em vez disso (decisão) |
|---|---|
| Impressões / Alcance | Quantos **converteram**? Qual o **CPL/CAC**? |
| Seguidores | Quantos seguidores viraram **e-mail na lista** ou **cliente**? |
| Curtidas / engajamento do post | O post **trouxe lead ou venda**? |
| Visualizações de vídeo | Quantas viraram **clique na oferta**? |
| Sessões / Usuários totais (GA4) | Conversões e **receita por canal** |
| Cliques no anúncio | **Taxa de conversão** e **CPL** desses cliques |
| "Meu vídeo viralizou (500k views)" | Quanto isso virou em **lista/receita**? Quase sempre: pouco |

A irmã de decisão está sempre **um passo adiante no funil**. Vaidade mede o topo (apareceu, foi visto, clicou). Decisão mede o fundo (converteu, pagou, voltou).

---

## Como você se engana (e como parar)

São padrões previsíveis. Reconhecê-los já é metade da cura.

1. **Comemorar o que cresceu mais.** O número que mais sobe costuma ser o mais vaidoso (impressões escalam com orçamento; receita não). Crescimento de impressão não é conquista — é, no máximo, o que você comprou.

2. **Olhar o total, esconder a taxa.** "10.000 visitas!" esconde "0,2% de conversão". Total infla o ego; **taxa** revela a verdade. Sempre que vir um número absoluto grande, peça a taxa.

3. **Confundir lead com cliente.** "Captei 300 leads" é bom — mas leads não pagam contas. A pergunta seguinte é sempre: quantos viraram **clientes pagantes** e a que **CAC**.

4. **Confundir ROAS com lucro.** ROAS 3 parece vitória. Se sua margem é 30%, você ainda pode estar empatando ou perdendo. ROAS é receita, não lucro — só decide depois de descontar custo do produto e operação.

5. **Reagir a ruído sem volume.** Um dia ruim, um pico estranho, 3 cliques sem conversão. Variação pequena não é tendência. (Ver protocolo de volume mínimo em `metricas-anuncios.md`.)

6. **Olhar o Tempo real do GA4 buscando dopamina.** "Tem 12 pessoas no site agora!" não muda nenhuma decisão. Tempo real serve para validar tracking; o resto é vício. (Ver `metricas-ga4.md`.)

7. **Montar relatório que não termina em ação.** Se o seu relatório/print acaba em "olha como cresceu" e não em "por isso vou continuar/pausar/escalar/ajustar X", ele é decoração.

---

## O teste de uma pergunta (use sempre)

Antes de dar peso a qualquer métrica, faça uma pergunta:

> **"Se esse número estivesse pela metade, eu faria algo diferente?"**

- **Sim** → é métrica de decisão. Dê atenção.
- **Não / não sei** → é vaidade naquele contexto. Anote e siga em frente.

E quando o empreendedor estiver claramente animado com um número de vaidade, o trabalho honesto é dizer, sem rodeio: *"isso é bonito e dá um gás, mas não responde a sua pergunta. O número que responde é este aqui — e ele está dizendo o seguinte."* Tirar o brilho falso de um número é tão útil quanto encontrar o número certo.

---

## Resumo de bolso

- Vaidade mede **topo** (apareceu, viu, clicou). Decisão mede **fundo** (converteu, pagou, voltou).
- Toda vaidade tem uma irmã de decisão um passo adiante no funil — pergunte por ela.
- Total engana; **taxa** e **custo** decidem.
- Lead ≠ cliente. ROAS ≠ lucro.
- O teste: *"se esse número caísse pela metade, eu mudaria minha ação?"* Se não, é vaidade.
- Métrica que não termina em ação é decoração. A decisão é sua.
