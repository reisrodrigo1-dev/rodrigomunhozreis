# Métricas de anúncios — o que é bom e a decisão (continuar / pausar / escalar)

Vale para **Meta Ads** (Facebook/Instagram) e **Google Ads**. As métricas são as mesmas; o que muda são as faixas de referência (a intenção no Google Search é maior que no feed do Meta, então conversão e custo se comportam diferente). Onde a diferença importa, está marcada.

Antes de qualquer benchmark, leia o protocolo de volume mínimo no fim — é a regra que separa análise de chute.

---

## As métricas, em ordem de funil

O dinheiro percorre um caminho. Cada métrica mede uma etapa. Ler na ordem do funil mostra **onde** o dinheiro vaza.

```
impressão → clique → visita à landing → lead → cliente → receita
   (CTR)      (CPC)                      (CPL)   (conversão)  (CAC, ROAS)
```

### CTR — Taxa de cliques
**O que é:** cliques ÷ impressões. Mede se o **criativo/copy** chama atenção.

**Faixas de referência (use como ordem de grandeza, não lei):**
- Meta (feed/stories): ~0,9%-1,5% é normal; acima de 2% é forte; abaixo de ~0,7% é fraco.
- Google Search: ~3%-6% é normal (intenção alta); abaixo de ~2% é fraco para Search.
- Google Display: ~0,4%-0,8% é normal (banner é frio).

**O que diz:** CTR baixo = o anúncio não atrai (criativo, headline ou público errado). CTR é a métrica do **anúncio em si**, não da oferta.

### CPC — Custo por clique
**O que é:** gasto ÷ cliques. Quanto você paga para trazer alguém à página.

**O que diz:** sobe quando o CTR cai (plataforma cobra mais de anúncio que ninguém clica) ou quando o público/leilão é caro. CPC alto isolado não é problema — é problema se o clique não converte. Um CPC caro que vira cliente barato está ótimo.

### CPL — Custo por lead
**O que é:** gasto ÷ leads (e-mails/cadastros capturados). A métrica-chave de campanha de topo de funil com isca.

**O que diz:** se a captura está saindo a um custo que a sua conta de negócio aguenta. CPL só faz sentido contra a sua meta: se um lead vale R$ 50 para você (porque X% viram clientes que pagam Y), um CPL de R$ 8 é excelente e de R$ 70 é inviável. Sem saber quanto vale seu lead, CPL é um número solto.

### Taxa de conversão
**O que é:** conversões ÷ cliques (ou ÷ visitas à landing). Mede se a **landing/oferta** transforma o clique em ação.

**Faixas de referência:** landing de isca (só e-mail) costuma converter ~20%-40%; landing de venda direta, ~1%-5% conforme preço e frieza do tráfego.

**O que diz:** é a métrica da **página**, não do anúncio. CTR ok + conversão baixa = o anúncio entrega gente, a página falha.

### CAC — Custo de aquisição de cliente
**O que é:** gasto total ÷ clientes **pagantes** conquistados. Não é CPL — lead não é cliente.

**O que diz:** quanto custa, de fato, ganhar quem paga. É a métrica que conversa com a Decolagem: CAC só fecha se for confortavelmente menor que o LTV (o quanto o cliente deixa ao longo do tempo). Regra prática de saúde: LTV ao menos ~3x o CAC.

### ROAS — Retorno sobre o gasto com anúncio
**O que é:** receita gerada ÷ gasto com anúncio. ROAS 3 = cada R$ 1 de anúncio voltou R$ 3 de receita.

**O que diz:** é a métrica mais direta de "valeu a pena?" para venda direta. **Cuidado:** ROAS é sobre *receita*, não *lucro*. ROAS 2 pode dar prejuízo se a sua margem for menor que 50%. O ROAS que importa é o que cobre o custo do produto + a operação + ainda sobra. Por isso muita gente trabalha com uma meta de **ROAS de break-even** (o mínimo para não perder dinheiro) e só comemora acima dela.

---

## A decisão: continuar, pausar ou escalar

A leitura sempre cruza **custo vs. meta** com **volume de dados**. Nunca decida só pelo número — decida pelo número **com volume suficiente**.

### PAUSAR / MATAR
- Já passou o volume mínimo (abaixo) **e** o custo não fecha: CPL/CAC acima da meta, ou ROAS abaixo do break-even.
- CTR muito baixo **e** custo alto, mesmo com volume: o anúncio não atrai — mate este criativo (não necessariamente o público).
- Sinal claro de que cada real está saindo mais caro do que volta. Cortar desperdício é decisão, não derrota.

### CONTINUAR / DEIXAR RODAR
- Ainda **não atingiu o volume mínimo** — não há dado para decidir. Deixe rodar até ter base.
- Dentro da meta, estável. Não mexa no que está funcionando só por ansiedade.

### ESCALAR
- Abaixo da meta de custo (CPL/CAC bom, ROAS acima do break-even) **com volume sólido e consistente** por alguns dias.
- Como escalar: aumente o orçamento ~20%-30% por vez e observe 2-3 dias. **Não dobre de uma vez** — mudança brusca de orçamento reinicia o aprendizado da plataforma e costuma piorar o desempenho. Escala é degrau, não salto.

### AJUSTAR (antes de matar)
Diagnóstico por par de métricas:
- **CTR baixo + conversão indefinida** → problema é o **criativo/copy**. Troque o anúncio antes de trocar o público.
- **CTR ok + conversão baixa** → problema é a **landing/oferta**. O anúncio traz gente; a página não fecha. (Passe para Alavanca/Vitrine.)
- **Conversão zero com cliques altos** → suspeite de **tracking quebrado** antes de culpar a oferta. Valide o evento no GA4 Tempo real.

---

## PROTOCOLO DE VOLUME MÍNIMO (leia antes de qualquer veredito)

Esta é a regra mais importante deste arquivo. Decidir com pouco dado é jogar moeda e chamar de análise.

**Não pause, não escale e não conclua nada antes de atingir, no mínimo:**
- **~50-100 cliques** no conjunto de anúncios, **e**
- **~3 dias** rodando (para alisar variação de dia da semana), **e**
- idealmente **pelo menos algumas conversões** (1 ou 2 conversões não definem uma taxa — uma a mais muda tudo).

Por quê: com 10 cliques e 0 conversão, a "taxa de conversão real" pode perfeitamente ser 5% — você só não teve sorte ainda. Matar aí descarta um anúncio que talvez fosse bom. Com 100 cliques e 0 conversão, aí sim o sinal é forte.

**Exceções para agir antes do volume:**
- Gasto desproporcional sem nenhum sinal de vida (ex.: R$ 200 gastos, 0 cliques, 0 conversões): pode pausar para investigar configuração/segmentação — aqui o problema é setup, não desempenho.
- Erro evidente (anúncio apontando para link quebrado, público errado óbvio): conserte na hora.

**Quanto orçamento reservar para um teste honesto:** o suficiente para comprar o volume mínimo. Se seu CPC estimado é ~R$ 1,50, 100 cliques custam ~R$ 150 — esse é o piso do teste, não R$ 30. Testar com verba que não compra volume mínimo é gastar para não aprender nada.

---

## Resumo de bolso

| Métrica | Mede | Decisão que destrava |
|---|---|---|
| CTR | O anúncio atrai? | Baixo → trocar criativo/copy |
| CPC | Custo do clique | Contexto; só preocupa se o clique não converte |
| CPL | Custo do lead | Acima da meta (com volume) → pausar/ajustar |
| Taxa de conversão | A landing fecha? | Baixa com CTR ok → ajustar oferta/página |
| CAC | Custo do cliente pagante | Maior que ~⅓ do LTV → modelo não fecha (ver Decolagem) |
| ROAS | Receita ÷ gasto | Abaixo do break-even (com volume) → pausar; bem acima → escalar |

**Regra final:** custo que fecha a conta vence número que cresce. Olhe o que tem cifrão associado (CPL, CAC, ROAS) antes de olhar impressões e alcance. E nunca decida antes do volume mínimo.
