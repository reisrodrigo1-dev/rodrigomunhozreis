# Métricas do GA4 — o que cada seção diz e a ação típica

O Google Analytics 4 (GA4) mede o que acontece **depois** do clique: quem chegou, de onde veio, o que fez e se converteu. O painel é grande e a maioria das telas é ruído para quem não é analista. Este arquivo aponta as quatro seções que realmente importam para um founder, o que cada uma responde e a ação que ela costuma destravar.

Antes de tudo, dois conceitos que o GA4 usa e confundem:

- **Usuário** = pessoa (aproximada por dispositivo/navegador). Quantas pessoas distintas.
- **Sessão** = uma visita. Uma pessoa pode ter várias sessões. Sessão expira após 30 min de inatividade.
- **Evento** = qualquer ação rastreada (page_view, scroll, clique, envio de formulário). No GA4, *tudo* é evento.
- **Conversão / evento-chave** = o evento que você marcou como "isto é o que importa" (ex.: gerar lead, comprar, agendar). Você define quais são. **Se você não marcou nenhum evento-chave, o GA4 não sabe o que é sucesso para você — e nenhuma análise séria é possível.** Configurar isso é o passo zero.

> Regra de ouro do GA4: o painel mostra dezenas de números por padrão. Quase todos são contexto, não decisão. Vá direto à seção que responde a sua pergunta e ignore o resto da tela.

---

## 1. Aquisição — "de onde vêm meus usuários?"

**O que responde:** por qual canal/origem as pessoas chegaram (Busca orgânica, Pago, Direto, Social, Referência, E-mail).

**Onde fica:** Relatórios → Aquisição → Aquisição de tráfego (por sessão) e Aquisição de usuários (primeira visita do usuário).

**O que olhar (e não olhar):**
- Olhe **conversões e receita por canal**, não só sessões. O canal que traz mais gente raramente é o que traz mais venda.
- A coluna que decide é "eventos-chave" (conversões) por canal e, se houver e-commerce, "receita" por canal.
- *Default channel group* é o agrupamento útil: compara orgânico vs. pago vs. direto vs. social num olhar.

**Como interpretar:**
- Canal com muita sessão e pouca conversão = tráfego de baixa qualidade ou intenção errada (típico de social e de anúncio mal segmentado).
- Canal com pouca sessão e muita conversão = ouro. É onde escalar.
- "Direct" inflado geralmente é tracking faltando (links sem UTM, tráfego de app, e-mail sem marcação) — desconfie antes de comemorar "muita gente me acessa direto".

**Ação típica:** reforce o investimento (tempo ou dinheiro) no canal que converte por menor custo; questione ou corte o canal que só traz volume vazio; conserte UTMs se "Direct"/"Unassigned" estiver alto demais.

---

## 2. Engajamento — "o que as pessoas fazem no site e o que importa de verdade?"

**O que responde:** se as pessoas interagem com o conteúdo, quais páginas seguram atenção, e quantas conversões aconteceram.

**Onde fica:** Relatórios → Engajamento → Visão geral, Eventos, Páginas e telas, Conversões.

**Métricas que importam:**
- **Taxa de engajamento** = % de sessões "engajadas" (duraram mais de 10s, tiveram conversão, ou 2+ pageviews). É o substituto saudável da antiga "taxa de rejeição". Faixa comum: 50-70% é razoável; abaixo de ~40% sugere que a página entrega menos do que o anúncio/link prometeu.
- **Páginas e telas:** quais páginas recebem mais visita e quais convertem. Use para achar a página que atrai mas não converte (candidata a conserto) e a que converte (candidata a receber mais tráfego).
- **Eventos:** confira se os eventos que você considera importantes (envio de formulário, clique no CTA, scroll até a oferta) estão de fato disparando. Se o evento não dispara, a conversão "some" — e você culpa a oferta quando o problema é tracking.

**O que NÃO supervalorizar:** tempo médio de engajamento e pageviews soltos são contexto, não decisão. Página com tempo alto e zero conversão não é "boa" — é uma sala de espera bonita.

**Ação típica:** identifique a página de maior tráfego com baixa conversão e priorize ajuste de oferta/CTA ali; confirme que os eventos-chave disparam antes de qualquer diagnóstico de "oferta ruim".

---

## 3. Conversões (eventos-chave) — "estou atingindo o objetivo?"

**O que responde:** quantas vezes o que importa de verdade aconteceu (lead gerado, compra, agendamento) e por qual caminho.

**Onde fica:** Relatórios → Engajamento → Conversões (ou "Eventos-chave", dependendo da versão). Para e-commerce: Monetização.

**O que olhar:**
- Volume de cada evento-chave e sua **tendência** (sobe, estável, cai).
- Conversões **por canal** e **por página de entrada** — cruza com Aquisição para responder "qual canal me dá cliente, não só visita".
- Se há receita: receita total, valor médio do pedido, e — se configurado — receita por canal.

**Como interpretar:**
- Conversão caindo com tráfego estável = problema na página/oferta ou em tracking (verifique se o evento ainda dispara — atualização de site costuma quebrar tag).
- Conversão zero com tráfego alto = quase sempre **tracking quebrado**, não oferta ruim. Investigue a tag antes de mudar a página.
- Conversão concentrada em um canal = você sabe onde está seu motor; proteja e amplie esse canal.

**Ação típica:** se a conversão é o gargalo e o tráfego existe, o trabalho é na oferta/landing (passe para Alavanca/Vitrine); se a conversão é boa e estável, o gargalo é volume de tráfego (passe para Alavanca/tráfego). O GA4 te diz **qual dos dois** é o problema.

---

## 4. Tempo real — "está acontecendo agora?"

**O que responde:** quem está no site neste minuto, de onde vêm, em que página estão, quais eventos estão disparando agora.

**Onde fica:** Relatórios → Tempo real.

**Para que serve de verdade (e para que NÃO serve):**
- **Serve** para **verificar tracking**: você publicou uma página/anúncio, acessa pelo celular, faz uma conversão de teste, e confirma no Tempo real que o evento aparece. É a ferramenta certa para "minha tag está funcionando?".
- **Serve** para checar um pico pontual: mandou um e-mail/post agora e quer ver se chegou tráfego.
- **NÃO serve** para decidir estratégia. Tempo real é um instantâneo, não tendência. Ficar olhando o "ao vivo" é a métrica de vaidade mais viciante do GA4 — dá sensação de movimento e não informa nada sobre o que fazer.

**Ação típica:** use logo após publicar algo (página, evento, campanha) para validar tracking e disparo de eventos; depois **feche a aba** e volte para os relatórios que mostram tendência.

---

## Resumo de bolso

| Seção | Pergunta que responde | Métrica que decide | Ação típica |
|---|---|---|---|
| Aquisição | De onde vem meu tráfego? | Conversões/receita **por canal** | Reforçar o canal que converte; cortar o que só traz volume; consertar UTMs |
| Engajamento | O que fazem no site? | Taxa de engajamento + conversão por página | Ajustar página de alto tráfego e baixa conversão; validar eventos |
| Conversões | Atinjo o objetivo? | Volume e tendência dos eventos-chave | Decidir se o gargalo é oferta (landing) ou volume (tráfego) |
| Tempo real | Está acontecendo agora? | Evento aparece ao vivo? | Validar tracking após publicar; não usar para estratégia |

**Erro recorrente:** olhar "Usuários" e "Sessões" na home do GA4, ver o número subindo e achar que isso é resultado. Não é. Sessão sem conversão é só custo. Sempre desça até conversão por canal — é lá que está a decisão.
