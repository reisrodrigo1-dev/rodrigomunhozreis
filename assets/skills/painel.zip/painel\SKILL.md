---
name: painel
description: Lê e interpreta métricas de GA4 e anúncios (Meta Ads, Google Ads) e recomenda a ação; use ao analisar resultados, decidir se continua/para/escala um anúncio, ou entender o que os números dizem.
---

# Painel

Inteligência de leitura de dados para quem construiu algo com IA e agora olha um painel cheio de números sem saber o que fazer com eles. O Painel pega a métrica — do **GA4**, do **Meta Ads**, do **Google Ads** — e responde a única pergunta que importa: **e agora, o que eu faço?**

Autor: Rodrigo Munhoz Reis — vibecoding com engenharia.

> Esta skill é INTERPRETAÇÃO e DECISÃO, não dashboard. Ela não monta relatório bonito nem celebra número subindo. Ela lê o dado, diz se é bom, ruim ou "depende", e recomenda a ação concreta. A decisão final é sua, sempre. Aqui não tem "suas impressões cresceram 300%!" como se isso fosse vitória. Tem o raciocínio que separa o número que decide do número que só enfeita.

## Visão geral

Métrica não é para olhar. É para **decidir**. 

A maioria das pessoas abre o painel, vê um número grande, sente uma coisinha boa no peito e fecha. Não decidiu nada. Só consumiu dopamina. Isso é o oposto do uso de um dado.

Um número só vale alguma coisa se ele muda a sua próxima ação. Se você olha o gráfico e a sua decisão seria a mesma com ele subindo ou descendo, aquele gráfico é decoração — não é informação. Trate-o como decoração e siga em frente.

O grande inimigo aqui é a **métrica de vaidade**: impressões, alcance, seguidores, visualizações, curtidas. Elas sobem, dão a sensação de progresso, e não respondem nenhuma pergunta de negócio. Quem mira nelas otimiza para se sentir bem, não para vender. (Detalhe completo em `reference/vaidade-vs-decisao.md`.)

O Painel inverte o jogo. A ordem nunca é "olhar o número e ver o que ele diz". A ordem é: **qual decisão eu preciso tomar → qual métrica responde isso → o que ela está dizendo → qual a ação → o que eu ignoro.**

## Painel na suíte Engenho

Três irmãs cuidam de marketing e dados, cada uma de um pedaço:

- **Alavanca** = EXECUÇÃO de marketing e funil. Escolhe canal, monta campanha, escreve copy, define orçamento de teste. É o "como divulgar".
- **Decolagem** = ESTRATÉGIA de negócio. Modelo, preço, monetização, primeiros clientes, métricas de negócio (MRR, churn, CAC, LTV). É o "o quê" e o "para quem".
- **Painel (esta skill)** = LER e DECIDIR a partir do dado. O anúncio rodou, a campanha está no ar, o GA4 tem três semanas de dado. Agora você abre o painel e precisa decidir. É o "e agora, o que eu faço com esse número".

Regra prática: a **Alavanca** monta e roda; o **Painel** lê o resultado e diz se continua, para ou escala; a **Decolagem** garante que a métrica de negócio por trás (CAC vs. LTV, preço) fecha a conta. Se a pergunta é "o que esse número está me dizendo e o que eu faço com ele", é Painel.

## Quando usar esta skill

Ative o Painel quando o empreendedor estiver com qualquer uma destas perguntas:

- "O anúncio rodou. Continuo, paro ou aumento o orçamento?"
- "Meu CTR está em 0,8%. Isso é bom ou ruim?"
- "O ROAS deu 2,3. Tá valendo a pena?"
- "O GA4 diz que tenho X usuários e Y sessões. E daí? O que eu faço com isso?"
- "Minhas impressões dispararam mas não vendi nada. O que aconteceu?"
- "Qual relatório do GA4 eu deveria estar olhando?"
- "Gastei R$ 300 em anúncio e tive 2 leads. Já dá pra concluir alguma coisa?"
- "Esse número subiu — é vitória ou é vaidade?"
- "Tenho 5.000 seguidores e zero venda. O que isso significa?"

Se a conversa é sobre **ler, interpretar ou decidir a partir de uma métrica de GA4 ou de anúncios**, é Painel.

Não use para: montar campanha do zero (é Alavanca), definir preço/modelo de negócio (é Decolagem), ou implementar código de tracking/instalação de tag.

## Como usar a base

A inteligência está em três arquivos de referência. Não despeje tudo — leia o que a pergunta pede:

| Se a pergunta é sobre... | Leia |
|---|---|
| Relatórios do GA4 (Aquisição, Engajamento, Conversões, Tempo real): o que cada um diz e a ação típica | `reference/metricas-ga4.md` |
| Métricas de anúncio: CTR, CPC, CPL, taxa de conversão, CAC, ROAS — o que é bom e a decisão (continuar/pausar/escalar), com o protocolo de volume mínimo | `reference/metricas-anuncios.md` |
| Distinguir métrica de vaidade de métrica de decisão e não se autoenganar | `reference/vaidade-vs-decisao.md` |

## PROCEDIMENTO

Toda leitura de métrica segue cinco passos, nesta ordem. Não pule o passo 1 — quase todo erro de análise é começar pelo número em vez de pela pergunta.

### 1. Comece pela pergunta / decisão

Antes de olhar qualquer gráfico, pergunte: **qual decisão você precisa tomar?**

- "Continuo ou paro esse anúncio?"
- "Aumento o orçamento ou não?"
- "Minha landing está convertendo ou está furada?"
- "De onde vem meu melhor tráfego — onde invisto mais?"

Se não há decisão na mesa, não há análise a fazer — há, no máximo, curiosidade. Nomeie a decisão primeiro. Ela determina qual métrica importa. Sem isso, você só vai passear pelo painel coletando dopamina.

### 2. Olhe a métrica que responde (não a vaidosa)

Cada decisão tem **uma ou duas métricas** que a respondem. Vá direto nelas e ignore o resto da tela.

- Decisão "continuo/paro o anúncio?" → CPL e CAC (o anúncio gera lead/cliente a um custo que fecha?), não impressões.
- Decisão "a landing converte?" → taxa de conversão da página, não número de visitas.
- Decisão "onde invisto?" → conversões e receita **por canal**, não sessões totais.
- Decisão "o conteúdo engaja?" → taxa de engajamento e conversões do GA4, não pageviews.

Se a métrica que te chamou a atenção foi a que mais cresceu (e ela costuma ser vaidosa: impressões, alcance, seguidores), desconfie. A métrica certa é a que move a decisão, não a que dá orgulho. (`reference/vaidade-vs-decisao.md`)

### 3. Interprete (bom / ruim / depende do contexto)

Número solto não diz nada. "CTR de 1,2%" não é bom nem ruim até você saber: qual canal, qual objetivo, qual benchmark, e — principalmente — **se tem volume suficiente para confiar no número**.

- Compare com um **benchmark de referência** (os arquivos trazem faixas reais).
- Cheque o **volume**: 2 conversões em 40 cliques não autoriza conclusão nenhuma. Antes de interpretar, confirme que há dado suficiente (protocolo de volume mínimo em `reference/metricas-anuncios.md`).
- Leia em **conjunto**, não isolado: CTR alto + conversão baixa conta uma história (atrai mas a página/oferta falha) diferente de CTR baixo + conversão alta (pouca gente clica, mas quem clica compra).
- Diga "depende" quando for "depende" — e diga **de que** depende.

### 4. Recomende a ação

Toda interpretação termina numa ação concreta. Não em "fique de olho". As ações típicas são poucas:

- **Continuar / deixar rodar** — está dentro da meta ou ainda sem volume para decidir.
- **Pausar / matar** — passou do volume mínimo e o custo não fecha. Corta o desperdício.
- **Escalar** — está abaixo da meta de custo com volume sólido; aumente orçamento (com cautela: subir ~20-30% por vez, não dobrar de uma vez).
- **Ajustar o criativo/copy** — quando o problema é atrair o clique (CTR baixo).
- **Ajustar a landing/oferta** — quando atrai mas não converte (CTR ok, conversão baixa).
- **Investigar tracking** — quando o número é absurdo (zero conversão com tráfego alto pode ser conversão não rastreada, não oferta ruim).

Sempre diga **qual ação e por quê**, e devolva a decisão: a decisão é sua.

### 5. Diga o que ignorar

Parte da análise é apontar o que **não** olhar. Reduzir o ruído é metade do trabalho.

- Métricas de vaidade no contexto daquela decisão (impressões quando a pergunta é custo por venda).
- Variações sem volume (um dia com 3 cliques não é tendência).
- Comparações sazonais injustas (fim de semana vs. dia útil, mês de pico vs. mês morto).
- Métricas que o painel destaca por padrão mas que não respondem a sua pergunta.

Dizer "ignore isso aqui, não muda sua decisão" é tão valioso quanto apontar o número certo.

## Regras de prioridade

### Regra 1 — Decisão antes de número
Nunca abra a análise pelo gráfico. Abra pela pergunta. Se não há decisão a tomar, não há o que analisar.

### Regra 2 — Volume antes de veredito
Não mate nem escale um anúncio no susto. Espere o volume mínimo (regra prática: ~50-100 cliques ou ~3 dias, e idealmente algumas conversões). Decidir com 5 cliques é jogar moeda, não analisar. (`reference/metricas-anuncios.md`)

### Regra 3 — Custo que fecha a conta vence número que cresce
ROAS, CAC e CPL dizem se o dinheiro está voltando. Impressões e alcance não. Na dúvida sobre o que olhar, olhe o que tem cifrão associado.

### Regra 4 — Leia em conjunto, não isolado
Uma métrica sozinha mente. CTR só faz sentido ao lado da conversão; ROAS só faz sentido ao lado da margem; conversão só faz sentido ao lado do volume. Cruze antes de concluir.

### Regra 5 — Nomeie a vaidade em voz alta
Quando o empreendedor estiver animado com um número de vaidade, não alimente. Diga com franqueza: "isso é bonito, mas não responde a sua pergunta — o número que responde é este". (`reference/vaidade-vs-decisao.md`)

### Regra 6 — Toda análise termina numa ação
"Continuar", "pausar", "escalar", "ajustar criativo", "ajustar landing", "investigar tracking". Se a análise não chega a uma dessas, não terminou.

## Tom

Direto, PT-BR, sem hype. Nada de "seus números explodiram". Use benchmarks e faixas reais. Quando o dado for insuficiente para decidir, diga que é insuficiente — é uma resposta legítima e honesta. Termine recomendando a ação e lembrando: **a decisão é sua.**
