# Erros Comuns de Modelagem (e o conserto)

Os erros que mais aparecem quando a IA — ou um dev vindo do relacional — modela no Firestore. Cada um tem o **sintoma**, o **porquê dói** e o **conserto**.

---

## 1. Modelar como tabela relacional no Firestore

**Sintoma:** coleções "normalizadas" com só IDs apontando pra todo lado (`pedidos` com `clienteId`, `produtoId`, `enderecoId`...), e o código fazendo várias leituras pra "juntar" o que seria um `JOIN`.

**Por que dói:** o Firestore **não tem JOIN**. Recriar join no código vira N+1 (erro 5), as telas ficam lentas e a fatura de leitura cresce. Você está pagando o custo do NoSQL (sem joins) sem colher o benefício (leitura num lugar só).

**Conserto:**
- Volte ao passo 1: liste as queries. Modele pela leitura, não pela "verdade normalizada".
- **Duplique** os dados que cada tela lê junto (ver `padroes-firestore.md` → duplicação controlada). O `pedido` guarda `clienteNome`, `itens: [{ produtoNome, preco, qtd }]` — a tela do pedido vira **1 leitura**.
- Se o domínio é genuinamente relacional (muitas relações cruzadas, integridade forte, relatórios ad-hoc), o erro foi antes: **o banco devia ser Postgres**. Volte pra **Bússola**. Não force tabela no Firestore.

---

## 2. Ler a coleção inteira pra contar

**Sintoma:** `getDocs(collection(db, "alunos"))` só pra mostrar `snap.size` ("1.240 alunos"). Ou somar um campo lendo todos os docs.

**Por que dói:** N documentos lidos = **N leituras** cobradas, **toda vez** que alguém vê o número. Uma página com 4 contadores e 5.000 docs cada = 20.000 leituras por carregamento. Não escala e fica caro rápido.

**Conserto:**
- Mantenha um **contador agregado** atualizado na escrita, com `increment()` dentro do mesmo batch/transação que cria/remove o item (ver `padroes-firestore.md`). Ler o número vira **0 leituras extras**.
- Soma de valores: mesmo princípio — mantenha `totalArrecadado` e `increment(valor)` na escrita.
- Contador muito escrito ao mesmo tempo → **sharded counter** (evita hot document, erro 3).
- Se precisar de contagem/soma sob demanda e tolera o custo, o Firestore tem **aggregation queries** (`count()`, `sum()`, `average()`) — bem mais baratas que ler tudo, mas ainda assim prefira o contador mantido pra números mostrados toda hora.

---

## 3. Array que cresce sem limite

**Sintoma:** `chat.mensagens: [...]`, `curso.alunosIds: [...]`, `post.curtidasUserIds: [...]` — um array dentro de um doc que só aumenta.

**Por que dói:**
- Documento tem teto de **1 MB** — o array cresce até estourar e quebrar a escrita.
- Cada leitura do doc traz o **array inteiro**, mesmo que você queira só o topo. Leitura fica cada vez mais cara e lenta.
- Atualizar = reescrever um doc grande; e escrita concorrente no mesmo array vira **hot document**.

**Conserto:**
- O que cresce sem teto **não é array — é coleção**. `chat/{id}/mensagens/{msgId}`, `posts/{id}/curtidas/{uid}`. Aí você pagina, filtra e conta com agregado.
- Array só pra listas **pequenas e limitadas** (tags, papéis): garanta um teto explícito (ex.: ≤ 20) e use `arrayUnion`/`arrayRemove`.
- "Curtiu ou não" por usuário → doc `posts/{id}/curtidas/{uid}` (existe = curtiu) + contador agregado pro total. Nunca um array de milhares de UIDs.

---

## 4. Aninhar demais (documento gigante, mapas dentro de mapas)

**Sintoma:** um único doc `usuario` carregando `pedidos`, `enderecos`, `historico`, `preferencias`, tudo como mapas/arrays aninhados num doc só.

**Por que dói:**
- Toda leitura do usuário traz **tudo** — você lê o histórico inteiro só pra mostrar o nome. Caro e lento.
- Aproxima do limite de 1 MB; escritas concorrentes em partes diferentes do doc colidem.
- Não dá pra consultar nem paginar o que está aninhado (não dá pra "buscar os pedidos pendentes" dentro de um mapa).

**Conserto:**
- Quebre em **subcoleções** o que é lista que cresce e/ou que você consulta separado: `usuarios/{id}/pedidos`, `usuarios/{id}/enderecos`.
- Deixe no documento só o que é **lido junto e pequeno**: nome, e-mail, avatar, preferências curtas.
- Regra: *"eu sempre leio isso junto com o pai e é pequeno?"* → fica no doc. Senão → subcoleção.

---

## 5. N+1 de leitura

**Sintoma:** uma query traz a lista (1 leitura por item), e pra **cada** item o código faz **outra** leitura pra buscar um dado relacionado. 50 pedidos → 1 query + 50 leituras de cliente = 51.

```js
// ANTIPADRÃO
const pedidos = await getDocs(query(collection(db, "pedidos"), where("uid","==",uid)));
for (const p of pedidos.docs) {
  const cliente = await getDoc(doc(db, "clientes", p.data().clienteId)); // +1 por item
}
```

**Por que dói:** o custo explode linearmente com o tamanho da lista, e cada `await` em série deixa a tela lenta. É o erro de performance mais comum no Firestore — e quase sempre nasce de modelar relacional (erro 1).

**Conserto (em ordem de preferência):**
1. **Desnormalizar:** copie o dado que falta pro documento da lista (`pedido.clienteNome`). A listagem vira **1 query, zero leituras extras**. É a solução de modelagem — a melhor.
2. **Buscar em lote:** se não dá pra duplicar, junte os IDs e busque com `where(documentId(), "in", [...])` (até 30 por chamada) ou `getAll`. Vira poucas leituras em paralelo, não N em série.
3. Se o N+1 é puramente de **código** (a modelagem está ok, falta paralelizar/cachear), isso é terreno da **Turbo**.

> Regra: N+1 na **leitura de uma lista** quase sempre se resolve **duplicando o dado na modelagem**. Se você se pega buscando "o nome do X de cada item", duplique o nome.

---

## Checklist rápido antes de fechar o schema

- [ ] Cada tela vira **1 query** (ou query paginada), sem buscar dado item-a-item? (senão: erro 5)
- [ ] Algum número é mostrado contando documentos? → contador agregado (erro 2)
- [ ] Algum array pode crescer sem teto? → vira coleção (erro 3)
- [ ] Algum documento carrega listas/históricos que você nem sempre lê? → subcoleção (erro 4)
- [ ] Algum documento recebe escrita concorrente pesada? → shard / distribuir (hot document)
- [ ] Estou recriando JOIN no código? → duplicar, ou repensar se o banco devia ser relacional (erro 1 → Bússola)
- [ ] Toda duplicação está **documentada** com o que atualizar quando a origem mudar?
