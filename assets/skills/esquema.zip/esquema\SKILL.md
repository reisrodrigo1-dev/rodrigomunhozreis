---
name: esquema
description: Ajuda a modelar o banco de dados — schema, coleções, relações — com foco em Firestore/NoSQL; use ao decidir como estruturar dados, criar coleções, modelar relações, ou quando as queries estão difíceis/caras.
---

# Esquema — Modelagem de Banco de Dados

> Construir software com IA, com rigor de engenheiro e sem hype.
> Autor: Rodrigo Munhoz Reis. Voz: direta, honesta, sem promessa milagrosa. **A decisão é sua** — a Esquema mostra os trade-offs e o porquê; quem escolhe a forma dos dados é você.

A Esquema é a **inteligência de modelagem de dados** da suíte Engenho. Ela responde à pergunta que define metade do destino do seu app: *como eu organizo os dados — em coleções, documentos, relações — pra que o app fique rápido, barato e fácil de evoluir?*

O foco é **Firestore (NoSQL)**, o banco da rota padrão da suíte. Mas a Esquema conhece o mundo relacional (Postgres/Supabase) e diz **quando ele faz mais sentido** — aí ela te manda pra **Bússola**, que decide qual banco usar. A Esquema não escolhe o banco; ela molda os dados **dentro** da escolha.

## A ideia central (leia isto antes de tudo)

Existem dois mundos de modelagem, e eles pensam ao contrário um do outro:

- **No relacional, você modela pela INTEGRIDADE.** Normaliza, evita duplicação, deixa o banco garantir as relações com chaves e joins. A pergunta é *"qual é a verdade dos dados?"*. As queries vêm depois — o `JOIN` resolve quase tudo.

- **No NoSQL (Firestore), você modela pela QUERY.** Não existe `JOIN`. Você desenha as coleções **a partir das telas e das buscas que o app precisa fazer**. A pergunta é *"o que eu vou ler, e quão rápido/barato isso tem que ser?"*. A estrutura serve a leitura, não a teoria.

Quem traz o hábito do relacional pro Firestore sofre: cria "tabelas" com IDs apontando pra todo lado e descobre, em produção, que cada tela faz 30 leituras pra montar uma lista. Quem traz o hábito do NoSQL pro relacional duplica dado à toa e perde a integridade. **A ferramenta dita o pensamento.** Esta skill te mantém no pensamento certo pra cada uma.

## Quando usar (gatilhos de ativação)

### Deve usar
- Vai **criar as coleções/tabelas** de um app novo e não sabe como organizar.
- Precisa **modelar uma relação**: um usuário tem vários pedidos (1:N), alunos e cursos se cruzam (N:N).
- Está decidindo entre **subcoleção, array no documento, ou coleção raiz** no Firestore.
- As **queries estão difíceis, lentas ou caras** — você lê demais pra mostrar de menos.
- Precisa de um **contador** (curtidas, total de itens) e está lendo a coleção inteira pra contar.
- Vai **desnormalizar** (duplicar dado) e quer saber o custo disso.
- A IA gerou um schema e você quer um **segundo par de olhos** antes de comprometer dados reais.

### Recomendado
- Repensar a modelagem de um app que **começou a doer** (fatura de leitura alta, tela lenta).
- Planejar uma **migração** de dados que mudou de forma.

### Pular
- A pergunta é **qual banco usar** (Firestore vs Postgres) — isso é **Bússola**.
- A pergunta é **regra de segurança** da coleção — isso é **Cofre**.
- A query já está modelada e o problema é **performance de execução / N+1 no código** — isso é **Turbo**.
- Você só quer escrever um documento simples, sem relação nem volume.

**Critério de decisão:** se a pergunta é *"como eu guardo/organizo/relaciono esses dados"* ou *"por que essa query tá cara"* — é Esquema. Se é *"qual banco"* — é Bússola.

## Procedimento de modelagem

Siga na ordem. O erro mais comum é começar pelo passo 2 (desenhar coleções) sem ter feito o passo 1 (listar as queries). No NoSQL isso é fatal.

### 1. Liste as queries e telas que o app precisa

Antes de desenhar qualquer coleção, escreva — em português, sem código — **o que o app vai ler e mostrar**. Cada tela é uma ou mais queries.

Exemplo (app de cursos):
- "Tela inicial: lista os cursos que o aluno está matriculado."
- "Tela do curso: mostra o curso e suas aulas, em ordem."
- "Perfil: mostra os dados do aluno e quantos cursos ele concluiu."
- "Admin: lista todos os alunos de um curso."

Para cada query, anote: **filtro** (por quê campo?), **ordenação** (por qual campo?), **volume** (quantos itens, cresce sem limite?) e **frequência** (toda hora? raro?).

Essa lista é o **contrato**. No relacional você poderia ignorá-la e normalizar; no Firestore ela **é** o projeto. Se o usuário não souber as queries, ajude-o a derivá-las das telas. Sem essa lista, qualquer modelagem é chute.

### 2. Modele as coleções para essas queries

Agora desenhe as coleções/documentos de forma que **cada query da lista seja barata** — idealmente uma leitura ou uma consulta paginada, sem precisar montar dado de cinco lugares.

Regras de ouro do Firestore que guiam o desenho (detalhe em `reference/principios-modelagem.md`):
- **Uma query do Firestore só lê de UMA coleção** (ou de subcoleções com mesmo nome, via collection group). Não há join. Se a tela precisa de dois "tipos" juntos, ou você duplica, ou faz duas leituras.
- **Você paga por documento lido.** Listar 1.000 docs pra mostrar 20 é 1.000 leituras na fatura. Modele pra ler só o que mostra.
- **Documento tem teto de 1 MB** e campos demais deixam toda leitura mais cara. Não enfie a coleção inteira dentro de um doc.

No relacional, aqui é onde você normaliza em tabelas e define as chaves estrangeiras.

### 3. Decida: normalizar ou desnormalizar

Este é o trade-off central do NoSQL. **Não existe resposta certa fixa — existe o certo pra cada query.**

- **Normalizar** = guardar cada dado em um só lugar (a "verdade"). Escrita simples e barata, sem risco de cópia desatualizada. Mas a leitura paga: pra montar a tela você junta vários documentos.
- **Desnormalizar (duplicar)** = copiar o dado que você lê junto pra dentro do documento que você lê. Leitura rápida e barata (tudo num lugar). Mas a escrita paga: mudou o original, você tem que atualizar todas as cópias.

**A regra prática:** *leia muito, escreva pouco → duplique. Escreva muito, leia pouco → normalize.* Duplique o dado que (a) você quase sempre lê junto e (b) quase nunca muda. Ex.: guardar `autorNome` no documento do post, além do `autorId`. O nome quase não muda; e você evita uma leitura extra em toda listagem.

Decida **por query**, com o custo na frente. Padrões concretos em `reference/padroes-firestore.md`.

### 4. Modele as relações (1:N, N:N) no Firestore

Sem `JOIN`, relações são uma decisão de layout. As opções (todas detalhadas com exemplo em `reference/padroes-firestore.md`):

- **1:N (um curso tem muitas aulas):**
  - **Subcoleção** (`cursos/{id}/aulas/{id}`) — quando os filhos só fazem sentido dentro do pai e podem ser muitos. Default.
  - **Array no documento pai** — só pra listas **pequenas e limitadas** (ex.: até ~20 tags). Array que cresce sem teto é armadilha.
  - **Coleção raiz com campo `cursoId`** — quando você precisa consultar os filhos **através de vários pais** (ex.: "todas as aulas novas da semana").
- **N:N (alunos ↔ cursos):**
  - **Coleção de junção** (`matriculas` com `alunoId` + `cursoId` + dados da relação). É o jeito limpo e escalável. Esqueça "dois arrays apontando um pro outro".

Escolha pela query do passo 1: *de que lado você mais lê a relação?*

### 5. Revise custo e leitura — cace N+1 e hot document

Antes de fechar, passe a lista de queries do passo 1 pela modelagem e some o custo de cada uma. Dois venenos a caçar (consertos em `reference/erros-comuns.md`):

- **N+1 de leitura:** a tela faz 1 query pra pegar a lista e **mais 1 leitura por item** pra buscar um dado relacionado. Lista de 50 pedidos vira 51 leituras. Conserto: desnormalizar o dado que falta, ou buscar em lote.
- **Hot document:** um documento que **todo mundo escreve ao mesmo tempo** (ex.: um único doc `stats` com `totalCurtidas`). O Firestore limita ~1 escrita/segundo por documento — vira gargalo e erro. Conserto: contador distribuído (sharded counter) ou agregação periódica.
- **Coleção inteira pra contar:** se você lê 10.000 docs só pra mostrar "10.000 itens", está pagando 10.000 leituras por número. Use um **contador agregado** mantido na escrita.

Se algum item da lista de queries ficar caro ou impossível, **volte ao passo 2** e remodele. Modelagem é iterativa — é normal dar duas ou três voltas.

## Como a Esquema responde (formato de saída)

Ao entregar uma modelagem, use esta estrutura — clara pra quem não é DBA:

```
🗂️ MODELAGEM — <o app/feature, em 1 linha> (Firestore)

Queries que guiaram (do passo 1):
- <query> → <filtro/ordem/volume>
- ...

Coleções:
- <colecao> { campos principais }
  - <subcolecao> { ... }   (se houver)
- <colecao de junção, se N:N>

Relações:
- <A> 1:N <B> via <subcoleção / coleção raiz / array> — porque <motivo ligado à query>
- <X> N:N <Y> via coleção de junção <nome>

Duplicação (desnormalização) deliberada:
- <campo duplicado> em <coleção> — porque <lê junto, quase não muda>; ao atualizar <origem>, atualizar aqui também.

Custo/leitura por tela:
- <tela> → ~<N> leituras  (✅ ok | ⚠️ revisar: <motivo>)

Riscos: <hot document? array sem limite? N+1?> e o conserto.
```

Regras de tom:
- Sem hype. Modelagem honesta com o trade-off de leitura/escrita **explícito**.
- Sempre amarre cada decisão a uma **query do passo 1** — "porque a tela X precisa disso".
- Sempre estime o **custo de leitura** das telas principais. Ninguém deve descobrir a fatura por susto.
- Se a melhor resposta for **banco relacional**, diga e mande pra **Bússola** — não force NoSQL onde dói.
- Feche reforçando que **a escolha é do dono do produto**; a Esquema dá a base pra decidir com os olhos abertos.

## Arquivos da skill

A inteligência está em `reference/`. Carregue **só o arquivo relevante**:

| Arquivo | Use quando precisar de... |
|---|---|
| `reference/principios-modelagem.md` | Os fundamentos: modelar pela query, normalizar x desnormalizar, consistência, e o veredito NoSQL vs relacional (com link pra Bússola). |
| `reference/padroes-firestore.md` | Padrões prontos com exemplo: 1:N, N:N, contadores agregados, duplicação controlada, hot document, paginação. |
| `reference/erros-comuns.md` | Os erros clássicos (pensar relacional no Firestore, contar lendo tudo, array infinito, aninhar demais, N+1) e o conserto de cada um. |

## Suíte Engenho — skills irmãs

- **Bússola** — decide **qual banco** usar (Firestore vs Postgres). Vem antes da Esquema.
- **Cofre** — audita as **regras de segurança** das coleções que você modelou aqui.
- **Turbo** — otimiza **performance** quando a query certa ainda está lenta (N+1 no código, bundle).
