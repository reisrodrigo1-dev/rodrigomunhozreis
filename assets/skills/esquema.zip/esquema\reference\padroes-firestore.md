# Padrões de Firestore (com exemplo)

Catálogo de padrões prontos pra modelar relações e leitura no Firestore. Cada um traz **quando usar**, **o exemplo** e o **custo/risco**. Escolha pela query que a tela precisa (passo 1 do procedimento).

Convenção de notação:
```
colecao/{id}            documento dentro de uma coleção
colecao/{id}/sub/{id}   subcoleção dentro do documento
{ campo: valor }        campos do documento
```

---

## 1:N — um pai, muitos filhos

Três layouts. A escolha depende de **de onde você lê os filhos**.

### Opção A — Subcoleção (default)

```
cursos/{cursoId}              { titulo, descricao, professorNome }
cursos/{cursoId}/aulas/{aulaId}   { titulo, ordem, duracaoMin, videoUrl }
```

**Use quando:** os filhos só fazem sentido dentro do pai, podem ser muitos, e você quase sempre lê "os filhos **deste** pai" (a tela do curso lista as aulas daquele curso).

- Leitura da tela: `cursos/{id}` (1 leitura) + query em `cursos/{id}/aulas` ordenada por `ordem` (paginada). Barato e direto.
- Os filhos **não** pesam na leitura do pai — subcoleção é separada do documento pai. Listar o curso não lê as aulas.
- Cresce à vontade: subcoleção não tem o limite de 1 MB do documento.

**Cuidado:** pra consultar filhos **através de vários pais** (ex.: "todas as aulas adicionadas hoje, de qualquer curso"), use **collection group query** sobre `aulas` — exige que todas as subcoleções tenham o mesmo nome e um índice de collection group.

### Opção B — Array dentro do documento pai

```
cursos/{cursoId}   { titulo, tags: ["react", "firebase", "iniciante"] }
```

**Use quando:** a lista é **pequena, limitada e lida sempre junto com o pai** (tags, papéis de um usuário, IDs de favoritos com teto). Pensar em **dezenas, nunca milhares**.

- Leitura: vem de graça junto com o pai (1 leitura). Imbatível pra lista curta.
- Escrita: `arrayUnion` / `arrayRemove` adicionam/removem sem ler o array todo.

**Cuidado (armadilha clássica):** array que **cresce sem limite** estoura o doc (1 MB), encarece toda leitura do pai e fica lento. Se você não consegue garantir um teto, **não é array — é subcoleção ou coleção raiz.** Ver `erros-comuns.md`.

### Opção C — Coleção raiz com campo de referência

```
aulas/{aulaId}   { cursoId, titulo, ordem, criadoEm }
```

**Use quando:** você precisa consultar os filhos **de forma transversal**, com filtros variados, independente do pai. Ex.: "aulas criadas esta semana", "aulas do professor X em qualquer curso".

- Leitura por pai: `where("cursoId", "==", cursoId)` — funciona igual subcoleção.
- Leitura transversal: `where("criadoEm", ">=", ...)` sobre a coleção inteira — fácil.
- Exige índices compostos pros filtros + ordenação combinados (o Firestore avisa).

> **Regra de escolha 1:N:** lê só "filhos deste pai" → **subcoleção**. Lista curta e fixa → **array**. Precisa cruzar filhos de vários pais → **coleção raiz**.

---

## N:N — muitos para muitos (coleção de junção)

Alunos se matriculam em vários cursos; cada curso tem vários alunos. **Não** use dois arrays apontando um pro outro (não escala, não dá pra pôr dados na relação, e atualizar os dois lados é frágil).

**Padrão: coleção de junção** — um documento por par da relação.

```
matriculas/{matriculaId}   {
  alunoId,
  cursoId,
  matriculadoEm,
  progresso: 0.4,       // dado QUE PERTENCE À RELAÇÃO
  concluido: false,
  // duplicação controlada pra evitar leitura extra nas listagens:
  cursoTitulo,          // copiado de cursos/{cursoId}
  alunoNome             // copiado de users/{alunoId}
}
```

Queries que isso resolve, cada uma de **uma** coleção:
- "Cursos do aluno" → `where("alunoId", "==", uid)`. Com `cursoTitulo` duplicado, a lista já vem pronta — **sem N+1**.
- "Alunos do curso" → `where("cursoId", "==", cursoId)`. Com `alunoNome`, idem.
- Dado da relação (progresso, conclusão) mora aqui, onde pertence — não cabe nem no aluno nem no curso.

**ID determinístico** (opcional, recomendado): use `${alunoId}_${cursoId}` como ID do documento de matrícula. Assim você lê/escreve "esta matrícula específica" sem query, e impede matrícula duplicada de graça.

**Custo de escrita:** se duplicou `cursoTitulo` e o título muda, atualize as matrículas via Cloud Function (`onUpdate` em `cursos`) ou batch. Vale o trade-off porque título quase nunca muda e listagem é lida toda hora.

---

## Contadores agregados (não conte lendo tudo)

Mostrar "1.240 alunos neste curso" **não** deve ler 1.240 documentos. Mantenha o número.

### Contador simples (baixa frequência de escrita)

```
cursos/{cursoId}   { titulo, totalAlunos: 1240 }
```

Na matrícula, incremente atomicamente:
```js
import { increment } from "firebase/firestore";
// dentro de um writeBatch junto com a criação da matrícula:
batch.update(cursoRef, { totalAlunos: increment(1) });
```

- Leitura do número: **0 leituras extras** — vem junto com o curso.
- `increment()` é atômico no servidor: sem condição de corrida, sem ler-somar-escrever.

### Contador distribuído / sharded (alta frequência → evita hot document)

Se MUITA gente incrementa o **mesmo** contador ao mesmo tempo (curtidas de um post viral, > ~1 escrita/seg sustentada), o contador único vira **hot document** e começa a falhar. Distribua em N shards:

```
posts/{postId}/shards/{shardId}   { count: 37 }   // ex.: 10 shards
```

- **Escrever:** sorteie um shard (0..N-1) e faça `increment(1)` nele. Espalha a carga por N documentos → N escritas/seg de capacidade.
- **Ler:** some os N shards (N leituras — escolha N pequeno, ex. 10). Ou mantenha um total consolidado por Cloud Function se a leitura também for quente.

Regra: contador frio → 1 campo + `increment`. Contador quente → shards. Ver hot document abaixo.

---

## Duplicação controlada (desnormalização deliberada)

Copie pro documento que você LÊ o dado que vem de outro, **quando** ele é lido junto quase sempre e muda quase nunca.

```
posts/{postId}   {
  titulo, conteudo,
  autorId,          // a referência (a verdade)
  autorNome,        // cópia de users/{autorId}.nome
  autorAvatar       // cópia de users/{autorId}.avatar
}
```

- Listar 20 posts com nome e avatar do autor = **20 leituras** (só os posts), não 40. Sem N+1.
- Sempre guarde **também** a referência (`autorId`) — é o caminho de volta pra verdade e pra atualizar a cópia.
- **Documente a cópia** e mantenha em dia: Cloud Function `onUpdate` em `users` propaga `nome`/`avatar` pros posts daquele autor (aceitando defasagem de segundos), ou aceite que posts antigos guardam o nome de quando foram escritos (às vezes é o comportamento desejado).

Não duplique dado que muda toda hora nem dado grande. Ver a regra de bolso em `principios-modelagem.md`.

---

## Hot document — o que é e como evitar

**Hot document** = um único documento que recebe escritas concorrentes acima do que o Firestore aguenta (~1 escrita/seg sustentada por doc). Sintoma: erros de contenção, escritas lentas, falhas em pico.

Casos clássicos e o conserto:
- **Contador único muito escrito** (curtidas, visitas de algo viral) → **sharded counter** (acima).
- **Doc de "configuração global" / `stats` que todos atualizam** → separe por entidade, ou agregue em background, não no caminho quente.
- **Fila/feed num só documento** → vira coleção (um doc por item), não um array gigante num doc.

Princípio: **distribua a escrita por muitos documentos.** Leitura concorrente do mesmo doc é tranquila; **escrita** concorrente é o problema.

---

## Paginação (não leia a coleção inteira)

Liste em páginas, lendo só o que mostra. Use cursor com `startAfter` (não `offset` — offset ainda lê e cobra os pulados).

```js
import { collection, query, orderBy, limit, startAfter, getDocs } from "firebase/firestore";

// primeira página
const q1 = query(collection(db, "posts"), orderBy("criadoEm", "desc"), limit(20));
const snap1 = await getDocs(q1);
const ultimo = snap1.docs[snap1.docs.length - 1];

// próxima página: começa depois do último visto
const q2 = query(collection(db, "posts"), orderBy("criadoEm", "desc"), startAfter(ultimo), limit(20));
```

- Custo por página = `limit` (ex.: 20 leituras), não o tamanho da coleção.
- Guarde o **cursor** (último doc/snapshot) pra próxima página; `startAfter(valor)` também aceita o valor do campo de ordenação.
- Precisa ordenar por um campo e filtrar por outro? O Firestore vai pedir um **índice composto** — crie pelo link que ele mostra no erro.
