# Princípios de Modelagem

Os fundamentos que valem pra qualquer decisão de schema. Leia antes de aplicar os padrões — eles explicam **por que** cada padrão existe.

---

## 1. Modele pela query, não pela teoria

No NoSQL, a estrutura dos dados é a **resposta** a uma pergunta: *quais leituras o app precisa fazer, e quão rápidas/baratas elas têm que ser?*

No relacional você pode modelar primeiro "a verdade dos dados" (entidades, relações, formas normais) e depois escrever as queries — o `JOIN` junta tudo na hora da leitura. No Firestore **não existe JOIN**: cada query lê de uma única coleção. Então a estrutura **tem** que ser desenhada já sabendo o que vai ser lido junto.

**Consequência prática:** liste as telas e as queries **antes** de criar coleção. Para cada uma, anote filtro, ordenação, volume e frequência. Essa lista é o projeto. Mudou a tela principal → reavalie o schema; não é falha, é a natureza do NoSQL.

> Regra: se você não consegue escrever a query que uma tela precisa olhando só pro seu modelo, o modelo está errado pra aquela tela — não a query.

---

## 2. Normalizar x desnormalizar — o trade-off central

São duas estratégias opostas. A arte do NoSQL é escolher a certa **por query**.

### Normalizar (cada dado em um só lugar)
- **Ganha:** uma só fonte de verdade. Mudou o dado, mudou em todo lugar. Escrita simples e barata. Sem risco de cópia velha.
- **Perde:** a leitura paga. Pra montar a tela você lê vários documentos e junta no código (e isso vira N+1).
- **Quando:** o dado **muda muito** ou é **grande**; a relação é lida **raramente**.

### Desnormalizar (duplicar o dado onde se lê)
- **Ganha:** leitura num lugar só — rápida e barata. A tela vira 1 leitura.
- **Perde:** a escrita paga. Mudou o original, você atualiza **todas** as cópias (ou conviva com cópia velha). Mais código, mais risco de inconsistência.
- **Quando:** o dado é **lido junto quase sempre** e **muda quase nunca**.

### A regra de bolso
> **Lê muito, escreve pouco → duplique. Escreve muito, lê pouco → normalize.**

Exemplos:
- `autorNome` dentro do `post` (além de `autorId`): **duplique**. Nome quase não muda; aparece em toda listagem.
- Saldo de uma conta que muda a cada transação: **normalize** (ou use contador transacional). Duplicar vira pesadelo de consistência.
- Foto de perfil do usuário em cada comentário: **depende** — se "trocar foto atualiza histórico antigo" não importa pro produto, duplique e relaxe; se importa, normalize.

**Duplicação é uma decisão deliberada, não um acidente.** Documente toda cópia: *o que* foi duplicado, *de onde*, e *o que atualizar* quando a origem mudar. Cópia não documentada é bug esperando acontecer.

---

## 3. Consistência: forte vs eventual

Quando você duplica, abre mão de consistência automática. Decida conscientemente o nível que cada dado precisa:

- **Consistência forte (tudo sempre certo no mesmo instante):** dinheiro, estoque, saldo, permissões. Aqui você **não duplica de qualquer jeito** — usa transação (`runTransaction`) ou escrita em lote (`writeBatch`) pra manter as cópias coerentes, ou simplesmente normaliza. O Firestore garante atomicidade dentro de uma transação/batch.
- **Consistência eventual (pode ficar alguns segundos/minutos defasado):** contador de curtidas, "nome do autor" no post, total aproximado. Aqui duplicar é tranquilo; uma cópia velha por pouco tempo não machuca ninguém.

Pergunta de triagem: **"se esse dado ficar errado por 30 segundos, alguém perde dinheiro ou confiança?"** Sim → consistência forte (transação/normalize). Não → eventual (duplique à vontade).

### Mantendo cópias em dia
- Poucas cópias e atômicas → `writeBatch` / `runTransaction` na hora da escrita.
- Muitas cópias ou processo pesado → **Cloud Function** disparada na escrita do original (`onUpdate`) atualiza as cópias em background. Aceita defasagem de segundos.

---

## 4. Custo é modelagem

No Firestore você paga por **operação**: cada documento lido, escrito e deletado conta. A modelagem decide o custo direto da sua fatura.

- Listar 1.000 docs pra mostrar 20 = **1.000 leituras**. Modele pra ler só o que mostra (paginação, campos certos).
- Contar lendo a coleção inteira = N leituras por número. Use **contador agregado**.
- Tela que faz 1 query + 1 leitura por item = **N+1**. Duplique o dado faltante ou busque em lote.

Estime o custo das telas principais **na modelagem**, não depois do susto. Uma tela que abre 10.000 vezes/dia e faz 50 leituras cada = 500 mil leituras/dia só nela.

---

## 5. Limites do Firestore que moldam o schema

Não são detalhes — são restrições físicas que **mudam o desenho**:

- **Documento ≤ 1 MB.** E quanto maior o doc, mais cara cada leitura dele. Não enfie listas grandes dentro de um doc — vira subcoleção.
- **~1 escrita/segundo por documento** (sustentada). Documento que todo mundo escreve junto = **hot document** = gargalo. Distribua (sharded counter).
- **Array:** ótimo pra listas pequenas e fixas; ruim pra coisa que cresce sem limite (estoura o doc e fica caro). Limite de elementos práticos: dezenas, não milhares.
- **Query só de uma coleção** (ou collection group de subcoleções homônimas). Sem join.
- **Índice composto** é necessário pra filtrar + ordenar por campos diferentes; o Firestore avisa e dá o link pra criar. Planeje os índices junto com as queries.

---

## 6. NoSQL x Relacional — quando cada um vence

A Esquema modela **dentro** do banco escolhido. **Qual** banco escolher é trabalho da **Bússola** — mas aqui vai o resumo pra você reconhecer quando está forçando NoSQL onde dói:

### Firestore (NoSQL) brilha quando
- Dados ligados a um **usuário** ou a um **agregado** claro (perfil, pedidos do usuário, posts).
- As queries são **previsíveis** — você sabe de antemão como vai ler.
- Precisa de **tempo real** (listeners) e **offline** (mobile).
- Quer lançar rápido, com auth/SDK prontos, e a IA escrevendo bem o código.
- A escala é de leitura alta e o modelo desnormaliza bem.

### Relacional (Postgres/Supabase) vence quando
- **Relações ricas e queries ad-hoc** — você vai cruzar dados de jeitos que não dá pra prever ("vendas por região por mês por vendedor").
- **Integridade forte** é o coração do produto: financeiro, estoque, contabilidade, marketplace com saldo.
- **Relatórios e agregações** complexas (`GROUP BY`, `SUM`, `JOIN` de várias tabelas) são rotina.
- Muitas relações N:N que você consulta dos dois lados com filtros variados.
- Transações multi-entidade são frequentes e críticas.

### O sinal de alerta
Se ao modelar no Firestore você está criando "tabelas" com IDs apontando pra todo lado, recriando `JOIN` no código, e duplicando dado que **muda toda hora** — pare. Isso é o relacional pedindo passagem. **Não modele relacional dentro do Firestore.** Volte pra **Bússola** e reavalie o banco. Forçar NoSQL num domínio relacional gera código frágil, caro e cheio de N+1.

> A decisão do banco é da Bússola. A Esquema só te avisa quando o modelo está gritando "eu queria ser uma tabela".
