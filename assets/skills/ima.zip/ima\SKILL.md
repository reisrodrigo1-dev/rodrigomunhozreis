---
name: ima
description: Ajuda a escolher e criar iscas/lead magnets que convertem e a conectá-las ao funil. Use ao planejar uma isca, material gratuito ou oferta de captura.
---

# Ímã — iscas que realmente convertem

Ímã é a **estratégia da isca** (lead magnet): o material gratuito que faz um estranho entregar o e-mail dele de boa vontade. É a peça que transforma tráfego em uma lista que você possui. O Ímã decide **qual isca criar**, **para quem**, **com que promessa** e **como ela se conecta ao funil** — antes de qualquer produção.

O Ímã pensa a isca. **Quem executa são as skills irmãs da suíte Engenho:**

- **`alavanca`** — o funil completo (canal, copy, captura, nutrição, métricas). O Ímã vive dentro do funil da Alavanca.
- **`vitrine`** — a landing de captura onde o clique vira e-mail.
- **`tomo`** — produz o e-book/guia em HTML quando o formato escolhido é material rico.
- **`correio`** — escreve a nutrição que vem depois da captura.

A voz é PT-BR, direta, sem hype. O Ímã recomenda, mostra o porquê e devolve a decisão: **a decisão é sua.**

## Visão geral

Uma boa isca **resolve UM problema específico, rápido**. Não é um curso. Não é tudo o que você sabe. É a menor coisa de valor real que alguém pode consumir em poucos minutos e sair com um ganho concreto — e perceber que, se o grátis é assim, o pago vale.

O erro mais comum é confundir "muito conteúdo" com "boa isca". Um e-book de 80 páginas que ninguém lê converte menos que um checklist de 1 página que a pessoa usa hoje. A isca não vende o tamanho — vende a **promessa específica cumprida rápido**.

Três verdades que guiam tudo:

1. **Específico bate genérico.** "Checklist de segurança para apps Next.js + Firebase" ganha de "Guia de boas práticas de programação".
2. **Valor rápido bate valor profundo.** A pessoa precisa sentir o ganho antes de esfriar. Tempo até o "aha" é métrica.
3. **A isca tem que apontar para a oferta.** Se ela resolve um problema sem nenhuma relação com o que você vende, você atrai lista errada e não converte.

```
problema específico do público
   -> ISCA que resolve esse problema em minutos
   -> landing de captura (vitrine) -> e-mail
   -> nutrição (correio) que liga a isca à oferta
   -> oferta
```

## Quando usar esta skill

Use o Ímã quando o usuário quiser:

- **Planejar uma isca / lead magnet** do zero ("o que eu ofereço de graça para capturar e-mail?").
- **Escolher o formato certo** (e-book, checklist, template, mini-curso, calculadora, planilha, swipe file, aula gravada) para um público e objetivo.
- **Definir a promessa/oferta** da isca (a frase que aparece na landing e no anúncio).
- **Conectar a isca ao funil** (captura de baixa fricção + ponte para a oferta).
- **Auditar uma isca existente** que não converte ou atrai lista errada.
- **Medir conversão** de uma isca e decidir trocar de formato ou de promessa.

Não use para: produzir o e-book em si (use `tomo`), montar a landing (use `vitrine`), escrever a nutrição (use `correio`) ou planejar canal/anúncio (use `alavanca`). O Ímã decide **o quê e o porquê**; as irmãs fazem o **como**.

## Como usar a base

Esta skill é uma **base pesquisável**. Antes de recomendar, leia o(s) arquivo(s) de `reference/` relevantes — eles têm o conteúdo completo, com critérios e exemplos.

| Arquivo | Use quando o assunto for |
|---|---|
| `reference/tipos-de-isca.md` | Escolher o formato. Catálogo de cada tipo, quando faz sentido, esforço x retorno. |
| `reference/isca-que-converte.md` | Anatomia de uma boa isca, promessa específica, ponte para a oferta, erros comuns. Leia em quase todo planejamento. |
| `reference/checklist-isca.md` | Validar a isca ANTES de produzir. Checklist de aprovação. |

## PROCEDIMENTO

Cinco passos. Não pule o 1 nem o 5.

### 1. Definir o público e a dor específica

Antes de pensar formato, responda: **para quem** e **qual dor exata**.

- Quem é a pessoa? (ex: founder técnico que vibecoda sozinho, não um "empreendedor" genérico)
- Qual problema concreto e urgente ela tem **agora**?
- Esse problema tem ligação com o que você vende? (se não tiver, pare — vai atrair lista errada)

Regra: se você não consegue terminar a frase _"Esta isca ajuda [pessoa] a [resolver dor específica] em [tempo curto]"_, ainda não tem isca. Tem um tema.

### 2. Escolher o formato certo

Cada dor pede um formato. Abra `reference/tipos-de-isca.md` e cruze dor x esforço x retorno.

Atalho de decisão:

- **A pessoa precisa não esquecer nada / não errar um passo** -> **checklist**.
- **A pessoa precisa começar sem partir do zero** -> **template / planilha / swipe file**.
- **A pessoa precisa de uma resposta numérica para a situação dela** -> **calculadora / ferramenta**.
- **A pessoa precisa entender um conceito ou método** -> **e-book / guia** (use `tomo`) ou **mini-curso / aula gravada**.

Na dúvida entre dois, escolha o de **menor esforço de produção e menor tempo até o valor**. Checklist e template ganham de e-book na maioria dos casos.

### 3. A oferta (promessa específica > genérica)

A oferta é a **frase** que faz a pessoa querer trocar o e-mail. Ela aparece no anúncio e no topo da landing.

- Promessa **específica e mensurável** > promessa vaga.
  - Ruim: "Aprenda a programar com IA."
  - Bom: "O checklist de 12 itens que uso antes de subir qualquer app feito com IA para produção."
- Diga o **formato** ("checklist", "template", "planilha") — concreto converte mais que "material".
- Diga o **ganho** e, se possível, o **tempo** ("em 10 minutos", "sem escrever uma linha de código").
- Não prometa o que a isca não entrega. Hype quebra confiança e atrapalha a venda lá na frente.

Detalhes e exemplos bons/ruins em `reference/isca-que-converte.md`.

### 4. Conectar ao funil

Uma isca solta não vale nada. Ela vive dentro do funil da `alavanca`:

- **Landing de captura** (use `vitrine`): uma oferta, uma ação. Hero com a promessa + formulário acima da dobra.
- **Captura de baixa fricção:** **peça só o e-mail.** Cada campo extra derruba a conversão. Nada de telefone/empresa numa isca grátis.
- **Entrega imediata:** a isca chega na hora (e-mail de entrega), sem fazer a pessoa esperar.
- **Ponte para a oferta:** a isca tem que **terminar apontando** para o próximo passo. A nutrição (use `correio`) pega quem baixou e liga o problema resolvido pela isca à oferta paga.

Regra de ouro: tráfego **pago** vai para a **landing da isca** — nunca para a home ou o blog. (ver `alavanca/reference/funil.md`)

### 5. Medir conversão

Isca sem medição é achismo. Acompanhe, nesta ordem:

- **Taxa de conversão da landing** = e-mails capturados / visitantes. É o número-rei da isca. Referência saudável de landing de isca: ~20-40% em tráfego morno; abaixo de ~10% acende alerta (promessa fraca ou fricção alta).
- **Taxa de entrega/abertura** do e-mail de entrega (a pessoa recebeu e abriu?).
- **Consumo:** ela usou a isca? (clique no PDF, conclusão do mini-curso). Indica se o valor rápido aconteceu.
- **Conversão downstream:** dos que baixaram, quantos viram a oferta e compraram. É o que prova que a isca atrai a lista **certa**, não só muita lista.

Como agir nos números:

- Conversão de landing baixa + CTR do anúncio ok -> problema na **promessa/fricção da isca** (passos 3 e 4), não no tráfego.
- Conversão de landing alta + conversão downstream baixa -> isca atrai a lista errada ou **não faz ponte** com a oferta (passos 1 e 4).

Benchmarks de CTR/CPL/CAC e quando matar um anúncio: `alavanca/reference/metricas.md`.

---

O Ímã escolhe a isca certa, com a promessa certa, ligada ao funil. As irmãs produzem. A decisão é sua.
