# Checklist — validar uma isca antes de produzir

Use antes de investir tempo produzindo. **Se algum item crítico falhar, pare e ajuste — não produza.** Produzir uma isca errada custa caro: você gasta o tempo, gasta o tráfego e ainda enche a lista de gente que não compra.

Marque cada item. Os marcados com **(crítico)** são eliminatórios.

## Público e dor

- [ ] **(crítico)** Sei exatamente **para quem** é (uma pessoa específica, não "empreendedores" em geral).
- [ ] **(crítico)** A isca resolve **UM** problema concreto e urgente desse público.
- [ ] Consigo completar a frase: _"Esta isca ajuda [pessoa] a [resolver dor específica] em [tempo curto]."_
- [ ] A dor é do **público**, não um tema que só eu acho interessante.

## Ponte com a oferta

- [ ] **(crítico)** Quem baixa esta isca é **a mesma pessoa** que compraria minha oferta.
- [ ] A isca resolve um **pedaço** do problema; a oferta resolve o resto (ou o próximo nível).
- [ ] A isca **termina apontando** para o próximo passo (CTA suave / "e agora?").
- [ ] Já sei como a nutrição (`correio`) vai ligar a isca à oferta.

## Formato

- [ ] **(crítico)** O formato escolhido entrega o valor **rápido** (ver `tipos-de-isca.md`).
- [ ] Considerei um formato de **menor esforço** que resolveria igual (checklist/template antes de e-book).
- [ ] O esforço de produção é justificado pelo retorno esperado.
- [ ] Consigo produzir com **qualidade** neste formato (se não, troco de formato).

## Promessa / oferta

- [ ] **(crítico)** A promessa é **específica**, não genérica.
- [ ] A promessa nomeia o **formato** ("checklist", "template", "planilha"...).
- [ ] A promessa diz o **ganho** e, se possível, o **tempo**.
- [ ] **(crítico)** A promessa é **honesta** — sem hype, sem milagre. Eu entrego o que prometo.
- [ ] A isca **supera** a promessa (subprometo, superentrego) — não decepciona.

## Funil e captura

- [ ] Existe (ou existirá) uma **landing de oferta única** para ela (use `vitrine`).
- [ ] **(crítico)** A captura pede **só o e-mail** (sem telefone/empresa/cargo numa isca grátis).
- [ ] A **entrega é imediata** após a captura.
- [ ] Sei de onde virá o **tráfego** (pago/orgânico) e que ele vai para a landing, não para a home/blog (ver `alavanca`).

## Medição

- [ ] Vou medir **taxa de conversão da landing** (e-mails / visitantes).
- [ ] Vou medir **consumo** (a pessoa usou a isca?).
- [ ] Vou medir **conversão downstream** (dos que baixaram, quantos compraram).
- [ ] Sei o que faço se a conversão vier baixa (ajustar promessa/fricção antes de culpar o tráfego).

---

## Veredito

- **Todos os (crítico) marcados + maioria do resto:** pode produzir.
- **Algum (crítico) em branco:** **não produza.** Volte ao passo correspondente do procedimento e ajuste.
- **Vários não-críticos em branco:** dá para produzir, mas anote os gaps — costumam ser onde a conversão vaza depois.

A isca certa, validada antes, economiza o recurso mais caro: o seu tempo e o seu tráfego. A decisão é sua.
