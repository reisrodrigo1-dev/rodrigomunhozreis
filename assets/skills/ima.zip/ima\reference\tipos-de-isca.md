# Tipos de isca — catálogo de formatos

Cada formato resolve um tipo de dor e tem um perfil de esforço x retorno diferente. A regra geral: **o melhor formato é o que entrega valor mais rápido com o menor esforço de produção.** Material grande impressiona; material que a pessoa usa hoje converte.

Legenda de esforço/retorno:
- **Esforço** = quanto custa produzir (tempo + complexidade).
- **Tempo até o valor** = quanto a pessoa demora para sentir o ganho depois de baixar. Quanto menor, melhor a conversão e a confiança.
- **Conversão** = quão bem a promessa costuma virar e-mail na landing.

Ordem abaixo: do menor esforço para o maior.

---

## 1. Checklist

Uma lista de itens a verificar/seguir para não errar nem esquecer nada num processo.

- **Resolve a dor de:** "tenho medo de esquecer um passo / fazer errado".
- **Esforço:** baixo (1 página, normalmente).
- **Tempo até o valor:** imediato — a pessoa usa no mesmo dia.
- **Conversão:** alta. Concreto, rápido, promessa fácil de cumprir.
- **Quando faz sentido:** processo com etapas onde errar dói (subir app para produção, configurar segurança, lançar um produto, revisar copy).
- **Exemplo:** "Checklist de 12 itens antes de subir um app feito com IA para produção."
- **Produção:** PDF simples ou página. Para padrão editorial, use `tomo`.

## 2. Template / modelo

Um arquivo pronto para a pessoa preencher/adaptar (documento, prompt, estrutura, e-mail, contrato).

- **Resolve a dor de:** "não sei começar / não quero começar do zero".
- **Esforço:** baixo a médio.
- **Tempo até o valor:** imediato — copia, cola, adapta.
- **Conversão:** alta. Economiza trabalho na hora.
- **Quando faz sentido:** existe um artefato repetível que seu público recria sempre do zero (template de prompt, estrutura de proposta, modelo de e-mail de cobrança).
- **Exemplo:** "Template de prompt P.R.O.M.P.T.E.R. pronto para colar no Claude."

## 3. Planilha

Uma planilha que calcula, organiza ou acompanha algo automaticamente.

- **Resolve a dor de:** "preciso organizar/calcular isso e dá trabalho montar".
- **Esforço:** médio (montar fórmulas e testar).
- **Tempo até o valor:** rápido.
- **Conversão:** boa, principalmente para público que vive em planilha (founders, financeiro, ops).
- **Quando faz sentido:** há números recorrentes para acompanhar (custo de infra, runway, precificação, ROI de anúncio).
- **Exemplo:** "Planilha que estima o custo de infra + IA do seu projeto por faixa de usuários."

## 4. Swipe file (arquivo de referência)

Uma coleção curada de exemplos prontos para "roubar com orgulho" (headlines, anúncios, prompts, e-mails, telas).

- **Resolve a dor de:** "não tenho repertório / inspiração / referência boa".
- **Esforço:** médio (curar e organizar com critério).
- **Tempo até o valor:** rápido.
- **Conversão:** boa, sobretudo para quem produz (marketing, copy, design, dev).
- **Quando faz sentido:** seu público recria as mesmas peças e se beneficia de exemplos validados.
- **Exemplo:** "30 prompts que uso de verdade para vibecodar com segurança."

## 5. Calculadora / ferramenta interativa

Uma mini-ferramenta web onde a pessoa insere os dados dela e recebe um resultado personalizado.

- **Resolve a dor de:** "qual é o número/resposta para o MEU caso?".
- **Esforço:** alto (é software — precisa construir e hospedar).
- **Tempo até o valor:** imediato e personalizado — o mais "uau" dos formatos.
- **Conversão:** muito alta quando o resultado importa para a pessoa; e gera tráfego orgânico e backlinks.
- **Quando faz sentido:** há um cálculo de decisão relevante (custo, ROI, preço, economia). Vale o esforço quando a calculadora vira ativo de SEO.
- **Exemplo:** "Calculadora de quanto seu app vai custar com X usuários."
- **Atenção:** é o único formato em que a entrega pode vir antes da captura (mostra o resultado, pede e-mail para enviar o relatório completo).

## 6. Mini-curso por e-mail

Uma sequência curta (3-5 e-mails) que ensina algo passo a passo, um e-mail por dia.

- **Resolve a dor de:** "quero aprender um método, mas sem encarar um curso longo".
- **Esforço:** médio a alto (escrever a sequência).
- **Tempo até o valor:** progressivo (dias).
- **Conversão:** boa, e tem um bônus enorme: **já é nutrição** — a pessoa entra direto numa sequência que constrói relacionamento e termina na oferta.
- **Quando faz sentido:** seu tema tem um método em etapas e você quer aquecer a lista enquanto entrega valor.
- **Exemplo:** "Mini-curso de 5 dias: do prompt à feature em produção, com segurança."
- **Produção:** a sequência é escrita com `correio`.

## 7. E-book / guia

Um material rico em PDF/HTML que explica um conceito ou método com profundidade.

- **Resolve a dor de:** "quero entender o assunto a fundo, num lugar só".
- **Esforço:** alto.
- **Tempo até o valor:** mais lento (a pessoa precisa ler).
- **Conversão:** boa na captura, MAS risco real de **não ser consumido** — e isca não lida não gera confiança nem venda.
- **Quando faz sentido:** o tema exige contexto e profundidade, ou serve de companion de palestra/autoridade. Para não cair na armadilha do "PDF que ninguém lê", torne-o acionável (passos, prompts copiáveis, plano de N dias).
- **Exemplo:** "Guia: vibecoding com engenharia — do prompt à produção."
- **Produção:** use `tomo` (capa escura, miolo claro, prompts copiáveis, plano de N dias).

## 8. Aula gravada / vídeo

Uma aula ou workshop gravado, acessível após a captura.

- **Resolve a dor de:** "quero ver alguém fazer / aprender assistindo".
- **Esforço:** alto (gravar, editar, hospedar).
- **Tempo até o valor:** médio (depende da duração — mantenha curto).
- **Conversão:** boa quando o tema é demonstrável (mostrar o processo na tela vale mais que descrever).
- **Quando faz sentido:** o valor está em **ver fazendo** (vibecodar ao vivo, montar um funil, configurar segurança). Aproveita autoridade de quem aparece.
- **Exemplo:** "Aula de 25 min: construindo um app seguro com IA, do zero ao deploy."
- **Roteiro:** use `claquete`.

---

## Tabela-resumo

| Formato | Esforço | Tempo até o valor | Conversão | Melhor para |
|---|---|---|---|---|
| Checklist | Baixo | Imediato | Alta | Não esquecer / não errar um passo |
| Template | Baixo-médio | Imediato | Alta | Começar sem partir do zero |
| Planilha | Médio | Rápido | Boa | Calcular/acompanhar números |
| Swipe file | Médio | Rápido | Boa | Repertório/referência para quem produz |
| Calculadora | Alto | Imediato (personalizado) | Muito alta | Resposta numérica do caso da pessoa |
| Mini-curso e-mail | Médio-alto | Progressivo | Boa (já nutre) | Ensinar método em etapas |
| E-book/guia | Alto | Lento | Boa (risco de não ler) | Profundidade / autoridade / companion |
| Aula gravada | Alto | Médio | Boa | Valor está em ver fazendo |

## Como escolher entre eles

1. Comece pela **dor** (passo 1 do procedimento), não pelo formato que você acha bonito.
2. Entre dois formatos que servem, escolha o de **menor esforço e menor tempo até o valor**. Na dúvida, **checklist ou template** quase sempre ganham.
3. Só vá para e-book/aula/calculadora quando a dor **realmente exigir** profundidade, demonstração ou cálculo — e quando você puder produzir com qualidade.
4. Se quiser que a isca **já comece a nutrir**, prefira o **mini-curso por e-mail**.
