# Anatomia de uma isca que converte

Uma isca converte quando faz três coisas, nesta ordem: **promete algo específico**, **entrega valor rápido** e **constrói uma ponte para a oferta**. Falhar em qualquer uma das três quebra o funil — às vezes de forma invisível (você captura e-mail, mas nunca vende).

---

## Os 3 pilares

### 1. Promessa específica

A promessa é a frase que faz um estranho decidir trocar o e-mail dele. Ela é específica quando deixa claro **para quem é**, **o que resolve** e **em quanto tempo**.

Específico vence genérico sempre — porque genérico não parece feito para a pessoa.

| Genérico (fraco) | Específico (forte) |
|---|---|
| "Guia de boas práticas de programação" | "Checklist de 12 itens antes de subir um app feito com IA para produção" |
| "Aprenda marketing digital" | "Os 3 e-mails de boas-vindas que transformam quem baixou seu e-book em cliente" |
| "Material sobre custos de software" | "Planilha que estima o custo de infra + IA do seu projeto por faixa de usuários" |
| "Dicas para escrever prompts" | "30 prompts prontos que uso para vibecodar com segurança" |

Como deixar específico:
- **Coloque um número** quando fizer sentido ("12 itens", "5 dias", "30 prompts"). Número sinaliza escopo finito e cumprível.
- **Nomeie o formato** ("checklist", "template", "planilha") — concreto converte mais que "material" ou "conteúdo".
- **Diga o ganho e, se der, o tempo** ("em 10 minutos", "sem escrever uma linha de código").
- **Mire na pessoa certa.** Falar para "todo mundo" não fala para ninguém.

### 2. Valor rápido

A pessoa precisa sentir o ganho **antes de esfriar**. O tempo entre baixar e ter o "aha" é uma métrica de verdade — quanto menor, mais ela confia em você e mais aberta fica para a oferta.

- **Resolva UM problema, não dez.** Uma isca focada que resolve uma coisa de verdade vale mais que um calhamaço que tangencia tudo.
- **Acionável > teórico.** Passos, modelos prontos, prompts copiáveis. A pessoa tem que conseguir *fazer*, não só *ler*.
- **Entrega imediata.** A isca chega na hora da captura. Esperar mata o impulso.
- **Cumpra a promessa logo nas primeiras linhas/telas.** Não enrole até a página 40. O valor prometido aparece cedo.

Teste do valor rápido: _se a pessoa só consumisse os primeiros 2 minutos, ela já sairia com algo útil?_ Se não, a isca está mal construída (ou é o formato errado — ver `tipos-de-isca.md`).

### 3. Ponte para a oferta

Esta é a parte que quase todo mundo esquece — e é a que separa "lista grande" de "lista que compra". A isca tem que resolver um problema que **naturalmente leva** ao que você vende.

- A isca resolve **um pedaço** do problema. A oferta resolve o **problema inteiro** (ou o próximo nível dele).
  - Isca: "Checklist para subir app com IA com segurança." -> Oferta: curso/produto de vibecoding com engenharia.
  - Isca: "Os 3 e-mails de boas-vindas." -> Oferta: serviço/produto de funil completo.
- A isca deve **terminar apontando** para o próximo passo (um CTA suave, um "e agora?").
- A **nutrição** (escrita com `correio`) pega quem baixou e faz a ligação explícita entre o problema que a isca resolveu e a oferta. A ponte começa na isca e se completa nos e-mails.

Pergunta de validação: _quem baixa esta isca é exatamente quem compraria minha oferta?_ Se a resposta é "não necessariamente", você vai encher a lista de gente errada.

---

## Erros comuns (e como evitar)

### Isca genérica
"Guia completo de [tema amplo]". Não fala com ninguém em específico, não promete um ganho claro. **Conserto:** estreite até doer. Um público, uma dor, um formato.

### Ampla demais
Tenta cobrir o assunto inteiro. Vira um e-book de 80 páginas que ninguém lê — e isca não consumida não gera confiança. **Conserto:** corte para UM problema. Se sobrou muita coisa, são várias iscas, não uma.

### Sem ligação com o produto (a pior)
Converte e-mail à beça com um tema "viral" que não tem nada a ver com o que você vende. Resultado: lista grande, conversão zero, e você pagou pelos leads. **Conserto:** aplique o teste da ponte (pilar 3) **antes** de produzir.

### Fricção alta na captura
Formulário pedindo nome, e-mail, telefone, empresa e cargo numa isca grátis. Cada campo derruba a conversão. **Conserto:** peça **só o e-mail**. (ver `alavanca/reference/funil.md`)

### Promessa com hype / inflada
"Fature 6 dígitos em 7 dias com este PDF." Atrai curioso, não comprador, e quebra a confiança quando a isca não entrega o milagre. **Conserto:** prometa só o que entrega. Específico e honesto converte melhor a médio prazo — e mantém a lista quente para a venda.

### Promessa boa, isca fraca
A landing promete ouro, o material entrega pouco. A pessoa baixa, se decepciona e ignora a nutrição. **Conserto:** a isca tem que **superar** a promessa, não decepcionar. Subprometa, superentregue.

### Tema "achei legal", não "a pessoa precisa"
Você produz o que *você* acha interessante, não o que tira o sono do público. **Conserto:** volte ao passo 1 do procedimento — a dor é do público, não sua.

---

## Resumo

Uma isca que converte: **promete uma coisa específica, entrega rápido um valor real e deixa a pessoa um passo mais perto da sua oferta.** Se cumprir os três pilares e evitar os erros, a captura vira lista certa — e lista certa vira venda. A decisão é sua.
