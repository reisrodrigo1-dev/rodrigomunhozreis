# LGPD — fundamentos aplicados a software

> Material de apoio da skill Salvaguarda. Linguagem acessível, foco em produto.
> **Não é parecer jurídico.** Para decisões de alto risco, valide com advogado de proteção de dados.

A LGPD é a Lei 13.709/2018 — a Lei Geral de Proteção de Dados Pessoais do Brasil. Ela regula como qualquer organização (inclusive uma startup de uma pessoa) pode **coletar, usar, guardar e compartilhar dados de pessoas físicas**. Quem fiscaliza é a ANPD (Autoridade Nacional de Proteção de Dados). Multas chegam a 2% do faturamento, limitadas a R$ 50 milhões por infração — mas, para o fundador pequeno, o risco mais provável e mais barato de evitar é reputacional e de bloqueio de tratamento.

A lei se aplica sempre que houver tratamento de dados de pessoas no Brasil, independentemente de onde a empresa esteja. Se sua landing tem um campo de e-mail, você está sob a LGPD.

---

## Os conceitos que importam

### Dado pessoal
Qualquer informação que identifique ou possa identificar uma pessoa. Óbvios: nome, CPF, e-mail, telefone/WhatsApp, endereço. Menos óbvios e igualmente cobertos: **IP, cookies de identificação, device ID, ID de usuário, geolocalização, histórico de comportamento**. Em software, "dado pessoal" é muito mais amplo do que o fundador costuma imaginar — analytics e Pixel coletam dado pessoal mesmo sem nome.

### Dado pessoal sensível
Subcategoria com proteção reforçada: origem racial/étnica, convicção religiosa, opinião política, filiação a sindicato, dado referente à saúde, à vida sexual, dado genético ou biométrico. Tratar dado sensível em geral **exige consentimento específico e destacado** (ou outra hipótese restrita do Art. 11). Se seu produto toca em qualquer um desses — app de saúde, fitness, dating, etc. — o cuidado sobe de nível e vale falar com advogado.

### Dado de crianças e adolescentes
Tratamento de dados de menores de 18 exige cuidado extra; para crianças (até 12), exige **consentimento específico e em destaque de um dos pais ou responsável**, e o melhor interesse da criança. Se seu público inclui menores, isso muda o design do consentimento.

### Titular
A pessoa física a quem os dados se referem — o seu usuário, lead, assinante. É ele quem tem os direitos (ver "Direitos do titular").

### Controlador
Quem **decide** como e por que os dados são tratados. Na prática, é a **sua empresa / você, fundador**. É o controlador que responde perante o titular e a ANPD. A política de privacidade é assinada pelo controlador.

### Operador
Quem **trata os dados em nome do controlador**, seguindo suas instruções. São os **terceiros** que você usa: Mailchimp/Resend (e-mail), Google Analytics, Meta (Pixel), Firebase/Google Cloud (banco e hospedagem), Stripe/gateway (pagamento). Você (controlador) continua responsável por eles. Por isso eles têm que estar listados na política e, idealmente, ter um contrato/termo de tratamento (DPA) — provedores grandes oferecem um DPA padrão.

### Encarregado (DPO)
A pessoa de contato entre você, os titulares e a ANPD. Pode ser você mesmo no começo. O importante é ter um **canal público** (e-mail) que recebe e responde pedidos de titulares. A política precisa informar esse contato.

---

## Bases legais (Art. 7º) — o coração da conformidade

Você **não pode** tratar dado pessoal "porque sim". Todo tratamento precisa de uma das 10 bases legais. Escolher a base certa é a decisão mais importante. As que aparecem em quase todo produto de software:

| Base legal | Quando usar em software | Exemplo |
|------------|-------------------------|---------|
| **Consentimento** | Marketing, newsletter, cookies não essenciais, Pixel, qualquer coleta opcional. Exige opt-in livre, informado, inequívoco e **revogável**. | Caixa "quero receber novidades por e-mail" |
| **Execução de contrato** | Dados necessários para entregar o serviço que o usuário pediu. | E-mail/senha de login; dados de entrega de um pedido |
| **Legítimo interesse** | Usos esperados e de baixo risco para o titular. Exige avaliação de proporcionalidade (LIA) e **não cobre dado sensível**. | Prevenção a fraude; analytics básico de produto; segurança |
| **Cumprimento de obrigação legal** | Quando uma lei te obriga a guardar. | Guardar nota fiscal e registros fiscais pelo prazo legal |
| **Proteção da vida / da saúde** | Emergências. | Raro em SaaS comum |
| **Exercício regular de direitos** | Defesa em processo. | Guardar logs para se defender de uma disputa |

Regra de ouro para o fundador: **consentimento para o que é marketing/opcional; contrato para o que é o serviço em si; legítimo interesse com parcimônia e nunca para dado sensível.** Não empilhe consentimento onde o contrato já basta — pedir consentimento para o login é errado e atrapalha.

### Sobre o consentimento (o que mais dá problema)
Para valer, o consentimento tem que ser:
- **Livre** — sem coação, sem "aceite tudo ou não use".
- **Informado** — a pessoa sabe para quê está consentindo (link para a política).
- **Inequívoco** — opt-in ativo. **Caixa pré-marcada não vale.** Aceitar cookies por scroll não vale.
- **Específico** — por finalidade. Um aceite genérico para "tudo" é frágil.
- **Revogável** — tem que ser tão fácil sair quanto foi entrar.
- **Comprovável** — você precisa guardar **o que** foi consentido, **quando** e em **qual versão** dos termos. É aqui que entra o `consentVersion` + timestamp.

---

## Direitos do titular (Art. 18)

O titular pode exigir, e você tem que conseguir atender (prazo de resposta em geral imediato ou em até 15 dias para confirmação/acesso):

- **Confirmação** de que você trata os dados dele.
- **Acesso** aos dados — uma cópia do que você tem.
- **Correção** de dados incompletos, inexatos ou desatualizados.
- **Anonimização, bloqueio ou eliminação** de dados desnecessários ou tratados em desconformidade.
- **Portabilidade** — receber os dados em formato estruturado para levar a outro serviço.
- **Eliminação** dos dados tratados com base em consentimento (com exceções legais).
- **Informação** sobre com quem você compartilhou os dados.
- **Revogação do consentimento.**
- **Oposição** a tratamento feito sem consentimento, quando houver descumprimento.
- **Revisão** de decisões automatizadas que afetem seus interesses.

Em produto, isso vira features: editar perfil (correção), excluir conta (eliminação), exportar dados (portabilidade/acesso), descadastrar (revogação). No mínimo viável, um e-mail de encarregado que responde a esses pedidos manualmente já tira você do pior cenário — mas o caminho automatizado é o objetivo.

---

## Transferência e compartilhamento com terceiros

Todo terceiro que recebe dado pessoal seu (operador) precisa:
- Estar **listado na Política de Privacidade** (de preferência nominalmente, ou por categoria com exemplos).
- Tratar os dados **só para a finalidade** que você definiu.
- Idealmente ter um **DPA/termo de tratamento** — Google, Meta, Stripe, Mailchimp oferecem um padrão; aceite-o.

**Transferência internacional:** muitos desses serviços guardam dados fora do Brasil (servidores nos EUA, etc.). A LGPD permite, mas exige garantias adequadas. Para o fundador, a ação prática é: usar provedores reconhecidos, aceitar o DPA deles, e **declarar na política que há transferência internacional**. Se você trata dado sensível em volume e transfere para fora, fale com advogado.

---

## Retenção e minimização

Dois princípios que viram regra de engenharia:

- **Minimização** — colete só o que precisa para a finalidade. Não peça CPF se você só vai mandar newsletter. Cada campo a mais é risco a mais.
- **Retenção limitada** — guarde só pelo tempo necessário. Defina prazo por finalidade e tenha um plano para apagar/anonimizar o que passou do prazo. "Guardar para sempre" é não conformidade. Exemplos de prazo: lead não convertido — 6 a 12 meses; dados de cobrança — prazo fiscal/legal aplicável; conta inativa — política de inatividade definida.

---

## Segurança (Art. 46)

Você tem que adotar medidas técnicas e administrativas para proteger os dados. Em Next.js + Firebase, o básico inegociável:
- **Regras de segurança do Firestore** restritivas — cada usuário lê/escreve só o que é dele; dado pessoal não fica público.
- **Variáveis de ambiente / secrets** fora do código versionado.
- **HTTPS** em tudo (padrão no Vercel/Firebase Hosting).
- **Acesso mínimo** ao console do Firebase/admin.
- Em caso de **incidente de segurança** (vazamento), há dever de comunicar a ANPD e os titulares em prazo razoável — esse é um cenário em que você **deve** acionar advogado imediatamente.

---

## Glossário rápido

- **ANPD** — Autoridade Nacional de Proteção de Dados, o regulador.
- **DPA** (Data Processing Agreement) — termo/contrato de tratamento entre controlador e operador.
- **DPO / Encarregado** — pessoa de contato para assuntos de proteção de dados.
- **LIA** — avaliação de legítimo interesse (documenta por que o legítimo interesse é proporcional).
- **RIPD / DPIA** — relatório de impacto à proteção de dados, exigível em tratamentos de alto risco.
- **Tratamento** — qualquer operação com dado pessoal: coletar, usar, armazenar, compartilhar, eliminar.
- **consentVersion** — versão dos termos a que o usuário consentiu; guardada para comprovar o consentimento.
