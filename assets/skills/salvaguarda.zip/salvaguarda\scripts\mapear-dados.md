# Guia de varredura — encontrar dados pessoais no código

> Material de apoio da skill Salvaguarda (Etapa 1 do procedimento).
> Objetivo: varrer o repositório atrás de todo ponto onde dado pessoal entra, é armazenado ou sai para terceiro.
> Comandos em `ripgrep` (`rg`) — rápido e respeita `.gitignore`. Rode na raiz do projeto.

---

## Como usar

1. Rode os blocos abaixo na ordem.
2. Para cada hit, abra o arquivo e registre no inventário: **qual dado / onde coleta / onde armazena / sai p/ terceiro**.
3. Não confie só no grep — ele aponta candidatos. Confirme lendo o código.

---

## 1. Formulários e campos de entrada

Procura por campos típicos de dado pessoal e por inputs/validações.

```bash
# Campos por nome (PT e EN)
rg -i -n "email|e-mail|whatsapp|telefone|celular|phone|\bcpf\b|\bcnpj\b|\bnome\b|\bname\b|sobrenome|endereco|address|cep|\brg\b|nascimento|birth|\bidade\b" --glob '!node_modules'

# Inputs e formulários
rg -n "<input|<form|name=|type=[\"']email[\"']|type=[\"']tel[\"']" --glob '*.{tsx,jsx,ts,js,html}'

# Validação de schema (campos revelam o que é coletado)
rg -n "z\.object|yup\.object|register\(|useForm|zodResolver" --glob '*.{ts,tsx,js,jsx}'

# Handlers de submit
rg -n "onSubmit|handleSubmit|FormData|req\.body" --glob '*.{ts,tsx,js,jsx}'
```

## 2. Armazenamento — Firestore / banco

Procura por onde os dados são gravados e em quais coleções.

```bash
# Operações de escrita Firestore
rg -n "addDoc|setDoc|updateDoc|doc\(|collection\(|writeBatch" --glob '*.{ts,tsx,js,jsx}'

# Nomes de coleção que costumam guardar dado pessoal
rg -i -n "users|usuarios|leads|subscribers|assinantes|contacts|contatos|clientes|customers|orders|pedidos|profiles|perfis" --glob '*.{ts,tsx,js,jsx}'

# Outros bancos / ORMs (se houver)
rg -n "prisma|knex|mongoose|supabase|INSERT INTO|createUser" --glob '*.{ts,tsx,js,jsx}'
```

## 3. Analytics e métricas

Procura por ferramentas que coletam IP, comportamento, device.

```bash
# Google Analytics / GA4 / Firebase Analytics
rg -n "gtag|G-[A-Z0-9]+|getAnalytics|logEvent|GoogleAnalytics|ga\(" --glob '*.{ts,tsx,js,jsx,html}'

# Outras ferramentas de analytics
rg -i -n "hotjar|clarity|mixpanel|amplitude|posthog|segment|plausible" --glob '*.{ts,tsx,js,jsx,html}'
```

## 4. Pixels e cookies de marketing

Procura por trackers de anúncio e manipulação de cookies.

```bash
# Meta / Facebook Pixel
rg -n "fbq\(|fbevents|connect\.facebook\.net|pixelId|FB_PIXEL" --glob '*.{ts,tsx,js,jsx,html}'

# Google Ads / TikTok / outros pixels
rg -i -n "googletagmanager|gtm\.js|AW-[0-9]+|tiktok.*pixel|ttq\.|linkedin.*insight" --glob '*.{ts,tsx,js,jsx,html}'

# Cookies próprios
rg -n "document\.cookie|setCookie|js-cookie|cookies\(\)|next/headers.*cookies" --glob '*.{ts,tsx,js,jsx}'

# Scripts de terceiros injetados
rg -n "<Script|next/script|dangerouslySetInnerHTML" --glob '*.{ts,tsx,js,jsx}'
```

## 5. Terceiros / envio de dados para fora

Procura por integrações que recebem dado pessoal.

```bash
# E-mail marketing / transacional
rg -i -n "mailchimp|sendgrid|resend|mailgun|brevo|sendinblue|postmark" --glob '*.{ts,tsx,js,jsx}'

# Pagamento
rg -i -n "stripe|mercadopago|mercado pago|pagarme|asaas|paypal|gerencianet" --glob '*.{ts,tsx,js,jsx}'

# CRM / automação
rg -i -n "hubspot|rdstation|activecampaign|pipedrive|salesforce" --glob '*.{ts,tsx,js,jsx}'

# Chamadas externas genéricas (revisar destinos)
rg -n "fetch\(|axios|https?://" --glob '*.{ts,tsx,js,jsx}' --glob '!*.test.*'
```

## 6. Verificações de segurança (rápidas)

```bash
# Regras do Firestore — confira se não estão abertas
rg -n "allow read|allow write|request\.auth" firestore.rules

# Secrets vazados no código (não deveria existir)
rg -i -n "apiKey|api_key|secret|password|token\s*=" --glob '!*.env*' --glob '!node_modules'

# Variáveis de ambiente expostas ao client (NEXT_PUBLIC_ é público!)
rg -n "NEXT_PUBLIC_" --glob '*.{ts,tsx,js,jsx}'
```

---

## Montando o inventário

Com os hits em mãos, preencha:

| Dado | Onde coleta (arquivo) | Onde armazena | Sai p/ terceiro? | Finalidade | Base legal | Retenção |
|------|----------------------|---------------|------------------|------------|------------|----------|
| E-mail | `components/NewsletterForm.tsx` | Firestore `subscribers` + Resend | Sim (Resend) | Newsletter | Consentimento | 12 meses |
| Nome | `app/cadastro/page.tsx` | Firestore `users` | Não | Conta | Contrato | Vida da conta |
| IP/comportamento | `app/layout.tsx` (GA4) | Google Analytics | Sim (Google) | Análise | Legítimo interesse | Padrão GA |
| Conversões | `app/layout.tsx` (`fbq`) | Meta | Sim (Meta) | Mensuração de ads | Consentimento | Padrão Meta |

As três últimas colunas vêm na **Etapa 2** do procedimento. Esse inventário alimenta a Política de Privacidade e os avisos de consentimento (Etapa 4).

---

## Observações

- Em Windows/PowerShell, se não tiver `rg`, use o Grep do próprio Claude Code (mesma engine ripgrep) ou instale via `winget install BurntSushi.ripgrep.MSVC`.
- Ajuste `--glob` ao seu projeto (ex.: incluir `.vue`, `.svelte`, `.astro`).
- O grep acha candidatos; a confirmação é sempre lendo o código. Dado pessoal "escondido" (ex.: nome dentro de um objeto genérico `payload`) pode não casar com os padrões — vale uma leitura dos handlers de formulário e das funções de escrita no banco.
