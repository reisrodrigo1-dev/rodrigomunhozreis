# Política de Privacidade — modelo preenchível

> Modelo da skill Salvaguarda. Substitua todos os `{{PLACEHOLDERS}}` pelos dados reais do seu inventário (data map).
> Apague as instruções entre `<!-- -->` antes de publicar.
> **Não é parecer jurídico.** Para alto risco, valide com advogado de proteção de dados.

---

# Política de Privacidade

**Última atualização:** {{DATA_ULTIMA_ATUALIZACAO}}
**Versão:** {{VERSAO_POLITICA}} <!-- ex.: v1.0 — mantenha alinhado ao consentVersion -->

## 1. Quem somos (Controlador)

Esta Política descreve como **{{NOME_DA_EMPRESA_OU_RESPONSAVEL}}** ({{CNPJ_OU_IDENTIFICACAO}}), responsável pelo {{NOME_DO_PRODUTO}} (`{{URL_DO_SITE}}`), trata seus dados pessoais, na qualidade de **controlador** nos termos da Lei Geral de Proteção de Dados (Lei 13.709/2018 — LGPD).

**Contato do Encarregado (DPO):** {{EMAIL_DO_ENCARREGADO}}

## 2. Quais dados coletamos

<!-- Liste APENAS o que seu código realmente coleta — use o inventário da Etapa 1. -->

Coletamos os seguintes dados pessoais:

- **Dados que você nos fornece:** {{EX_NOME_EMAIL_WHATSAPP}} — quando você {{EX_PREENCHE_FORMULARIO_OU_SE_CADASTRA}}.
- **Dados de uso e navegação:** {{EX_ENDERECO_IP_PAGINAS_VISITADAS_DISPOSITIVO}} — coletados automaticamente por ferramentas de análise.
- **Cookies e identificadores:** {{EX_COOKIES_PROPRIOS_E_DE_TERCEIROS}} — conforme sua escolha no banner de cookies.

<!-- Se você trata dado sensível ou de menores, declare aqui e revise com advogado. -->

## 3. Para que usamos seus dados (finalidades e bases legais)

<!-- Uma linha por finalidade. A base legal tem que ser a real — ver reference/lgpd-fundamentos.md. -->

| Finalidade | Dados usados | Base legal (LGPD) |
|------------|--------------|-------------------|
| {{EX_ENVIAR_NEWSLETTER}} | {{EX_EMAIL}} | Consentimento |
| {{EX_CRIAR_E_MANTER_SUA_CONTA}} | {{EX_EMAIL_SENHA}} | Execução de contrato |
| {{EX_ANALISAR_USO_E_MELHORAR_O_PRODUTO}} | {{EX_DADOS_DE_NAVEGACAO}} | Legítimo interesse |
| {{EX_PROCESSAR_PAGAMENTOS}} | {{EX_DADOS_DE_COBRANCA}} | Execução de contrato |
| {{EX_OBRIGACOES_FISCAIS}} | {{EX_DADOS_DE_NOTA_FISCAL}} | Cumprimento de obrigação legal |

## 4. Com quem compartilhamos (operadores e terceiros)

<!-- Liste nominalmente cada terceiro que recebe dado pessoal. Use o inventário. -->

Compartilhamos dados, apenas no necessário e para as finalidades acima, com:

- **{{EX_GOOGLE_FIREBASE}}** — {{EX_HOSPEDAGEM_E_BANCO_DE_DADOS}}.
- **{{EX_GOOGLE_ANALYTICS}}** — {{EX_ANALISE_DE_USO}}.
- **{{EX_META_PIXEL}}** — {{EX_MENSURACAO_DE_ANUNCIOS}}.
- **{{EX_MAILCHIMP_OU_RESEND}}** — {{EX_ENVIO_DE_EMAILS}}.
- **{{EX_GATEWAY_DE_PAGAMENTO}}** — {{EX_PROCESSAMENTO_DE_PAGAMENTOS}}.

Não vendemos seus dados pessoais.

## 5. Transferência internacional

<!-- Mantenha se algum operador guarda dados fora do Brasil (a maioria guarda). -->

Alguns dos provedores acima podem armazenar dados em servidores localizados fora do Brasil ({{EX_ESTADOS_UNIDOS}}). Nesses casos, adotamos garantias adequadas, como os termos de tratamento de dados (DPA) oferecidos por esses provedores, conforme exige a LGPD.

## 6. Por quanto tempo guardamos (retenção)

<!-- Defina um prazo por finalidade. Nada de "para sempre". -->

- {{EX_DADOS_DE_LEAD_NAO_CONVERTIDO}}: {{EX_ATE_12_MESES}}.
- {{EX_DADOS_DA_CONTA}}: enquanto a conta estiver ativa e por {{EX_PRAZO}} após o encerramento.
- {{EX_DADOS_DE_COBRANCA_E_FISCAIS}}: pelo prazo exigido pela legislação aplicável.

Após o prazo, os dados são eliminados ou anonimizados.

## 7. Seus direitos como titular

Nos termos da LGPD, você pode, a qualquer momento:

- Confirmar se tratamos seus dados e **acessar** uma cópia deles.
- **Corrigir** dados incompletos, inexatos ou desatualizados.
- Solicitar a **eliminação** dos dados tratados com base no seu consentimento.
- Solicitar a **portabilidade** dos seus dados.
- **Revogar o consentimento** a qualquer momento.
- Obter **informação** sobre com quem compartilhamos seus dados.

Para exercer qualquer direito, escreva para **{{EMAIL_DO_ENCARREGADO}}**. Responderemos dentro dos prazos legais.

## 8. Cookies

Usamos cookies essenciais (necessários ao funcionamento) e, mediante seu consentimento, cookies de análise e de marketing. Você pode gerenciar sua escolha no banner de cookies ou nas configurações do seu navegador. {{EX_LINK_PARA_CONFIGURACOES_DE_COOKIES}}

## 9. Segurança

Adotamos medidas técnicas e administrativas para proteger seus dados, incluindo {{EX_CONTROLE_DE_ACESSO_HTTPS_REGRAS_DE_BANCO}}. Em caso de incidente de segurança relevante, comunicaremos os titulares e a ANPD conforme a lei.

## 10. Alterações nesta Política

Podemos atualizar esta Política. Mudanças materiais serão comunicadas e, quando necessário, solicitaremos novo consentimento. A data e a versão no topo indicam a vigência.

## 11. Contato

Dúvidas sobre esta Política ou sobre seus dados: **{{EMAIL_DO_ENCARREGADO}}**.

---

<!--
CHECKLIST ANTES DE PUBLICAR:
- [ ] Todos os {{PLACEHOLDERS}} substituídos.
- [ ] A lista de dados/terceiros bate com o código (inventário da Etapa 1).
- [ ] consentVersion no produto está alinhado à VERSAO_POLITICA aqui.
- [ ] Link da política presente no rodapé E nos pontos de consentimento.
- [ ] Comentários <!-- --> removidos.
-->
