---
name: salvaguarda
description: Ajuda a adequar um produto de software à LGPD: mapeia dados pessoais coletados, aponta gaps (consentimento, base legal, retenção, terceiros) e gera Política de Privacidade e fluxo de consentimento. Use ao tratar conformidade, privacidade ou coleta de dados.
---

# Salvaguarda — adequação prática à LGPD para produtos de software

> Por Rodrigo Munhoz Reis — vibecoding com engenharia.
> Conformidade sem advogado caro, sem enrolação. A decisão é sua.

## Aviso importante (leia primeiro)

Esta skill entrega **orientação prática de engenharia para reduzir risco de não conformidade**, não aconselhamento jurídico formal. Ela ajuda você a entender o que a LGPD pede, a encontrar onde seu código coleta dados pessoais e a montar os documentos básicos (Política de Privacidade, avisos de consentimento). Para situações de alto risco — dados sensíveis em escala, dados de crianças/adolescentes, decisão automatizada com efeito jurídico, incidente de segurança, transferência internacional sensível, ou qualquer dúvida que possa virar processo — **valide com um advogado especializado em proteção de dados.** Use isto para chegar barato a 80% e saber exatamente onde os 20% precisam de um especialista.

## Visão geral

A LGPD (Lei 13.709/2018) se aplica a praticamente qualquer produto de software que colete dados pessoais de pessoas no Brasil: uma landing com formulário de e-mail, um app com cadastro, um site com analytics ou Pixel, um banco Firestore com perfis de usuário. Estar em conformidade não é "ter um PDF de política no rodapé" — é conseguir responder, com honestidade, a cinco perguntas:

1. **Que dado pessoal eu coleto?** (e por onde ele entra)
2. **Para quê, e com que base legal eu posso coletar isso?**
3. **Quanto tempo eu guardo, e com quem eu compartilho?**
4. **O titular consegue exercer os direitos dele?** (acessar, corrigir, excluir, revogar)
5. **Eu documentei tudo isso de forma que um usuário — ou a ANPD — consiga entender?**

Esta skill conduz exatamente esse caminho, partindo do código (Next.js + Firebase é o stack assumido, mas o método vale para qualquer um) até os documentos finais.

## Quando usar

Acione esta skill quando o trabalho envolver:

- Adequar uma landing page, app ou SaaS à LGPD.
- Revisar se a coleta de dados de um produto está conforme.
- Escrever ou atualizar uma Política de Privacidade.
- Montar ou revisar o fluxo/caixa de consentimento (newsletter, e-book, cookies, Pixel).
- Mapear quais dados pessoais o código realmente coleta e onde eles vão parar.
- Avaliar uso de terceiros (analytics, e-mail marketing, pagamento, CRM) sob a ótica de proteção de dados.
- Implementar mecanismos de direitos do titular (exclusão de conta, exportação de dados, revogação de consentimento).

Não acione para questões puramente jurídicas que exijam parecer formal (contratos, litígios, resposta a notificação da ANPD) — nesses casos, oriente o usuário a procurar um advogado e use a skill apenas para preparar o material de apoio.

## Procedimento

Siga as cinco etapas em ordem. Cada uma produz um artefato concreto. Não pule o mapeamento — sem ele, política e consentimento viram ficção.

### Etapa 1 — Mapear todo dado pessoal coletado no código

Objetivo: produzir um inventário (um "data map") de tudo que entra. Varra o repositório atrás de quatro fontes de coleta:

- **Formulários e inputs** — campos de e-mail, telefone/WhatsApp, nome, CPF, endereço, data de nascimento. Procure por `<input`, `name=`, `register(`, `useState`, validações (zod/yup), e os handlers de submit.
- **Banco de dados** — coleções/documentos Firestore (ou tabelas) que guardam dados de pessoas: `users`, `leads`, `subscribers`, `contacts`, `orders`. Veja o shape dos documentos gravados (`addDoc`, `setDoc`, `updateDoc`).
- **Analytics e métricas** — Google Analytics / GA4, Firebase Analytics, Hotjar, Clarity, Mixpanel. Esses coletam identificadores, comportamento, IP, device. Procure por `gtag`, `analytics`, `logEvent`, IDs de medição (`G-`).
- **Pixels e cookies de marketing** — Meta Pixel (`fbq`), Google Ads, TikTok Pixel, cookies próprios. Procure por `fbq(`, `fbevents`, `<Script` de terceiros, `document.cookie`, libs de cookie consent.

Use o guia em `scripts/mapear-dados.md` para os comandos de varredura. Para cada item encontrado, registre: **qual dado**, **onde é coletado** (arquivo/componente), **onde é armazenado** (coleção/serviço) e **se sai para terceiro**.

Saída desta etapa: uma tabela de inventário, por exemplo:

| Dado | Onde coleta | Onde armazena | Sai p/ terceiro? |
|------|-------------|---------------|------------------|
| E-mail | `components/NewsletterForm.tsx` | Firestore `subscribers` + Mailchimp | Sim (Mailchimp) |
| Nome | `app/cadastro/page.tsx` | Firestore `users` | Não |
| IP / comportamento | GA4 (`gtag`) | Google Analytics | Sim (Google) |
| Eventos de conversão | Meta Pixel (`fbq`) | Meta | Sim (Meta) |

### Etapa 2 — Para cada dado: finalidade, base legal e retenção

Para cada linha do inventário, responda três coisas. Consulte `reference/lgpd-fundamentos.md` para as definições.

- **Finalidade** — por que você precisa deste dado? Tem que ser específica e legítima. "Para o que der" não é finalidade. "Enviar a newsletter semanal" é.
- **Base legal** — qual das 10 bases do Art. 7º autoriza esse tratamento? As que mais aparecem em produto de software:
  - **Consentimento** — marketing, newsletter, cookies não essenciais, Pixel. Exige opt-in livre, informado e inequívoco; tem que poder revogar.
  - **Execução de contrato** — dados necessários para entregar o serviço que o usuário contratou (e-mail de login, dados de cobrança).
  - **Legítimo interesse** — usos esperados e de baixo risco (segurança, prevenção a fraude, analytics básico) — exige avaliação de proporcionalidade e nunca cobre dado sensível.
  - **Cumprimento de obrigação legal** — guardar nota fiscal, registros fiscais/contábeis.
  - **Atenção:** dado sensível (saúde, biometria, opinião política, religião, orientação sexual) tem regras mais estritas — em geral exige consentimento específico e destacado. Dado de criança/adolescente exige consentimento de um dos pais/responsável.
- **Retenção** — por quanto tempo você guarda? Defina um prazo por finalidade (ex.: lead não convertido por 12 meses; dados de cobrança pelo prazo fiscal/legal). Guardar "para sempre" é gap.

Saída: a tabela da Etapa 1 ganha três colunas — Finalidade, Base legal, Retenção.

### Etapa 3 — Apontar os gaps

Compare o estado atual com o devido. Use `reference/checklist-conformidade.md` como referência. Gaps típicos em produto Next.js + Firebase:

- Coleta sem base legal clara (ex.: Pixel disparando antes de qualquer consentimento).
- Consentimento sem versionamento (`consentVersion`) — impossível provar a que o usuário consentiu e quando.
- Pixel/Analytics carregando no primeiro load, antes do banner de cookies (consentimento prévio furado).
- Política de Privacidade ausente, desatualizada ou que não bate com o que o código faz.
- Terceiros (Mailchimp, GA, Meta) não listados na política e sem registro de que são operadores.
- Sem mecanismo de exclusão de conta / revogação de consentimento.
- Retenção indefinida (nada nunca é apagado).
- Regras do Firestore abertas demais (dado pessoal legível por quem não devia).
- Dados sensíveis ou de menores tratados sem o cuidado extra.

Saída: lista priorizada de gaps (crítico / importante / desejável), cada um com o arquivo/ponto onde aparece e a ação recomendada.

### Etapa 4 — Gerar/atualizar a Política de Privacidade e o aviso de consentimento

Com o inventário e os gaps em mãos, preencha os templates — eles não são genéricos, têm que refletir o data map real:

- **Política de Privacidade** — use `templates/politica-privacidade.md`. Preencha os placeholders com os dados reais do inventário: que dados, finalidades, bases legais, terceiros (cada operador nominalmente), retenção, e como exercer direitos. Inclua nome do controlador e canal de contato do encarregado/DPO.
- **Aviso de consentimento** — use `templates/aviso-consentimento.md`. Escolha o texto certo para cada ponto de coleta (newsletter, e-book, cookies/Pixel). Garanta opt-in ativo (nunca pré-marcado), linguagem clara e link para a política.
- **Versionamento** — toda caixa de consentimento deve gravar `consentVersion` + timestamp + escopo do que foi aceito. Se a política mudar materialmente, suba a versão e re-peça consentimento onde necessário. Implemente no padrão Firebase: grave o registro de consentimento junto ao documento do usuário/lead.

Saída: arquivos de Política e de avisos preenchidos, prontos para revisão e publicação, mais a recomendação de implementação do `consentVersion`.

### Etapa 5 — Checklist de direitos do titular

A LGPD dá ao titular direitos que o produto precisa conseguir atender. Confirme que há um caminho (mesmo manual, por e-mail, no início) para cada um:

- **Confirmação e acesso** — o titular pode saber se você trata os dados dele e obter uma cópia.
- **Correção** — pode corrigir dado incompleto/desatualizado (ex.: editar perfil).
- **Exclusão / eliminação** — pode pedir apagamento dos dados tratados por consentimento (ex.: botão "excluir conta" que remove o documento do Firestore e descadastra dos terceiros).
- **Portabilidade** — pode pedir exportação dos dados em formato legível (ex.: export JSON/CSV).
- **Revogação de consentimento** — pode retirar o consentimento com a mesma facilidade com que deu (ex.: link de descadastro, toggle de cookies, off de marketing).
- **Oposição e informação sobre compartilhamento** — pode se opor a tratamento e saber com quem os dados são compartilhados (já coberto pela política).

Saída: checklist com cada direito marcado como atendido / parcial / ausente, e a ação para fechar os pendentes. No mínimo, deixe um canal de contato do encarregado que responda a esses pedidos dentro do prazo.

## Arquivos de apoio

- `reference/lgpd-fundamentos.md` — conceitos essenciais (dado pessoal, sensível, titular, controlador, operador, bases legais, direitos, terceiros, retenção) aplicados a software.
- `reference/checklist-conformidade.md` — checklist prático de conformidade para app/landing.
- `templates/politica-privacidade.md` — modelo de Política de Privacidade preenchível.
- `templates/aviso-consentimento.md` — textos de consentimento prontos (newsletter, e-book, cookies/Pixel).
- `scripts/mapear-dados.md` — guia de varredura do código atrás de dados pessoais.

## Princípios de voz ao usar esta skill

- PT-BR, direto, sem hype. Diga o que está em conformidade e o que não está.
- Sempre que houver risco real, diga "valide com advogado" — sem encher linguiça.
- A decisão é do usuário. Você aponta o gap e a opção; ele escolhe o trade-off.
- Conformidade é engenharia de risco, não burocracia. Priorize o que reduz risco de verdade.
