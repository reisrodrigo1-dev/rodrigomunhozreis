# Avisos de consentimento — textos prontos

> Modelo da skill Salvaguarda. Use o texto certo para cada ponto de coleta.
> Regra inegociável: **opt-in ativo** (nada de caixa pré-marcada), linguagem clara, link para a política.
> **Não é parecer jurídico.** Para alto risco, valide com advogado.

---

## 1. Newsletter / lista de e-mails

Use quando o usuário se inscreve para receber conteúdo recorrente.

**Caixa de consentimento (opt-in, desmarcada por padrão):**

> ☐ Quero receber novidades, conteúdos e ofertas de {{NOME_DO_PRODUTO}} por e-mail. Sei que posso me descadastrar a qualquer momento e que meus dados são tratados conforme a [Política de Privacidade]({{URL_POLITICA}}).

**Microcopy abaixo do botão:**

> Ao se inscrever, você concorda com o tratamento do seu e-mail para envio das nossas comunicações. Você pode revogar a qualquer momento pelo link de descadastro em cada e-mail.

---

## 2. E-book / material rico (lead magnet)

Use quando há troca: o usuário dá os dados para receber um material.

**Caixa de consentimento (opt-in):**

> ☐ Concordo em receber o material solicitado e comunicações relacionadas de {{NOME_DO_PRODUTO}} no e-mail informado, conforme a [Política de Privacidade]({{URL_POLITICA}}).

**Microcopy:**

> Usamos seu e-mail para enviar o material e, eventualmente, conteúdos relacionados. Sem spam. Descadastro a um clique, a qualquer momento.

<!-- Se você separar "receber o material" de "receber marketing", use duas caixas distintas — é a forma mais robusta de consentimento específico. -->

---

## 3. Banner de cookies / Pixel / Analytics

Use no primeiro acesso. **Pixel e Analytics não essenciais só disparam DEPOIS do aceite.**

**Banner:**

> **Sua privacidade**
> Usamos cookies essenciais para o site funcionar e, com o seu consentimento, cookies de análise e de marketing (como {{EX_GOOGLE_ANALYTICS_E_META_PIXEL}}) para melhorar sua experiência e medir nossas campanhas. Você decide.
>
> [ Aceitar todos ]   [ Rejeitar não essenciais ]   [ Preferências ]   [ Política de Privacidade ]({{URL_POLITICA}})

**Tela de Preferências (granular):**

> - **Essenciais** (sempre ativos) — necessários para o site funcionar.
> - ☐ **Análise** — nos ajudam a entender o uso do site ({{EX_GA4}}).
> - ☐ **Marketing** — mensuração de anúncios ({{EX_META_PIXEL}}).
>
> [ Salvar preferências ]

**Regra de implementação:** rejeitar tem que ser tão fácil quanto aceitar (botão de mesmo peso visual). Não dispare scripts de marketing/análise antes do clique de aceite.

---

## 4. Cadastro / criação de conta

Aqui o tratamento essencial é base **execução de contrato** — não peça consentimento para o que é o serviço. Consentimento só para o que for marketing/opcional.

**Texto de aceite dos termos (obrigatório para usar o serviço):**

> Ao criar sua conta, você concorda com os [Termos de Uso]({{URL_TERMOS}}) e com a [Política de Privacidade]({{URL_POLITICA}}).

**Caixa opcional de marketing (separada, opt-in):**

> ☐ Quero receber novidades e ofertas por e-mail. (opcional)

---

## 5. WhatsApp / telefone

Quando você coleta WhatsApp para contato comercial.

**Caixa de consentimento (opt-in):**

> ☐ Autorizo o contato de {{NOME_DO_PRODUTO}} pelo WhatsApp/telefone informado para {{EX_ATENDIMENTO_E_OFERTAS}}, conforme a [Política de Privacidade]({{URL_POLITICA}}).

---

## Registro do consentimento (consentVersion)

Sempre que o usuário consentir, **grave o registro** para conseguir comprovar depois. Estrutura recomendada (padrão Firebase):

```json
{
  "consent": {
    "version": "v1.0",
    "timestamp": "2026-06-15T14:32:00Z",
    "scopes": ["newsletter", "cookies_marketing"],
    "source": "landing_home",
    "ipHash": "{{opcional}}"
  }
}
```

Regras:
- `version` deve bater com a **versão da Política de Privacidade** vigente no momento.
- Grave junto ao documento do usuário/lead no Firestore.
- Se a política mudar materialmente, suba a versão e re-peça consentimento onde a mudança afetar a base do tratamento.
- Na revogação, registre também o evento de revogação (não apague o histórico de consentimento — ele é sua prova).

---

## O que NÃO fazer

- ❌ Caixa pré-marcada (consentimento não vale).
- ❌ Pixel/Analytics disparando no primeiro load, antes do aceite.
- ❌ "Ao continuar navegando você aceita os cookies" (não é consentimento válido).
- ❌ Botão "Aceitar" gigante e "Rejeitar" escondido (não é livre).
- ❌ Pedir consentimento para o que já é execução de contrato (atrapalha e é errado).
- ❌ Consentir sem link para a política.
