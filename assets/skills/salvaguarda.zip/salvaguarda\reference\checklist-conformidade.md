# Checklist de conformidade LGPD — app / landing page

> Material de apoio da skill Salvaguarda. Marque cada item como ✅ feito / ⚠️ parcial / ❌ ausente.
> **Não é parecer jurídico.** Itens marcados com 🔴 são os que mais geram risco — priorize.

Pensado para o stack Next.js + Firebase, mas o conteúdo vale para qualquer produto.

---

## 1. Mapeamento (você sabe o que coleta?)

- [ ] Existe um inventário (data map) de todo dado pessoal coletado.
- [ ] Cada formulário do produto está mapeado (campos, arquivo).
- [ ] Cada coleção do Firestore com dado pessoal está mapeada.
- [ ] Analytics (GA4 / Firebase Analytics) está identificado como coleta de dado pessoal.
- [ ] Pixels (Meta `fbq`, Google Ads, TikTok) estão identificados.
- [ ] Cookies próprios e de terceiros estão listados.
- [ ] 🔴 Você sabe **com quais terceiros** cada dado é compartilhado.

## 2. Base legal e finalidade

- [ ] 🔴 Cada dado coletado tem uma **finalidade específica** declarada.
- [ ] 🔴 Cada tratamento tem uma **base legal** definida (Art. 7º).
- [ ] Você não coleta dado que não usa (minimização — sem CPF "por garantia").
- [ ] Marketing/newsletter/Pixel estão sob **consentimento**, não outra base.
- [ ] Dados do serviço em si estão sob **execução de contrato**, não consentimento.
- [ ] Não há dado **sensível** sendo tratado sem o cuidado reforçado (se houver, advogado).
- [ ] Não há dado de **menor** sem consentimento de responsável (se aplicável).

## 3. Consentimento

- [ ] 🔴 Existe caixa de consentimento com **opt-in ativo** (nada pré-marcado).
- [ ] O texto do consentimento é claro e específico por finalidade.
- [ ] Há link para a Política de Privacidade no ponto de consentimento.
- [ ] 🔴 O consentimento grava **`consentVersion` + timestamp + escopo**.
- [ ] 🔴 Pixel/Analytics não essenciais **só disparam após** o consentimento (não no primeiro load).
- [ ] Banner de cookies permite **recusar** tão fácil quanto aceitar.
- [ ] Há um plano para **re-pedir consentimento** quando a política mudar materialmente.

## 4. Política de Privacidade

- [ ] 🔴 Existe uma Política de Privacidade publicada e acessível (rodapé + checkout/cadastro).
- [ ] Ela informa o **controlador** (razão social / responsável) e o **contato do encarregado**.
- [ ] Lista **quais dados** são coletados.
- [ ] Lista **finalidades** e **bases legais**.
- [ ] Lista os **terceiros/operadores** (Mailchimp, Google, Meta, Firebase, gateway...).
- [ ] Declara **transferência internacional**, se houver.
- [ ] Informa **prazos de retenção**.
- [ ] Explica **como o titular exerce os direitos**.
- [ ] 🔴 O que está escrito **bate com o que o código realmente faz** (sem ficção).
- [ ] Tem **data da última atualização** / versão.

## 5. Direitos do titular

- [ ] Há um **canal** (e-mail do encarregado) que recebe pedidos de titulares.
- [ ] **Acesso** — o titular consegue obter cópia dos dados.
- [ ] **Correção** — o titular consegue editar seus dados (ex.: perfil).
- [ ] 🔴 **Exclusão** — existe forma de excluir conta/dados (e descadastrar dos terceiros).
- [ ] **Portabilidade** — existe forma de exportar os dados (JSON/CSV).
- [ ] 🔴 **Revogação** — descadastro de e-mail / off de marketing / toggle de cookies funciona.
- [ ] Os pedidos são atendidos dentro do prazo (confirmação/acesso em até 15 dias).

## 6. Segurança e terceiros

- [ ] 🔴 **Regras do Firestore** restringem acesso (cada um lê só o que é dele; dado pessoal não é público).
- [ ] Secrets/keys estão em variáveis de ambiente, fora do repositório.
- [ ] Tudo trafega por **HTTPS**.
- [ ] Acesso ao console Firebase/admin é mínimo e protegido (2FA).
- [ ] Os principais operadores têm **DPA** aceito (Google, Meta, gateway, e-mail).
- [ ] Existe noção de **o que fazer em caso de incidente** (e de que isso aciona advogado).

---

## Priorização sugerida

1. **Crítico (🔴) primeiro** — fechar esses itens reduz a maior parte do risco real.
2. Política de Privacidade publicada e coerente com o código.
3. Consentimento com `consentVersion` e Pixel disparando só após aceite.
4. Caminho de exclusão/revogação para o titular.
5. Retenção e DPAs — importante, menos urgente.

## Quando parar e chamar advogado

- Tratamento de **dado sensível** em escala (saúde, biometria, orientação sexual, etc.).
- Dados de **crianças/adolescentes** como público central.
- **Decisão automatizada** com efeito jurídico relevante sobre a pessoa.
- **Incidente de segurança / vazamento** — aja imediatamente.
- **Notificação da ANPD** ou disputa com titular.
- Transferência internacional de dado sensível em volume.
