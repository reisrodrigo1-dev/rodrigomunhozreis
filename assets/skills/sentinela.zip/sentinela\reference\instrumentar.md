# Instrumentar — como capturar o sinal

Vigiar (`o-que-vigiar.md`) é decidir o que importa. **Instrumentar** é fazer o sistema te
contar. Sem instrumentação, todo erro acontece longe dos seus olhos — na máquina do
usuário, no log que ninguém lê, na função que morreu calada. Este guia mostra como
capturar erro no Next.js, ler logs na Vercel, monitorar o Firebase e o que uma ferramenta
de erro (tipo Sentry) resolve que o resto não resolve.

Regra que atravessa tudo aqui: **capturar não é esconder.** Um `catch` que engole o erro
sem logar é pior que o erro — apaga a evidência. E **nunca logue segredo ou dado pessoal**
(regra do Bastião, detalhada em `regras-de-log.md`).

---

## 1. Capturar erro no Next.js (App Router)

### `error.tsx` — o error boundary de rota

No App Router, um arquivo `error.tsx` numa pasta de rota vira um **error boundary**: se o
componente daquele segmento estourar na renderização, o Next mostra esse fallback em vez
de tela branca. É a diferença entre "deu ruim, tente de novo" e o usuário olhando pro nada.

```tsx
// app/dashboard/error.tsx
'use client'; // error boundaries são sempre client components

import { useEffect } from 'react';

export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void; // tenta re-renderizar o segmento
}) {
  useEffect(() => {
    // logue/reporte. NÃO logue dado sensível que possa estar no error.
    console.error('Erro no dashboard:', error.message, { digest: error.digest });
    // se usar Sentry: Sentry.captureException(error);
  }, [error]);

  return (
    <div role="alert">
      <h2>Algo deu errado aqui.</h2>
      <button onClick={() => reset()}>Tentar de novo</button>
    </div>
  );
}
```

Coloque um `error.tsx` em cada área crítica (`/checkout`, `/dashboard`), não só na raiz —
assim um erro no checkout não derruba o app inteiro.

### `global-error.tsx` — a última rede

`error.tsx` não pega erro do **layout raiz**. Pra isso existe o `global-error.tsx`, que
substitui o `<html>`/`<body>` inteiro quando até o layout raiz falha. É a última rede de
segurança — funciona só em produção.

```tsx
// app/global-error.tsx
'use client';

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <html lang="pt-BR">
      <body>
        <h2>O aplicativo encontrou um erro.</h2>
        <button onClick={() => reset()}>Recarregar</button>
      </body>
    </html>
  );
}
```

### `try/catch` em Route Handlers e Server Actions

Error boundary pega erro de **renderização**. A lógica de servidor — rotas de API, Server
Actions — precisa do seu próprio `try/catch` em toda fronteira que toca rede, banco ou IA.

```tsx
// app/api/pedido/route.ts
import { NextResponse } from 'next/server';
import { logger } from '@/lib/logger'; // ver regras-de-log.md

export async function POST(req: Request) {
  const requestId = crypto.randomUUID();
  try {
    const body = await req.json();
    const pedido = await criarPedido(body); // pode estourar
    logger.info('pedido_criado', { requestId, pedidoId: pedido.id });
    return NextResponse.json({ ok: true, pedidoId: pedido.id });
  } catch (err) {
    // loga o erro com contexto — NÃO loga o body inteiro (pode ter PII)
    logger.error('falha_criar_pedido', {
      requestId,
      message: err instanceof Error ? err.message : String(err),
    });
    // resposta tratada, sem vazar stack pro cliente
    return NextResponse.json(
      { ok: false, error: 'Não foi possível criar o pedido.' },
      { status: 500 }
    );
  }
}
```

```tsx
// app/actions.ts — Server Action
'use server';
import { logger } from '@/lib/logger';

export async function salvarPerfil(dados: FormData) {
  try {
    await db.perfil.update(/* ... */);
    return { ok: true };
  } catch (err) {
    logger.error('falha_salvar_perfil', {
      message: err instanceof Error ? err.message : String(err),
    });
    return { ok: false, error: 'Não foi possível salvar. Tente de novo.' };
  }
}
```

**Padrão a seguir em toda fronteira:** `try/catch` → logar com contexto → devolver resposta
tratada (nunca vazar stack trace nem mensagem interna pro cliente).

---

## 2. Logs na Vercel

A Vercel captura automaticamente tudo que vai pra `stdout`/`stderr` — ou seja, todo
`console.log`/`console.error` das suas funções e do build.

- **Onde ver:** dashboard do projeto → aba **Logs** (runtime logs das funções) e
  **Deployments → Logs** (build). Dá pra filtrar por rota, status code e nível.
- **Logs em tempo real no terminal:** `vercel logs <url-do-deployment>` segue o fluxo ao vivo.
- **Limite importante:** os runtime logs da Vercel são **efêmeros** — ficam por um período
  curto (horas a poucos dias, dependendo do plano). **Não são seu sistema de auditoria.**
  Pra reter de verdade, use **Log Drains** mandando pra um destino externo (Better Stack,
  Datadog, etc.) ou uma ferramenta de erro dedicada.
- **Estruture o log** (JSON — ver `regras-de-log.md`). A Vercel parseia JSON e deixa
  filtrável por campo, em vez de string que você lê no olho.

Resumo: a Vercel é ótima pra **ver agora o que está acontecendo**, fraca pra **investigar o
que aconteceu semana passada**. Pra isso, drene pra fora.

---

## 3. Monitorar o Firebase

O Firebase tem várias frentes pra vigiar, cada uma num canto:

- **Firestore — uso e custo:** o billing é por **operação** (leitura, escrita, exclusão).
  O vilão clássico é o `.get()` numa coleção grande dentro de um loop, ou uma query sem
  filtro. Acompanhe **reads/writes** no painel de uso e configure **billing alert no
  GCP/Firebase** (orçamento com aviso por e-mail). É a defesa mais barata contra a fatura
  surpresa (dimensão Custo).
- **Cloud Functions:** têm logs no **Cloud Logging** (console do Firebase → Functions →
  Logs). Use `functions.logger` (não `console.log`) — ele já loga estruturado com
  severidade, integrando com os filtros e alertas do Cloud Logging.
  ```js
  const { logger } = require('firebase-functions/v2');
  logger.error('falha_processar', { jobId, message: err.message });
  ```
- **Auth:** acompanhe falhas de login e picos de tentativa (dimensão Segurança). Os
  eventos aparecem no Cloud Logging.
- **Crashlytics:** se houver app mobile (Flutter/React Native), é o equivalente do Sentry
  pra crashes de app — agrupa, prioriza e alerta.
- **Performance Monitoring:** SDK do Firebase que mede latência de telas e requests no
  cliente (dimensão Performance).
- **Alertas:** o Cloud Monitoring permite criar **alerting policies** (ex.: "erros de
  função > X em 5 min" → e-mail/Slack).

**Regra de ouro do Firebase:** as **Security Rules** (auditadas pela skill **Cofre**) são
a sua primeira linha. Monitorar não substitui fechar as regras — vigiar uma porta aberta
só te avisa depois que entraram.

---

## 4. O que uma ferramenta de erro (tipo Sentry) resolve

`error.tsx` + `try/catch` + logs da Vercel já te dão muito. Mas há um buraco que eles não
fecham sozinhos: o **erro não tratado, na máquina do usuário, que você nunca vai ver** —
porque não estourou no servidor e ninguém te mandou o `console`.

Uma ferramenta de erro dedicada (Sentry e similares: Highlight, Bugsnag, Rollbar) resolve:

- **Captura automática** de exceções não tratadas — front (browser) e back (server),
  sem você espalhar `try/catch` em tudo.
- **Agrupamento inteligente:** 10.000 ocorrências do mesmo bug viram **um** issue com
  contador, não 10.000 linhas de log.
- **Contexto rico:** stack trace com **source maps** (o erro no código original, não no
  bundle minificado), rota, navegador, release, breadcrumbs (o que o usuário fez antes).
- **Alerta integrado:** dispara quando surge erro novo ou quando a taxa de um erro sobe —
  alimenta direto a dimensão Erros e o passo 4 (alertas) do procedimento.
- **Performance/tracing:** muitas medem latência e mostram qual parte da request foi lenta
  (dimensão Performance) na mesma ferramenta.

No Next.js, instala com um SDK (`@sentry/nextjs`) que se conecta sozinho ao App Router,
gera source maps no build e captura cliente + servidor. Custo: tem plano grátis generoso —
pra um produto novo, raramente é o que pesa na conta.

**Quando vale:** assim que há usuário real que não é você. O `console.error` te conta o
que aconteceu **no seu servidor**; a ferramenta de erro te conta o que aconteceu **na tela
do cliente** — que é onde a maioria dos bugs de front mora. A decisão é sua, mas o buraco
que ela fecha é justamente o mais difícil de enxergar de outro jeito.

---

## Checklist de instrumentação

- [ ] `error.tsx` nas áreas críticas (`/checkout`, `/dashboard`) e `global-error.tsx` na raiz.
- [ ] `try/catch` em toda Route Handler e Server Action que toca rede/banco/IA — logando, não engolindo.
- [ ] Resposta de erro tratada pro cliente (sem stack trace, sem mensagem interna).
- [ ] Logs estruturados (JSON) indo pro `stdout`/`stderr` (Vercel) e/ou drenados pra fora.
- [ ] Billing alert configurado no Firebase/GCP e na Vercel (defesa de custo).
- [ ] `functions.logger` nas Cloud Functions (não `console.log`).
- [ ] Ferramenta de erro (Sentry-like) instalada assim que houver usuário real.
- [ ] Nada de segredo ou dado pessoal nos logs (ver `regras-de-log.md`).
