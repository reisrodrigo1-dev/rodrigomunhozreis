---
name: sentinela
description: monta observabilidade — logs, captura de erros e alertas pra saber quando algo quebra em produção; use ao colocar algo no ar ou ao investigar saúde do sistema.
---

# Sentinela

> Depois do deploy, o trabalho não acabou. É preciso vigiar.
>
> — Rodrigo Munhoz Reis, *vibecoding com engenharia*

## Visão geral

Subir pra produção é o começo, não o fim. No momento em que usuários reais entram, o
sistema começa a falhar de jeitos que você não previu: uma rota que estoura sob carga,
um custo de IA que dispara, um erro silencioso que come 5% das conversões sem ninguém
perceber. **Sentinela** é a disciplina de enxergar isso — instrumentar o sistema pra
que ele te conte o que está acontecendo, e te avise quando algo quebra, **antes** do
cliente reclamar (ou pior, sumir).

Observabilidade não é "instalar uma ferramenta". É decidir **o que importa vigiar**,
**capturar o sinal** (erro, latência, custo), **logar com critério** (sem vazar segredo)
e **ser avisado** só quando vale acordar você. Esta skill cobre os cinco passos, com
foco na stack Next.js + Firebase + Vercel.

Sentinela faz parte da suíte **Engenho**, ao lado de:
- **Bastião** — segurança. Regra dele que vale aqui: **nunca logar segredo nem dado
  pessoal.** Log é superfície de vazamento. Respeite isso em cada `console.log`.
- **Lupa** — depuração. Quando o alerta dispara, Lupa entra pra investigar a causa.
- **Termômetro** — custo. Vigiar custo (passo 1) conversa direto com o que Termômetro estima.
- **Resgate** — incidente. Quando o alerta vira fogo, Resgate ajuda a apagar e fazer o post-mortem.

A decisão é sua. Sentinela mostra o que vigiar e como; o quanto investir nisso depende
do seu estágio.

## Quando usar

Use Sentinela quando:
- Vai **colocar algo no ar** (primeiro deploy ou nova feature crítica) e quer saber se
  vai quebrar antes do usuário.
- O sistema **já está em produção sem instrumentação** ("tá no ar, mas não sei se tá de pé").
- Quer **investigar a saúde** de um sistema: está lento? caro? caindo? convertendo?
- Um usuário relatou um erro que você **não consegue reproduzir** — falta visibilidade.
- A conta da Vercel/Firebase/OpenAI **veio mais alta** e você não sabe de onde.

Não precisa de Sentinela pra um protótipo local que só você usa. A vigilância importa
quando há **alguém do outro lado** dependendo do sistema.

## Procedimento

### 1. Decidir o que importa vigiar

Não dá pra vigiar tudo, e tentar isso gera ruído que você vai aprender a ignorar.
Escolha as dimensões que, **se quebrarem, machucam o negócio**. As seis dimensões e o
sinal de alerta de cada estão em `reference/o-que-vigiar.md`. Em resumo:

| Dimensão | Pergunta | Sinal de alerta típico |
|---|---|---|
| **Erros** | O código está estourando? | Taxa de erro acima do normal, erro novo nunca visto |
| **Performance** | Está rápido o suficiente? | Latência p95 alta, função perto do timeout |
| **Custo** | A conta vai explodir? | Gasto diário acima do teto, pico de chamadas de IA |
| **Uptime** | Está no ar? | Health check falhando, página fora |
| **Segurança** | Tem alguém forçando? | Pico de 401/403, brute force no login |
| **Negócio** | Está cumprindo o propósito? | Conversão caiu, fluxo crítico parou |

**Comece pequeno.** Para um produto novo: **erros + uptime + custo**. Eles pegam 80% das
dores com 20% do esforço. As outras dimensões entram conforme o produto cresce.

Defina, para cada dimensão escolhida, o que é "normal" — sem linha de base você não
sabe o que é alerta.

### 2. Instrumentar a captura de erro

Um erro que ninguém captura é um erro que não existe — até o cliente te contar. O guia
completo (com código para Next.js, Vercel e Firebase) está em `reference/instrumentar.md`.
O essencial:

- **Error boundary no React** — `error.tsx` em rotas do App Router pega erros de
  renderização e mostra um fallback em vez de tela branca. `global-error.tsx` pega o
  que escapa do layout raiz.
- **`try/catch` em rotas e Server Actions** — toda fronteira que toca rede, banco ou IA
  precisa de `try/catch` que **loga o erro** (não só engole) e devolve resposta tratada.
- **Ferramenta de erro (tipo Sentry)** — captura automaticamente exceções não tratadas,
  agrupa por tipo, mostra stack trace + contexto e dispara alerta. Resolve o problema de
  "o erro aconteceu na máquina do usuário e eu nunca vou ver".

Regra: **capturar é diferente de esconder.** Um `catch` vazio que não loga nada é pior
que o erro original — ele apaga a evidência.

### 3. Logar com critério

Log demais vira ruído; log de menos te deixa cego; log errado vaza dado. As regras
completas estão em `reference/regras-de-log.md`. Os pilares:

- **Níveis:** `error` (quebrou, precisa de ação), `warn` (suspeito, ainda funcionou),
  `info` (evento de negócio relevante). Em produção, descarte `debug`.
- **NUNCA logar:** senha, token, chave de API, segredo, dado pessoal sensível (CPF,
  cartão), corpo inteiro de request com PII. Isso é regra do **Bastião** — log é texto
  que vai parar em sistemas de terceiros e fica retido. Tratar como dado público.
- **Log estruturado:** JSON com campos (`level`, `message`, `requestId`, `userId` quando
  permitido, `duration`) — não string solta. Estruturado é filtrável, buscável e alertável.

### 4. Configurar alertas

Logar sem alerta é só guardar evidência pra depois. Alerta é o que transforma vigilância
passiva em ação. Defina, para cada dimensão do passo 1:

- **Condição** — o que dispara (ex.: "taxa de erro > 1% por 5 min", "custo diário > R$ X",
  "health check falhou 3x seguidas").
- **Canal** — onde te avisa. Comece simples: e-mail para o que pode esperar, push/Slack/
  WhatsApp para o que é urgente. Não misture os dois — urgente que chega por e-mail é
  ignorado; rotina que chega por push vira fadiga de alerta.
- **Severidade** — nem todo alerta merece acordar você às 3h. Separe **P1** (cliente
  impactado agora, acorda) de **P2/P3** (vê amanhã).
- **Quem age** — se é só você, ok. Se é time, defina quem responde a quê.

**Cuidado com fadiga de alerta:** se tudo é urgente, nada é. Alerta que dispara toda
hora e nunca exige ação você vai silenciar — e aí ele não te avisa quando importa.
Ajuste os limiares até que **um alerta = uma ação real**.

### 5. Revisar periodicamente

Observabilidade apodrece. Limiar calibrado pra 100 usuários mente com 10.000. Métrica
que importava no lançamento virou ruído depois do pivô. Revise:

- **Semanal (5 min):** algum alerta disparou? Foi real? O que aprendi?
- **Mensal:** algum alerta nunca disparou (excesso) ou disparou demais (fadiga)? Recalibre.
- **A cada mudança grande de escala/feature:** as dimensões do passo 1 ainda são as certas?
- **Pós-incidente:** todo incidente que te pegou de surpresa vira um alerta novo. Se o
  cliente avisou antes do seu sistema, faltou um sentinela ali. (Aqui **Resgate** entra
  com o post-mortem.)

A meta não é dashboard bonito. É **descobrir que algo quebrou antes do seu cliente** — e
saber o suficiente pra consertar rápido.

## Referências

- `reference/o-que-vigiar.md` — as seis dimensões e o sinal de alerta de cada.
- `reference/instrumentar.md` — captura de erro no Next.js, logs na Vercel, monitoramento
  do Firebase, e o que uma ferramenta tipo Sentry resolve.
- `reference/regras-de-log.md` — níveis, o que logar x o que jamais logar, log estruturado.
