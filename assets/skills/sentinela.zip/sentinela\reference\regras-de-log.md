# Regras de log — logar com critério

Log é uma faca de dois gumes. Bem feito, é a primeira coisa que você olha quando algo
quebra. Mal feito, é ruído que esconde o sinal — ou pior, uma **superfície de vazamento**:
texto que sai do seu sistema, vai parar em ferramentas de terceiros (Vercel, Datadog,
Sentry) e fica **retido** lá. Tudo que você loga, trate como se fosse público.

Este documento define três coisas: os **níveis** de log, **o que logar x o que jamais
logar**, e como fazer **log estruturado**.

---

## 1. Níveis de log

Nível é a primeira ferramenta contra ruído. Ele responde "isso exige minha atenção?".
Use poucos e com disciplina:

| Nível | Quando usar | Exige ação? |
|---|---|---|
| **`error`** | Algo quebrou. Uma operação falhou e o usuário ou o sistema foi afetado. | **Sim** — é candidato a alerta (passo 4). |
| **`warn`** | Algo suspeito, mas funcionou. Recuperou de um retry, payload estranho, depreciação, limite chegando perto. | Talvez — vigie se vira padrão. |
| **`info`** | Evento de negócio relevante: pedido criado, usuário cadastrado, pagamento confirmado. | Não — é o diário do sistema. |
| **`debug`** | Detalhe de desenvolvimento pra entender o fluxo. | Não — **descarte em produção.** |

**Regras de nível:**
- **`error` é o que vira alerta.** Se você loga como `error` algo que não exige ação, vai
  treinar a si mesmo (e ao time) a ignorar `error`. Aí, quando o `error` de verdade chegar,
  ninguém olha. Seja rígido: `error` = quebrou, precisa de alguém.
- **`debug` não vai pra produção.** Controle por variável de ambiente
  (`LOG_LEVEL=info` em prod, `debug` em dev). Debug em prod é custo, ruído e risco de vazar
  dado que você imprimiu "só pra ver".
- **`info` é o seu diário** — os eventos que contam a história do sistema. É o que alimenta
  a dimensão Negócio (`o-que-vigiar.md`). Logue eventos, não cada passo.

---

## 2. O que logar x o que JAMAIS logar

Esta é a parte mais importante e a mais ignorada. **É regra do Bastião** (a skill irmã de
segurança), e não é negociável: **log nunca contém segredo nem dado pessoal.**

### O que logar (com critério)
- **Identificadores não-sensíveis:** `requestId`, `pedidoId`, `userId` (o ID interno, não
  o e-mail/CPF), `traceId`. Permitem rastrear sem expor a pessoa.
- **Eventos e seu desfecho:** `"pedido_criado"`, `"login_falhou"`, `"pagamento_recusado"`.
- **Metadados úteis:** rota, método HTTP, status code, `duration` (ms), nome da função.
- **Mensagem de erro e tipo** — `err.message`, `err.name`. Stack trace em sistema de erro
  dedicado, não cuspido em log aberto.

### O que JAMAIS logar
- **Senhas** — em texto ou hash. Nunca passam perto de um log.
- **Tokens e chaves:** JWT, token de sessão, API keys (OpenAI, Stripe, Firebase),
  refresh tokens, secrets de `.env`.
- **Dados pessoais sensíveis:** CPF, RG, número de cartão, CVV, dados de saúde — proibido
  por LGPD e por bom senso. (A skill **Salvaguarda** cobre a parte de conformidade.)
- **Dados pessoais comuns sem necessidade:** e-mail, telefone, endereço, nome completo.
  Se precisar correlacionar a um usuário, logue o **ID interno**, não o dado pessoal.
- **Corpo inteiro de request/response** — é o jeito mais fácil de vazar tudo acima de uma
  vez. Logue os campos que você escolheu, nunca o objeto cru.
- **Cookies e headers de Authorization.**

### O perigo do "logar o objeto inteiro"

O erro mais comum, e o mais perigoso:

```ts
// PERIGOSO — vaza tudo: senha, token, PII, o que vier no body
logger.info('request recebido', { body: req.body });
logger.error('falha no login', { user }); // 'user' pode ter hash de senha, e-mail, token

// CERTO — você escolhe explicitamente o que sai
logger.info('request_recebido', { rota: '/api/login', requestId });
logger.error('login_falhou', { requestId, userId: user.id, motivo: 'senha_invalida' });
```

**Regra prática:** nunca passe um objeto inteiro pro log. Liste os campos, um por um. Se
você não consegue afirmar que **cada** campo é seguro, não loga o objeto.

### Redação como rede de segurança
Adicione uma camada que **mascara** campos sensíveis por nome (`password`, `token`,
`authorization`, `cpf`, `card`, `secret`, `apiKey`) antes de qualquer coisa ir pro
transporte de log. É a rede pra quando alguém esquecer a regra acima — mas é rede, não
substituto: continue escolhendo os campos na mão.

---

## 3. Log estruturado

Logue **JSON com campos**, não string solta. A diferença é o que você consegue fazer
depois:

```ts
// String solta — bonita de ler, impossível de filtrar/alertar:
console.log(`Pedido ${id} do usuário ${userId} falhou: ${err.message}`);

// Estruturado — filtrável, buscável, alertável por campo:
logger.error('pedido_falhou', {
  pedidoId: id,
  userId,            // ID interno, nunca e-mail/CPF
  message: err.message,
  duration: 320,
  requestId,
});
```

**Por que estruturado ganha:**
- **Filtrável:** "me mostra todo `pedido_falhou` do `userId` X nas últimas 24h" vira uma
  query, não uma leitura no olho. Vercel, Cloud Logging, Datadog e Sentry todos parseiam JSON.
- **Alertável:** alerta do passo 4 dispara em cima de um campo (`level: error` +
  `event: pagamento_recusado` > N) — impossível com string livre.
- **Correlacionável:** o `requestId`/`traceId` costura todos os logs de uma mesma requisição.
  Quando o cliente diz "deu erro às 14h32", você pega o ID e segue o rastro inteiro.

### Campos mínimos recomendados
| Campo | Pra quê |
|---|---|
| `level` | `error` / `warn` / `info` — filtro e alerta |
| `event` | nome curto do evento (`pedido_criado`) — agrupamento |
| `message` | descrição legível (ou `err.message`) |
| `requestId` / `traceId` | correlacionar logs da mesma request |
| `userId` | quem (ID interno, **nunca** PII) |
| `duration` | ms da operação — alimenta a dimensão Performance |
| `timestamp` | quando (a maioria das libs põe automático) |

### Como fazer no Next.js
Pode ser tão simples quanto um wrapper sobre `console`, ou uma lib leve (Pino) pra
produção. O essencial é centralizar num módulo (`lib/logger.ts`) pra que a redação e o
formato JSON valham pra todo mundo:

```ts
// lib/logger.ts — esqueleto
const SENSIVEIS = ['password', 'senha', 'token', 'authorization', 'cpf', 'card', 'secret', 'apiKey'];

function redigir(meta: Record<string, unknown>) {
  const out: Record<string, unknown> = {};
  for (const [k, v] of Object.entries(meta)) {
    out[k] = SENSIVEIS.some((s) => k.toLowerCase().includes(s)) ? '[REDACTED]' : v;
  }
  return out;
}

function log(level: 'error' | 'warn' | 'info', event: string, meta: Record<string, unknown> = {}) {
  if (level === 'info' && process.env.LOG_LEVEL === 'error') return;
  console[level](JSON.stringify({ level, event, ...redigir(meta), ts: new Date().toISOString() }));
}

export const logger = {
  error: (event: string, meta?: Record<string, unknown>) => log('error', event, meta),
  warn: (event: string, meta?: Record<string, unknown>) => log('warn', event, meta),
  info: (event: string, meta?: Record<string, unknown>) => log('info', event, meta),
};
```

Esse `logger` é o que aparece nos exemplos de `instrumentar.md`. Centralizado, ele garante
que **toda** linha de log saia estruturada e passe pela redação.

---

## Checklist de log

- [ ] Níveis usados com disciplina — `error` só pra o que exige ação.
- [ ] `debug` desligado em produção (`LOG_LEVEL`).
- [ ] Nenhuma senha, token, chave ou segredo logado — em lugar nenhum.
- [ ] Nenhum dado pessoal (e-mail, CPF, cartão) — só ID interno.
- [ ] Nunca logar objeto/`body` inteiro — campos escolhidos um a um.
- [ ] Camada de redação por nome de campo como rede de segurança.
- [ ] Log estruturado em JSON, com `requestId` pra correlacionar.
- [ ] Logger centralizado num módulo único.
