# O que vigiar — as seis dimensões

Você não consegue vigiar tudo, e não deveria tentar. Vigilância demais vira ruído, e
ruído você aprende a ignorar — até o dia em que o alerta importante se perde no meio.
Este documento lista as seis dimensões que cobrem praticamente toda dor de produção, com
o **sinal de alerta** de cada: o que olhar, o que é "normal", e o que dispara ação.

Para um produto novo, comece por **três**: Erros, Uptime e Custo. As outras entram
conforme o produto e o time crescem.

---

## 1. Erros

**Pergunta:** o código está estourando para os usuários?

É a dimensão mais óbvia e a mais negligenciada — porque a maioria dos erros acontece na
máquina do usuário, longe dos seus olhos. Sem captura (ver `instrumentar.md`), você só
descobre quando alguém reclama. E a maioria não reclama: vai embora.

**O que medir:**
- **Taxa de erro** — % de requests/sessões que resultam em erro. Tenha uma linha de base.
- **Erros novos** — um tipo de erro que nunca apareceu antes é mais urgente que um
  conhecido. Deploy recente + erro novo = quase sempre o deploy.
- **Volume por erro** — 1 usuário afetado vs. 10.000 muda tudo na prioridade.

**Sinal de alerta:**
- Taxa de erro sobe acima do normal (ex.: de 0,2% para 2%).
- Surge um erro **novo** logo após um deploy.
- Um erro conhecido **dispara em volume** (de 5/dia para 500/hora).

**Onde:** ferramenta tipo Sentry (agrupa e alerta automaticamente), logs da Vercel,
Crashlytics se houver app mobile.

---

## 2. Performance (latência)

**Pergunta:** está rápido o suficiente pra não perder usuário?

Lentidão não estoura erro — ela só faz o usuário desistir. E na Vercel/serverless,
latência alta também é **custo** (tempo de execução) e risco de **timeout** (a função
morre no meio).

**O que medir:**
- **Latência p95 / p99**, não a média. A média esconde a cauda; o p95 conta o que 1 em
  20 usuários sente. É lá que mora a dor.
- **Tempo das rotas/ações críticas** — login, checkout, a chamada de IA.
- **Proximidade do timeout** — função que roda 8s num limite de 10s é uma bomba-relógio.
- **Core Web Vitals** (LCP, INP) pro front, se conversão importa.

**Sinal de alerta:**
- p95 de uma rota crítica ultrapassa o limite que você definiu (ex.: > 2s).
- Funções chegando perto do timeout configurado.
- Degradação gradual ao longo de dias (vazamento, tabela crescendo sem índice).

**Onde:** Vercel Analytics / Speed Insights, logs com `duration` (ver `regras-de-log.md`),
métricas de query do Firestore.

---

## 3. Custo

**Pergunta:** a conta vai explodir antes de eu perceber?

Na stack serverless + IA, o custo é **variável e silencioso**. Um loop que chama a API da
OpenAI, um job que lê o Firestore inteiro, um bot que martela um endpoint — nada disso dá
erro. Só aparece na fatura, no fim do mês, quando já gastou. Esta é a dimensão que
conversa direto com a skill **Termômetro**.

**O que medir:**
- **Gasto diário** por provedor (Vercel, Firebase, OpenAI/Anthropic) — diário, não mensal.
  Mensal você descobre tarde demais.
- **Volume de chamadas de IA** e tokens — o vilão de custo número um em apps com IA.
- **Leituras/escritas no Firestore** — cobrança por operação; um `.get()` numa coleção
  grande dentro de um loop é fácil de escrever e caro de rodar.
- **Invocações e tempo de função** na Vercel.

**Sinal de alerta:**
- Gasto diário acima do teto que você definiu.
- Pico súbito de chamadas de IA ou de reads no Firestore sem aumento equivalente de
  usuários — quase sempre bug ou abuso.
- Tendência de alta consistente que projeta estourar o orçamento no fim do mês.

**Onde:** billing alerts do Firebase/GCP (configure um teto!), dashboard de custo da
Vercel, painel de uso da OpenAI/Anthropic. **Configure orçamento com alerta** em cada
provedor — é a defesa mais barata que existe.

---

## 4. Uptime

**Pergunta:** o sistema está no ar agora?

A pergunta mais básica, e a que dá mais vergonha errar: descobrir pelo cliente que o site
está fora há duas horas. Uptime é barato de monitorar e não tem desculpa pra não ter.

**O que medir:**
- **Disponibilidade** de uma URL de health check — um endpoint simples (`/api/health`) que
  responde 200 se o essencial (app + banco) está de pé.
- **Dependências externas** — se você depende do Firebase, da OpenAI, de um gateway de
  pagamento, a saúde deles é a sua saúde.

**Sinal de alerta:**
- Health check falha 2–3x seguidas (uma falha pode ser blip; três é incidente).
- Tempo de resposta do health check disparando (sintoma antes da queda total).
- Provedor crítico com incidente aberto (acompanhe as status pages deles).

**Onde:** monitor de uptime externo (UptimeRobot, Better Stack, Checkly) batendo no health
check de fora — tem que ser **de fora**, senão cai junto e não te avisa.

---

## 5. Segurança

**Pergunta:** tem alguém tentando forçar a porta?

Vigilância de segurança em runtime — complementar ao que **Bastião** revisa no código.
Aqui você observa o comportamento em produção atrás de sinais de ataque ou abuso.

**O que medir:**
- **Picos de 401/403** — muita tentativa negada = alguém testando credenciais ou forçando rota.
- **Tentativas de login falhas** — brute force / credential stuffing.
- **Rate limit estourando** — um IP ou usuário martelando um endpoint.
- **Acessos a rotas que não existem** (varredura de vulnerabilidade) — picos de 404 em
  caminhos tipo `/wp-admin`, `/.env`.

**Sinal de alerta:**
- Pico anormal de respostas 401/403/429.
- Muitas falhas de login concentradas num curto intervalo ou vindo de um IP.
- Tentativas de acesso a `.env`, `/admin`, paths de CMS que você nem usa.

**Onde:** logs da Vercel filtrados por status, regras do Firebase Auth, WAF/rate limit do
provedor. Se vazou segredo de fato, a skill **Faro** (e o protocolo do Bastião) entra.

---

## 6. Negócio

**Pergunta:** o sistema está cumprindo o propósito pra que existe?

A dimensão mais esquecida e, muitas vezes, a mais importante. Um sistema pode estar **sem
erros, rápido, barato e no ar — e mesmo assim quebrado** do ponto de vista do negócio: o
botão de comprar sumiu num deploy, o e-mail de confirmação parou de sair, a conversão
despencou. Tecnicamente "saudável", comercialmente sangrando.

**O que medir:**
- **Conversão dos fluxos críticos** — cadastro, checkout, ativação. Quantos entram x
  quantos completam.
- **Eventos de negócio que param** — "zero vendas nas últimas 2h" num horário que sempre
  tem vendas é alerta, mesmo sem nenhum erro técnico.
- **Funil** — em que passo as pessoas estão caindo? Caiu de repente?

**Sinal de alerta:**
- Conversão de um fluxo cai abruptamente (especialmente após deploy).
- Um evento de negócio que sempre ocorre **para de ocorrer** (silêncio é alerta).
- Queda gradual de engajamento/retenção que nenhuma métrica técnica explica.

**Onde:** analytics de produto (PostHog, Plausible, GA), eventos de negócio logados em
`info` (ver `regras-de-log.md`), métricas do seu próprio banco.

---

## Resumo

| # | Dimensão | Sinal de alerta em uma linha |
|---|---|---|
| 1 | Erros | Taxa sobe, erro novo pós-deploy, erro conhecido em volume |
| 2 | Performance | p95 acima do limite, função perto do timeout |
| 3 | Custo | Gasto diário acima do teto, pico de IA/reads sem mais usuários |
| 4 | Uptime | Health check falha 3x, dependência crítica fora |
| 5 | Segurança | Pico de 401/403/429, brute force, varredura de rotas |
| 6 | Negócio | Conversão despenca, evento crítico para, funil quebra |

**Comece com 1, 3 e 4.** Adicione as outras conforme o produto exige. Para cada dimensão
que escolher, defina o que é "normal" antes — sem linha de base, você não tem alerta, tem
adivinhação. A decisão de quanto vigiar é sua; o custo de não vigiar nada é descobrir tudo
pelo cliente.
