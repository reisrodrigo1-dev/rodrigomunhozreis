# Anti-padrões — erros comuns e como consertar

Use este arquivo para **diagnosticar prompts ruins**. Quando o usuário disser "esse prompt não funciona" ou trouxer um resultado decepcionante, identifique qual destes erros está acontecendo e aplique o conserto. Cada anti-padrão mapeia para uma letra do P.R.O.M.P.T.E.R. que está faltando.

Modo de diagnóstico rápido — olhe o sintoma da SAÍDA:

| Sintoma da resposta | Anti-padrão provável | Letra a reforçar |
|---|---|---|
| Genérica, "morna", óbvia | Prompt vago / sem Papel | O, P |
| Inventou fato/número | Sem Proteção | P (proteção) |
| Formato errado (veio prosa, queria JSON) | Sem Texto de saída / sem Exemplo | T, E |
| Nível errado (raso demais ou complexo demais) | Papel ausente ou errado | P (papel) |
| Pulou etapas / raciocínio confuso | Sem Marcha | M |
| Respondeu coisa que você não pediu / dispersa | Pediu tudo de uma vez | O, M |
| Varia muito a cada execução | Ambíguo / sem Exemplo | T, E |
| Ignorou seu contexto | Sem Realidade ou contexto enterrado | R |

---

## Anti-padrão 1 — Prompt vago

**Sintoma:** "Escreva sobre marketing." → resposta genérica que serviria para qualquer um.

**Por que acontece:** sem Objetivo e Realidade, a IA otimiza para "parecer útil" e responde para um leitor médio inexistente.

**Conserto:** adicione **Objetivo concreto + Realidade**.
- Antes: "Escreva sobre marketing."
- Depois: "Escreva 3 dicas de marketing de conteúdo para um SaaS B2B com orçamento baixo, voltadas a quem está começando do zero. Resultado: aplicável já esta semana."

---

## Anti-padrão 2 — Sem Papel

**Sintoma:** resposta no nível errado — rasa para um especialista, ou técnica demais para um leigo.

**Por que acontece:** sem Papel, a IA não sabe que repertório e vocabulário usar.

**Conserto:** adicione "Você é..." com profissão + nível.
- Antes: "Revise meu código."
- Depois: "Você é um engenheiro sênior e revisor cético. Revise meu código apontando bugs e casos de borda."

---

## Anti-padrão 3 — Sem Exemplo (quando precisa)

**Sintoma:** o formato ou estilo nunca sai como você quer, por mais que você descreva.

**Por que acontece:** algumas coisas (estilo, formato exato, nível de detalhe) se transmitem melhor mostrando do que descrevendo.

**Conserto:** cole 1 exemplo de saída boa.
- Antes: "Escreva no meu tom de voz."
- Depois: "Escreva no estilo deste exemplo (use só como referência de tom, não copie o conteúdo): [trecho]."

Regra: **formato rígido (JSON/tabela/CSV) sem exemplo quase sempre quebra.** Sempre dê um exemplo do formato.

---

## Anti-padrão 4 — Pedir tudo de uma vez

**Sintoma:** "Analise o mercado, crie o plano, escreva a copy e me dê o código." → resposta superficial em tudo, ou ignora partes.

**Por que acontece:** misturar tarefas distintas dilui o foco e estoura o que cabe numa resposta boa.

**Conserto:** quebre em passadas sequenciais, ou em prompts separados.
- Depois: "Vamos em etapas. Passo 1: analise o mercado (só isso). Quando eu disser 'ok', seguimos para o plano." Ou: "Faça em ordem: primeiro a análise; depois, com base nela, o plano."

---

## Anti-padrão 5 — Sem Proteção (a IA inventa)

**Sintoma:** números, citações, fontes ou fatos que parecem certos mas são inventados (alucinação).

**Por que acontece:** a IA preenche lacunas para "completar" a resposta quando não tem dado.

**Conserto:** adicione regras explícitas de incerteza.
- Depois: "Use apenas os dados fornecidos. Não invente números, nomes ou citações. Se não tiver a informação, escreva 'não tenho esse dado' em vez de chutar."

Crítico em jurídico, saúde, finanças, dados de cliente e código de produção.

---

## Anti-padrão 6 — Sem Texto de saída definido

**Sintoma:** veio um textão quando você queria 3 bullets; veio prosa quando queria JSON.

**Conserto:** especifique formato, tamanho e estrutura.
- Depois: "Formato: no máximo 5 bullets, sem introdução, comece direto. Cada bullet com no máximo 1 frase."

---

## Anti-padrão 7 — Sem Marcha em tarefa multi-etapa

**Sintoma:** em decisões/planos/depuração, a IA já dá a conclusão sem mostrar o raciocínio, e erra.

**Conserto:** force a ordem.
- Depois: "Antes de recomendar, faça nesta ordem: 1) liste critérios; 2) avalie cada opção; 3) só então conclua."

---

## Anti-padrão 8 — Contexto enterrado ou irrelevante

**Sintoma:** você deu muito contexto, mas a IA ignorou o que importava — ou se prendeu a detalhe irrelevante.

**Por que acontece:** informação essencial misturada com ruído; instrução importante perdida no meio de um parágrafo longo.

**Conserto:** separe o contexto em seção rotulada, e coloque a instrução principal em destaque (início ou fim). Corte contexto que não muda a resposta.
- Depois: estruture com rótulos — `Contexto:`, `Sua tarefa:`, `Regras:`, `Formato:`.

---

## Anti-padrão 9 — Instruções negativas demais (só dizer o que NÃO fazer)

**Sintoma:** "Não seja formal, não use jargão, não seja longo, não..." → a IA fica travada ou ignora.

**Por que acontece:** o modelo trabalha melhor com alvo positivo do que com lista de proibições.

**Conserto:** converta proibição em instrução positiva.
- Antes: "Não escreva formal demais e não seja prolixo."
- Depois: "Escreva casual e conciso, no máximo 100 palavras."

---

## Anti-padrão 10 — Polidez e ruído que não ajudam

**Sintoma:** prompts cheios de "por favor, se possível, quem sabe você poderia talvez..." que diluem a instrução.

**Conserto:** seja direto e imperativo. Educação não melhora a resposta; clareza sim.
- Depois: "Escreva X. Formato: Y."

---

## Anti-padrão 11 — Não iterar (esperar acertar de primeira)

**Sintoma:** o usuário desiste no primeiro resultado ruim ("a IA não consegue fazer isso").

**Por que acontece:** trata o prompt como pergunta única, não como spec que se refina.

**Conserto:** ensine o ciclo de Refino. Mude **uma letra por vez** e reteste. Quase todo prompt fica bom em 2-3 iterações dirigidas. Veja a letra R em `prompter-metodo.md`.

---

## Anti-padrão 12 — Pedir a opinião sem dar critério

**Sintoma:** "Qual a melhor opção?" → resposta indecisa ("depende") ou um chute sem base.

**Conserto:** dê os critérios e o contexto da decisão (vira o padrão "Decidir entre opções"). Se você não sabe os critérios, peça à IA para listá-los primeiro.

---

## Roteiro para consertar um prompt trazido pelo usuário

1. Peça o **prompt atual** e um **exemplo do resultado ruim** (o sintoma).
2. Cruze o sintoma com a tabela de diagnóstico no topo deste arquivo.
3. Identifique a(s) letra(s) faltante(s) do P.R.O.M.P.T.E.R.
4. Reconstrua o prompt adicionando só o que falta (não reescreva o que já estava bom).
5. Entregue o prompt corrigido + diga em 1 linha o que mudou e por quê + 1 dica de teste.

Não reescreva tudo por reflexo: conserte a causa. Um prompt que só precisava de formato (T) não precisa virar um monstro de 8 seções.
