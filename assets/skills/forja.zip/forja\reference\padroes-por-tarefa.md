# Padrões por tipo de tarefa

Cada padrão tem: **quando usar**, um **TEMPLATE** (esqueleto com `[VARIÁVEIS]` para preencher) e um **EXEMPLO** já preenchido. Todos os templates são aplicações do P.R.O.M.P.T.E.R. — as letras estão marcadas para você ver a estrutura.

Use o template como ponto de partida e ajuste. Não entregue o template cru ao usuário: preencha com o contexto dele.

Índice:
1. Escrever texto
2. Decidir entre opções
3. Programar / depurar
4. Analisar dados
5. Vender / copy
6. Resumir
7. Traduzir
8. Criar plano
9. Brainstorm
10. Extrair informação

---

## 1. Escrever texto

**Quando usar:** produzir qualquer texto novo (e-mail, post, artigo, descrição, resposta).

**TEMPLATE**
```
[P] Você é um [redator/copywriter/especialista] que escreve com [tom].
[R] Contexto:
- Tema: [assunto]
- Público: [quem vai ler]
- Objetivo do texto: [o que ele deve provocar no leitor]
- Informações a usar: [fatos, dados, pontos obrigatórios]
[O] Escreva [tipo de texto] que [resultado desejado].
[T] Formato: [tamanho], tom [tom], em PT-BR. [Restrições de estilo: sem clichês, sem emojis, etc.]
[P-proteção] Não invente fatos. Use só as informações acima. Se faltar algo essencial, pergunte.
[E] (opcional) Estilo de referência: [trecho-modelo].
```

**EXEMPLO**
```
Você é um redator de conteúdo experiente, com tom claro e profissional.
Contexto:
- Tema: lançamento de um plano anual com 20% de desconto.
- Público: clientes atuais que pagam mensal.
- Objetivo do texto: convencer a migrar para o anual.
- Informações a usar: economia de 2 meses, mesmo recurso, sem fidelidade.
Escreva um e-mail curto que faça o cliente migrar para o plano anual.
Formato: máximo 120 palavras, tom direto e amistoso, PT-BR, com um CTA claro no fim. Sem emojis.
Não invente números além dos fornecidos.
```

---

## 2. Decidir entre opções

**Quando usar:** escolher entre alternativas (ferramentas, abordagens, candidatos, caminhos). Sempre use **Marcha**.

**TEMPLATE**
```
[P] Você é um [consultor/arquiteto/especialista] que decide por trade-offs explícitos.
[R] Decisão: [o que precisa decidir].
Opções: [A], [B], [C].
Contexto e restrições: [orçamento, prazo, equipe, prioridades].
[O] Recomende a melhor opção para o meu caso.
[M] Siga esta ordem:
1. Liste os critérios de decisão que importam aqui.
2. Avalie cada opção contra cada critério (pontos fortes e fracos).
3. Só então recomende uma, com a justificativa e em que caso a recomendação mudaria.
[P-proteção] Se faltar informação para decidir bem, diga qual antes de recomendar. Não esconda a incerteza.
[T] Formato: tabela comparativa (critério × opção) + 1 parágrafo de recomendação.
```

**EXEMPLO**
```
Você é um arquiteto de software que decide por trade-offs explícitos.
Decisão: escolher banco de dados para um SaaS novo.
Opções: PostgreSQL, MongoDB, Firebase.
Contexto: time de 2 devs, dados relacionais, orçamento baixo, MVP em 2 meses.
Recomende a melhor opção para o meu caso.
Siga esta ordem:
1. Liste os critérios (custo, curva de aprendizado, fit com dados relacionais, escala futura).
2. Avalie cada opção contra cada critério.
3. Recomende uma, justifique, e diga em que cenário mudaria.
Se faltar informação importante, peça antes.
Formato: tabela comparativa + 1 parágrafo de recomendação. PT-BR.
```

---

## 3. Programar / depurar

**Quando usar:** escrever, refatorar ou consertar código. Para bug, sempre dê o erro e o que já tentou.

**TEMPLATE (escrever código)**
```
[P] Você é um engenheiro de software sênior que escreve código simples e testável.
[R] Stack: [linguagem/framework/versões]. Contexto: [onde isso roda, restrições].
[O] Implemente [o que precisa fazer], de forma que [critério: passa nestes casos].
[M] Antes de codar, liste suas suposições. Depois implemente. Depois aponte casos de borda.
[P-proteção] Se a especificação estiver ambígua, pergunte em vez de assumir silenciosamente.
[T] Entregue: código comentado no essencial + breve explicação das decisões. Sem reescrever partes não pedidas.
```

**TEMPLATE (depurar)**
```
[P] Você é um engenheiro sênior especialista em depuração.
[R] Stack: [...]. Código relevante:
[cole o trecho]
Erro / comportamento observado:
[cole o erro / descreva]
O que já tentei: [...]
[O] Encontre a causa raiz e proponha a correção.
[M] Siga: 1) explique o que o código faz; 2) levante hipóteses de causa; 3) indique a mais provável e por quê; 4) dê a correção e como validar.
[P-proteção] Não chute a correção sem explicar a causa. Se precisar de mais informação (log, versão), peça.
[T] Formato: causa raiz + correção (código) + como testar.
```

**EXEMPLO (depurar)**
```
Você é um engenheiro sênior especialista em depuração.
Stack: Python 3.11, FastAPI. Código relevante:
[trecho da rota /upload]
Erro observado: requisições grandes retornam 413 só em produção, local funciona.
O que já tentei: aumentar o timeout do cliente (não resolveu).
Encontre a causa raiz e proponha a correção.
Siga: 1) o que o código faz; 2) hipóteses; 3) a mais provável e por quê; 4) correção + como validar.
Não chute sem explicar a causa. Se faltar config (nginx, proxy), peça.
Formato: causa raiz + correção + como testar.
```

---

## 4. Analisar dados

**Quando usar:** tirar conclusões de uma planilha, tabela, relatório ou conjunto de números.

**TEMPLATE**
```
[P] Você é um analista de dados que separa correlação de causalidade e deixa premissas explícitas.
[R] Dados:
[cole a tabela / descreva a fonte e colunas]
Pergunta de negócio: [o que quero descobrir].
[O] Responda a pergunta com base nos dados, indicando a confiança.
[M] 1) verifique a qualidade/limites dos dados; 2) faça a análise; 3) apresente achados; 4) liste o que NÃO dá para concluir.
[P-proteção] Não invente números nem extrapole além dos dados. Marque cada conclusão como "suportada" ou "hipótese".
[T] Formato: 3-5 achados em bullets + 1 recomendação + ressalvas.
```

**EXEMPLO**
```
Você é um analista de dados que separa correlação de causalidade.
Dados: [tabela de vendas mensais por canal, 12 meses].
Pergunta de negócio: qual canal devo priorizar no próximo trimestre?
Responda com base nos dados, indicando a confiança.
1) cheque limites dos dados; 2) analise; 3) achados; 4) o que não dá pra concluir.
Não extrapole além dos dados. Marque cada conclusão como suportada ou hipótese.
Formato: 3-5 achados + 1 recomendação + ressalvas. PT-BR.
```

---

## 5. Vender / copy

**Quando usar:** texto que precisa converter — anúncio, headline, página de venda, e-mail de oferta.

**TEMPLATE**
```
[P] Você é um copywriter de resposta direta. Clareza, prova e benefício acima de adjetivos.
[R] Produto: [o que é]. Público: [quem]. Dor que resolve: [dor]. Diferencial: [por que este]. Prova: [números, depoimentos].
[O] Escreva [headline / anúncio / seção] que faça [público] [ação desejada].
[M] Comece pela dor/desejo do público, mostre o benefício, traga a prova, feche com CTA.
[P-proteção] Não prometa o que o produto não entrega. Use só a prova fornecida. Sem clichês de marketing.
[T] Formato: [3 variações de headline / texto de X palavras]. Tom [tom]. PT-BR.
[E] Estilo de referência: [marca/exemplo, se houver].
```

**EXEMPLO**
```
Você é um copywriter de resposta direta.
Produto: skill de IA que monta prompts profissionais. Público: fundadores que usam IA mas não sabem prompar bem. Dor: prompts ruins = respostas ruins, retrabalho. Diferencial: método P.R.O.M.P.T.E.R. com engenharia. Prova: usado pelo Rodrigo Reis em palestras.
Escreva 3 variações de headline que façam um fundador clicar para conhecer.
Comece pela dor, mostre o benefício, traga prova, feche com CTA implícito.
Não prometa milagre. Sem clichês. Tom direto, sem hype.
Formato: 3 headlines + 1 subheadline cada. PT-BR.
```

---

## 6. Resumir

**Quando usar:** condensar um texto longo, reunião, documento, thread.

**TEMPLATE**
```
[P] Você é um sintetizador que preserva o essencial e corta o resto.
[R] Texto a resumir:
[cole]
Para quem é o resumo: [audiência] e para que decisão/uso: [objetivo].
[O] Resuma para que [audiência] consiga [objetivo] em [tempo].
[P-proteção] Não adicione informação que não está no texto. Se o texto for ambíguo, preserve a ambiguidade.
[T] Formato: [TL;DR de 1 frase + 3-5 bullets + ações, se houver]. Máximo [X] palavras.
```

**EXEMPLO**
```
Você é um sintetizador que preserva o essencial.
Texto a resumir: [ata da reunião de produto].
Para quem: o CEO. Para quê: decidir se aprova o roadmap em 2 minutos.
Resuma para que o CEO decida rápido.
Não adicione nada fora do texto.
Formato: TL;DR de 1 frase + 3 bullets de decisões + lista de pendências com responsável. Máximo 150 palavras. PT-BR.
```

---

## 7. Traduzir

**Quando usar:** traduzir mantendo tom, registro e termos técnicos.

**TEMPLATE**
```
[P] Você é um tradutor profissional de [idioma A] para [idioma B], especialista em [domínio].
[R] Texto:
[cole]
Contexto de uso: [onde será usado, público].
[O] Traduza preservando significado, tom e termos técnicos.
[P-proteção] Não traduza nomes próprios/termos consagrados sem necessidade. Em ambiguidade, escolha a opção mais natural e marque com [nota] se relevante. Glossário a respeitar: [termos].
[T] Registro: [formal/informal]. Entregue apenas a tradução [+ notas, se pedidas].
```

**EXEMPLO**
```
Você é um tradutor profissional de PT-BR para inglês, especialista em tecnologia/SaaS.
Texto: [descrição de produto].
Contexto: landing page para o mercado dos EUA.
Traduza preservando significado, tom e termos técnicos.
Mantenha termos de produto em inglês quando for o uso padrão. Registro: profissional e direto (US).
Entregue apenas a tradução.
```

---

## 8. Criar plano

**Quando usar:** transformar um objetivo em um plano de etapas. Sempre use **Marcha**.

**TEMPLATE**
```
[P] Você é um [PM/estrategista/especialista] que cria planos executáveis e priorizados.
[R] Objetivo: [meta]. Situação atual: [ponto de partida]. Restrições: [prazo, recursos, equipe].
[O] Crie um plano que leve de [hoje] até [objetivo].
[M] 1) divida em fases/marcos; 2) liste tarefas por fase; 3) priorize por impacto vs esforço; 4) aponte riscos e dependências.
[P-proteção] Se o objetivo for grande demais para o prazo/recurso, diga e proponha um escopo realista.
[T] Formato: plano por fases, com tarefas, responsável (se houver) e marco de "pronto". [+ próximos 3 passos imediatos].
```

**EXEMPLO**
```
Você é um Product Manager que cria planos executáveis.
Objetivo: lançar a skill Forja como referência em vibecoding. Situação atual: skill pronta, sem divulgação. Restrições: 1 pessoa, 30 dias, baixo orçamento.
Crie um plano que leve da skill pronta até reconhecimento como autoridade.
1) fases; 2) tarefas por fase; 3) priorize por impacto vs esforço; 4) riscos.
Se 30 dias for irreal, diga e proponha escopo realista.
Formato: plano por fases + os 3 próximos passos imediatos. PT-BR.
```

---

## 9. Brainstorm

**Quando usar:** gerar ideias, ângulos, nomes, hipóteses. Aqui se **relaxa a Proteção** e pede quantidade/variedade primeiro.

**TEMPLATE**
```
[P] Você é um gerador de ideias criativo e prolífico, sem medo de ideias ousadas.
[R] Desafio: [o que precisa de ideias]. Contexto/restrições reais: [só as essenciais].
[O] Gere [N] ideias variadas para [desafio].
[M] Busque variedade deliberada: ideias seguras, ideias ousadas e 1-2 ideias "fora da caixa". Não filtre ainda.
[T] Formato: lista de [N] ideias, cada uma com 1 linha de explicação. Sem julgar qualidade nesta etapa.
[refino] Depois, marque as 3 mais promissoras e diga por quê.
```

**EXEMPLO**
```
Você é um gerador de ideias criativo e prolífico.
Desafio: nomes para uma palestra sobre prompts com engenharia. Contexto: público de fundadores, tom direto, marca "vibecoding com engenharia".
Gere 15 nomes variados.
Misture seguros, ousados e 2 fora da caixa. Não filtre ainda.
Formato: lista de 15, 1 linha cada.
Depois marque os 3 melhores e diga por quê. PT-BR.
```

---

## 10. Extrair informação

**Quando usar:** transformar texto livre em dados estruturados (campos, JSON, tabela, CSV). Saída rígida → **sempre** com Exemplo.

**TEMPLATE**
```
[P] Você é um extrator de dados preciso. Você só extrai o que está no texto.
[R] Texto de entrada:
[cole]
[O] Extraia [campos desejados].
[P-proteção] Se um campo não estiver no texto, use [null / "não informado"] — NÃO invente. Não infira além do explícito.
[T] Responda APENAS com [JSON/tabela/CSV] neste formato exato:
[mostre o schema]
[E] Exemplo:
Entrada: [exemplo curto]
Saída: [saída no formato]
Agora faça para o texto real acima.
```

**EXEMPLO**
```
Você é um extrator de dados preciso. Só extraia o que está no texto.
Texto de entrada: [e-mail de um lead pedindo orçamento].
Extraia: nome, empresa, produto de interesse, prazo, orçamento.
Se um campo não estiver no texto, use null. Não invente.
Responda APENAS com JSON neste formato:
{ "nome": "", "empresa": "", "produto": "", "prazo": "", "orcamento": null }
Exemplo:
Entrada: "Oi, sou a Ana da Acme, queria orçamento do plano Pro."
Saída: { "nome": "Ana", "empresa": "Acme", "produto": "plano Pro", "prazo": null, "orcamento": null }
Agora faça para o texto real acima.
```

---

## Combinando padrões

Pedidos reais costumam misturar padrões. Use o template do **padrão dominante** e enxerte os campos do outro:

- "Resuma este contrato **e** liste os riscos" = Resumir + Extrair informação (resumo em prosa + tabela de riscos por cláusula).
- "Analise estes dados **e** escreva um e-mail com a recomendação" = Analisar dados + Escrever texto (faça em duas passadas: primeiro a análise, depois o e-mail baseado nela).
- "Decida a stack **e** já me dê o código inicial" = Decidir + Programar (decida primeiro, só então gere código da opção escolhida).

Regra: quando combinar, peça em **passadas sequenciais** dentro do mesmo prompt ("Primeiro faça X. Depois, com base em X, faça Y."). Isso evita que a IA misture as etapas.
