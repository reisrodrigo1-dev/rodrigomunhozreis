# Dicas práticas por modelo — Claude vs GPT vs Gemini

O P.R.O.M.P.T.E.R. funciona em qualquer modelo. O que muda é o **ajuste fino**: cada família responde melhor a certos formatos e tem manias próprias. Use este arquivo quando o usuário disser para qual IA é o prompt, ou quando perguntar diferenças.

Aviso honesto (a decisão é sua): modelos evoluem rápido e o comportamento varia por versão. Trate o que segue como heurística prática, não lei. Na dúvida, **teste nos dois e compare** — é o jeito vibecoding-com-engenharia de decidir.

---

## Visão rápida

| Dimensão | Claude (Anthropic) | GPT (OpenAI) | Gemini (Google) |
|---|---|---|---|
| Estrutura preferida | Tags tipo XML/markdown, seções claras | Markdown, listas, instruções diretas | Markdown, instruções explícitas e literais |
| Instruções longas/contexto | Lida muito bem com prompts longos e documentos extensos | Bom; gosta de instruções objetivas e enumeradas | Bom; tende a seguir instruções ao pé da letra |
| Raciocínio passo a passo | Forte; responde bem a "pense passo a passo" e a etapas explícitas | Forte; modelos de raciocínio dispensam micro-instrução de "pense" | Forte; se beneficia de etapas explícitas |
| Tom padrão | Cuidadoso, sinaliza incerteza, evita exagero | Confiante, fluido | Direto, factual |
| Manias a vigiar | Pode ser prolixo/cauteloso demais; pode adicionar ressalvas | Pode soar genérico/"corporativo"; às vezes confiante demais | Pode ser literal demais e curto demais; segue formato à risca |

---

## Claude (Anthropic)

**Pontos fortes:** prompts longos e estruturados, leitura de documentos grandes, seguir instruções com nuance, sinalizar incerteza honestamente, raciocínio em etapas.

**O que funciona bem:**
- **Tags estruturais (estilo XML)** para separar partes do prompt. Claude foi treinado para respeitá-las:
  ```
  <contexto> ... </contexto>
  <tarefa> ... </tarefa>
  <regras> ... </regras>
  <exemplo> ... </exemplo>
  ```
  Isso reduz o risco de instrução se misturar com dados.
- **Papel via system + instrução clara.** Definir "Você é..." e o objetivo logo no começo funciona muito bem.
- **Pedir raciocínio explícito** ("pense passo a passo antes de responder") melhora decisões e análise.
- **Exemplos dentro de tags** `<exemplo>` são seguidos com fidelidade.
- Dá para pedir que ele **questione antes de assumir** — Claude colabora bem nesse modo.

**Manias a domar:**
- Tende a ser **cauteloso e prolixo**. Se quiser resposta seca, peça explicitamente: "Responda direto, sem preâmbulo nem ressalvas, no máximo X palavras."
- Pode adicionar disclaimers. Em tarefa de baixo risco, diga: "Não adicione avisos; assuma que sei o contexto."

**Modelo da casa:** esta skill (Forja) roda em Claude — os prompts que você gera para uso *dentro* do Claude podem abusar de tags e de instruções longas e estruturadas.

---

## GPT (OpenAI)

**Pontos fortes:** versatilidade, fluência de escrita, seguir instruções enumeradas, ecossistema de ferramentas. Modelos de raciocínio são fortes em problemas multi-etapa.

**O que funciona bem:**
- **Instruções diretas e enumeradas.** GPT responde muito bem a "Faça: 1)... 2)... 3)...".
- **Papel + formato no topo, restrições no fim.** Markdown limpo, sem firula.
- **Delimitar dados com marcadores** (aspas triplas, `###`, ou `---`) para separar instrução de conteúdo:
  ```
  Resuma o texto entre ###.
  ###
  [texto]
  ###
  ```
- Para **modelos de raciocínio** (família "o"/raciocínio): dê o objetivo e os critérios, e **evite** microgerenciar o "pense passo a passo" — eles já raciocinam internamente. Foque no *o quê* e no *critério de sucesso*, não no *como pensar*.
- Para **modelos de chat padrão**: aí sim "pense passo a passo" ajuda em tarefas complexas.

**Manias a domar:**
- Pode soar **genérico/corporativo**. Force voz específica via Papel + Exemplo de estilo.
- Pode ser **confiante demais** e inventar com segurança. Reforce a Proteção: "Se não tiver certeza, diga. Não invente fontes."
- Tende a encher de listas e cabeçalhos. Se quiser prosa, peça: "Responda em prosa corrida, sem bullets."

---

## Gemini (Google)

**Pontos fortes:** factual, integração com o ecossistema Google, bom com contexto longo, segue formato com fidelidade.

**O que funciona bem:**
- **Instruções explícitas e literais.** Gemini tende a fazer exatamente o que está escrito — então escreva exatamente o que quer, sem deixar implícito.
- **Formato declarado de forma inequívoca.** Se quer JSON, diga "responda APENAS com JSON válido, sem texto antes ou depois" e dê o schema + exemplo.
- **Restrições positivas** funcionam melhor que negativas (vale para todos, mas Gemini é especialmente literal).
- Bom para tarefas factuais e extração quando o schema está cristalino.

**Manias a domar:**
- Pode ser **curto/literal demais** e parar antes do que você queria. Se faltar profundidade, peça explicitamente: "Seja completo; cubra todos os pontos abaixo; não resuma demais."
- Por seguir ao pé da letra, **ambiguidade vira resposta estranha.** Não deixe nada subentendido — preencha bem a Realidade e o Texto de saída.
- Pode variar mais o formato entre execuções — reforce com Exemplo.

---

## Regras de portabilidade (do mesmo prompt entre modelos)

1. **Mantenha o miolo P.R.O.M.P.T.E.R.** igual — Papel, Objetivo, Realidade, Proteção e formato valem para todos.
2. **Troque só a embalagem estrutural:**
   - Claude → tags `<...>`.
   - GPT/Gemini → markdown com `###`/`---` para delimitar dados.
3. **Calibre a verbosidade:** peça concisão ao Claude; peça completude ao Gemini; force voz específica no GPT.
4. **Endureça a Proteção no GPT** (confiança excessiva) e a **clareza no Gemini** (literalidade).
5. **Sempre teste nos dois** se a tarefa é crítica. O melhor prompt é o que você validou, não o que parecia melhor no papel.

---

## Como aplicar isso na entrega da Forja

Quando o usuário disser o modelo-alvo:
- Adapte a **embalagem** (tags vs markdown) e inclua a dica de mania relevante.
- Se ele não disser o modelo, gere o prompt em **markdown estruturado** (funciona razoavelmente em todos) e ofereça como variação uma versão com tags `<...>` para Claude.
- Na dica de refino, sugira testar o mesmo prompt em dois modelos quando a tarefa for importante.
