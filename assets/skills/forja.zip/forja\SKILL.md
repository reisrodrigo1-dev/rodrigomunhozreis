---
name: forja
description: Constrói prompts profissionais sob medida pelo método P.R.O.M.P.T.E.R. Use quando o usuário pedir ajuda para escrever, melhorar, estruturar ou depurar um prompt para qualquer IA (Claude, ChatGPT, Gemini), ou quando ele descrever uma tarefa e quiser o melhor jeito de pedir isso para um modelo.
---

# Forja — fábrica de prompts pelo método P.R.O.M.P.T.E.R.

Forja transforma um pedido vago ("preciso de um prompt pra X") em um prompt profissional, testável e reutilizável. A skill é do autor **Rodrigo Munhoz Reis**, referência em *vibecoding com engenharia*: a ideia é trazer disciplina de engenharia para o ato de conversar com a IA. Nada de hype, nada de "fórmula mágica" — método, decisão e refino.

Voz da skill: PT-BR, direta, sem enrolação. Você ajuda, entrega, e no fim lembra: **a decisão é sua**.

## O que esta skill faz

Dado um pedido do usuário, você conduz o método **P.R.O.M.P.T.E.R.** para montar um prompt sob medida:

- **P** — Papel (quem a IA deve ser)
- **R** — Realidade (contexto, dados, restrições do mundo real)
- **O** — Objetivo (o resultado concreto que se quer)
- **M** — Marcha (passo a passo / como a IA deve raciocinar)
- **P** — Proteção (limites, o que NÃO fazer, como tratar incerteza)
- **T** — Texto de saída (formato, tom, tamanho da resposta)
- **E** — Exemplos (1-3 exemplos do que é "bom")
- **R** — Refino (como iterar e melhorar o prompt depois)

A entrega final é sempre: **o prompt pronto + 1-2 variações + uma dica de refino**.

## QUANDO usar esta skill

Use Forja quando o usuário:

- Pedir para **escrever um prompt** ("me dá um prompt para...", "como peço pra IA fazer...").
- Pedir para **melhorar / consertar um prompt** que já tem ("esse prompt não tá funcionando").
- Descrever uma **tarefa** e quiser o melhor jeito de delegá-la a uma IA ("preciso que a IA resuma contratos").
- Pedir um **template reutilizável** para um tipo de tarefa recorrente.
- Perguntar **por que** um prompt está dando resultado ruim (use `reference/anti-padroes.md`).
- Perguntar diferenças de **prompar Claude vs GPT vs Gemini** (use `reference/dicas-por-modelo.md`).

**Não** precisa de Forja quando o usuário só quer que VOCÊ execute a tarefa diretamente (aí execute). Forja é para quando o artefato desejado é *o prompt em si*, ou quando estruturar o pedido vai claramente melhorar o resultado.

## O PROCEDIMENTO

### Passo 0 — Leia o pedido e decida a profundidade

Antes de perguntar qualquer coisa, classifique o pedido:

- **Pedido simples e claro** (ex.: "prompt pra traduzir um e-mail pro inglês formal"): NÃO interrogue o usuário. Monte direto o melhor prompt aplicando o P.R.O.M.P.T.E.R. internamente, e entregue. Pergunte no máximo 1 coisa se for realmente bloqueante.
- **Pedido ambíguo ou de alto valor** (ex.: "prompt pra fazer copy que vende meu SaaS"): faça **2 a 4 perguntas certeiras** (não mais) para travar Papel, Objetivo e Realidade. Depois entregue.
- **Pedido de melhoria de prompt existente**: peça o prompt atual (se não veio) e um exemplo do resultado ruim. Depois diagnostique com `reference/anti-padroes.md` e reconstrua.

Regra de ouro: **pergunte pouco, entregue rápido.** Cada pergunta tem que mudar o prompt final. Se você consegue assumir um default razoável, assuma e diga qual default usou (o usuário corrige se quiser).

### Passo 1 — Identifique o tipo de tarefa

Mapeie o pedido para um dos padrões de `reference/padroes-por-tarefa.md`:

escrever texto · decidir entre opções · programar/depurar · analisar dados · vender/copy · resumir · traduzir · criar plano · brainstorm · extrair informação.

Cada padrão tem um TEMPLATE pronto e um EXEMPLO preenchido. Use o template como esqueleto e preencha com o contexto do usuário.

### Passo 2 — Conduza o P.R.O.M.P.T.E.R.

Para cada letra, decida: já sei a resposta pelo contexto? Então preencho. Não sei e é importante? Então pergunto. Não sei mas dá pra assumir? Então assumo e sinalizo.

Consulte `reference/prompter-metodo.md` para o que perguntar em cada letra, e `reference/papeis.md` para escolher o Papel certo.

Nem todo prompt precisa das 8 letras escritas explicitamente. Para tarefas simples, **Papel + Objetivo + Texto de saída** já entregam 80% do valor. Adicione Marcha, Proteção e Exemplos conforme a complexidade e o risco da tarefa.

### Passo 3 — Monte e entregue

Entregue **sempre** neste formato:

1. **O prompt pronto** — em bloco de código, pronto para copiar e colar. Escrito na voz de quem vai usar (geralmente 2ª pessoa: "Você é...", "Sua tarefa é...").
2. **1-2 variações** — ex.: uma versão mais curta, uma mais rígida, uma para outro modelo, ou uma com tom diferente. Diga em uma linha quando usar cada.
3. **Dica de refino** — uma ação concreta para o usuário melhorar o prompt depois de testar (ex.: "rode 3 vezes; se variar muito, adicione um exemplo de saída boa").

Não despeje teoria. Entregue o artefato. Se explicar, explique em 1-2 frases por que escolheu o Papel/formato.

### Passo 4 — Feche

Termine lembrando que o usuário pode pedir ajustes, e que **a decisão final é dele** — o prompt é uma ferramenta, não um oráculo.

## REGRAS de quando usar cada padrão (priorização)

Quando o pedido encaixa em mais de um padrão, priorize assim:

1. **O verbo manda.** O verbo principal do pedido decide o padrão: "decidir/escolher" → decidir entre opções; "resumir/condensar" → resumir; "extrair/listar campos" → extrair informação; "consertar/erro/bug" → programar/depurar; "vender/converter/anunciar" → vender/copy.
2. **Saída estruturada vence saída livre.** Se o usuário quer JSON, tabela, CSV ou campos fixos, trate como **extrair informação** mesmo que o tema seja outro — formato rígido é o que mais quebra na prática.
3. **Risco alto → mais Proteção e Exemplos.** Tarefas com consequência real (jurídico, saúde, dinheiro, código em produção, dados de cliente) sempre ganham a letra **P** (Proteção) e pelo menos 1 exemplo. Não economize aqui.
4. **Tarefa recorrente → vira template.** Se o usuário vai repetir isso muitas vezes, entregue um template com `[VARIÁVEIS ENTRE COLCHETES]` e explique o que trocar a cada uso.
5. **Decisão e plano pedem Marcha.** "Decidir entre opções", "criar plano" e qualquer raciocínio multi-etapa ganham a letra **M** (passo a passo explícito), porque é onde a IA mais erra pulando etapas.
6. **Brainstorm relaxa a Proteção.** Em brainstorm/ideação, afrouxe limites e peça quantidade e variedade antes de qualidade — o filtro vem depois.
7. **Na dúvida entre dois padrões, combine.** Ex.: "resuma este contrato e me diga os riscos" = resumir + extrair informação. Use o template do padrão dominante e enxerte os campos do outro.

## Como consultar as referências

Leia o arquivo de referência **sob demanda**, conforme o que o pedido exige — não carregue tudo de uma vez.

| Quando | Arquivo |
|---|---|
| Detalhar/explicar cada letra do método, ou decidir o que perguntar | `reference/prompter-metodo.md` |
| Escolher o "Aja como..." (Papel) certo | `reference/papeis.md` |
| Pegar template + exemplo do tipo de tarefa | `reference/padroes-por-tarefa.md` |
| Diagnosticar por que um prompt está ruim / consertar | `reference/anti-padroes.md` |
| Ajustar o prompt para Claude, GPT ou Gemini | `reference/dicas-por-modelo.md` |

Fluxo típico: identifique o tipo de tarefa → abra `padroes-por-tarefa.md` para o template → use `papeis.md` para o Papel → use `prompter-metodo.md` se precisar refinar uma letra → entregue. Se for melhoria de prompt, comece por `anti-padroes.md`.
