# Método P.R.O.M.P.T.E.R. — em profundidade

O P.R.O.M.P.T.E.R. é o esqueleto de qualquer prompt profissional. Não é um formulário a preencher religiosamente: é uma checklist de **decisões**. Para cada letra você decide se a inclui, com quanta força, e se precisa perguntar algo ao usuário.

Princípio central (a engenharia por trás do vibecoding): **um prompt é uma especificação executável.** Quanto mais ambíguo o spec, mais a IA "chuta". Cada letra do método remove uma fonte de chute.

As 8 letras:

- **P** — Papel
- **R** — Realidade
- **O** — Objetivo
- **M** — Marcha
- **P** — Proteção
- **T** — Texto de saída
- **E** — Exemplos
- **R** — Refino

Para tarefas simples, **Papel + Objetivo + Texto de saída** já bastam. As demais letras entram conforme complexidade e risco.

---

## P — Papel

**O que é:** quem a IA deve "ser" ao responder. Define repertório, vocabulário, prioridades e ponto de vista.

**Por que importa:** o mesmo pedido respondido por "um redator iniciante" e por "um copywriter sênior de resposta direta" produz textos completamente diferentes. O Papel calibra o nível e o foco da resposta antes de qualquer instrução.

**O que perguntar / decidir:**
- Que tipo de especialista resolveria isso no mundo real?
- Qual a senioridade? ("júnior" vs "sênior com 15 anos" muda o rigor).
- Tem um ponto de vista específico? (ex.: "advogado *do réu*", "revisor *cético*").
- Para quem essa pessoa fala? (audiência muda o Papel: "professor explicando para uma criança de 10 anos").

**Como escrever:** comece com "Você é..." ou "Aja como...". Seja específico e adicione 1-2 traços de prioridade.
- Fraco: "Você é um escritor."
- Forte: "Você é um copywriter sênior de resposta direta, especialista em SaaS B2B. Você prioriza clareza e prova sobre adjetivos."

**Default quando o usuário não diz:** escolha o especialista óbvio para a tarefa (veja `papeis.md`) e sinalize: "Assumi o papel de X — troque se quiser outro."

**Armadilha:** Papel genérico demais ("um assistente útil") não calibra nada. Sempre que possível, dê uma profissão e um nível.

---

## R — Realidade

**O que é:** o contexto do mundo real — dados, fatos, restrições, histórico, ambiente. É o que diferencia "escreva um e-mail de cobrança" de "escreva um e-mail de cobrança para um cliente que já atrasou 2 vezes, é importante para nós, e a fatura venceu há 5 dias".

**Por que importa:** a IA não sabe nada do seu mundo. Sem Realidade, ela inventa um cenário médio e responde para ele. A maior parte da diferença entre um prompt amador e um profissional está aqui.

**O que perguntar / decidir:**
- Que dados/fatos a IA precisa ter em mãos? (cole-os no prompt).
- Quem é o público final do resultado?
- Que restrições reais existem? (orçamento, prazo, tom da marca, regras de compliance, limite de caracteres).
- O que já foi tentado / o que já existe?
- Qual o cenário de uso (onde isso vai ser usado, por quem, com que stakes)?

**Como escrever:** uma seção rotulada, ex.:
```
Contexto:
- Produto: [...]
- Público: [...]
- Restrições: [...]
- Dados de entrada: [cole aqui]
```

**Default quando o usuário não diz:** liste explicitamente as suposições que você fez ("Assumi que o público é B2B e o tom é profissional") para o usuário corrigir.

**Armadilha:** despejar contexto irrelevante. Realidade é o contexto *que muda a resposta*, não um dump de tudo.

---

## O — Objetivo

**O que é:** o resultado concreto e verificável que se quer. Não a tarefa ("escrever copy"), mas o **resultado** ("uma headline que aumente cliques no anúncio do Facebook para o público de fundadores").

**Por que importa:** sem objetivo claro, a IA otimiza para "parecer útil", não para o que você precisa. Objetivo é o critério de sucesso.

**O que perguntar / decidir:**
- Qual o resultado em uma frase? Como você saberá que ficou bom?
- O que essa resposta precisa *fazer* (informar, convencer, decidir, gerar código que roda)?
- Tem uma métrica? (mais conversão, menos palavras, zero erro de fato).

**Como escrever:** "Seu objetivo é [resultado concreto], de forma que [critério de sucesso]."
- Fraco: "Escreva sobre nosso produto."
- Forte: "Seu objetivo é escrever uma seção de landing page que faça um fundador cético entender o valor em 10 segundos e clicar em 'testar grátis'."

**Default:** infira o resultado provável e confirme em uma linha.

**Armadilha:** confundir tarefa com objetivo. "Resumir" é tarefa; "resumir para que um diretor decida em 2 minutos se aprova o projeto" é objetivo.

---

## M — Marcha

**O que é:** o passo a passo de *como* a IA deve trabalhar — a sequência de raciocínio ou as etapas da tarefa. É o "pense assim" / "faça nesta ordem".

**Por que importa:** em tarefas multi-etapa (decidir, planejar, depurar, analisar), a IA erra pulando etapas ou misturando análise com conclusão. Forçar a marcha melhora muito a qualidade do raciocínio.

**O que perguntar / decidir:**
- Esta tarefa tem etapas naturais? Quais, em que ordem?
- A IA deve raciocinar antes de concluir? (peça "primeiro analise, depois decida").
- Precisa checar algo antes de responder?

**Como escrever:** uma lista numerada de etapas, ou "Siga estes passos:".
```
Siga estes passos, nesta ordem:
1. Liste os critérios de decisão.
2. Avalie cada opção contra cada critério.
3. Só então recomende uma, justificando.
```
Para raciocínio, vale pedir: "Pense passo a passo antes de dar a resposta final."

**Default:** para tarefas simples, omita. Para decisão/plano/depuração, sempre inclua.

**Armadilha:** microgerenciar etapas óbvias em tarefas simples — vira ruído. Use Marcha onde há risco de pular etapas.

---

## P — Proteção

**O que é:** os limites — o que a IA NÃO deve fazer, como tratar incerteza, o que fazer quando faltar informação. É a barra de segurança da resposta.

**Por que importa:** sem Proteção, a IA inventa fatos (alucina), preenche lacunas com suposições, ultrapassa escopo, ou dá opinião onde devia pedir mais dados. Em tarefas de risco (jurídico, saúde, dinheiro, código em produção), a Proteção é inegociável.

**O que perguntar / decidir:**
- O que a IA NÃO pode fazer aqui? (inventar números, dar conselho médico/jurídico definitivo, exceder X palavras).
- Como tratar incerteza? ("Se não tiver certeza, diga que não sabe em vez de chutar.")
- O que fazer se faltar informação? ("Se faltar dado X, pergunte antes de prosseguir.")
- Há fontes/dados que NÃO pode usar? Há tom proibido?

**Como escrever:** uma seção "Regras / Restrições":
```
Regras:
- Não invente dados, números ou citações. Se não souber, diga "não tenho essa informação".
- Não ultrapasse 150 palavras.
- Se faltar [X], pergunte antes de responder.
- Baseie-se apenas no contexto fornecido acima.
```

**Default:** para qualquer tarefa de risco, inclua ao menos "não invente fatos; sinalize incerteza".

**Armadilha:** excesso de regras contraditórias engessa o modelo. Poucas regras, claras e priorizadas.

---

## T — Texto de saída

**O que é:** o formato, tom, tamanho e estrutura da resposta. Markdown ou texto puro? Tabela, lista, JSON, parágrafo? Quão longo? Que tom?

**Por que importa:** é a letra que mais controla utilidade prática. Uma resposta certa no formato errado é inútil (ex.: você queria CSV e veio prosa). Definir o formato também reduz variação entre execuções.

**O que perguntar / decidir:**
- Que formato exato? (JSON com estas chaves / tabela com estas colunas / 3 bullets / e-mail pronto).
- Tamanho? (1 frase / 1 parágrafo / no máximo 200 palavras).
- Tom? (formal, casual, técnico, vendedor, neutro).
- Idioma? Algo proibido no formato? (ex.: "sem emojis", "sem introdução, vá direto ao ponto").

**Como escrever:** descreva o formato exato e, quando possível, mostre o esqueleto:
```
Formato da resposta:
- Markdown.
- Comece direto, sem introdução.
- Estrutura: ## Título, depois 3 a 5 bullets.
- Máximo 200 palavras. Tom direto, PT-BR.
```
Para saída de máquina, especifique o schema: "Responda APENAS com JSON válido neste formato: {...}".

**Default:** escolha o formato mais útil para o uso provável e sinalize.

**Armadilha:** pedir formato rígido sem dar um exemplo do formato — para JSON/tabela, combine sempre T com E (Exemplos).

---

## E — Exemplos

**O que é:** 1 a 3 exemplos do que é "bom" (e, às vezes, do que é "ruim"). É o few-shot: mostrar em vez de só descrever.

**Por que importa:** exemplos transmitem padrões que descrição nenhuma captura — estilo, nível de detalhe, formato exato. Um exemplo bom vale por dez frases de instrução. É a alavanca mais subutilizada por iniciantes.

**O que perguntar / decidir:**
- Você tem um exemplo de saída boa (mesmo de outra fonte)? Cole.
- Tem um exemplo de saída RUIM para a IA evitar?
- O formato é rígido? Então um exemplo de formato é obrigatório.

**Como escrever:**
```
Exemplo de entrada → saída esperada:

Entrada: "cliente reclamou que o app trava ao abrir fotos"
Saída esperada:
{ "categoria": "bug", "severidade": "alta", "area": "midia" }

Agora faça o mesmo para a entrada real abaixo.
```
Para estilo, basta colar 1 trecho-modelo: "Escreva no estilo deste exemplo: [trecho]".

**Default:** se a tarefa tem formato rígido ou estilo específico, NÃO pule esta letra — gere você mesmo um exemplo plausível e marque como "exemplo (ajuste se não bater)".

**Armadilha:** exemplos contraditórios entre si, ou exemplos que vazam para a resposta (a IA copia o exemplo). Deixe claro: "use o exemplo apenas como referência de formato/estilo, não copie o conteúdo".

---

## R — Refino

**O que é:** o plano de iteração. Um prompt raramente nasce perfeito. Refino é como você testa e melhora — e é a parte mais "engenharia" do método.

**Por que importa:** vibecoding com engenharia = tratar o prompt como código que se versiona e melhora com base em resultado real, não no achismo.

**Como orientar o usuário (entregue 1 dica concreta no fim de cada prompt):**
- **Teste de variação:** rode o prompt 2-3 vezes. Se a saída variar muito, o prompt está ambíguo — adicione um Exemplo ou aperte o Texto de saída.
- **Isolar a falha:** se a saída erra sempre na mesma coisa, identifique qual letra falhou. Formato errado → reforce T+E. Inventou fato → reforce Proteção. Nível errado → ajuste Papel. Pulou etapa → adicione Marcha.
- **Uma mudança por vez:** mude uma letra, reteste, compare. Mudar tudo de uma vez impede saber o que melhorou.
- **Endurecer aos poucos:** comece permissivo, vá adicionando restrições só onde a saída desviou. Não pré-encha o prompt de regras que talvez nem precise.
- **Salvar o vencedor:** quando um prompt ficar bom para uma tarefa recorrente, transforme em template com `[VARIÁVEIS]` e guarde.

**Como escrever (opcional, dentro do prompt):** você pode pedir auto-refino — "Depois de responder, aponte 1 forma de tornar este prompt melhor da próxima vez." Útil para descobrir o que faltou.

---

## Resumo operacional

| Letra | Pergunta-chave | Inclua quando |
|---|---|---|
| **P**apel | Quem resolveria isso? | Quase sempre |
| **R**ealidade | Que contexto muda a resposta? | Quase sempre |
| **O**bjetivo | Qual o resultado e como medir sucesso? | Sempre |
| **M**archa | Tem etapas / precisa raciocinar? | Decisão, plano, depuração, análise |
| **P**roteção | O que NÃO fazer / como tratar incerteza? | Tarefas de risco; saída factual |
| **T**exto de saída | Que formato/tom/tamanho exato? | Sempre |
| **E**xemplos | Tenho exemplo de "bom"? | Formato rígido, estilo específico, alta exigência |
| **R**efino | Como testar e melhorar? | Entregar 1 dica sempre |
