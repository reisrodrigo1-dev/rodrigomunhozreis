# Cláusulas essenciais de um contrato simples

> Parte da skill **Pacto** — vibecoding com engenharia, por Rodrigo Munhoz Reis.

## ⚠️ Aviso jurídico

Este material é **didático**. Explica o que cada cláusula faz e protege para você montar um **rascunho** consciente — **não é parecer jurídico e não substitui um advogado.** A redação exata, a validade no seu caso e os efeitos legais dependem de detalhes que só um profissional avalia. Leis e jurisprudência mudam. **Antes de assinar qualquer contrato, mande revisar por um advogado.** A decisão é sua.

---

Um contrato simples pode ser curto, mas precisa de um núcleo de cláusulas. Cada uma resolve uma pergunta que, se ficar no ar, vira conflito. Abaixo, o que cada cláusula é, o que ela protege e o erro comum.

## 1. Qualificação das partes

**O que é:** a identificação completa de quem está contratando e quem está sendo contratado. Nome completo / razão social, CPF / CNPJ, endereço, e — útil — e-mail e representante legal (no caso de empresa).

**O que protege:** define exatamente quem está obrigado pelo contrato. Sem isso, você não sabe contra quem cobrar ou quem responde. Distingue se a parte é pessoa física ou jurídica — o que muda tributação e responsabilidade.

**Erro comum:** identificar só pelo primeiro nome ou "a empresa". Se der briga, não dá para individualizar o responsável.

## 2. Objeto

**O que é:** a descrição do que será feito ou entregue. O serviço, o produto, o trabalho — com escopo: o que está **dentro** e, idealmente, o que está **fora**.

**O que protege:** é o coração do contrato. Define a obrigação principal. Um objeto bem escrito impede o "escopo que incha" (cliente pedindo cada vez mais pelo mesmo preço) e o "entregou menos do que combinou".

**Erro comum:** objeto vago ("desenvolvimento de site", "serviços de marketing"). Quanto mais específico (páginas, entregáveis, marcos, limites de revisão), menos espaço para interpretação conflitante.

## 3. Prazo (vigência)

**O que é:** quando o contrato começa e quando termina. Prazo **determinado** (com data de fim) ou **indeterminado**. Se há renovação, como ela ocorre (automática ou por acordo).

**O que protege:** evita que uma parte fique presa para sempre ou que a outra suma sem prazo. Define até quando valem as obrigações.

**Erro comum:** não definir prazo, ou prever renovação automática infinita sem porta de saída. Sempre combine prazo **com** a cláusula de rescisão.

## 4. Pagamento (preço e forma)

**O que é:** quanto será pago, como (à vista, parcelado, mensal, por entrega, por hora), quando vence cada parcela, e o que acontece em caso de atraso (juros, multa, correção, suspensão do serviço). Quem arca com impostos e taxas.

**O que protege:** é o que garante que o prestador recebe e que o cliente sabe o que vai pagar. A cláusula de atraso é o que transforma um calote de "ele disse, ela disse" em algo cobrável.

**Erro comum:** combinar só o valor total e esquecer datas, forma e consequência do atraso. Outro erro: não dizer quem paga imposto — vira surpresa no fechamento.

## 5. Obrigações das partes

**O que é:** o que cada lado se compromete a fazer além do óbvio. Do prestador: entregar no prazo, com qualidade, prestar contas. Do contratante: fornecer informações/acessos, pagar em dia, aprovar entregas em prazo razoável.

**O que protege:** deixa claro que o sucesso depende dos dois. Protege o prestador quando o cliente atrasa por não enviar material; protege o cliente quando o prestador não entrega.

**Erro comum:** listar só as obrigações do prestador. O contratante também tem deveres — se ele trava o projeto, isso precisa estar escrito.

## 6. Propriedade intelectual

**O que é:** define de quem fica o que for **criado** durante o trabalho — código, design, texto, marca, material. Se há **cessão** (transferência de direitos) do prestador para o cliente, ela precisa ser explícita: o que é cedido, de forma total ou parcial, e a partir de quando (em geral, após o pagamento integral).

**O que protege:** evita o conflito clássico — o cliente acha que "pagou, é meu"; o prestador, por lei, é o autor. No Brasil, a criação pertence a quem cria, salvo cessão escrita. Se o cliente precisa ser dono, **tem que estar no contrato, específico.**

**Erro comum:** não tratar PI, ou tratar de forma genérica ("todos os direitos do cliente"). Detalhe: prestador costuma querer reservar portfólio e ferramentas próprias/reutilizáveis — isso também se negocia aqui. **Este é o ponto que mais merece olho de advogado.**

## 7. Confidencialidade

**O que é:** o que é informação sigilosa, o que cada parte pode e não pode fazer com ela, e por quanto tempo o sigilo dura (inclusive após o fim do contrato). O que acontece se vazar.

**O que protege:** protege segredos de negócio, dados, estratégia, código, números — de qualquer lado. Essencial quando o trabalho dá acesso a informação sensível. (Quando o sigilo é o objetivo central da relação, o instrumento próprio é um NDA — ver `tipos-de-contrato.md`.)

**Erro comum:** confidencialidade que acaba junto com o contrato. Segredo costuma precisar durar **anos depois** do fim. E não definir o que é confidencial deixa a cláusula sem dente.

## 8. Rescisão

**O que é:** como o contrato termina antes da hora. Quem pode encerrar, com quanto aviso prévio, com ou sem multa, e o que acontece com o que já foi feito e já foi pago. Inclui rescisão por descumprimento (uma parte não cumpre, a outra pode sair).

**O que protege:** dá porta de saída para os dois lados e organiza o "fim do casamento". Sem ela, sair do contrato vira disputa sobre quem deve o quê.

**Erro comum:** não prever rescisão, ou prever multa só para um lado. Defina: aviso prévio, devolução/retenção de valores proporcionais ao trabalho feito, e o destino das entregas parciais.

## 9. Foro

**O que é:** a cidade/comarca onde eventuais conflitos serão resolvidos na Justiça. Pode também prever tentativa de solução amigável ou mediação antes.

**O que protege:** evita ter que litigar em outra cidade/estado, longe de você. Define a "casa" do conflito.

**Erro comum:** copiar o foro de um modelo aleatório (de outra cidade). Ajuste para a sua comarca — e saiba que cláusula de foro tem regras próprias que o advogado valida.

---

## Cláusulas de apoio (úteis, conforme o caso)

- **Multa por descumprimento** — penalidade por quebra de obrigação. Negocie o percentual.
- **Não solicitação / não aliciamento** — impede uma parte de "roubar" cliente ou funcionário da outra.
- **Caso fortuito / força maior** — o que acontece em eventos fora do controle das partes.
- **Disposições gerais** — alterações só por escrito, independência das cláusulas, comunicações oficiais.
- **LGPD / proteção de dados** — se o contrato envolve tratamento de dados pessoais, precisa de cláusula específica. Para isso, use a skill irmã **Salvaguarda**.

---

**De novo, porque importa:** o que está aqui te ajuda a montar um **rascunho** e a conversar de igual para igual com um profissional. Não é a palavra final. **Mande para um advogado revisar antes de assinar.** A decisão — e a responsabilidade — é sua.
