# Tipos de contrato simples: qual usar e o cuidado-chave

> Parte da skill **Pacto** — vibecoding com engenharia, por Rodrigo Munhoz Reis.

## ⚠️ Aviso jurídico

Este guia ajuda você a **escolher o tipo de rascunho** certo. Ele **não é parecer jurídico e não substitui um advogado.** A escolha errada de instrumento — ou a redação errada do certo — pode não te proteger ou criar risco (por exemplo, configurar vínculo trabalhista sem querer). Leis e jurisprudência mudam. **Antes de assinar, mande revisar por um advogado.** A decisão é sua.

---

Pacto cobre três tipos comuns no dia a dia de quem presta serviço ou contrata terceiros. Não cobre societário, trabalhista (CLT), imobiliário nem complexos — nesses, vá direto ao advogado.

## 1. Contrato de prestação de serviço

**O que é:** um lado (prestador) se obriga a executar um serviço ou entregar um resultado; o outro (contratante) paga por isso. É o contrato mais comum entre founders, freelancers e agências.

**Quando usar:**
- Você vai desenvolver um site, app, design, identidade, campanha, consultoria.
- Há uma entrega ou um período de trabalho definido, com preço acordado.
- A relação é entre prestador e cliente, sem subordinação (sem "chefe").

**Cuidado-chave:** o **objeto** e o **escopo**. É aqui que mora o "escopo que incha". Descreva com precisão o que está dentro, o que está fora, quantas revisões, quais entregáveis e marcos. E trate a **propriedade intelectual** com clareza — quem fica dono do que foi criado. Esses dois pontos sozinhos evitam a maioria dos conflitos.

**Base:** use `templates/prestacao-de-servico.md`.

## 2. NDA / Acordo de confidencialidade

**O que é:** um contrato cujo objetivo central é proteger informação sigilosa trocada entre as partes. Pode ser **unilateral** (só um lado revela segredo e o outro se obriga a guardar) ou **mútuo/bilateral** (os dois trocam segredos).

**Quando usar:**
- Antes de mostrar números, código-fonte, estratégia, base de clientes ou segredo de negócio a alguém de fora (parceiro, investidor em conversa inicial, prestador, candidato).
- Antes de uma negociação ou parceria em que informação sensível vai circular.
- Como **complemento** a um contrato de serviço, quando o trabalho dá acesso a dados confidenciais (às vezes vira só uma cláusula no contrato principal; às vezes, um documento à parte assinado antes).

**Cuidado-chave:** **definir o que é "informação confidencial"** e por **quanto tempo** o sigilo dura — inclusive depois de a relação terminar. Um NDA com definição vaga ou que expira junto com a conversa não protege nada. Defina também as exceções (o que já era público, o que a parte já sabia) e a consequência do vazamento. NDA bom é específico; NDA genérico é teatro.

## 3. Contrato de freelancer / prestador PJ

**O que é:** a contratação de um profissional autônomo (pessoa física) ou de uma pessoa jurídica (PJ / MEI) para executar um trabalho específico, **sem vínculo empregatício**. Na prática é uma prestação de serviço, mas com um risco específico que merece tratamento próprio.

**Quando usar:**
- Você (founder/empresa) contrata um dev, designer, redator, social media etc. como autônomo ou PJ.
- O trabalho é por projeto, por entrega ou por período, sem subordinação, horário fixo nem exclusividade típica de emprego.

**Cuidado-chave: NÃO configurar vínculo trabalhista.** Este é o risco número um. Se na prática a relação tiver os elementos de emprego — **pessoalidade** (só aquela pessoa pode fazer), **habitualidade** (rotina contínua), **subordinação** (recebe ordens, cumpre horário) e **onerosidade** (salário disfarçado de "nota") — a Justiça pode reconhecer vínculo CLT, com encargos retroativos, independentemente do que o papel diz. O contrato precisa refletir uma relação **genuinamente autônoma**: liberdade de método, sem horário imposto, sem exclusividade obrigatória, pagamento por entrega/projeto. **Este ponto é exatamente onde um advogado trabalhista é indispensável** — o texto do contrato não basta; a prática tem que bater.

Trate também aqui: **propriedade intelectual** (o que o freelancer cria geralmente precisa ser cedido ao contratante, por escrito) e **confidencialidade**.

---

## Resumo rápido

| Tipo | Use quando | Cuidado-chave |
|------|------------|---------------|
| Prestação de serviço | Há serviço/entrega definida por um preço | Objeto/escopo claros + propriedade intelectual |
| NDA / confidencialidade | Vai trocar informação sigilosa | Definir o que é sigiloso e por quanto tempo dura |
| Freelancer / PJ | Contrata autônomo/PJ por projeto | Não configurar vínculo trabalhista (CLT) |

**Pode usar mais de um:** ex. um NDA assinado antes da conversa e um contrato de prestação de serviço depois de fechado o trabalho.

---

**Lembrete que não cansa de valer:** isto te ajuda a montar um **rascunho** e escolher o caminho. Não é a palavra final. **Mande para um advogado revisar antes de assinar** — e, no caso de freelancer/PJ, considere um advogado trabalhista especificamente. A decisão é sua.
