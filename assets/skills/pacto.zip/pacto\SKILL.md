---
name: pacto
description: rascunha contratos simples (prestação de serviço, NDA, freelancer) como ponto de partida — NÃO substitui advogado; use ao precisar de um rascunho de contrato ou entender cláusulas essenciais.
---

# Pacto — rascunho de contratos simples para quem presta serviço

> Por Rodrigo Munhoz Reis — vibecoding com engenharia.
> Um ponto de partida claro, não um substituto de advogado. A decisão é sua.

## ⚠️ Aviso jurídico (leia antes de qualquer coisa)

**Esta skill gera um RASCUNHO. Um ponto de partida. NÃO é parecer jurídico, NÃO é aconselhamento legal e NÃO substitui um advogado.**

Três verdades que você precisa aceitar antes de usar isto:

1. **É rascunho, não documento final.** O que sai daqui serve para você organizar o acordo, entender o que precisa estar escrito e chegar mais barato e mais preparado na frente de um advogado. Não é para assinar como está.
2. **Leis mudam, casos são diferentes.** O que vale para um contrato pode ser nulo ou perigoso em outro. Detalhe, valor, setor, regime tributário e a relação entre as partes mudam tudo. Nenhum modelo genérico cobre o seu caso específico.
3. **Antes de assinar, mande para um advogado revisar.** Sempre. Especialmente se o contrato envolve valor alto, propriedade intelectual relevante, dados pessoais, exclusividade, longo prazo, ou qualquer coisa que doa se der errado. Um advogado custa menos que um processo.

Use isto para chegar a 80% organizado e saber exatamente o que perguntar para o profissional fechar os 20% que importam. **A decisão de usar, ajustar e assinar é sua — e a responsabilidade também.**

## Visão geral

Founder e prestador de serviço fecham acordo no WhatsApp, no aperto de mão, no "depois a gente formaliza". E depois não formaliza. Quando dá problema — cliente não paga, escopo incha, alguém vaza informação, a relação azeda — não há nada escrito que proteja ninguém.

Um contrato simples bem feito não é burocracia: é o mapa do combinado. Quem faz o quê, por quanto, até quando, de quem é o que foi produzido, o que acontece se alguém quiser sair. Pacto te ajuda a transformar um acordo informal num rascunho estruturado, cobrindo as cláusulas que todo contrato simples precisa, para então — e só então — levar a um advogado.

Esta skill cobre três tipos comuns no dia a dia de quem presta serviço ou contrata: **prestação de serviço**, **NDA/confidencialidade** e **contrato de freelancer/PJ**. Não cobre societário, trabalhista (CLT), imobiliário, M&A nem nada complexo — nesses casos, o caminho é direto para o advogado.

Faz parte da suíte **Engenho**. Quando o trabalho for **proposta comercial** (antes do contrato), use a skill irmã **Acordo**. Quando envolver **dados pessoais e LGPD** (que muitas vezes precisa virar cláusula no contrato), use a skill irmã **Salvaguarda**.

## Quando usar

Acione esta skill quando o trabalho envolver:

- Rascunhar um contrato de prestação de serviço entre prestador e cliente.
- Montar um NDA / acordo de confidencialidade antes de uma conversa, parceria ou projeto.
- Formalizar a contratação de um freelancer ou prestador PJ.
- Entender quais cláusulas um contrato simples precisa ter e o que cada uma protege.
- Revisar um contrato informal e ver o que está faltando antes de levar a um advogado.
- Preparar o material para uma consulta jurídica — chegar com o acordo já estruturado.

**Não acione (mande direto para o advogado) quando envolver:** vínculo trabalhista/CLT, contrato societário ou de sócios, distrato complexo, contratos de valor alto ou estratégicos, propriedade intelectual valiosa (patente, software-produto), imóveis, importação/exportação, litígio em andamento, ou qualquer situação onde um erro custa caro. Nesses casos, Pacto serve no máximo para organizar suas ideias antes da consulta.

## Procedimento

Cinco etapas, em ordem. A última não é opcional.

### Etapa 1 — Entender a relação

Antes de escolher modelo, entenda o acordo. Pergunte (ou levante) com clareza:

- **Quem são as partes?** Nome completo / razão social, CPF / CNPJ, endereço de cada lado. Pessoa física ou jurídica de cada parte — isso muda obrigações tributárias e trabalhistas.
- **O quê?** Qual é o objeto: o serviço, a entrega, o trabalho. Descreva com precisão o que está dentro e o que está fora do escopo. Vago aqui = briga depois.
- **Por quanto?** Valor, forma de pagamento (à vista, parcelado, por entrega, mensal, por hora), quando vence, o que acontece em atraso, quem paga impostos/taxas.
- **Por quanto tempo?** Prazo determinado (data de início e fim) ou indeterminado? Tem renovação? Como cada lado encerra antes da hora?

Saída: um resumo de uma tela com partes, objeto, valor/pagamento e prazo. Se algum desses quatro estiver indefinido, **resolva antes de rascunhar** — contrato não inventa o que as partes não combinaram.

### Etapa 2 — Escolher o tipo de contrato

Com a relação clara, escolha o modelo. Consulte `reference/tipos-de-contrato.md` para os critérios e o cuidado-chave de cada um.

- **Prestação de serviço** — um lado entrega um serviço/resultado, o outro paga. O mais comum. Use quando há uma entrega definida (um site, uma consultoria, um design, um período de trabalho).
- **NDA / confidencialidade** — protege informação sigilosa trocada entre as partes. Use antes de mostrar números, código, estratégia ou segredo de negócio a alguém de fora.
- **Freelancer / PJ** — contratação de um profissional autônomo ou pessoa jurídica para um trabalho específico, sem vínculo empregatício. Use ao contratar terceiros — com atenção máxima para não configurar vínculo trabalhista.

Pode ser mais de um: por exemplo, um NDA assinado antes e um contrato de prestação de serviço depois. Diga ao usuário qual(is) o caso pede.

### Etapa 3 — Preencher as cláusulas essenciais

Todo contrato simples precisa de um núcleo de cláusulas. Consulte `reference/clausulas-essenciais.md` — explica o que cada uma protege. O mínimo:

- **Qualificação das partes** — quem é quem, com dados completos.
- **Objeto** — o que será feito/entregue, com escopo claro.
- **Prazo** — quando começa, quando termina, renovação.
- **Pagamento** — quanto, como, quando, atraso e impostos.
- **Obrigações de cada parte** — o que cada lado se compromete a fazer.
- **Propriedade intelectual** — de quem fica o que for produzido.
- **Confidencialidade** — o que é sigiloso e por quanto tempo.
- **Rescisão** — como encerrar, aviso prévio, multas.
- **Foro** — onde se resolve um conflito.

Para prestação de serviço, parta de `templates/prestacao-de-servico.md` e preencha os placeholders com o resumo da Etapa 1. Para NDA ou freelancer, monte a partir das cláusulas essenciais aplicáveis (o template de prestação serve de base estrutural).

### Etapa 4 — Revisar os pontos sensíveis

Antes de fechar o rascunho, releia com lupa os quatro pontos que mais geram conflito. São onde um contrato simples vira um problema caro:

- **Pagamento** — está claro o valor, a data, a forma e o que acontece em atraso (juros, multa, suspensão do serviço)? Quem arca com impostos? Tem entrada / sinal? Sem isso, calote vira "ele disse, ela disse".
- **Propriedade intelectual** — quem fica com o que foi criado? Por padrão, no Brasil, o autor é o criador; se o cliente deve ser dono do código/design/conteúdo, a cessão precisa estar **escrita e específica**. Esquecer isto é o erro nº 1 de prestador.
- **Rescisão** — como cada lado sai? Tem aviso prévio? Multa? O que acontece com o trabalho já feito e o já pago? Contrato sem porta de saída prende os dois.
- **Confidencialidade** — o que não pode vazar, por quanto tempo, e o que acontece se vazar? Crítico em projetos com dados, estratégia ou código.

Saída: lista dos pontos sensíveis com o status (resolvido / precisa decisão / mandar pro advogado). Marque honestamente o que está acima da sua alçada.

### Etapa 5 — Mandar para um advogado revisar (antes de assinar)

**Esta etapa não é opcional e não é decorativa.** O rascunho está pronto para servir ao seu propósito: ser revisado por um profissional.

- Entregue o rascunho ao usuário deixando claro, de novo, que é um **ponto de partida**.
- Recomende explicitamente: **leve a um advogado antes de assinar.** Especialmente se houver valor alto, PI relevante, dados pessoais (acione **Salvaguarda**), exclusividade, longo prazo, ou contraparte com mais poder de barganha.
- Diga o que perguntar ao advogado: "essas cláusulas me protegem?", "a cessão de PI está correta?", "isso configura vínculo trabalhista?", "o foro e a rescisão fazem sentido?".
- Reforce: leis e jurisprudência mudam; o modelo é genérico; o caso dele é específico. **A assinatura é decisão e responsabilidade dele.**

## Arquivos de apoio

- `reference/clausulas-essenciais.md` — as cláusulas que todo contrato simples precisa e o que cada uma protege.
- `reference/tipos-de-contrato.md` — prestação de serviço, NDA e freelancer/PJ: quando usar cada um e o cuidado-chave.
- `templates/prestacao-de-servico.md` — modelo preenchível de contrato de prestação de serviço, com placeholders e aviso de revisão jurídica.

## Princípios de voz ao usar esta skill

- PT-BR, direto, sem hype. Diga o que o contrato cobre e o que não cobre.
- **Repita o disclaimer jurídico.** É rascunho, não parecer; revisar com advogado antes de assinar; leis mudam. Não tem "exagero" nisso — tema jurídico exige.
- Nunca afirme que algo "é legal" ou "está garantido". Você estrutura o acordo; quem valida juridicamente é o advogado.
- A decisão é do usuário. Você aponta a cláusula, o risco e a opção; ele escolhe e assina sob a própria responsabilidade.
- Contrato bom é o que as duas partes entendem. Prefira linguagem clara a juridiquês decorativo — mas avise que o advogado pode preferir a forma técnica.
