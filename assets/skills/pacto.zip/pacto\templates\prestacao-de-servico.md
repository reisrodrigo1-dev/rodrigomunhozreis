# Modelo — Contrato de Prestação de Serviço (RASCUNHO)

> Parte da skill **Pacto** — vibecoding com engenharia, por Rodrigo Munhoz Reis.

## ⚠️ AVISO JURÍDICO — LEIA ANTES DE USAR ESTE MODELO

**Este é um RASCUNHO / modelo genérico. Um ponto de partida. NÃO é parecer jurídico e NÃO substitui um advogado.**

- Os textos abaixo são genéricos e podem **não se aplicar** ao seu caso, ou aplicar-se de forma incompleta ou perigosa.
- Leis e jurisprudência mudam; valores, prazos e cláusulas precisam ser ajustados à sua realidade.
- **Antes de assinar, mande este documento para um advogado revisar.** Especialmente se houver valor alto, propriedade intelectual relevante, dados pessoais (use a skill irmã **Salvaguarda**), exclusividade ou longo prazo.

Preencha os campos entre `[colchetes]`. Apague esta seção de aviso só **depois** da revisão profissional — ou, melhor, mantenha como lembrete interno. **A decisão de usar e assinar é sua, e a responsabilidade também.**

---

# CONTRATO DE PRESTAÇÃO DE SERVIÇOS

Pelo presente instrumento particular, as partes abaixo qualificadas:

**CONTRATANTE:** `[Nome completo / Razão social]`, `[CPF / CNPJ nº ...]`, com endereço em `[endereço completo]`, neste ato representada por `[nome do representante, se PJ]`, doravante denominada simplesmente **CONTRATANTE**;

**CONTRATADO(A) / PRESTADOR(A):** `[Nome completo / Razão social]`, `[CPF / CNPJ nº ...]`, com endereço em `[endereço completo]`, doravante denominado(a) simplesmente **PRESTADOR**;

resolvem celebrar o presente Contrato de Prestação de Serviços, que se regerá pelas cláusulas a seguir.

## Cláusula 1 — Objeto

1.1. O PRESTADOR se obriga a executar para a CONTRATANTE os seguintes serviços: `[descreva com precisão o serviço/entrega — ex.: desenvolvimento de website institucional com até X páginas, conforme especificação no Anexo I]`.

1.2. Estão incluídos no escopo: `[liste o que está dentro]`.

1.3. **Não** estão incluídos no escopo (e serão tratados como serviço adicional, mediante novo acordo e valor): `[liste o que está fora — ex.: manutenção após a entrega, criação de conteúdo, novas funcionalidades não previstas]`.

1.4. Revisões/ajustes incluídos: `[ex.: até 2 rodadas de revisão por entrega; revisões adicionais serão cobradas à parte]`.

## Cláusula 2 — Prazo

2.1. O presente contrato vigora pelo prazo de `[ ___ ]`, com início em `[data]` e término em `[data ou "a conclusão da entrega"]`. *(Escolha: prazo determinado ou indeterminado.)*

2.2. Renovação: `[ex.: não há renovação automática / renova-se automaticamente por igual período salvo manifestação por escrito com X dias de antecedência]`.

2.3. Cronograma de entregas (se houver): `[marco 1 — data; marco 2 — data; ...]`.

## Cláusula 3 — Preço e forma de pagamento

3.1. Pela prestação dos serviços, a CONTRATANTE pagará ao PRESTADOR o valor total de `R$ [valor]` (`[valor por extenso]`).

3.2. Forma de pagamento: `[ex.: 50% como entrada na assinatura e 50% na entrega final / X parcelas mensais de R$ Y / por hora a R$ Z]`.

3.3. Vencimento(s): `[datas ou condições — ex.: até o dia X de cada mês / em até 5 dias após cada entrega]`.

3.4. Forma: `[PIX / transferência / boleto]`, para `[dados de pagamento]`.

3.5. **Atraso:** em caso de atraso no pagamento, incidirão `[ex.: multa de 2% sobre o valor em atraso, juros de 1% ao mês e correção monetária]`. A CONTRATANTE fica ciente de que `[ex.: o PRESTADOR poderá suspender os serviços e a entrega de materiais até a regularização]`.

3.6. **Impostos e taxas:** `[defina quem arca — ex.: os tributos incidentes sobre o serviço são de responsabilidade do PRESTADOR; eventuais taxas de transferência ficam a cargo de ___]`.

## Cláusula 4 — Obrigações das partes

4.1. **São obrigações do PRESTADOR:** executar os serviços com diligência e qualidade; cumprir os prazos acordados; manter a CONTRATANTE informada do andamento; `[outras]`.

4.2. **São obrigações da CONTRATANTE:** efetuar os pagamentos nas datas previstas; fornecer, em tempo hábil, as informações, materiais, acessos e aprovações necessários; `[outras]`. O atraso da CONTRATANTE em fornecer o necessário poderá prorrogar, na mesma medida, os prazos de entrega.

## Cláusula 5 — Propriedade intelectual

> ⚠️ **Cláusula sensível — peça revisão específica do advogado.** No Brasil, a criação pertence a quem cria, salvo cessão escrita.

5.1. `[ESCOLHA o cenário e ajuste:]`

- **Cenário A — cessão ao contratante:** Após o pagamento integral, o PRESTADOR cede à CONTRATANTE os direitos patrimoniais sobre os materiais especificamente produzidos para este projeto (`[ex.: código-fonte, arquivos de design, textos]`), para uso `[ex.: livre e por prazo indeterminado, no território nacional/mundial]`.
- **Cenário B — reserva do prestador:** O PRESTADOR reserva para si as ferramentas, bibliotecas, componentes reutilizáveis e know-how preexistentes, concedendo à CONTRATANTE apenas licença de uso para a finalidade do projeto.

5.2. O PRESTADOR poderá `[sim/não]` exibir o trabalho em seu portfólio, respeitada a confidencialidade da Cláusula 6.

## Cláusula 6 — Confidencialidade

6.1. Cada parte se obriga a manter sigilo sobre toda informação confidencial a que tiver acesso em razão deste contrato — `[ex.: dados, números, estratégias, código, base de clientes]` — não a divulgando a terceiros sem autorização escrita.

6.2. A obrigação de sigilo permanece em vigor por `[ex.: 2 (dois) anos]` **após** o término deste contrato.

6.3. Não se considera confidencial a informação que já era pública, que a parte já detinha licitamente, ou cuja divulgação seja exigida por lei/autoridade.

## Cláusula 7 — Rescisão

7.1. Qualquer das partes poderá rescindir este contrato mediante aviso prévio por escrito de `[ex.: 30 dias]`.

7.2. Em caso de rescisão, a CONTRATANTE pagará ao PRESTADOR o valor proporcional aos serviços efetivamente prestados até a data, e o PRESTADOR entregará o trabalho realizado até então. `[Defina o destino de entregas parciais e de valores já pagos.]`

7.3. O descumprimento de qualquer obrigação por uma das partes autoriza a outra a rescindir o contrato, sem prejuízo de `[ex.: multa de ___ e perdas e danos]`.

## Cláusula 8 — Disposições gerais

8.1. Qualquer alteração deste contrato só terá validade se feita por escrito e assinada por ambas as partes.

8.2. A nulidade de uma cláusula não invalida as demais.

8.3. Este contrato não estabelece vínculo empregatício, societário ou de subordinação entre as partes. *(Se a relação for de freelancer/PJ, este ponto exige atenção redobrada — ver `reference/tipos-de-contrato.md` e consultar advogado trabalhista.)*

## Cláusula 9 — Foro

9.1. As partes elegem o foro da Comarca de `[cidade/UF]` para dirimir quaisquer dúvidas ou conflitos oriundos deste contrato, com renúncia a qualquer outro, por mais privilegiado que seja. `[Opcional: as partes buscarão solução amigável/mediação antes de recorrer ao Judiciário.]`

---

E, por estarem assim justas e contratadas, as partes assinam o presente em duas vias de igual teor.

`[Cidade]`, `[data]`.

\
\_______________________________________
**CONTRATANTE** — `[nome]`

\
\_______________________________________
**PRESTADOR** — `[nome]`

Testemunhas (opcional):

1. `[nome / CPF]`
2. `[nome / CPF]`

---

## ⚠️ Antes de assinar (de novo)

Este documento é um **RASCUNHO**. Releia os pontos sensíveis — **pagamento, propriedade intelectual, rescisão, confidencialidade** — e **mande para um advogado revisar antes de assinar.** Leis mudam, seu caso é específico, e a responsabilidade pela assinatura é sua.
