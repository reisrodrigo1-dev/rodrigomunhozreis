# Padrões de arquitetura

> Base pesquisável da Bússola. Para cada padrão: **o que é** (em português simples), **quando usar**, **quando NÃO usar** e a recomendação no mundo da rota padrão (Next.js + Firebase + Vercel).
> Princípio que atravessa tudo: **não resolva problema que você não tem.** Cada peça nova é custo, falha potencial e mais coisa pra IA errar. Só adicione com um gatilho concreto.

---

## 1. Monolito vs Serviços (microsserviços)

**Monolito:** um único aplicativo que faz tudo (frontend + API + lógica) em um projeto e um deploy. No mundo Next, o app inteiro (páginas + Route Handlers) é um monolito — e isso é ótimo.

**Microsserviços:** o sistema é quebrado em vários serviços pequenos e independentes, cada um com seu deploy, às vezes seu banco. Cada um escala e falha sozinho.

**Quando usar monolito (quase sempre, começando):**
- Time pequeno (1 a poucas pessoas), produto novo, MVP, SaaS começando.
- Você quer um lugar só para entender, depurar e fazer deploy.
- **Default absoluto para quem está começando.** Um Next na Vercel é um monolito e aguenta muito mais do que você imagina.

**Quando considerar serviços:**
- Times grandes que precisam trabalhar e fazer deploy **independentes**.
- Uma parte tem necessidade **radicalmente diferente** (ex.: processamento de vídeo/ML pesado que precisa escalar e falhar isolado do resto).
- Escala comprovada em que partes do sistema têm cargas muito diferentes.

**Não use serviços quando:** você ainda é um time pequeno sem o problema que microsserviços resolvem. Eles trocam complexidade de código por complexidade de operação (rede, observabilidade, deploys coordenados, consistência distribuída). É a forma mais comum de over-engineering em projeto novo.

**Meio-termo prático:** monolito modular — código bem organizado em módulos dentro de um só projeto. Você ganha clareza sem pagar o custo de operar uma frota de serviços. Comece aqui; extraia um serviço só quando uma parte gritar por isolamento.

---

## 2. Renderização no Next: SSR, SSG, ISR, CSR

Como a página é montada muda performance, custo e SEO. Em português direto:

- **SSG (Static Site Generation):** a página é gerada **uma vez no build** e servida como arquivo pronto. Mais rápida e barata possível. **Use para:** conteúdo que não muda por requisição — landing, blog, docs, páginas de marketing.
- **SSR (Server-Side Rendering):** a página é montada **no servidor a cada visita**, com dados frescos. **Use para:** páginas que dependem do usuário logado ou de dados que mudam a toda hora (dashboard, feed personalizado).
- **ISR (Incremental Static Regeneration):** estático que **se atualiza sozinho** a cada X tempo (ou sob demanda). O melhor dos dois mundos: rápido como estático, fresco como dinâmico. **Use para:** catálogo de produtos, listagem de blog com posts novos, páginas semi-dinâmicas com muito tráfego.
- **CSR (Client-Side Rendering):** o navegador busca os dados depois de carregar a página (React puro no cliente). **Use para:** áreas internas atrás de login onde SEO não importa (um painel), ou trechos muito interativos.

**Regra de bolso:** comece **estático (SSG)** e só vá para dinâmico (SSR) na parte que **realmente** precisa de dado por-requisição. Para muito tráfego em conteúdo semi-dinâmico, **ISR** quase sempre é a resposta. SSR em tudo = pagar compute à toa e perder velocidade.

**Armadilha de custo:** marcar páginas como dinâmicas sem necessidade faz a Vercel executar função a cada visita — a fatura sobe com o tráfego. Estático escala de graça.

---

## 3. Autenticação e autorização (auth)

**Autenticação** = provar quem você é (login). **Autorização** = decidir o que você pode fazer/ver. São coisas diferentes; as duas importam.

**Onde a auth deve viver:** **no servidor.** Verificação de "está logado?" e "pode acessar isto?" precisa acontecer no backend (route handler, regra de banco, middleware) — **nunca** só esconder um botão no front. O navegador é território hostil.

**Recomendações por contexto:**
- **Rota padrão:** **Firebase Auth** — login pronto (e-mail/senha, Google, Apple, telefone), integra com as regras do Firestore (autorização no próprio banco). Default para começar.
- **Supabase Auth** — equivalente no mundo Postgres; integra com Row Level Security (autorização por linha no banco). Default quando o banco é Supabase.
- **Auth.js (NextAuth) / Clerk / Lucia** — quando você não usa Firebase/Supabase e precisa montar auth no Next. **Clerk** é o mais "pronto" (UI, organizações, MFA) e bom para não-técnico, porém pago ao crescer. **Auth.js** é flexível e grátis, mas você monta mais. **Lucia** dá controle total para quem é técnico.

**Padrões de autorização:**
- **Por dono (ownership):** o registro pertence a um `uid`; a regra/consulta só deixa o dono acessar. É o padrão mais comum e cobre a maioria dos SaaS. **Sempre filtre por dono no servidor/regra**, não só no front.
- **Por papel (RBAC):** papéis (admin, editor, viewer) definem permissões. Use quando há níveis de acesso claros.
- **Multi-tenant:** dados separados por organização/time. Em Postgres, Row Level Security; em Firestore, estrutura por `orgId` + regras. Planeje cedo se o produto é B2B com times.

**Armadilha clássica (IDOR):** confiar num id vindo do cliente sem checar se aquele usuário é o dono. Sempre valide a posse no backend.

---

## 4. Banco de dados: Relacional (SQL) vs NoSQL/Firestore

**Relacional (Postgres, MySQL):** dados em tabelas com relações fortes e queries flexíveis (joins, agregações, relatórios). Estrutura definida e consistente. **Use quando:** os dados têm muitas relações (usuários ↔ pedidos ↔ itens ↔ produtos), você precisa de relatórios/queries complexas, integridade forte importa (financeiro, estoque, marketplace), ou você pensa naturalmente em "tabelas e joins".

**NoSQL de documentos (Firestore, MongoDB):** dados em documentos flexíveis (tipo JSON), sem esquema rígido, escala horizontal fácil, ótimo para tempo real. **Use quando:** dados ligados a um usuário, estrutura evolui rápido, você quer tempo real (atualização ao vivo na tela), e as consultas são simples (buscar os documentos de um usuário). Default da rota padrão.

**Critério de decisão objetivo:**
- Se você se pega querendo **JOIN, GROUP BY, relatório cruzando muitas entidades** → **relacional (Postgres/Supabase)**.
- Se os dados são **por-usuário, simples de buscar, e tempo real ajuda** → **Firestore**.
- **Marketplace, ERP, financeiro, estoque, qualquer coisa com relações ricas** → relacional, sem titubear.
- **Chat, feed, presença ao vivo, MVP simples por-usuário** → Firestore brilha.

**Armadilha cara no Firestore:** modelar como relacional e fazer "joins na mão" — várias leituras por tela (problema N+1). No Firestore você paga **por leitura de documento**, então isso explode a conta e a latência. Se o modelo é relacional, use um banco relacional. No Firestore, **desnormalize** (duplique dados de propósito) para ler em poucas operações.

**Meio-termo:** Supabase entrega Postgres com a facilidade gerenciada do Firebase (auth, storage, API automática, tempo real). É a ponte natural quando você quer relacional sem montar tudo.

---

## 5. Armazenamento de arquivos (storage)

Imagens, uploads, PDFs, vídeos — **não** vão no banco; vão em storage de objetos.

- **Firebase Storage** — default da rota padrão; integra com Firebase Auth e regras. Bom para avatar, uploads de usuário, mídia de app.
- **Supabase Storage** — equivalente no mundo Supabase.
- **AWS S3 / Cloudflare R2 / Backblaze B2** — quando o volume cresce. **R2 não cobra egress (saída de dados)**, o que economiza muito em projeto com muito download/streaming. S3 é o padrão de mercado, mas egress pesa.
- **CDN de imagem (Cloudinary, ImageKit, ou o Image Optimization da Vercel/Next)** — quando você serve muitas imagens e quer redimensionar/otimizar automático.

**Regras:** valide tipo e tamanho no upload; nunca confie no `Content-Type` do cliente; sirva com o tipo correto (SVG pode carregar script — cuidado). Para downloads privados, use **URLs assinadas** com expiração, não link público.

**Armadilha:** guardar arquivo (base64) dentro do documento/registro do banco. Incha o banco, encarece leitura e estoura limites. Arquivo no storage, **referência (URL/caminho) no banco**.

---

## 6. Filas e processamento assíncrono

**O que é:** em vez de fazer o trabalho pesado na hora da requisição (e segurar o usuário esperando), você **enfileira** a tarefa e um **worker** processa em segundo plano. O usuário recebe "estamos processando" na hora.

**Quando usar (gatilhos concretos):**
- Tarefa demora mais que alguns segundos: enviar muitos e-mails, gerar relatório/PDF pesado, processar vídeo/imagem, chamar IA em lote.
- Trabalho que **estoura o timeout** de uma serverless function (Vercel/Functions cortam tarefas longas).
- Picos de carga: enfileirar absorve o pico sem derrubar o sistema.
- Retry confiável: tarefa que precisa tentar de novo se falhar (webhook, integração externa).

**Quando NÃO usar:** se tudo termina rápido dentro da requisição, fila é complexidade sem retorno. **Não adicione fila por precaução** — adicione quando uma tarefa específica está estourando o tempo.

**Opções:** **Inngest** ou **Trigger.dev** (ótimos com Next/Vercel, gerenciados, fáceis para quem não quer operar infra), filas do **Cloud Tasks/Pub-Sub** (Google), **QStash** (Upstash, simples), ou **BullMQ + Redis** (se você opera infra própria). Para o começo, prefira o gerenciado.

---

## 7. Cache

**O que é:** guardar resultado pronto para não recalcular/refazer a mesma busca toda vez. Deixa mais rápido e mais barato.

**Camadas de cache, da mais simples para a mais complexa:**
1. **CDN / estático (Vercel, Cloudflare):** o mais fácil e poderoso. Páginas estáticas e ISR já são servidas da borda, perto do usuário. **Comece por aqui** — resolve a maioria.
2. **Cache de dados no framework:** o Next cacheia `fetch` e dados; ISR é cache de página. Muitas vezes basta usar bem o que o framework já dá.
3. **Cache dedicado (Redis — Upstash):** quando você precisa guardar resultado de consulta cara, sessão, rate limit, contadores. **Upstash Redis** é serverless e casa com Vercel.

**Quando adicionar Redis (gatilho):** consulta cara e repetida ao banco que pesa na fatura/latência; rate limiting; dados quentes lidos muitas vezes. **Não comece com Redis** — adicione quando medir um gargalo real.

**Armadilha:** cache resolve velocidade, mas cria o problema de **invalidação** (dado velho na tela). Cacheie o que pode ficar levemente desatualizado; não cacheie o que precisa estar sempre exato sem um plano de invalidação.

---

## 8. Tempo real (realtime)

Atualização ao vivo na tela sem o usuário recarregar (chat, presença, notificações, colaboração).

- **Firestore** — tempo real nativo: você "escuta" um documento/coleção e a tela atualiza sozinha. Razão forte para escolher Firebase quando tempo real é central.
- **Supabase Realtime** — escuta mudanças no Postgres ao vivo. Equivalente no mundo relacional.
- **Pusher / Ably / WebSockets próprios** — quando precisa de controle fino ou já não usa Firebase/Supabase.

**Quando usar:** chat, dashboards ao vivo, colaboração simultânea, status que muda (pedido "em preparo → a caminho"). **Quando não:** se atualizar ao recarregar ou a cada X segundos (polling) já resolve, tempo real é complexidade extra. Nem todo "ao vivo" precisa de WebSocket.

---

## 9. Gatilhos: quando adicionar cada peça (resumo)

Use como checklist anti-over-engineering. **Sem o gatilho, não adicione.**

| Peça | Adicione SÓ quando... | Antes disso, use... |
|---|---|---|
| Microsserviço | Times independentes ou parte com escala/falha radicalmente diferente | Monolito modular |
| SSR (dinâmico) | A página depende mesmo de dado por-requisição | SSG / ISR |
| Fila + worker | Tarefa estoura timeout ou demora segundos | Fazer na requisição |
| Redis (cache) | Consulta cara repetida medida como gargalo | CDN + cache do framework |
| Banco relacional extra | Relações ricas / relatórios / integridade forte | Firestore por-usuário |
| Tempo real (WebSocket) | Colaboração/chat/status ao vivo de verdade | Recarregar / polling |
| Search dedicado (Algolia/Meili) | Busca textual rica que o banco não atende bem | Query do próprio banco |
| Multi-região / réplica | Latência global comprovada ou exigência de compliance | Uma região + CDN |

> Regra de ouro: cada linha desta tabela é uma promessa de mais custo e mais operação. Compre só o que o problema atual exige. O resto é dívida disfarçada de previdência.
