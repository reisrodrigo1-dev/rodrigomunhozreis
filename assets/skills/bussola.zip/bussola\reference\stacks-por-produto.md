# Stacks por tipo de produto

> Base pesquisável da Bússola. Para cada tipo de produto: **stack recomendada**, **alternativas sérias** e **quando escolher cada uma**.
> A "rota padrão" do autor é Next.js + Firebase + Vercel + Tailwind + GitHub. Aqui está onde ela vence e onde outra coisa vence.
> Lembrete: a decisão é do dono do produto. Isto é recomendação fundamentada, não dogma.

Como ler cada bloco:
- **Recomendada** = o default para quem está começando (não-técnico ou júnior), escala inicial pequena/média.
- **Alternativas** = opções sérias, com o gatilho que as torna a escolha certa.
- **Quando escolher cada uma** = o critério de decisão objetivo.
- **Armadilhas** = os erros comuns que a Bússola evita.

---

## 1. Landing page / Site institucional

Páginas de marketing, "quem somos", captação de e-mail/lead, sem login nem dados por usuário. O que importa: carregar rápido, aparecer no Google (SEO), ser barato.

**Recomendada:** **Astro + Tailwind + Vercel (ou Cloudflare Pages).** Formulário via serviço pronto (Formspree, ou uma função serverless gravando no Firestore/Resend para e-mail).
- Por quê: Astro gera HTML estático, então a página é praticamente instantânea e o SEO é impecável. Hospedagem estática é a coisa mais barata que existe (free tier sobra de longe).

**Alternativas:**
- **Next.js (SSG) + Vercel** — escolha se a landing é parte de um app maior que já é Next, ou se você já sabe Next e não quer aprender Astro. Funciona muito bem; é só um pouco mais "pesado" que Astro para puro conteúdo.
- **Framer / Webflow / Carrd (no-code)** — escolha se ninguém vai escrever código e a página é simples. Rápido de publicar, mas você fica preso à ferramenta e ao plano mensal.
- **WordPress** — escolha só se o cliente já vive no WordPress ou precisa que um não-técnico edite tudo via painel. Caro de manter seguro; evite para projeto novo.

**Quando escolher cada uma:**
- Conteúdo puro, quer o mais rápido/barato e SEO → **Astro**.
- Já é um app Next → **Next.js SSG** (não monte dois projetos).
- Sem código, simples, urgente → **no-code (Framer/Carrd)**.

**Armadilhas:** usar Next.js com SSR (servidor a cada visita) para uma página estática — paga compute à toa e fica mais lento. Para conteúdo, gere estático (SSG).

---

## 2. SaaS (aplicação web com contas de usuário)

Produto com login, dados por usuário, painel, planos pagos, talvez tempo real. O coração da maioria dos projetos de fundador.

**Recomendada (rota padrão):** **Next.js (App Router) + Firebase (Auth + Firestore + Storage) + Vercel + Tailwind + Stripe.**
- Por quê: tudo num ecossistema integrado. Auth pronta (e-mail, Google, etc.), banco em tempo real, deploy no `git push`, e a IA escreve esse stack muito bem. Você lança em dias, não semanas. Stripe para cobrança.

**Alternativas:**
- **Next.js + Supabase (Postgres + Auth + Storage) + Vercel** — escolha se os dados têm **relações ricas** (usuários ↔ times ↔ projetos ↔ permissões), se você quer **SQL** e relatórios, ou se quer reduzir lock-in (Postgres é portável). É a alternativa séria nº 1 à rota padrão. Curva um pouco maior, controle maior.
- **Next.js + Postgres dedicado (Neon/Railway) + Drizzle/Prisma + Auth.js** — escolha se você é dev experiente e quer controle total da camada de dados. Mais peças para montar e manter.
- **Remix / SvelteKit / Nuxt** no lugar do Next — escolha se você já domina esse framework. Tecnicamente ótimos; a desvantagem prática no vibecoding é menos exemplos para a IA do que Next.

**Quando escolher cada uma:**
- Começando, não-técnico/júnior, dados por-usuário simples, tempo real ajuda → **Firebase**.
- Pensa em "tabelas, joins, relatórios", quer SQL, time-based, multi-tenant relacional → **Supabase**.
- Dev sênior querendo controle e portabilidade máxima → **Postgres + ORM**.

**Armadilhas:** modelar no Firestore como se fosse relacional (joins manuais, leituras N+1 que explodem a fatura). Se você se pega "fazendo join na mão" o tempo todo, era Postgres.

---

## 3. E-commerce / Loja virtual

Vender produtos: catálogo, carrinho, checkout, pagamento, fiscal, frete, estoque. Pagamento e fiscal são onde mora o perigo.

**Recomendada (não quer manter o motor de venda):** **Shopify.** Tema customizado se precisar de cara própria.
- Por quê: checkout, pagamento, antifraude, fiscal, frete e estoque já resolvidos e mantidos por eles. Você foca em produto e marketing. Para a maioria das lojas, reinventar isso é desperdício.

**Alternativas:**
- **Next.js + Stripe (ou Mercado Pago/Pagar.me no Brasil) + Firebase/Supabase** — escolha quando a loja é **parte do seu produto** (experiência única, lógica de venda custom, assinaturas complexas, marketplace). Stripe cuida do pagamento; você cuida do catálogo e da experiência. Mais controle, muito mais trabalho (e responsabilidade fiscal é sua).
- **Medusa / Saleor (open-source headless)** — escolha se você é técnico, quer e-commerce próprio e controle total do backend. Poderoso e flexível; exige operação.
- **WooCommerce (WordPress)** — escolha se o cliente já é WordPress. Comum no Brasil para lojas pequenas; cuidado com manutenção e segurança.

**Quando escolher cada uma:**
- Quer vender rápido, sem manter infra de pagamento/fiscal → **Shopify**.
- A venda/experiência é o diferencial e você tem braço técnico → **Next + Stripe/gateway BR**.
- Loja simples e ecossistema já é WordPress → **WooCommerce**.

**Armadilhas:** construir checkout e cobrança "na mão" para economizar — é onde mais se erra (segurança, fiscal, conciliação). Use gateway (Stripe/Mercado Pago/Pagar.me) e, no Brasil, atenção a nota fiscal e split de pagamento. Atenção também à LGPD com dados de pagamento.

---

## 4. App Mobile

"Quero um app". A primeira pergunta é: precisa **mesmo** estar nas lojas, ou um site instalável resolve?

**Recomendada (precisa das lojas, reaproveitar web):** **Expo (React Native) + Firebase + EAS (build/deploy).**
- Por quê: um código para iOS e Android, em React (mesmo mundo do Next). Expo cuida de build, atualização over-the-air e publicação. Firebase fecha auth/banco/push. É o caminho de menor atrito para quem vem do web.

**Alternativas:**
- **PWA com Next.js** (instalável, funciona offline básico) — escolha quando "app" significa "ícone na tela e abre rápido", sem necessidade real de loja ou recurso nativo pesado. **Default para a maioria dos "quero um app".** Sem aprovação de loja, atualiza na hora, custo de web.
- **Flutter** — escolha se você/time já domina Dart/Flutter, ou quer UI muito customizada e performática igual nos dois sistemas. Ótimo, mas é outro ecossistema (menos sinergia com seu web React e menos exemplos React pra IA).
- **Nativo (Swift / Kotlin)** — escolha só com recurso nativo pesado (AR, BLE, jogos, hardware) ou exigência de performance/integração que Expo não cobre. Dobra o trabalho (dois apps).

**Quando escolher cada uma:**
- Precisa estar na App Store/Play e você vem do React → **Expo**.
- "App" é só presença instalável e velocidade → **PWA**.
- UI pesada/custom igual nos dois SOs e time topa Dart → **Flutter**.
- Recurso nativo pesado de verdade → **nativo**.

**Armadilhas:** ir para nativo (dobro de custo) quando um PWA resolveria; ou prometer "app na loja em uma semana" sem contar o tempo de revisão da Apple/Google e as exigências (conta de developer paga, política de privacidade, etc.).

---

## 5. Ferramenta interna / Painel administrativo

Uso interno da equipe: CRUD sobre dados, dashboards, automações. Ninguém de fora usa, então UX bonita importa menos que velocidade de construir.

**Recomendada (precisa de UI custom / vai virar produto):** **Next.js + Firebase/Supabase + Vercel**, com auth restrita ao time.
- Por quê: mesma rota padrão; controle total e pode evoluir para produto externo depois.

**Alternativas:**
- **Retool / Appsmith / Budibase (low-code de painel)** — escolha quando é **puro CRUD interno** sobre um banco existente e ninguém quer escrever frontend. Você arrasta componentes, liga no banco e está pronto em horas. Imbatível em velocidade para ferramenta interna; pago por usuário e preso à ferramenta.
- **Supabase Studio / Firebase Console direto** — para casos triviais, às vezes o painel nativo do banco já resolve sem construir nada.
- **Planilha (Google Sheets) + Apps Script / AppSheet** — escolha quando o "sistema" cabe numa planilha e o time já vive nela. Subestimado: muita ferramenta interna não precisa de app.

**Quando escolher cada uma:**
- CRUD interno, rápido, ninguém quer codar UI → **Retool/Appsmith**.
- Vai virar produto externo ou precisa de UX própria → **Next.js**.
- Cabe numa planilha → **planilha** (não construa app por construir).

**Armadilhas:** construir um app completo do zero para uma ferramenta que 5 pessoas vão usar 2x por dia — quando Retool ou uma planilha resolveriam em uma tarde.

---

## 6. Blog / Site de conteúdo

Foco em texto, SEO, leitura rápida, talvez muitos autores. Conteúdo é o produto.

**Recomendada:** **Astro + Markdown/MDX + Vercel/Cloudflare Pages.**
- Por quê: estático, rapidíssimo, SEO perfeito, conteúdo versionado em arquivos (Git). Barato a ponto de ser quase grátis em qualquer escala razoável de tráfego.

**Alternativas:**
- **Next.js (SSG/ISR) + MDX** — escolha se o blog faz parte de um app Next ou precisa de partes dinâmicas (comentários logados, paywall). ISR dá o melhor dos dois mundos (estático que revalida).
- **CMS headless (Sanity, Contentful, Strapi) + Astro/Next** — escolha quando **editores não-técnicos** precisam publicar sem mexer em Git. O CMS dá o painel; o site consome via API.
- **WordPress / Ghost** — escolha se quer tudo pronto (editor, temas, plugins) e não quer programar. Ghost é ótimo e moderno para publicação pura; WordPress é o padrão de mercado mas pede manutenção.

**Quando escolher cada uma:**
- Você (técnico) escreve em Markdown, quer o mais rápido/barato → **Astro**.
- Equipe não-técnica publica direto → **CMS headless** ou **Ghost/WordPress**.
- Blog dentro de um app Next → **Next.js + ISR**.

**Armadilhas:** subir um WordPress (e a manutenção/segurança que vem junto) para um blog que três posts por mês — um site estático resolveria sem servidor para cuidar.

---

## 7. API / Backend (serviço sem frontend próprio)

Backend que serve outros apps/clientes: API REST/GraphQL, webhooks, integrações, jobs.

**Recomendada (parte de um app web):** **Route Handlers do Next.js (API routes) na Vercel.**
- Por quê: se você já tem um Next, a API mora no mesmo projeto e deploy. Zero infra extra para o caso comum (endpoints, webhooks, BFF do seu próprio front).

**Alternativas:**
- **Cloud Functions (Firebase) / Cloud Run / Vercel Functions** — escolha para lógica server-side avulsa, triggers de banco, processamento sob demanda. Serverless: escala a zero, paga por uso. Cuidado com cold start em rota crítica.
- **API dedicada (Node/Fastify, NestJS, Hono) em container (Cloud Run, Railway, Fly.io)** — escolha quando o backend é o produto, precisa rodar contínuo, segura conexões longas, jobs pesados, ou serve vários clientes. Mais controle, mais operação.
- **Supabase (Postgres + PostgREST + Edge Functions)** — escolha se o backend é essencialmente "banco relacional com API"; o Supabase já expõe a API do banco e ainda dá auth e funções.
- **Python (FastAPI)** — escolha se o domínio é dados/ML/IA e o time é Python. Excelente para serviço de IA/ML; integra bem com o ecossistema de modelos.

**Quando escolher cada uma:**
- API é o "backend do meu próprio front" Next → **Route Handlers**.
- Funções avulsas, triggers, escala-a-zero → **serverless (Functions/Cloud Run)**.
- Backend é o produto, contínuo, multi-cliente → **API dedicada em container**.
- Domínio é IA/ML/dados → **FastAPI (Python)**.

**Armadilhas:** colocar trabalho pesado e longo (vídeo, ML, batch) dentro de uma serverless function com timeout curto — vai estourar limite. Trabalho longo pede fila + worker (veja `padroes-arquitetura.md`).

---

## 8. MVP rápido / Validar uma ideia

O objetivo não é o produto final — é **descobrir se alguém quer isso**, gastando o mínimo de tempo e dinheiro. Otimize para velocidade de aprender.

**Recomendada (rota padrão, enxuta):** **Next.js + Firebase + Vercel + Tailwind.** Auth só se a validação exigir login. Stripe só quando for cobrar de verdade.
- Por quê: é a stack que vai do zero ao no-ar mais rápido com a IA, sem montar infra. Tudo gerenciado, free tier cobre a fase de validação inteira.

**Alternativas (validar com ainda menos código):**
- **No-code/low-code (Bubble, Glide, Softr, Framer + Airtable)** — escolha quando a ideia cabe num fluxo simples e você quer testar **a proposta**, não construir tecnologia. Pode validar em dias sem codar. Limite: ao crescer ou complicar, você reescreve — e tudo bem, era um teste.
- **Landing + lista de espera (Astro/Carrd + form)** — o MVP mais barato de todos: nem construa o produto. Meça interesse (cadastros, pré-venda) antes de escrever a primeira tela funcional.
- **Supabase no lugar do Firebase** — se você já pensa relacional, troca direta sem perder velocidade.

**Quando escolher cada uma:**
- Vai construir e quer evoluir o código depois → **Next + Firebase**.
- Quer só testar a proposta, sem código → **no-code**.
- Nem sabe se tem demanda → **landing + lista de espera** primeiro.

**Armadilhas:** caprichar em escala, microsserviços, testes de carga e CI elaborado **antes** de ter um único usuário. No MVP, o risco é construir o que ninguém quer — não aguentar tráfego que não existe. Construa o suficiente para aprender, e nada mais.

---

## Tabela-resumo (consulta rápida)

| Produto | Default (começando) | Alternativa séria | Gatilho da alternativa |
|---|---|---|---|
| Landing / institucional | Astro + Vercel | Next SSG / no-code | Faz parte de app Next / ninguém coda |
| SaaS | Next + Firebase + Vercel | Next + Supabase (Postgres) | Dados relacionais, SQL, relatórios |
| E-commerce | Shopify | Next + Stripe/gateway BR | Loja é o diferencial e tem time técnico |
| App mobile | Expo (RN) + Firebase | PWA (Next) / Flutter / nativo | PWA: sem loja; Flutter: time Dart; nativo: hardware |
| Ferramenta interna | Next + Firebase/Supabase | Retool/Appsmith / planilha | CRUD puro, sem UI custom |
| Blog / conteúdo | Astro + MDX | CMS headless / Ghost | Editores não-técnicos publicam |
| API / backend | Next Route Handlers | Cloud Run / FastAPI | Backend é o produto / domínio IA/ML |
| MVP rápido | Next + Firebase | No-code / lista de espera | Validar proposta sem (ou quase sem) código |
