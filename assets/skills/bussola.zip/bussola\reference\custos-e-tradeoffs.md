# Custos e trade-offs

> Base pesquisável da Bússola. Aqui mora a verdade que ninguém conta antes da fatura: **onde é grátis, onde a conta começa a crescer**, e **o que você troca** em cada escolha.
> Valores são ordens de grandeza para orientar decisão — preços mudam, sempre confirme na fonte antes de fechar conta. O objetivo não é a tabela exata; é você nunca ser **pego de surpresa**.

---

## Como pensar custo (antes dos números)

Três verdades que valem mais que qualquer tabela:

1. **"De graça" tem teto.** Todo free tier acaba — em requisições, leituras, banda, build ou usuários ativos. O que importa é saber **qual métrica** te tira do grátis e **quando** isso acontece no seu caso.
2. **A conta cresce com o eixo errado.** Cada serviço cobra por uma coisa diferente: Firestore por **leitura de documento**, Vercel por **compute e banda**, storage por **egress (saída)**. O susto vem de quem cobra pelo eixo que você não estava olhando.
3. **Seu tempo é o maior custo do começo.** Gerenciado pago parece caro até você somar as horas montando e mantendo infra própria. No início, pagar a plataforma quase sempre sai mais barato que pagar seu tempo.

---

## Perfil de custo por serviço (rota padrão e vizinhos)

### Vercel (hospedagem/deploy do Next)
- **Grátis (Hobby):** ótimo para projetos pessoais, MVP, landing. Deploy ilimitado, domínio, HTTPS.
- **Onde a conta cresce:** uso comercial exige o plano Pro (por assento). A fatura sobe com **execução de funções** (páginas dinâmicas/SSR, route handlers) e **banda**. Páginas estáticas/ISR são baratíssimas; SSR em tudo é o que dói.
- **Trade-off:** conveniência suprema (deploy no `git push`, borda global) vs custo por compute e algum lock-in nas features próprias da Vercel. Alternativa mais barata por unidade: Cloudflare Pages, ou um container em Railway/Fly.io (mais trabalho).
- **Dica de economia:** maximize estático/ISR; mande para função só o que precisa ser dinâmico.

### Firebase (Auth + Firestore + Storage)
- **Grátis (Spark):** cobre MVP e início com folga. Auth praticamente grátis em volume normal.
- **Onde a conta cresce:** **Firestore cobra por operação** — leituras, escritas e exclusões de documento, mais armazenamento e banda. O vilão nº 1 é **excesso de leituras**: telas que leem muitos documentos, listeners abertos demais, modelagem relacional (joins na mão = N leituras). Storage cobra armazenamento e **egress**.
- **Trade-off:** velocidade de lançamento e integração imbatíveis vs **lock-in forte** (sair do Firestore é reescrever a camada de dados) e custo imprevisível se a modelagem for ruim. 
- **Dica de economia:** desnormalize para ler em poucas operações; pagine; evite listeners desnecessários; agregue contadores em vez de contar documentos.

### Supabase (Postgres + Auth + Storage)
- **Grátis:** um projeto com Postgres, auth e storage cobre início. (Projeto free pode pausar após inatividade — confira.)
- **Onde a conta cresce:** planos por projeto conforme tamanho do banco, compute e banda. Custo mais **previsível** que Firestore (você paga capacidade, não por leitura).
- **Trade-off:** Postgres é **portável** (menos lock-in — dá para levar o banco embora) e dá SQL/relatórios, em troca de uma curva um pouco maior que Firebase. Excelente meio-termo entre "gerenciado fácil" e "controle relacional".

### Banco Postgres dedicado (Neon, Railway, Fly, RDS)
- **Grátis/barato:** Neon e Railway têm tiers iniciais generosos; Neon escala a zero (paga pouco parado).
- **Onde a conta cresce:** compute contínuo, armazenamento, conexões. RDS (AWS) é poderoso e caro; bom só quando você já vive na AWS e tem time.
- **Trade-off:** controle total e portabilidade máxima vs você operar/monitorar/fazer backup. Para não-técnico, é mais corda para se enforcar; para dev sênior, é liberdade.

### Storage e CDN de arquivos
- **S3 (AWS):** padrão de mercado, barato para guardar, **caro no egress** (saída/download).
- **Cloudflare R2:** preço similar para guardar, **egress grátis** — ganha muito em projeto com muito download/streaming/mídia.
- **Firebase/Supabase Storage:** convenientes e integrados; bons até o volume crescer, aí avalie R2.
- **Trade-off central de storage:** quem serve muita mídia deve olhar **egress** antes de tudo. É o eixo que pega gente desprevenida.

### Funções serverless / Cloud Run
- **Grátis:** tiers cobrem volume baixo/médio; escalam a zero (não paga parado).
- **Onde a conta cresce:** muitas invocações, execução longa, memória alta. Cold start pode doer em latência (não em dinheiro).
- **Trade-off:** paga só pelo uso e não opera servidor vs limites de tempo/memória e cold start. Trabalho longo/pesado e contínuo fica mais barato e estável em **container** (Cloud Run/Railway).

### Cloudflare (Pages, Workers, R2)
- **Grátis:** dos tiers mais generosos do mercado para estático, Workers e R2.
- **Trade-off:** preço e performance de borda excelentes vs ecossistema/DX um pouco diferente do Vercel+Next (melhorando rápido). Ótimo para conteúdo, edge e quem é sensível a custo.

### Plataformas prontas (Shopify, Retool, Clerk, CMS pagos)
- **Custo:** mensalidade fixa (e por usuário/assento em Retool/Clerk).
- **Trade-off:** você compra **tempo e responsabilidade resolvida** (checkout/fiscal no Shopify, auth no Clerk, painel no Retool) e paga em mensalidade + lock-in. Vale quando o que eles resolvem **não é o seu diferencial** — não reinvente o que dá para alugar pronto e barato no início.

---

## Os trade-offs que importam

### 1. Velocidade vs Controle
O eixo mestre. **Gerenciado e integrado** (Firebase, Vercel, Shopify) te faz lançar em dias, em troca de menos controle e mais lock-in. **Montar do zero** (Postgres + infra própria) dá controle total, em troca de tempo e operação.

> No começo, **velocidade vence quase sempre** — porque o risco maior é não validar a ideia, não a escala. Controle você compra depois, quando souber que o produto vale a pena.

### 2. Lock-in (ficar preso a um fornecedor)
**O que é:** quanto custa (em retrabalho) trocar de fornecedor depois.
- **Alto lock-in:** Firebase/Firestore (sair = reescrever dados), recursos proprietários da Vercel, plataformas no-code (sair = reconstruir).
- **Baixo lock-in:** Postgres (banco portável), Next.js (roda em vários lugares), armazenamento padrão S3-compatível.

**A verdade honesta:** lock-in **não é pecado**. Firebase te prende, e também te faz lançar numa fração do tempo. A pergunta certa não é "tem lock-in?" e sim **"o que ganho em troca, e quanto custaria sair se precisar?"**. Decida com os olhos abertos. Para reduzir risco sem abrir mão de velocidade, **Supabase** é um meio-termo (gerenciado, mas Postgres portável por baixo).

### 3. Custo hoje vs Custo na escala
A escolha barata/rápida agora pode ficar cara depois — e tudo bem, **se você souber onde está o ponto de virada**.
- Firestore: barato no começo, pode ficar caro com muitas leituras → ponto de virada = padrão de leitura, não nº de usuários.
- Vercel SSR: ótimo no começo, compute pesa com tráfego → vira estático/ISR ou migra função pesada para container.
- S3 egress / Firebase Storage: viram caro com muito download → R2.

> Estratégia certa: **otimize para validar agora**, mas **saiba de antemão** qual métrica vai te morder e qual é o plano B. Migrar é um projeto consciente — não uma corrida em pânico depois da fatura.

### 4. Simplicidade vs "Poder" / Escala futura
Cada peça a mais (microsserviço, fila, Redis, banco extra) compra escala/flexibilidade futura ao preço de **complexidade hoje**: mais custo fixo, mais coisa para quebrar, mais coisa para a IA errar. 

> No começo, **menos peças = menos bugs, menos custo, mais velocidade.** Adicione complexidade quando um problema **real e presente** exigir — nunca "por precaução" para uma escala que talvez nunca chegue. Over-engineering é o jeito mais comum de um projeto começando morrer de complexidade antes de morrer de sucesso.

---

## Roteiro de decisão de custo (use ao recomendar)

1. **Qual métrica me tira do grátis?** (leituras? compute? banda? egress? assentos?) — identifique o eixo de cada serviço da stack.
2. **Quando isso acontece no caso dele?** (tráfego, usuários ativos, volume de mídia, padrão de leitura).
3. **Onde está a primeira dor provável?** — quase sempre: leituras no Firestore, compute SSR na Vercel, ou egress no storage.
4. **Qual o plano B e quanto custa migrar?** — diga o sinal de "hora de trocar" e a rota (ex.: Firestore → Postgres; S3 → R2; SSR → ISR; função → container).
5. **Comunique sem susto.** No formato de saída, sempre preencha "**Onde a conta cresce**" e "**Quando trocar**". Surpresa na fatura é falha da recomendação, não do cliente.

> Fechamento honesto: nenhuma escolha é "a mais barata" em todos os cenários. A boa escolha é a que é **barata o suficiente agora**, **previsível**, e com **saída conhecida**. A decisão é do dono do produto — a Bússola garante que ele decida sabendo onde a conta mora.
