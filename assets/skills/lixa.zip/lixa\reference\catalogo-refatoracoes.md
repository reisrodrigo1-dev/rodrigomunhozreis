# Catálogo de refatorações comuns

Cada refatoração aqui é uma transformação **mecânica que preserva o comportamento**. Antes e depois fazem exatamente a mesma coisa — só mudam a forma. Aplique **uma por vez**, rode a checagem, commite. Os exemplos são TypeScript/React, mas os princípios valem para qualquer linguagem.

> Regra geral: quanto mais a sua IDE conseguir fazer a transformação automaticamente (rename, extract), mais segura ela é — porque preserva comportamento por construção. Prefira o automático ao manual sempre que possível.

---

## 1. Extrair função

**Smell:** um bloco de código faz uma coisa identificável no meio de uma função maior; você precisaria de um comentário pra explicar o que ele faz.

**Por quê:** nomear o bloco com uma função substitui o comentário, permite reuso e isola o que pode ser testado.

**Antes:**
```ts
function processarPedido(pedido: Pedido) {
  // calcula o frete
  let frete = 0;
  if (pedido.peso > 10) frete = pedido.peso * 1.5;
  else frete = 10;
  if (pedido.regiao === "norte") frete *= 1.2;

  const total = pedido.subtotal + frete;
  salvar(pedido.id, total);
}
```

**Depois:**
```ts
function calcularFrete(pedido: Pedido): number {
  let frete = pedido.peso > 10 ? pedido.peso * 1.5 : 10;
  if (pedido.regiao === "norte") frete *= 1.2;
  return frete;
}

function processarPedido(pedido: Pedido) {
  const total = pedido.subtotal + calcularFrete(pedido);
  salvar(pedido.id, total);
}
```

---

## 2. Renomear (variável, função, parâmetro)

**Smell:** o nome mente ou não diz nada — `data`, `temp`, `handleClick2`, `getUser` que também salva.

**Por quê:** o nome é a documentação que nunca fica desatualizada. Nome honesto evita bug de interpretação.

**Antes:**
```ts
const d = users.filter(u => u.a);   // o que é "a"? e "d"?
```

**Depois:**
```ts
const usuariosAtivos = users.filter(u => u.ativo);
```

> **Mecânico de fábrica:** use o "Rename Symbol" da IDE (F2 no VS Code). Ele renomeia todas as referências de uma vez, sem deixar nenhuma pra trás — é a refatoração mais segura que existe. Renomear na mão arrisca esquecer uma ocorrência.

---

## 3. Simplificar condicional / early return

**Smell:** `if/else` aninhado, "pirâmide da perdição", a lógica principal escondida lá no fundo da indentação.

**Por quê:** tratar os casos de saída primeiro (guard clauses) achata a indentação e deixa o caminho principal no nível de cima, fácil de ler.

**Antes:**
```ts
function aplicarDesconto(user: User | null) {
  if (user) {
    if (user.ativo) {
      if (user.plano === "pro") {
        return calcular(user);
      } else {
        return 0;
      }
    } else {
      return 0;
    }
  } else {
    return 0;
  }
}
```

**Depois:**
```ts
function aplicarDesconto(user: User | null) {
  if (!user) return 0;
  if (!user.ativo) return 0;
  if (user.plano !== "pro") return 0;
  return calcular(user);
}
```

Outras simplificações do mesmo grupo:
- Condição com negação dupla → afirmação direta (`if (!(!x))` → `if (x)`).
- `if (cond) return true; else return false;` → `return cond;`.
- Ternário aninhado ilegível → early returns ou uma tabela/map de lookup.

---

## 4. Remover duplicação

**Smell:** o mesmo trecho (ou quase) aparece em dois, três lugares. Mudar a regra exige lembrar de todos.

**Por quê:** uma fonte da verdade. Você corrige/ajusta em um lugar só, e não esquece nenhuma cópia.

**Antes:**
```ts
// componente A
const preco = (item.valor * (1 - item.desconto)).toFixed(2);
// componente B
const preco = (produto.valor * (1 - produto.desconto)).toFixed(2);
```

**Depois:**
```ts
// lib/preco.ts
export function precoFinal(valor: number, desconto: number): string {
  return (valor * (1 - desconto)).toFixed(2);
}
// componentes A e B
const preco = precoFinal(item.valor, item.desconto);
```

> **Cuidado:** duplicação *aparente* não é duplicação *real*. Se dois trechos parecem iguais hoje mas mudam por razões diferentes amanhã, unificá-los cria acoplamento ruim. Una só o que tem o **mesmo motivo de existir**.

---

## 5. Extrair constante (eliminar valor mágico)

**Smell:** número ou string solta no meio do código — `* 1.2`, `=== "pro"`, `if (status === 3)`. Ninguém sabe o que significa sem investigar.

**Por quê:** o nome explica o valor, e você muda em um lugar só.

**Antes:**
```ts
if (tentativas > 3) bloquear();
const taxa = valor * 0.0299;
```

**Depois:**
```ts
const MAX_TENTATIVAS = 3;
const TAXA_CARTAO = 0.0299;

if (tentativas > MAX_TENTATIVAS) bloquear();
const taxa = valor * TAXA_CARTAO;
```

---

## 6. Dividir arquivo gigante

**Smell:** arquivo de 800 linhas com helpers, tipos, componentes e lógica de negócio tudo junto. Difícil de navegar, conflito de merge garantido.

**Por quê:** cada arquivo com uma responsabilidade clara. Mais fácil de achar, de testar e de revisar.

**Como (em passos pequenos, um por vez):**
1. Identifique grupos coesos: tipos, constantes, helpers puros, componentes.
2. Mova **um grupo** para o seu próprio arquivo (ex.: `tipos.ts`, `lib/frete.ts`, `components/CardPedido.tsx`).
3. Ajuste os imports. Rode a checagem (typecheck pega import quebrado na hora).
4. Commit. Repita para o próximo grupo.

```
checkout.tsx (800 linhas)
   ↓ dividido em
checkout.tsx          (só o componente de página, ~120 linhas)
checkout.types.ts     (tipos)
lib/frete.ts          (cálculo de frete, puro e testável)
components/ResumoPedido.tsx
```

> Não tente dividir tudo num commit só. Um grupo por vez, checagem entre cada um.

---

## 7. Extrair componente (React)

**Smell:** JSX gigante, um pedaço de UI com responsabilidade própria embutido no meio de outro, ou um trecho repetido em vários lugares do render.

**Por quê:** componente nomeado, reutilizável e testável isoladamente. O componente pai fica legível.

**Antes:**
```tsx
function Perfil({ user }: { user: User }) {
  return (
    <div>
      <h1>{user.nome}</h1>
      <div className="badge">
        <span className={user.ativo ? "on" : "off"} />
        {user.ativo ? "Ativo" : "Inativo"}
      </div>
      {/* ...mais 80 linhas... */}
    </div>
  );
}
```

**Depois:**
```tsx
function StatusBadge({ ativo }: { ativo: boolean }) {
  return (
    <div className="badge">
      <span className={ativo ? "on" : "off"} />
      {ativo ? "Ativo" : "Inativo"}
    </div>
  );
}

function Perfil({ user }: { user: User }) {
  return (
    <div>
      <h1>{user.nome}</h1>
      <StatusBadge ativo={user.ativo} />
      {/* ... */}
    </div>
  );
}
```

> Comportamento idêntico: mesma marcação renderizada, mesmas props fluindo. Só a organização mudou.

---

## 8. Extrair hook customizado (React)

**Smell:** a mesma lógica de estado/efeito (`useState` + `useEffect` + handlers) repetida em vários componentes, ou um componente com tanta lógica de estado que o JSX some no meio.

**Por quê:** isola a lógica com estado num hook reutilizável e testável; o componente volta a ser sobre renderizar.

**Antes:**
```tsx
function ListaUsuarios() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/users")
      .then(r => r.json())
      .then(setUsers)
      .catch(e => setErro(e.message))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <Spinner />;
  if (erro) return <Erro msg={erro} />;
  return <ul>{users.map(u => <li key={u.id}>{u.nome}</li>)}</ul>;
}
```

**Depois:**
```tsx
function useUsuarios() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const [erro, setErro] = useState<string | null>(null);

  useEffect(() => {
    fetch("/api/users")
      .then(r => r.json())
      .then(setUsers)
      .catch(e => setErro(e.message))
      .finally(() => setLoading(false));
  }, []);

  return { users, loading, erro };
}

function ListaUsuarios() {
  const { users, loading, erro } = useUsuarios();
  if (loading) return <Spinner />;
  if (erro) return <Erro msg={erro} />;
  return <ul>{users.map(u => <li key={u.id}>{u.nome}</li>)}</ul>;
}
```

> O hook (`use...`) tem que seguir as Regras dos Hooks: chamado no topo, sempre na mesma ordem. A lógica é a mesma de antes — só mudou de lugar.

---

## Como escolher a próxima refatoração

1. Comece pela que **destrava as outras**. Muitas vezes um early return ou um rename torna o resto óbvio.
2. Prefira a **mais mecânica** (rename, extract da IDE) — menor risco.
3. Faça **uma**, cheque, commite. Só então a próxima. Ver o procedimento na `SKILL.md` e a disciplina em `refatoracao-segura.md`.
