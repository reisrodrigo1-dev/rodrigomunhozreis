# Quando refatorar — e quando NÃO

Refatorar é investimento: custa tempo agora pra economizar tempo depois. Como todo investimento, ele só compensa quando há retorno. Refatorar código que ninguém vai tocar é gastar sem receber. Este guia separa o que **vale** do que é **gold-plating** (capricho sem retorno).

> Princípio: o melhor momento de refatorar é **logo antes de mexer no código de qualquer jeito**. Você já vai entrar ali — deixe o terreno limpo antes de construir.

---

## Quando VALE refatorar

### 1. Você vai mexer ali mesmo (regra do escoteiro com juízo)
Vai adicionar uma feature ou corrigir um bug num trecho bagunçado. Lixar **antes** de construir é mais seguro: você entende o terreno reorganizando-o (com testes verdes) e constrói sobre algo limpo. O retorno é imediato — a própria mudança que você ia fazer fica mais fácil.

### 2. Dói toda vez que você passa por ali
Atrito recorrente é o sinal mais honesto. A função de 200 linhas que você precisa reler inteira toda vez. O `if` aninhado que você nunca tem certeza de ter entendido. O trecho copiado em três arquivos que você sempre esquece de atualizar num deles. Se machuca de novo e de novo, o conserto se paga.

### 3. O Crivo (ou a revisão) apontou um code smell concreto
Duplicação real, função gigante, nome mentiroso, valor mágico, condicional ilegível, arquivo monstro. Não é "achei feio" — é um problema nomeado, com impacto. A Lixa é a ferramenta que conserta o que o Crivo encontrou. Ver o catálogo de smell→conserto em `catalogo-refatoracoes.md`.

### 4. A bagunça está bloqueando uma decisão técnica
Você não consegue testar porque a lógica está grudada na UI. Não consegue reusar porque está duplicada. Não consegue entender o impacto de uma mudança porque tudo está acoplado. Aqui a refatoração destrava trabalho real.

### 5. Antes de adicionar feature em código confuso
Empilhar lógica nova sobre código que você não entende multiplica o risco. Refatorar primeiro (commits `refactor:`, tudo verde), construir depois (commits `feat:`) — nessa ordem, em commits separados.

---

## Quando NÃO vale (gold-plating)

### 1. Código estável que ninguém toca
Funciona, está isolado, ninguém mexe há meses, não tem bug. Mesmo que esteja feio por dentro: **se você não precisa entrar ali, o ROI da refatoração é zero ou negativo.** Pior — você arrisca introduzir um bug num código que estava de pé. Deixe quieto.

### 2. "Ficaria mais bonito" sem motivo concreto
Trocar `function` por arrow function, reordenar imports, renomear coisas que já estão claras só pra ficar do seu jeito. Preferência de estilo não é refatoração com retorno — é capricho. Se incomoda mesmo, resolva com **linter/formatter automático**, não na mão, e em outro momento.

### 3. No meio de uma entrega, sem rede e sem tempo
Você está fechando uma feature, sem testes naquele trecho e com prazo. Parar pra refatorar agora mistura escopo e arrisca o que importa. **Anote a dívida** (um TODO com contexto, um item no backlog) e volte depois, num commit limpo só de refatoração, com a rede de segurança no lugar.

### 4. Refatoração "grande demais" de uma vez
Reescrever o módulo inteiro do zero não é refatoração — é um rewrite, com risco de rewrite. Se o plano não cabe em passos pequenos e reversíveis (ver `refatoracao-segura.md`), ele não é seguro. Quebre, ou trate como projeto à parte com sua própria rede.

### 5. Perseguir um padrão "porque é a boa prática"
Aplicar um design pattern, uma camada de abstração ou um "clean architecture" porque leu que é certo — sem um problema concreto que ele resolva — adiciona complexidade que você vai pagar pra sempre. Abstraia quando a dor aparece (regra de 3: duplicou três vezes? aí sim), não por antecipação.

---

## O teste rápido de decisão

Antes de refatorar, responda:

1. **Eu vou mexer nesse código em breve?** Sim → tende a valer.
2. **Isso me machuca de forma recorrente?** Sim → tende a valer.
3. **Tem um smell concreto com impacto real (não "é feio")?** Sim → tende a valer.
4. **Tenho rede de segurança (teste verde ou checagem manual)?** Não → resolva isso *antes*, ou não comece.
5. **É só estilo / preferência / "ficaria mais bonito"?** Sim → é gold-plating. Pare (ou jogue pro formatter automático).

Se 1, 2 ou 3 são "sim" **e** o 4 está garantido: refatore, em passos pequenos. Se a única razão é o item 5: deixe quieto.

> A decisão de até onde lixar é sua. A Lixa te dá o critério pra não confundir "necessário" com "capricho" — e pra não gastar tempo polindo o que ninguém vai pegar na mão.
