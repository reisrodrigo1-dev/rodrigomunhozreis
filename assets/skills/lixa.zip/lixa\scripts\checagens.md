# Checagens — a rede de segurança rodada a cada passo

Estes são os comandos que sustentam o Passo 3 do procedimento da Lixa: **rodar a checagem depois de cada passo de refatoração, para provar que o comportamento não mudou**. Stack assumida: Next.js + TypeScript. Deploy Vercel.

> Regra: você roda isto **entre cada passo pequeno**, não só no fim. Verde → commita e segue. Vermelho → reverte o passo na hora (não conserta por cima).

Os comandos assumem `npm`. Troque por `pnpm`/`yarn` conforme o projeto. Confira os scripts reais em `package.json` antes — nomes variam.

---

## A checagem entre passos (rápida)

Rode esta sequência depois de **cada** transformação. Quanto mais rápida, mais você roda — e rodar com frequência é o que pega a quebra cedo.

```bash
# 1. Typecheck — pega import quebrado, tipo errado, símbolo renomeado pela metade
npx tsc --noEmit

# 2. Testes da área que você está mexendo (foco = feedback rápido)
npm test -- <arquivo-ou-padrao>     # ex.: npm test -- frete
```

Se passou, commite o passo e vá para o próximo. O ciclo é: **muda 1 coisa → checa → verde → commita → repete.**

> Dica: deixe os testes em modo watch enquanto refatora — `npm test -- --watch`. Cada save re-roda a área afetada e você vê vermelho no segundo em que algo quebra.

---

## A checagem completa (antes de fechar / abrir PR)

Depois da última refatoração da sessão, rode a suíte inteira para garantir que nada quebrou fora da sua área de foco (regressão).

```bash
npm run lint            # estilo e erros estáticos
npx tsc --noEmit        # tipos, sem emitir build
npm test                # suíte completa — pega regressão fora do foco
npm run build           # prova que compila pra produção (= o que a Vercel roda)
```

Tudo verde **e iguais ao estado inicial** (mesmos testes passando que passavam antes de começar) = comportamento preservado.

---

## Typecheck honesto

```bash
npx tsc --noEmit
```

O `next build` pode pular checagem de tipo se o projeto tiver isto ligado — confira em `next.config`:
```js
typescript: { ignoreBuildErrors: true }   // o build esconde erro de tipo
eslint: { ignoreDuringBuilds: true }      // idem para o lint
```
Por isso rode `tsc --noEmit` sempre: ele não mente, e renomear/extrair são exatamente as mudanças que ele valida de graça.

---

## Quando NÃO há testes (checagem manual)

Sem suíte automatizada, a rede é o **roteiro manual** que você registrou no Passo 1. Depois de cada passo:

1. Rode `npx tsc --noEmit` (mesmo sem testes, o typecheck pega muita coisa de graça).
2. Repita exatamente o roteiro registrado: as mesmas entradas, os mesmos fluxos de tela, os mesmos casos de borda.
3. Compare cada resultado com o que você anotou **antes** de começar. Diferente = você mudou comportamento; reverta.

> Isto é mais lento e mais frágil que teste automatizado — é justamente por isso que vale criar a rede com a skill **Prova** antes de refatorar algo que importa.

---

## Commit do passo (reversível)

```bash
git diff                       # confira: o diff é SÓ a transformação que você descreveu?
git add -p                     # stage seletivo, se quiser separar
git commit -m "refactor: extrai validarCPF de checkout()"
```

Cada commit deve dizer **que é refatoração** e não mudar comportamento. Confirme que o diff não vazou nenhuma mudança de comportamento disfarçada:

```bash
git diff --staged | grep -nE "console\.(log|debug)|debugger|TODO|FIXME"   # lixo de debug?
```

---

## Checklist mínima do passo de refatoração

- [ ] rede de segurança estava **verde antes** de começar
- [ ] fiz **um** passo pequeno, descritível em uma frase
- [ ] `tsc --noEmit` passou
- [ ] testes da área passaram (ou roteiro manual conferido contra o "antes")
- [ ] o diff é **só estrutura** — nenhuma mudança de comportamento embutida
- [ ] commit `refactor:` pequeno e reversível
- [ ] suíte completa + `build` verdes antes de fechar a sessão / abrir PR
