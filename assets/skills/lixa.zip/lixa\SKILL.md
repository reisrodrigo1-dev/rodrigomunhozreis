---
name: lixa
description: Refatora código com segurança — melhora a estrutura sem mudar o comportamento. Use ao limpar/organizar código, reduzir duplicação ou dívida técnica, antes de adicionar feature em código bagunçado.
---

# Lixa — Refatoração Segura

> *Vibecoding com engenharia.* Refatorar é lixar a madeira, não trocar o móvel.
> A peça continua a mesma; só fica mais lisa de pegar. Se mudou de móvel, não foi refatoração — foi feature (e aí o risco é outro).

## Visão geral

**Refatorar é melhorar a estrutura interna do código sem mudar o que ele faz.** Mesma entrada, mesma saída, mesmos efeitos colaterais — só que mais legível, mais fácil de mudar e com menos repetição. O usuário não percebe diferença nenhuma. Os testes que passavam continuam passando. É exatamente esse o ponto.

**A regra de ouro:** o comportamento é **idêntico** antes e depois. Se o resultado observável mudou — uma resposta diferente, um campo novo, uma validação a mais, um bug "consertado de passagem" — você não refatorou, você mudou a feature. E misturar as duas coisas no mesmo passo é **receita de bug**: quando algo quebra, você não sabe se foi a reorganização ou a mudança de comportamento. Você perde o que torna a refatoração segura: a capacidade de afirmar "isso não devia ter mudado nada".

A Lixa não reescreve o seu projeto do zero nem persegue elegância por esporte. Ela aplica **transformações pequenas e conhecidas**, uma de cada vez, cada uma verificada, cada uma reversível. Devagar é o jeito rápido: passos pequenos com checagem constante chegam mais longe do que um "refactor gigante" que você não consegue mais reverter.

**O que a Lixa NÃO faz:**
- Não muda comportamento. Bug encontrado durante a refatoração vira um item separado, num commit separado, depois.
- Não refatora sem rede de segurança. Sem teste ou checagem do comportamento atual, refatorar é alterar código no escuro.
- Não faz "refactor enquanto adiciona a feature". Primeiro arruma o terreno (commit), depois constrói em cima (outro commit).
- Não persegue beleza sem motivo. Código estável que ninguém toca não precisa ficar "mais bonito" — ver `reference/quando-refatorar.md`.

**Stack-alvo:** Next.js, React, TypeScript. Os princípios valem para qualquer linguagem; os exemplos do catálogo assumem esse mundo (componentes, hooks, módulos TS).

## Quando usar

Acione a Lixa quando:

- **Você vai mexer naquele código mesmo.** Vai adicionar uma feature num arquivo bagunçado — lixe primeiro, construa depois. Refatorar o que você não vai tocar é desperdício.
- **Dói toda vez que você passa ali.** A função de 200 linhas, o `if` aninhado 4 níveis, o trecho copiado em três lugares. Atrito recorrente justifica o investimento.
- **O Crivo apontou um code smell.** Duplicação, função gigante, nome mentiroso, valor mágico, condicional ilegível — a Lixa é a ferramenta que conserta o que o Crivo achou.
- **Antes de adicionar feature em código confuso.** Entender o terreno reorganizando-o (com testes verdes) é mais seguro do que empilhar lógica nova sobre o que você não entende.

**Quando NÃO usar** (evitar gold-plating):
- Código estável, isolado, que ninguém toca há meses e funciona. "Ficaria mais bonito" não é motivo.
- No meio de uma entrega de feature, sem rede de segurança e sem tempo. Anote a dívida e volte depois, num commit limpo só de refatoração.

Os critérios completos de "vale / não vale" estão em **`reference/quando-refatorar.md`**.

> **Pré-requisito inegociável:** refatorar **sem teste** é arriscado. Sem uma rede de segurança que prove "o comportamento não mudou", você está editando código no escuro e torcendo. Se não há testes, ou você cria uma rede mínima com a skill **Prova** antes de começar, ou faz uma **checagem manual disciplinada** do comportamento atual (ver Passo 1). Não há terceira opção segura.

---

## PROCEDIMENTO de refatoração segura

A disciplina inteira cabe em cinco passos. Pule um e a segurança evapora. Os detalhes da disciplina e os riscos de furá-la estão em **`reference/refatoracao-segura.md`**.

### Passo 1 — Garantir a rede de segurança

**Meta:** ter como provar, a qualquer momento, que o comportamento não mudou.

1. **Existe teste cobrindo esse código?** Rode-o agora e confirme que está **verde antes de começar**. Refatorar sobre teste vermelho é cego — você não sabe o que era pra estar quebrado.
2. **Não existe teste?** Você tem duas saídas seguras:
   - **Criar a rede primeiro.** Escreva testes de caracterização (que capturam o comportamento *atual*, mesmo que esteja imperfeito) com a skill **Prova**. Eles viram o seu "antes" verificável.
   - **Checagem manual disciplinada.** Se teste automatizado não for viável agora: anote por escrito o comportamento atual (entradas → saídas, fluxos da tela, casos de borda), execute e registre os resultados *antes* de tocar em qualquer coisa. Esse registro é a sua rede — você vai repetir exatamente esses passos depois de cada mudança.
3. **Anote o comportamento esperado** mesmo quando há testes: o que entra, o que sai, que efeitos colaterais existem (escrita no banco, chamada de API, render). É contra essa descrição que você compara o "depois".

**Saída deste passo:** suíte verde (ou roteiro de checagem manual registrado). Sem isso, **pare** — você não tem como refatorar com segurança.

### Passo 2 — Passos PEQUENOS, um de cada vez

**Meta:** cada mudança tão pequena que, se quebrar, é óbvio o que foi.

1. Escolha **uma** transformação do catálogo (`reference/catalogo-refatoracoes.md`): extrair uma função, renomear *uma* coisa, aplicar *um* early return, remover *uma* duplicação.
2. Faça **só ela**. Resista a "já que estou aqui, também arrumo aquilo". Aquilo é o próximo passo, não este.
3. Prefira transformações **mecânicas e reversíveis** — as que a IDE faz com segurança (rename, extract function/variable) são as mais seguras de todas, porque preservam comportamento por construção.
4. Se o passo está ficando grande, **quebre em passos menores**. Um passo bom cabe na cabeça inteiro: você consegue dizer em uma frase o que mudou.

**Saída deste passo:** uma única transformação aplicada, descritível em uma linha.

### Passo 3 — Rodar a checagem a cada passo

**Meta:** provar, depois de *cada* passo, que o comportamento continua idêntico.

1. Rode a rede de segurança **agora**, antes de seguir para o próximo passo:
   - **Com testes:** `lint`, `typecheck` e a suíte de testes (ver `scripts/checagens.md`). Tudo verde.
   - **Sem testes:** repita o roteiro de checagem manual do Passo 1 e compare resultado a resultado.
2. **Verde → siga.** O passo está provado; pode commitar e ir para o próximo.
3. **Vermelho → reverta o passo imediatamente.** Não tente "consertar por cima". Como o passo era pequeno, descartar e refazer custa pouco. Investigar uma quebra grande custa caro — é justamente o que os passos pequenos evitam.
4. Nunca acumule dois ou três passos sem checar entre eles. A checagem entre passos é o que transforma "torço que não quebrou" em "sei que não quebrou".

**Saída deste passo:** confirmação verde de que o comportamento se manteve.

### Passo 4 — Commits pequenos e reversíveis

**Meta:** cada passo verificado vira um ponto de retorno seguro.

1. Commite **cada passo (ou pequeno grupo coeso de passos) verificado**, separadamente. Um commit por ideia de refatoração.
2. **Mensagem clara que diz que é refatoração** e não muda comportamento. Padrão recomendado:
   - `refactor: extrai validarCPF de checkout()` 
   - `refactor: early return em handleSubmit (sem mudança de comportamento)`
3. Commits pequenos te dão **rollback cirúrgico**: se algo aparecer errado três passos depois, você reverte exatamente o passo culpado sem arrastar o resto junto.
4. O histórico vira documentação: alguém lendo o log vê uma sequência de melhorias estruturais, cada uma isolada e reversível.

**Saída deste passo:** um ou mais commits `refactor:`, cada um pequeno e reversível.

### Passo 5 — Nunca misturar refatoração com mudança de comportamento

**Meta:** manter, no mesmo commit, ou só estrutura **ou** só comportamento — nunca os dois.

1. **Refatoração e feature são fases separadas, em commits separados.** Sequência segura: refatore o terreno (commits `refactor:`, tudo verde) → *depois* construa a feature em cima (commits `feat:`).
2. **Achou um bug no meio da refatoração?** Não conserte de passagem. Anote, termine a refatoração, e corrija o bug **depois, em um commit `fix:` próprio** — idealmente com um teste que trava a regressão (skill **Prova**).
3. **Por que isso importa:** se o commit mexe em estrutura *e* comportamento ao mesmo tempo e algo quebra, você perde a capacidade de dizer "a reorganização não devia ter mudado nada". A revisão fica mais difícil e o rollback arrasta junto o que você queria manter.
4. Na dúvida sobre o que é o quê: **mudou a saída observável? É comportamento.** Só mexeu na forma interna, com a mesma saída? É refatoração.

**Saída deste passo:** garantia de que nenhum commit mistura as duas naturezas.

---

## FORMATO DE SAÍDA

Quando a Lixa conduzir ou planejar uma refatoração, entregue assim — direto, PT-BR, sem hype.

### 1. Diagnóstico

O que está sendo refatorado e por quê (em 1–2 frases). Qual smell/atrito justifica mexer agora — e a confirmação de que **vale** mexer (Passo "quando usar"). Se não valer, diga e pare.

### 2. Rede de segurança

Estado da rede antes de começar: há testes? Estão verdes? Se não há, qual o plano (criar com Prova / checagem manual registrada). **Sem rede confirmada, a refatoração não começa.**

### 3. Plano em passos pequenos

A sequência de transformações, **uma por linha**, na ordem de aplicação. Cada uma deve ser pequena, mecânica quando possível, e descritível em uma frase. Aponte qual entrada do catálogo cada passo usa.

```
1. Extrair função validarCPF de checkout()      (extrair função)
2. Early return no início de checkout()          (simplificar condicional)
3. Remover duplicação do cálculo de frete        (remover duplicação)
4. Extrair constante TAXA_PADRAO                  (extrair constante)
```

### 4. Execução verificada

Para cada passo aplicado: o que mudou, e o resultado da checagem (verde/vermelho). Se vermelho, registre que foi revertido. Cada passo verde vira um commit `refactor:` com a mensagem proposta.

### 5. Fechamento

Confirmação final: **comportamento idêntico ao do início** (rede de segurança verde), nada de feature/fix misturado, commits pequenos e reversíveis. Liste, se houver, os bugs ou melhorias de comportamento **anotados para depois** (commits `fix:`/`feat:` futuros) — sem nunca tê-los aplicado dentro da refatoração.

Feche sempre lembrando: **a decisão de até onde lixar é sua.** A Lixa garante o método; você define o quanto vale.

---

## Referências

- **`reference/catalogo-refatoracoes.md`** — refatorações comuns com antes/depois (extrair função/componente, renomear, simplificar condicional/early return, remover duplicação, extrair constante, dividir arquivo gigante, extrair hook no React).
- **`reference/quando-refatorar.md`** — quando vale e quando NÃO vale mexer; como evitar gold-plating.
- **`reference/refatoracao-segura.md`** — a disciplina completa (rede de segurança, passos pequenos, separar do feature work) e os riscos de refatorar sem teste.
- **`scripts/checagens.md`** — comandos de lint/typecheck/build/test que apoiam a checagem a cada passo.

## Skills que combinam com a Lixa

- **Prova** — cria a rede de segurança (testes de caracterização) antes de refatorar, e trava regressões depois. Refatorar sem teste é arriscado; a Prova resolve isso.
- **Crivo** — aponta os code smells que a Lixa conserta, e revisa o diff de refatoração depois.
- **Lupa** — se a refatoração revelar um bug, a Lupa investiga a causa antes de você abrir o commit `fix:` separado.
