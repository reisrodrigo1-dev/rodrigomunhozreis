# Refatoração segura — a disciplina e os riscos

Refatoração é uma das atividades mais seguras da engenharia **quando feita com método** — e uma das mais perigosas quando feita no improviso. A diferença não é talento: é disciplina. Este documento detalha as três regras que tornam a refatoração segura e o que acontece quando você fura cada uma.

> A regra de ouro, de novo: **comportamento idêntico antes e depois.** Tudo aqui existe pra você conseguir *provar* que ela foi respeitada.

---

## 1. A rede de segurança (sem ela, é editar no escuro)

**O que é:** algo que prova, a qualquer instante, que o comportamento não mudou. Idealmente uma suíte de testes verde. Na falta dela, uma checagem manual disciplinada e registrada.

**Por que é inegociável:** refatoração é "mudar a forma sem mudar o comportamento". Sem como verificar o comportamento, você não tem como saber se mudou — você só *acredita* que não. E código que a IA reorganiza "confiante" quebra comportamento sutil o tempo todo: um `null` que antes era tratado, uma ordem de execução que importava, um efeito colateral que sumiu.

**Como montar:**
- **Tem testes?** Rode-os e confirme **verde antes de começar**. Refatorar sobre teste vermelho é cego — você não sabe o que já estava quebrado.
- **Não tem?** Escreva **testes de caracterização**: testes que capturam o comportamento *atual* (mesmo imperfeito), não o "ideal". O objetivo não é validar que está certo — é travar o que existe pra você notar se mudou. Use a skill **Prova**.
- **Teste automatizado inviável agora?** Registre por escrito o comportamento atual: entradas → saídas, fluxos de tela, casos de borda. Execute e anote os resultados **antes** de tocar em qualquer coisa. Esse registro é a rede — você repete exatamente esses passos depois de cada mudança.

**O risco de refatorar sem rede:** você troca a estrutura, roda uma vez na tela, parece ok, sobe. Três dias depois um caso de borda que você não exercitou está retornando o valor errado em produção — e agora você nem lembra quais dos 12 passos foi o culpado. Sem rede, "refatoração" e "introdução silenciosa de bug" são indistinguíveis. **Refatorar sem teste é arriscado: é a forma mais comum de transformar uma melhoria em incidente.**

---

## 2. Passos pequenos, com checagem entre cada um

**O que é:** uma transformação minúscula de cada vez (extrair *uma* função, renomear *uma* coisa), seguida imediatamente da rede de segurança, antes do próximo passo.

**Por que funciona:** o que torna a checagem útil não é rodá-la — é rodá-la **com pouca mudança no meio**. Se você fez um passo e quebrou, a causa está naquele passo, óbvia. Se você fez doze passos e quebrou, a causa está em algum lugar entre doze mudanças, e agora você está debugando a sua própria refatoração.

**A disciplina:**
1. Um passo. Mecânico e reversível quando possível (rename/extract da IDE são os mais seguros — preservam comportamento por construção).
2. Roda a checagem (`scripts/checagens.md`): lint, typecheck, testes. Ou repete o roteiro manual.
3. **Verde:** commita, segue.
4. **Vermelho:** **reverte o passo na hora.** Não conserta por cima. Como o passo era pequeno, refazer custa segundos. Esse é o superpoder dos passos pequenos: o custo de errar é desprezível.
5. Nunca acumula dois ou três passos sem checar entre eles.

**O risco do passo grande:** "vou reorganizar esse módulo inteiro e depois rodo os testes". Você passa duas horas, roda, 14 testes vermelhos. Agora você não sabe se é um bug ou catorze, nem por onde começar. A tentação é "consertar até ficar verde" — e aí você está editando comportamento pra fazer o teste passar, que é exatamente o oposto de refatorar. **Devagar é o jeito rápido.**

---

## 3. Separar refatoração de mudança de comportamento

**O que é:** num mesmo commit, ou só estrutura **ou** só comportamento. Nunca os dois misturados.

**Por que é a regra mais violada (e mais importante):** "já que estou aqui mexendo, também conserto aquele bug / adiciono aquele campo". No momento parece eficiência. Na prática, você acabou de destruir a propriedade que torna a refatoração segura: a capacidade de afirmar **"essa mudança não devia alterar nada observável"**. Se o commit muda forma *e* comportamento e algo quebra, você não sabe qual dos dois foi, a revisão fica muito mais difícil, e o rollback arrasta a feature junto com a faxina.

**A disciplina:**
- **Fases separadas, commits separados.** Refatore o terreno primeiro (`refactor:`, tudo verde). *Depois* construa a feature em cima (`feat:`). Nunca no mesmo commit.
- **Achou um bug refatorando?** Não conserte de passagem. Anote, **termine a refatoração com o bug intacto** (sim, mantém o comportamento errado — é o comportamento atual que a sua rede está protegendo), e depois corrija num commit `fix:` próprio, idealmente com um teste de regressão (skill **Prova**).
- **Mensagens de commit honestas:** `refactor:` promete "comportamento idêntico". `fix:`/`feat:` avisam "comportamento mudou aqui". Quem revisa lê o tipo e já sabe onde prestar atenção.

**Como saber o que é o quê:** mudou a saída observável (resposta, render, efeito colateral, dado salvo)? É **comportamento** → `fix:`/`feat:`. Só mudou a forma interna, com a mesma saída? É **refatoração** → `refactor:`.

---

## Por que commits pequenos e reversíveis fecham o ciclo

Cada passo verificado vira um **ponto de retorno seguro**. Isso te dá:
- **Rollback cirúrgico:** se um problema aparecer passos depois, você reverte exatamente o commit culpado, sem desfazer o resto.
- **Revisão fácil:** um commit que faz uma coisa nomeada se revisa em segundos.
- **Histórico que documenta:** o log vira uma trilha de melhorias estruturais isoladas, não um "refatorei tudo" impossível de auditar.
- **Coragem de refatorar:** quando reverter é barato e seguro, você mexe sem medo — e é justamente o medo que faz a dívida técnica se acumular.

---

## Resumo da disciplina

1. **Rede de segurança verde antes de começar.** Sem ela, pare. (Refatorar sem teste é arriscado.)
2. **Um passo pequeno por vez**, checagem entre cada um, reverte na hora se vermelho.
3. **Commit pequeno e reversível** a cada passo verificado (`refactor:`).
4. **Nunca misture** refatoração com feature/fix no mesmo commit.
5. Bug encontrado no caminho → **anota, separa, depois** (`fix:` com teste).

O método não é burocracia: é o que permite afirmar, com prova na mão, "isso não mudou nada — só ficou melhor de mexer". Essa frase é o produto inteiro da refatoração. A decisão de até onde ir é sua; a garantia de que foi seguro é da disciplina.
