#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Faro — escaneia um repositório atrás de segredos vazados.

Varre os arquivos versionáveis (ignora node_modules, .next, .git, dist, build...),
casa cada arquivo contra um catálogo de padrões de segredo por provedor, descarta
placeholders óbvios, sinaliza arquivos .env fora do .gitignore, ordena por
severidade e imprime um relatório legível (ou JSON com --json).

Uso:
    python escanear.py [CAMINHO] [--json] [--no-history-hint]

    CAMINHO            raiz do repositório (padrão: diretório atual)
    --json             saída em JSON (pra CI / outras ferramentas)
    --no-history-hint  não imprime o lembrete de checar o histórico do Git

Saída / exit code:
    0  nenhum achado
    1  algum segredo encontrado
    2  erro de uso

Sem dependências externas: roda em Python 3.8+.
"""

import argparse
import json
import os
import re
import subprocess
import sys

# Garante saida UTF-8 mesmo em consoles legados (ex.: cp1252 no Windows),
# evitando UnicodeEncodeError ao imprimir trechos de arquivos.
for _stream in (sys.stdout, sys.stderr):
    try:
        _stream.reconfigure(encoding="utf-8", errors="replace")
    except (AttributeError, ValueError):
        pass

# ---------------------------------------------------------------------------
# Severidades
# ---------------------------------------------------------------------------
CRITICO = "CRITICO"
ALTO = "ALTO"
MEDIO = "MEDIO"
BAIXO = "BAIXO"

_ORDEM_SEV = {CRITICO: 0, ALTO: 1, MEDIO: 2, BAIXO: 3}

# ---------------------------------------------------------------------------
# Catálogo de padrões. Cada item:
#   (id, nome, severidade, regex_compilada, contextual)
# "contextual" indica regex que depende de um nome de variável por perto
# (mais propenso a falso-positivo; tratado com confiança menor).
# Os ids batem com reference/padroes-de-segredo.md.
# ---------------------------------------------------------------------------
def _rx(pattern, flags=0):
    return re.compile(pattern, flags)


PADROES = [
    # Cloud / Infra
    (1, "AWS Access Key ID", CRITICO,
     _rx(r"\b(AKIA|ASIA|AGPA|AIDA|AROA)[0-9A-Z]{16}\b"), False),
    (2, "AWS Secret Access Key", CRITICO,
     _rx(r"(?i)aws_?secret_?access_?key['\"\s:=]+['\"]?([A-Za-z0-9/+]{40})"), True),
    (3, "GCP/Firebase Service Account", CRITICO,
     _rx(r'"type":\s*"service_account"|"private_key":\s*"-----BEGIN'), False),
    (4, "Google API Key", ALTO,
     _rx(r"\bAIza[0-9A-Za-z\-_]{35}\b"), False),
    (5, "GCP OAuth Client Secret", ALTO,
     _rx(r"\bGOCSPX-[0-9A-Za-z\-_]{20,}\b"), False),
    (6, "Azure Account/Shared Key", ALTO,
     _rx(r"(?i)(AccountKey|SharedAccessKey)=([A-Za-z0-9/+]{40,}={0,2})"), False),

    # Pagamentos
    (7, "Stripe Secret Key (live)", CRITICO,
     _rx(r"\b(sk|rk)_live_[0-9a-zA-Z]{24,}\b"), False),
    (8, "Stripe Secret Key (test)", MEDIO,
     _rx(r"\b(sk|rk)_test_[0-9a-zA-Z]{24,}\b"), False),
    (9, "Stripe Publishable Key", BAIXO,
     _rx(r"\bpk_(live|test)_[0-9a-zA-Z]{24,}\b"), False),
    (10, "PayPal/Braintree Access Token", ALTO,
     _rx(r"access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}"), False),

    # IA / LLM
    (11, "OpenAI API Key", CRITICO,
     _rx(r"\bsk-(proj-)?[A-Za-z0-9\-_]{20,}\b"), False),
    (12, "Anthropic API Key", CRITICO,
     _rx(r"\bsk-ant-[A-Za-z0-9\-_]{20,}\b"), False),
    (13, "Hugging Face / Replicate / Groq Key", ALTO,
     _rx(r"\b(hf_[A-Za-z0-9]{30,}|r8_[A-Za-z0-9]{30,}|gsk_[A-Za-z0-9]{40,})\b"), False),

    # Controle de versão / CI
    (14, "GitHub Token", CRITICO,
     _rx(r"\bgh[opusr]_[A-Za-z0-9]{36,}\b"), False),
    (15, "GitHub Fine-grained PAT", CRITICO,
     _rx(r"\bgithub_pat_[A-Za-z0-9_]{60,}\b"), False),
    (16, "GitLab PAT", ALTO,
     _rx(r"\bglpat-[A-Za-z0-9\-_]{20,}\b"), False),
    (17, "Vercel Token", ALTO,
     _rx(r"(?i)vercel[_-]?token['\"\s:=]+['\"]?([A-Za-z0-9]{24})"), True),
    (18, "npm Token", ALTO,
     _rx(r"\bnpm_[A-Za-z0-9]{36}\b"), False),

    # Mensageria / Comunicacao
    (19, "Slack Token", ALTO,
     _rx(r"\bxox[baprs]-[0-9A-Za-z\-]{10,}\b"), False),
    (20, "Slack Webhook URL", MEDIO,
     _rx(r"https://hooks\.slack\.com/services/[A-Za-z0-9/]+"), False),
    (21, "Discord Bot Token", ALTO,
     _rx(r"\b[MNO][A-Za-z0-9_-]{23}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,}\b"), False),
    (22, "Twilio SID/Key", ALTO,
     _rx(r"\b(AC|SK)[0-9a-f]{32}\b"), False),
    (23, "SendGrid API Key", ALTO,
     _rx(r"\bSG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}\b"), False),
    (24, "Mailgun/Mailchimp Key", ALTO,
     _rx(r"\b(key-[0-9a-f]{32}|[0-9a-f]{32}-us[0-9]{1,2})\b"), False),

    # Tokens / credenciais genericas
    (25, "JSON Web Token (JWT)", MEDIO,
     _rx(r"\beyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\b"), False),
    (26, "Chave privada (PEM/RSA/EC/SSH/PGP)", CRITICO,
     _rx(r"-----BEGIN ([A-Z]+ )?PRIVATE KEY-----"), False),
    (27, "Senha em conexao de banco", ALTO,
     _rx(r"\b(postgres(ql)?|mysql|mongodb(\+srv)?|redis|amqp)://[^:\s/]+:([^@\s/]+)@"), False),
    (28, "Basic Auth em URL", MEDIO,
     _rx(r"https?://[^:\s/]+:([^@\s/]+)@"), False),
    (29, "Bearer token hardcoded", MEDIO,
     _rx(r"(?i)bearer\s+[A-Za-z0-9\-_\.=]{20,}"), False),
    (30, "Atribuicao generica de segredo", MEDIO,
     _rx(r"(?i)(api[_-]?key|secret|token|password|passwd|pwd|client[_-]?secret|access[_-]?token|auth)['\"\s]*[:=]\s*['\"]([^'\"\s]{12,})['\"]"), True),

    # Stack Next.js / Firebase / Vercel
    (31, "NEXT_PUBLIC_* com segredo", ALTO,
     _rx(r"(?i)NEXT_PUBLIC_[A-Z_]*(SECRET|PRIVATE|SERVICE_ACCOUNT|SK_LIVE|PASSWORD)[A-Z_]*"), False),
    (32, "firebaseConfig hardcoded (verifique Security Rules)", BAIXO,
     _rx(r"(?i)(authDomain|messagingSenderId|appId)\s*:\s*['\"]"), False),
    (34, "Sentry DSN com secret", MEDIO,
     _rx(r"https://[0-9a-f]+:[0-9a-f]+@[a-z0-9.]*sentry\.io/"), False),

    # Outros provedores
    (35, "Algolia Admin Key", ALTO,
     _rx(r"(?i)algolia[_-]?admin[_-]?key['\"\s:=]+['\"]?([0-9a-f]{32})"), True),
    (36, "Cloudinary URL", ALTO,
     _rx(r"cloudinary://[0-9]+:[A-Za-z0-9\-_]+@"), False),
    (37, "Supabase service_role Key", CRITICO,
     _rx(r"(?i)service_role|SUPABASE_SERVICE_ROLE"), True),
    (38, "DigitalOcean Token", ALTO,
     _rx(r"\bdop_v1_[0-9a-f]{64}\b"), False),
    (39, "Datadog API Key", MEDIO,
     _rx(r"(?i)(datadog|dd)[_-]?api[_-]?key['\"\s:=]+['\"]?([0-9a-f]{32})"), True),
    (40, "Heroku API Key", ALTO,
     _rx(r"(?i)heroku[_-]?api[_-]?key['\"\s:=]+['\"]?([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})"), True),
    (41, "Shopify Token", ALTO,
     _rx(r"\bshp(at|ss|pa|ca)_[0-9a-fA-F]{32}\b"), False),
    (42, "Telegram Bot Token", MEDIO,
     _rx(r"\b[0-9]{8,10}:[A-Za-z0-9_-]{35}\b"), False),
]

# ---------------------------------------------------------------------------
# Filtros: diretorios e extensoes a ignorar; placeholders.
# ---------------------------------------------------------------------------
DIRS_IGNORADOS = {
    "node_modules", ".next", ".git", "dist", "build", "out", "coverage",
    ".turbo", ".vercel", ".cache", "vendor", "__pycache__", ".venv", "venv",
    ".idea", ".vscode", "bower_components", ".pytest_cache", ".mypy_cache",
    ".firebase", ".svelte-kit", ".nuxt", "target",
}

# Extensoes binarias / irrelevantes — pulamos sem abrir.
EXT_IGNORADAS = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".svg", ".bmp",
    ".pdf", ".zip", ".gz", ".tar", ".rar", ".7z", ".mp4", ".mov", ".avi",
    ".mp3", ".wav", ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".lock", ".map", ".min.js", ".min.css", ".wasm", ".node",
    ".so", ".dylib", ".dll", ".exe", ".bin", ".class", ".jar",
}

# Arquivos .env que devem estar no .gitignore.
RX_ENV = re.compile(r"^\.env(\..+)?$")
# .env.example e afins sao legitimos (valores fake).
RX_ENV_EXEMPLO = re.compile(r"^\.env\.(example|sample|template|dist)$|\.example$")

# Marcadores FORTES: se aparecem em qualquer lugar do valor, e placeholder.
# Sao palavras improvaveis de surgir por acaso dentro de um segredo real.
PLACEHOLDERS = [
    "example", "examplekey", "your-key", "your_key", "yourkey",
    "your-api-key", "your_api_key", "my-secret", "changeme", "change-me",
    "placeholder", "dummy", "test123", "xxxx", "xxxxx", "<your", "insert-",
    "replace-me", "todo", "fixme", "0000000000", "1234567890",
    "sample", "redacted", "secret_here", "notreal",
    "your-token", "your_token", "enter-your", "api-key-here", "supersecret",
    "mysecret", "password123", "p@ssw0rd", "loremipsum", "abcdefghij",
]

# Marcadores FRACOS: comuns o bastante pra aparecer por acaso dentro de um
# segredo de alta entropia (ex.: "abcdef" no meio de um token hex). So contam
# como placeholder quando DOMINAM o valor — valor curto ou quase todo o marcador.
PLACEHOLDERS_FRACOS = ["abcdef", "foo", "bar", "baz", "xxx"]

MAX_BYTES = 2_000_000  # nao abre arquivos maiores que ~2 MB

# ---------------------------------------------------------------------------
def eh_placeholder(trecho):
    """True se o trecho parece um valor de exemplo/fake."""
    baixo = trecho.lower()
    for ph in PLACEHOLDERS:
        if ph in baixo:
            return True
    # marcadores fracos: so contam se o valor for curto ou dominado por eles
    if len(trecho) <= 16:
        for ph in PLACEHOLDERS_FRACOS:
            if ph in baixo:
                return True
    # sequencias repetitivas (xxxx, aaaa, 0000) sem entropia real
    nucleo = re.sub(r"[^A-Za-z0-9]", "", trecho)
    if len(nucleo) >= 4 and len(set(nucleo.lower())) <= 2:
        return True
    return False


def deve_ignorar_arquivo(nome):
    nome_baixo = nome.lower()
    for ext in EXT_IGNORADAS:
        if nome_baixo.endswith(ext):
            return True
    return False


def listar_arquivos(raiz):
    """Anda na arvore pulando DIRS_IGNORADOS e arquivos binarios."""
    for dirpath, dirnames, filenames in os.walk(raiz):
        dirnames[:] = [d for d in dirnames if d not in DIRS_IGNORADOS]
        for fn in filenames:
            if deve_ignorar_arquivo(fn):
                continue
            yield os.path.join(dirpath, fn)


def ler_texto(caminho):
    try:
        if os.path.getsize(caminho) > MAX_BYTES:
            return None
    except OSError:
        return None
    try:
        # utf-8-sig descarta um BOM inicial, se houver
        with open(caminho, "r", encoding="utf-8-sig", errors="ignore") as f:
            return f.read()
    except (OSError, ValueError):
        return None


def confianca(contextual, trecho):
    """Heuristica simples de confianca pro relatorio."""
    if eh_placeholder(trecho):
        return "baixa (parece placeholder)"
    return "media" if contextual else "alta"


def escanear_arquivo(caminho, raiz):
    achados = []
    texto = ler_texto(caminho)
    if texto is None:
        return achados
    linhas = texto.splitlines()
    rel = os.path.relpath(caminho, raiz)

    for (pid, nome, sev, rx, contextual) in PADROES:
        for m in rx.finditer(texto):
            # Em padroes contextuais o grupo capturado E o segredo (o resto e o
            # nome da variavel). Nos demais, grupos costumam ser so prefixos de
            # alternancia (ex.: (sk|rk)) — o segredo e o match inteiro.
            grupos = [g for g in m.groups() if g]
            if contextual and grupos:
                trecho = grupos[-1]
            else:
                trecho = m.group(0)
            # avaliacao de placeholder usa o match inteiro pra ter contexto,
            # evitando descartar um segredo so porque um GRUPO curto parece fake.
            if eh_placeholder(m.group(0)):
                continue
            # numero da linha
            inicio = m.start()
            num_linha = texto.count("\n", 0, inicio) + 1
            conteudo = linhas[num_linha - 1].strip() if num_linha - 1 < len(linhas) else ""
            achados.append({
                "padrao_id": pid,
                "padrao": nome,
                "severidade": sev,
                "arquivo": rel.replace("\\", "/"),
                "linha": num_linha,
                "trecho": _mascarar(trecho),
                "contexto": conteudo[:160],
                "confianca": confianca(contextual, trecho),
            })
    return achados


def _mascarar(valor):
    """Mostra so o comeco/fim do segredo no relatorio."""
    if len(valor) <= 12:
        return valor[:3] + "***"
    return valor[:6] + "..." + valor[-4:]


# ---------------------------------------------------------------------------
# .env fora do .gitignore
# ---------------------------------------------------------------------------
def eh_repo_git(raiz):
    return os.path.isdir(os.path.join(raiz, ".git"))


def git_ignora(raiz, caminho_rel):
    """True se o git ignora o caminho. Se nao houver git, retorna None."""
    if not eh_repo_git(raiz):
        return None
    try:
        r = subprocess.run(
            ["git", "check-ignore", "-q", caminho_rel],
            cwd=raiz,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        return r.returncode == 0
    except (OSError, subprocess.SubprocessError):
        return None


def checar_envs(raiz):
    """Acha arquivos .env* e diz se estao protegidos pelo .gitignore."""
    problemas = []
    for dirpath, dirnames, filenames in os.walk(raiz):
        dirnames[:] = [d for d in dirnames if d not in DIRS_IGNORADOS]
        for fn in filenames:
            if not RX_ENV.match(fn):
                continue
            if RX_ENV_EXEMPLO.search(fn):
                continue  # .env.example e legitimo
            caminho = os.path.join(dirpath, fn)
            rel = os.path.relpath(caminho, raiz).replace("\\", "/")
            ignorado = git_ignora(raiz, rel)
            if ignorado is False:
                problemas.append({
                    "arquivo": rel,
                    "severidade": CRITICO,
                    "motivo": "arquivo .env NAO esta coberto pelo .gitignore "
                              "(risco de ser commitado com todos os segredos)",
                })
            elif ignorado is None:
                problemas.append({
                    "arquivo": rel,
                    "severidade": ALTO,
                    "motivo": "arquivo .env encontrado; nao foi possivel confirmar "
                              "o .gitignore (sem repo git ou git indisponivel) "
                              "— verifique manualmente",
                })
    return problemas


# ---------------------------------------------------------------------------
# Relatorio
# ---------------------------------------------------------------------------
def ordenar(achados):
    return sorted(achados, key=lambda a: (_ORDEM_SEV.get(a["severidade"], 9),
                                          a["arquivo"], a["linha"]))


def imprimir_humano(achados, envs, raiz, mostrar_hint):
    sep = "=" * 64
    print(sep)
    print(" FARO - relatorio de segredos")
    print(" raiz: " + os.path.abspath(raiz))
    print(sep)

    if envs:
        print()
        print("[.env / .gitignore]")
        for e in envs:
            print("  [{}] {}".format(e["severidade"], e["arquivo"]))
            print("        {}".format(e["motivo"]))

    if not achados:
        print()
        print("Nenhum segredo casou os padroes no codigo atual.")
    else:
        print()
        print("[Achados no codigo]  total: {}".format(len(achados)))
        sev_atual = None
        for a in achados:
            if a["severidade"] != sev_atual:
                sev_atual = a["severidade"]
                print()
                print("--- {} ---".format(sev_atual))
            print("  {}:{}  {}".format(a["arquivo"], a["linha"], a["padrao"]))
            print("        valor: {}   confianca: {}".format(a["trecho"], a["confianca"]))
            if a["contexto"]:
                print("        contexto: {}".format(a["contexto"]))

    print()
    print(sep)
    total = len(achados) + len(envs)
    if total == 0:
        print(" Limpo. Mesmo assim, confira o historico do Git (passo 3 da skill).")
    else:
        print(" {} achado(s). Para cada um: rotacione a chave (obrigatorio se".format(total))
        print(" vazou), remova do codigo, limpe do historico. Ver reference/remediacao.md")
    if mostrar_hint and eh_repo_git(raiz):
        print()
        print(" Lembrete: este scanner ve o codigo ATUAL. Segredos podem viver no")
        print(" historico mesmo apagados. Cheque com:")
        print('   git log -p --all -S "AKIA"   (e outros prefixos do catalogo)')
    print(sep)


def main(argv=None):
    parser = argparse.ArgumentParser(
        description="Faro — caca segredos vazados no repositorio.")
    parser.add_argument("caminho", nargs="?", default=".",
                        help="raiz do repositorio (padrao: diretorio atual)")
    parser.add_argument("--json", action="store_true",
                        help="saida em JSON")
    parser.add_argument("--no-history-hint", action="store_true",
                        help="nao imprime o lembrete de checar o historico")
    args = parser.parse_args(argv)

    raiz = args.caminho
    if not os.path.isdir(raiz):
        sys.stderr.write("erro: caminho nao e um diretorio: {}\n".format(raiz))
        return 2

    achados = []
    for caminho in listar_arquivos(raiz):
        achados.extend(escanear_arquivo(caminho, raiz))
    achados = ordenar(achados)
    envs = checar_envs(raiz)

    if args.json:
        saida = {
            "raiz": os.path.abspath(raiz),
            "total_achados": len(achados),
            "total_env_problemas": len(envs),
            "env_problemas": envs,
            "achados": achados,
        }
        print(json.dumps(saida, ensure_ascii=False, indent=2))
    else:
        imprimir_humano(achados, envs, raiz, not args.no_history_hint)

    return 1 if (achados or envs) else 0


if __name__ == "__main__":
    sys.exit(main())
