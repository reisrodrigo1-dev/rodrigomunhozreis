# Catálogo de padrões de segredo

Referência dos padrões que o Faro procura. Para cada um: como reconhecer (forma / regex) e o risco se vazar. Severidades: **CRÍTICO** (credencial viva de produção, dá acesso direto), **ALTO** (acesso amplo ou senha), **MÉDIO** (depende de contexto), **BAIXO** (info sensível, baixo impacto direto).

As regex aqui são as mesmas usadas pelo scanner (`scripts/escanear.py`). Elas miram a *forma* do segredo — prefixos e comprimentos característicos — pra reduzir falso-positivo.

---

## Cloud / Infra

### 1. AWS Access Key ID — CRÍTICO
- **Forma:** `AKIA` seguido de 16 caracteres maiúsculos/dígitos. Também `ASIA` (credencial temporária STT), `AGPA`, `AIDA`, `AROA`.
- **Regex:** `\b(AKIA|ASIA|AGPA|AIDA|AROA)[0-9A-Z]{16}\b`
- **Risco:** identifica a conta AWS. Sozinha não autentica, mas combinada com a secret key (abaixo) dá acesso programático total. Bots varrem o GitHub atrás desse prefixo em segundos.

### 2. AWS Secret Access Key — CRÍTICO
- **Forma:** 40 caracteres base64 (`A-Za-z0-9/+`). Difícil isolar sozinha; o scanner mira quando aparece perto de `aws_secret`, `AWS_SECRET_ACCESS_KEY` ou de um Access Key ID.
- **Regex (contextual):** `(?i)aws_?secret_?access_?key['"\s:=]+['"]?[A-Za-z0-9/+]{40}`
- **Risco:** a metade que autentica. Com ela e o Access Key ID, atacante sobe instâncias (mineração), lê S3, apaga tudo. Conta de prejuízo na casa dos milhares.

### 3. Google Cloud / Firebase Service Account (JSON) — CRÍTICO
- **Forma:** JSON com `"type": "service_account"` e um bloco `"private_key": "-----BEGIN PRIVATE KEY-----..."`. Arquivo típico: `serviceAccountKey.json`, `*-firebase-adminsdk-*.json`.
- **Regex:** `"type":\s*"service_account"` **ou** `"private_key":\s*"-----BEGIN`
- **Risco:** acesso admin ao projeto GCP/Firebase. Bypassa todas as Security Rules do Firestore/Storage — lê e escreve qualquer dado de qualquer usuário. Um dos vazamentos mais graves possíveis nessa stack.

### 4. Google API Key (`AIza...`) — ALTO
- **Forma:** `AIza` seguido de 35 caracteres (`[0-9A-Za-z\-_]`).
- **Regex:** `\bAIza[0-9A-Za-z\-_]{35}\b`
- **Risco:** usada por Maps, Firebase web, YouTube, etc. Se não estiver restrita por domínio/IP no console, terceiros consomem sua cota e geram conta. No client (Firebase web) ela é "pública" por design — mas só é segura se as restrições e as Security Rules estiverem certas. Vazar fora desse contexto é ALTO.

### 5. GCP OAuth Client Secret — ALTO
- **Forma:** `GOCSPX-` seguido de ~28 caracteres.
- **Regex:** `\bGOCSPX-[0-9A-Za-z\-_]{20,}\b`
- **Risco:** permite forjar o fluxo OAuth da sua aplicação Google — login com Google, consentimento. Sequestro de identidade do app.

### 6. Azure / Microsoft — ALTO
- **Forma:** connection strings com `AccountKey=` (Storage), `SharedAccessKey=` (Service Bus), ou client secret de App Registration.
- **Regex:** `(?i)(AccountKey|SharedAccessKey)=[A-Za-z0-9/+]{40,}={0,2}`
- **Risco:** acesso ao recurso Azure correspondente (storage, fila, etc.).

---

## Pagamentos

### 7. Stripe Secret Key — live (`sk_live`) — CRÍTICO
- **Forma:** `sk_live_` seguido de 24+ caracteres alfanuméricos. Variante restrita: `rk_live_`.
- **Regex:** `\b(sk|rk)_live_[0-9a-zA-Z]{24,}\b`
- **Risco:** controle total da conta Stripe de produção. Criar cobranças, reembolsos, ler dados de clientes, transferir saldo. Dinheiro real.

### 8. Stripe Secret Key — test (`sk_test`) — MÉDIO
- **Forma:** `sk_test_` + 24+ chars.
- **Regex:** `\b(sk|rk)_test_[0-9a-zA-Z]{24,}\b`
- **Risco:** ambiente de teste, sem dinheiro real. Ainda assim não deve vazar — expõe estrutura e pode dar acesso a dados de teste. Rotacione mesmo assim.

### 9. Stripe Publishable Key (`pk_live` / `pk_test`) — BAIXO
- **Forma:** `pk_live_` ou `pk_test_` + chars.
- **Regex:** `\bpk_(live|test)_[0-9a-zA-Z]{24,}\b`
- **Risco:** projetada pra ir no client — não é segredo. O Faro sinaliza só pra confirmar que ninguém trocou `pk` por `sk` por engano. Baixíssimo impacto.

### 10. PayPal / Braintree Access Token — ALTO
- **Forma:** `access_token$production$` + 16 hex + `$` + 32 hex.
- **Regex:** `access_token\$production\$[0-9a-z]{16}\$[0-9a-f]{32}`
- **Risco:** acesso à API de pagamentos PayPal/Braintree em produção.

---

## IA / LLM

### 11. OpenAI API Key (`sk-`) — CRÍTICO
- **Forma:** `sk-` seguido de 20+ chars; projetos novos usam `sk-proj-`. Antigas: `sk-` + 48 chars.
- **Regex:** `\bsk-(proj-)?[A-Za-z0-9\-_]{20,}\b`
- **Risco:** uso da sua cota OpenAI. Atacante torra créditos em minutos; sem limite de gasto configurado, conta cara. Rotacione na hora.

### 12. Anthropic API Key (`sk-ant-`) — CRÍTICO
- **Forma:** `sk-ant-` seguido de `api03-` (ou similar) + ~95 chars.
- **Regex:** `\bsk-ant-[A-Za-z0-9\-_]{20,}\b`
- **Risco:** uso da sua cota Anthropic (Claude). Mesmo perfil de prejuízo da OpenAI.

### 13. Outros provedores de IA — ALTO
- **Forma:** Cohere, Hugging Face (`hf_...`), Replicate (`r8_...`), Google AI (`AIza...`, ver item 4), Groq (`gsk_...`).
- **Regex:** `\b(hf_[A-Za-z0-9]{30,}|r8_[A-Za-z0-9]{30,}|gsk_[A-Za-z0-9]{40,})\b`
- **Risco:** consumo de cota / acesso a modelos privados (Hugging Face).

---

## Controle de versão / CI

### 14. GitHub Personal Access Token (`ghp_`) — CRÍTICO
- **Forma:** `ghp_` + 36 chars. Variantes: `gho_` (OAuth), `ghu_` (user-to-server), `ghs_` (server), `ghr_` (refresh).
- **Regex:** `\bgh[opusr]_[A-Za-z0-9]{36,}\b`
- **Risco:** acesso aos seus repositórios com o escopo do token. Se tem `repo`, o atacante lê/escreve código privado, abre releases maliciosas, lê outros segredos do repo.

### 15. GitHub Fine-grained PAT — CRÍTICO
- **Forma:** `github_pat_` + 22 chars + `_` + 59 chars.
- **Regex:** `\bgithub_pat_[A-Za-z0-9_]{60,}\b`
- **Risco:** igual ao item 14, com escopo possivelmente mais restrito — ainda assim crítico.

### 16. GitLab PAT (`glpat-`) — ALTO
- **Forma:** `glpat-` + 20 chars.
- **Regex:** `\bglpat-[A-Za-z0-9\-_]{20,}\b`
- **Risco:** acesso à API GitLab no escopo do token.

### 17. Vercel Token — ALTO
- **Forma:** token de 24 chars hex/alfanum, geralmente em `VERCEL_TOKEN` ou `~/.vercel`.
- **Regex (contextual):** `(?i)vercel[_-]?token['"\s:=]+['"]?[A-Za-z0-9]{24}`
- **Risco:** deploy, leitura de env vars de produção, controle dos projetos Vercel da conta.

### 18. npm Token — ALTO
- **Forma:** `npm_` + 36 chars.
- **Regex:** `\bnpm_[A-Za-z0-9]{36}\b`
- **Risco:** publicar pacotes em seu nome — vetor de supply-chain attack.

---

## Mensageria / Comunicação

### 19. Slack Token — ALTO
- **Forma:** `xox` + tipo (`b`/`p`/`a`/`s`/`r`) + `-` + sequências numéricas e hex.
- **Regex:** `\bxox[baprs]-[0-9A-Za-z\-]{10,}\b`
- **Risco:** ler/postar em canais, acessar dados do workspace conforme o escopo.

### 20. Slack Webhook URL — MÉDIO
- **Forma:** `https://hooks.slack.com/services/T.../B.../...`.
- **Regex:** `https://hooks\.slack\.com/services/[A-Za-z0-9/]+`
- **Risco:** qualquer um posta no seu canal. Spam/phishing interno.

### 21. Discord Bot Token — ALTO
- **Forma:** três segmentos base64 separados por ponto, começando com ID do bot.
- **Regex:** `\b[MNO][A-Za-z0-9_-]{23}\.[A-Za-z0-9_-]{6}\.[A-Za-z0-9_-]{27,}\b`
- **Risco:** controle do bot Discord — ler/enviar mensagens, gerenciar servidores conforme permissões.

### 22. Twilio — ALTO
- **Forma:** Account SID `AC` + 32 hex; Auth Token 32 hex; API Key `SK` + 32 hex.
- **Regex:** `\b(AC|SK)[0-9a-f]{32}\b`
- **Risco:** enviar SMS/ligações na sua conta — conta financeira e uso pra fraude/phishing.

### 23. SendGrid API Key — ALTO
- **Forma:** `SG.` + 22 chars + `.` + 43 chars.
- **Regex:** `\bSG\.[A-Za-z0-9\-_]{22}\.[A-Za-z0-9\-_]{43}\b`
- **Risco:** enviar e-mail pelo seu domínio — phishing com sua reputação, queima de deliverability.

### 24. Mailgun / Mailchimp / Postmark — ALTO
- **Forma:** Mailgun `key-` + 32 hex; Mailchimp 32 hex + `-us` + dígitos; Postmark UUID.
- **Regex:** `\b(key-[0-9a-f]{32}|[0-9a-f]{32}-us[0-9]{1,2})\b`
- **Risco:** envio de e-mail em seu nome.

---

## Tokens e credenciais genéricas

### 25. JSON Web Token (JWT) — MÉDIO
- **Forma:** três blocos base64url separados por ponto, começando por `eyJ` (header `{"alg"...`).
- **Regex:** `\beyJ[A-Za-z0-9\-_]+\.eyJ[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\b`
- **Risco:** depende. Se for um token de sessão/serviço válido, dá acesso enquanto não expirar. Decodifique o payload (é base64, não criptografado) pra ver `exp` e escopo. Sinalizado como MÉDIO; suba pra ALTO se for token de serviço de longa duração.

### 26. Chave privada (PEM / RSA / EC / OpenSSH / PGP) — CRÍTICO
- **Forma:** bloco `-----BEGIN ... PRIVATE KEY-----`. Cobre RSA, EC, DSA, OpenSSH e PGP.
- **Regex:** `-----BEGIN ([A-Z]+ )?PRIVATE KEY-----`
- **Risco:** a chave privada é o ativo mais sensível que existe. Pode autenticar SSH em servidores, assinar como você, decriptar TLS. Vazou = comprometido, ponto.

### 27. Senha em string de conexão de banco — ALTO
- **Forma:** URI `protocolo://usuario:SENHA@host`. Protocolos: `postgres`, `postgresql`, `mysql`, `mongodb`, `mongodb+srv`, `redis`, `amqp`.
- **Regex:** `\b(postgres(ql)?|mysql|mongodb(\+srv)?|redis|amqp)://[^:\s/]+:[^@\s/]+@`
- **Risco:** acesso direto ao banco com a senha embutida. Leitura/escrita/dump de todos os dados. O scanner ignora `:senha@` óbvios de placeholder (`password`, `***`, `user:pass`).

### 28. Basic Auth em URL — MÉDIO
- **Forma:** `https://usuario:senha@host` (qualquer protocolo http/https).
- **Regex:** `https?://[^:\s/]+:[^@\s/]+@`
- **Risco:** credenciais embutidas em URL. Vazam em logs, histórico de browser, referer.

### 29. Token Bearer genérico em header — MÉDIO
- **Forma:** `Authorization: Bearer <token>` com token longo hardcoded.
- **Regex:** `(?i)bearer\s+[A-Za-z0-9\-_\.=]{20,}`
- **Risco:** token de API hardcoded. Confirme o que ele acessa.

### 30. Atribuição genérica de segredo no código — MÉDIO
- **Forma:** variável com nome sugestivo (`api_key`, `apikey`, `secret`, `token`, `password`, `passwd`, `pwd`, `auth`, `client_secret`, `access_token`, `private_key`) recebendo string longa literal.
- **Regex:** `(?i)(api[_-]?key|secret|token|password|passwd|pwd|client[_-]?secret|access[_-]?token|auth)['"\s]*[:=]\s*['"][^'"\s]{12,}['"]`
- **Risco:** captura segredos que não têm prefixo conhecido. Mais ruidoso — por isso MÉDIO e com filtro forte de placeholder.

---

## Específicos da stack (Next.js / Firebase / Vercel)

### 31. `NEXT_PUBLIC_*` com segredo dentro — ALTO
- **Forma:** variável `NEXT_PUBLIC_...` cujo nome **ou** valor sugere segredo: `NEXT_PUBLIC_*SECRET*`, `NEXT_PUBLIC_*API_KEY*` apontando pra chave server-side, `NEXT_PUBLIC_STRIPE_SECRET`, etc.
- **Regex:** `(?i)NEXT_PUBLIC_[A-Z_]*(SECRET|PRIVATE|SERVICE_ACCOUNT|SK_LIVE|PASSWORD)[A-Z_]*`
- **Risco:** **tudo que começa com `NEXT_PUBLIC_` é embutido no bundle JavaScript e enviado pro browser.** Qualquer visitante lê via DevTools. Se você colocou um segredo aí, ele está público — não importa que esteja num `.env`. Erro de arquitetura clássico nessa stack. Rotacione e mova pra variável server-side (sem o prefixo).

### 32. `firebaseConfig` hardcoded no client — BAIXO/MÉDIO
- **Forma:** objeto `{ apiKey, authDomain, projectId, ... }` colado no código.
- **Regex:** `(?i)(authDomain|messagingSenderId|appId)\s*:\s*['"]`
- **Risco:** o `firebaseConfig` do client é **público por design** — não é o vazamento em si. O risco real é o que ele revela: se as Firestore/Storage Security Rules estiverem abertas (`allow read, write: if true`), qualquer um com esse config acessa seu banco. Sinalizado como BAIXO/MÉDIO pra você **verificar as Security Rules**, não pra rotacionar a chave.

### 33. `.env` versionado — CRÍTICO (contexto)
- **Forma:** arquivo `.env`, `.env.local`, `.env.development`, `.env.production`, `.env.staging` presente no repositório e **não** coberto pelo `.gitignore`.
- **Detecção:** o scanner cruza a existência do arquivo com `git check-ignore`.
- **Risco:** o `.env` concentra todos os segredos do projeto. Versionado, vaza tudo de uma vez. Severidade depende do conteúdo — trate como CRÍTICO até provar o contrário. Exceção legítima: `.env.example` com valores fake.

### 34. Sentry DSN com chave secreta — MÉDIO
- **Forma:** DSN antigo `https://<public>:<secret>@sentry.io/...` (o `:<secret>` é o problema; DSN moderno não tem).
- **Regex:** `https://[0-9a-f]+:[0-9a-f]+@[a-z0-9.]*sentry\.io/`
- **Risco:** a parte secreta do DSN permite forjar eventos e acessar a API do projeto Sentry.

---

## Outros provedores comuns

### 35. Algolia Admin Key — ALTO
- **Contexto:** `ALGOLIA_ADMIN_KEY`, chave hex de 32 chars com poder de escrita no índice.
- **Regex (contextual):** `(?i)algolia[_-]?admin[_-]?key['"\s:=]+['"]?[0-9a-f]{32}`
- **Risco:** apagar/reescrever índices de busca.

### 36. Cloudinary URL — ALTO
- **Forma:** `cloudinary://<api_key>:<api_secret>@<cloud_name>`.
- **Regex:** `cloudinary://[0-9]+:[A-Za-z0-9\-_]+@`
- **Risco:** upload/exclusão de mídia, consumo de cota.

### 37. Supabase Service Role Key — CRÍTICO
- **Forma:** JWT com `"role":"service_role"` no payload. Costuma estar em `SUPABASE_SERVICE_ROLE_KEY`.
- **Regex:** `(?i)service_role` combinado com forma de JWT (item 25), ou contexto `SUPABASE_SERVICE_ROLE`.
- **Risco:** bypassa o Row Level Security do Supabase — acesso total ao banco, como o service account do Firebase. CRÍTICO. (A `anon key` é pública por design — baixo risco.)

### 38. DigitalOcean Token — ALTO
- **Forma:** `dop_v1_` + 64 hex.
- **Regex:** `\bdop_v1_[0-9a-f]{64}\b`
- **Risco:** controle dos recursos DigitalOcean da conta.

### 39. Datadog API Key — MÉDIO
- **Forma:** 32 hex, contexto `DD_API_KEY` / `DATADOG`.
- **Regex (contextual):** `(?i)(datadog|dd)[_-]?api[_-]?key['"\s:=]+['"]?[0-9a-f]{32}`
- **Risco:** injetar métricas/logs falsos, custo.

### 40. Heroku API Key — ALTO
- **Forma:** UUID v4, contexto `HEROKU_API_KEY`.
- **Regex (contextual):** `(?i)heroku[_-]?api[_-]?key['"\s:=]+['"]?[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}`
- **Risco:** deploy e gestão dos apps Heroku.

### 41. Shopify Token — ALTO
- **Forma:** `shpat_` (admin), `shpss_` (shared secret), `shppa_` (private app) + 32 hex.
- **Regex:** `\bshp(at|ss|pa|ca)_[0-9a-fA-F]{32}\b`
- **Risco:** acesso à API da loja Shopify — pedidos, clientes, produtos.

### 42. Telegram Bot Token — MÉDIO
- **Forma:** `<id>:<35 chars>`.
- **Regex:** `\b[0-9]{8,10}:[A-Za-z0-9_-]{35}\b`
- **Risco:** controle do bot Telegram.

---

## Sobre placeholders

O scanner descarta automaticamente valores que casam padrões mas são claramente fakes. Lista de marcadores ignorados (case-insensitive, qualquer parte do valor):

`example`, `examplekey`, `your-key`, `your_key`, `yourkey`, `your-api-key`, `my-secret`, `changeme`, `change-me`, `placeholder`, `dummy`, `test123`, `xxxx`, `xxxxx`, `<your`, `insert`, `replace`, `todo`, `fixme`, `0000000000`, `1234567890`, `abcdef`, `foo`, `bar`, `baz`, `sample`, `redacted`, `secret_here`, `notreal`.

Falso-positivo ainda acontece (ex.: um hash legítimo que parece chave). Por isso o scanner reporta um nível de confiança e você confirma antes de rotacionar — embora, na dúvida sobre um segredo de produção, rotacionar é o lado seguro pra errar.
