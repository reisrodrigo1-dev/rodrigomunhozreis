---
name: faro
description: Escaneia o repositório atrás de segredos vazados (chaves de API, senhas, .env no Git) e diz como remediar. Use antes de commitar/subir, ou ao revisar se algo sensível vazou.
---

# Faro

Faro é um caçador de segredos vazados. Ele fareja o repositório atrás de chaves de API, senhas, tokens e arquivos `.env` que não deveriam estar versionados — no código atual **e** no histórico do Git — e te diz exatamente o que fazer com cada achado.

Segredo que vaza não se "desfaz" apagando uma linha. Se vazou, vazou: tem que rotacionar. Esta skill parte desse princípio.

## Quando usar

- **Antes de commitar ou dar push** — varredura rápida pra não subir nada sensível.
- **Antes de tornar um repo público** (ou abrir o código pra alguém novo).
- **Quando bate a dúvida** "será que eu commitei aquela chave?".
- **Em revisão de PR** que mexe em config, env, deploy, CI/CD.
- **Depois de um incidente** — pra mapear o estrago e o que precisa rotacionar.

Stack típica do público (Next.js, Firebase, Vercel, GitHub) tem armadilhas próprias: `NEXT_PUBLIC_*` que vaza no bundle, `firebaseConfig` colado no client, service account JSON do GCP commitado, `.env.local` esquecido fora do `.gitignore`. O Faro conhece essas.

## Procedimento

Siga na ordem. Cada passo alimenta o próximo.

### 1. Escanear o código por padrões de segredo

Rode o scanner na raiz do repositório:

```bash
python scripts/escanear.py .
```

Ele varre os arquivos versionáveis (ignora `node_modules/`, `.next/`, `.git/`, `dist/`, `build/`, etc.), casa cada arquivo contra o catálogo de padrões, descarta placeholders óbvios (`your-key`, `xxx`, `example`, `changeme`) e ordena os achados por severidade.

Para integrar com outra ferramenta ou CI, use `--json`:

```bash
python scripts/escanear.py . --json
```

O catálogo completo de padrões, com como reconhecer cada um e o risco associado, está em [`reference/padroes-de-segredo.md`](reference/padroes-de-segredo.md). Consulte quando precisar entender um achado ou explicar a severidade.

### 2. Conferir se `.env*` está no `.gitignore`

O scanner já sinaliza quando encontra um `.env`, `.env.local`, `.env.production` etc. que **não** está coberto pelo `.gitignore`. Confirme manualmente:

```bash
git check-ignore .env .env.local .env.production
```

Se o comando **não** lista o arquivo, ele não está sendo ignorado — e provavelmente já foi (ou vai ser) commitado. Adicione ao `.gitignore`:

```gitignore
# Variáveis de ambiente — nunca versionar
.env
.env.*
!.env.example
```

Atenção: adicionar ao `.gitignore` **não remove** o que já está versionado. Se o arquivo já entrou em algum commit, vá pro passo 3.

### 3. Checar o histórico do Git por segredos já commitados

Um segredo pode ter sido removido do arquivo atual mas continuar vivo no histórico. Quem clona o repo, clona o histórico inteiro.

Busca rápida por termos no histórico completo:

```bash
git log -p --all -S "AKIA" -- .            # exemplo: AWS access key
git log -p --all --pickaxe-regex -S "sk_live_[0-9a-zA-Z]{24,}"   # Stripe live
```

Para listar arquivos sensíveis que já existiram em qualquer commit:

```bash
git log --all --diff-filter=A --name-only --pretty=format: | sort -u | grep -E '\.env|credentials|serviceAccount|\.pem$'
```

Achou algo no histórico? O arquivo precisa ser **expurgado** do histórico (passo 4), não só apagado no commit mais recente.

### 4. Para cada achado: localização, severidade e remediação

Para todo segredo encontrado, reporte:

- **Localização** — arquivo, linha e se está no working tree, no commit atual e/ou no histórico.
- **Severidade** — `CRÍTICO` (credencial de produção viva: `sk_live`, AWS secret, private key, service account), `ALTO` (token de acesso, senha de banco), `MÉDIO` (chave pública mal usada, JWT), `BAIXO` (provável placeholder, mas confirme).
- **Como remediar**, nesta ordem inegociável:
  1. **Rotacionar a chave no provedor — obrigatório se vazou.** Gere uma nova credencial e revogue a antiga. Enquanto a chave antiga existir, ela está comprometida, independente de você limpar o Git.
  2. **Remover do código** — tirar o valor do arquivo, mover pra variável de ambiente / secret manager.
  3. **Limpar do histórico** se já foi commitado — `git filter-repo` ou BFG, depois force-push (combinando com o time).

O passo a passo detalhado de remediação, incluindo por que "só apagar o commit" não basta e os comandos de `git filter-repo` e BFG, está em [`reference/remediacao.md`](reference/remediacao.md).

## Princípios

- **Se vazou, rotacione.** Limpar o Git sem rotacionar é teatro de segurança. A regra de ouro: trate todo segredo que tocou o repositório como comprometido.
- **Sem alarme falso barato.** O scanner filtra placeholders, mas falso-positivo acontece. Ao reportar, diga seu nível de confiança.
- **A decisão é sua.** O Faro aponta, explica o risco e mostra o caminho. Rotacionar uma chave de produção pode quebrar coisas — quem decide quando e como é você.
