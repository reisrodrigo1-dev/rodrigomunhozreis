# Remediação: o que fazer quando um segredo vazou

Regra que governa tudo aqui: **se um segredo tocou o repositório, considere-o comprometido.** Não importa se você apagou rápido, se o repo é privado, se "ninguém viu". A única ação que de fato fecha o buraco é rotacionar. O resto é higiene.

A ordem importa. Faça nesta sequência.

---

## Passo 1 — Rotacionar a chave no provedor (OBRIGATÓRIO)

Antes de mexer no Git, antes de qualquer coisa: **gere uma credencial nova e revogue a antiga.** Enquanto a chave vazada existir, ela funciona pra quem a tem.

Por quê primeiro? Porque limpar o histórico do Git pode levar minutos a horas (e exige coordenação com o time). A chave fica exposta esse tempo todo. Rotacionar é o que para o sangramento — faça já, depois limpe o Git com calma.

Onde rotacionar, por provedor:

| Provedor | Onde |
|---|---|
| **AWS** | IAM → Users → Security credentials → desative e delete a access key, crie nova. Se foi root key, é incidente sério: rotacione e revise CloudTrail. |
| **GCP / Firebase** | IAM & Admin → Service Accounts → Keys → delete a chave JSON, gere nova. Revise logs de acesso. |
| **Firebase Web API Key** | Não "rotaciona" como segredo — restrinja por domínio/IP no Google Cloud Console (API restrictions) e revise as Security Rules. |
| **Stripe** | Dashboard → Developers → API keys → Roll key. A antiga morre na hora. |
| **OpenAI / Anthropic** | Painel de API keys → revoke a chave → create new. Configure limite de gasto. |
| **GitHub** | Settings → Developer settings → Personal access tokens → revoke. Gere novo com escopo mínimo. |
| **Vercel** | Account Settings → Tokens → delete e recrie. |
| **Banco de dados** | Troque a senha do usuário (`ALTER USER ... PASSWORD`) ou rode o usuário. Atualize a connection string nos ambientes. |
| **Supabase** | Project Settings → API → gere novo service_role / JWT secret (isso invalida tokens existentes). |

Depois de rotacionar, **atualize a credencial nova** onde ela é usada de verdade — variável de ambiente local, secrets do Vercel/GitHub Actions, secret manager. Nunca de volta pro código.

---

## Passo 2 — Remover do código

Agora tire o valor do arquivo:

1. Substitua o literal por leitura de variável de ambiente:
   ```js
   // antes
   const stripe = new Stripe("sk_live_51Abc...");
   // depois
   const stripe = new Stripe(process.env.STRIPE_SECRET_KEY);
   ```
2. Coloque o valor real (a chave **nova**, rotacionada) no `.env.local` — e garanta que `.env*` está no `.gitignore`.
3. Para o que vai pra produção, use o secret manager da plataforma:
   - **Vercel:** Project → Settings → Environment Variables.
   - **GitHub Actions:** repo → Settings → Secrets and variables → Actions.
   - Nunca commite o valor de produção, nem "temporariamente".
4. Commit dessa mudança. Isso conserta o working tree e o commit atual — mas **não** o histórico. Vá pro passo 3.

---

## Passo 3 — Limpar o histórico do Git (se já foi commitado)

### Por que "só apagar o commit" NÃO basta

O Git é um banco de dados append-only de snapshots. Quando você faz um commit novo removendo a chave, você **adiciona** um snapshot novo — o snapshot antigo, com a chave, continua lá. Qualquer um faz:

```bash
git log -p --all          # vê o diff de todo commit
git show <hash-antigo>    # vê o arquivo como era
```

E pronto, recupera o segredo. `git revert`, `git rm`, ou um commit "fix: remove key" **não apagam nada do passado** — só empilham por cima. Pior: se o repo já foi pro GitHub, o GitHub guarda os commits mesmo "órfãos" por um tempo, e qualquer fork/clone já tem o histórico inteiro.

Pra remover de verdade, é preciso **reescrever o histórico** — recriar todos os commits afetados sem o segredo. Isso muda os hashes de todos os commits a partir do ponto afetado, por isso exige force-push e coordenação com o time.

> Lembre: mesmo com o histórico limpo, a chave antiga já esteve exposta. Por isso o passo 1 (rotacionar) é inegociável. Limpar o histórico evita exposição *futura* de uma chave que você esqueceu de rotacionar, e tira lixo sensível do repo — mas não "descompromete" a chave.

### Opção A — git filter-repo (recomendado)

`git filter-repo` é a ferramenta oficial recomendada hoje (substituiu o antigo `git filter-branch`, que é lento e cheio de pegadinhas).

Instalar:
```bash
pip install git-filter-repo
# ou: brew install git-filter-repo
```

**Faça backup do repo antes** (`cp -r repo repo-backup` ou um clone à parte). Reescrever histórico é destrutivo.

Remover um arquivo inteiro de todo o histórico (ex.: `.env`, `serviceAccountKey.json`):
```bash
git filter-repo --path .env --invert-paths
git filter-repo --path serviceAccountKey.json --invert-paths
```

Remover/mascarar um **valor** específico em todos os arquivos e commits, crie um arquivo `expressions.txt`:
```
sk_live_51Abc1234567890==>***REMOVIDO***
AKIAIOSFODNN7EXAMPLE==>***REMOVIDO***
```
e rode:
```bash
git filter-repo --replace-text expressions.txt
```

Depois, force-push (ver "Finalizando" abaixo).

### Opção B — BFG Repo-Cleaner

BFG é mais simples pra casos comuns (apagar arquivos por nome, substituir textos) e bem mais rápido que `filter-branch`. Exige Java.

Apagar arquivos por nome em todo o histórico:
```bash
bfg --delete-files .env
bfg --delete-files serviceAccountKey.json
```

Substituir segredos por `***REMOVED***` (passe um arquivo com um segredo por linha):
```bash
bfg --replace-text segredos.txt
```

O BFG **não** mexe no commit mais recente (ele assume que o `HEAD` já está limpo — por isso você faz o passo 2 antes). Depois dele:
```bash
git reflog expire --expire=now --all
git gc --prune=now --aggressive
```

### Finalizando a reescrita (vale pra A e B)

1. **Force-push** todos os refs:
   ```bash
   git push origin --force --all
   git push origin --force --tags
   ```
2. **Avise o time.** Todo mundo precisa re-clonar ou rebasear — os hashes mudaram. Quem tiver um clone antigo ainda carrega o segredo; peça pra apagarem e clonarem de novo.
3. **Force a expiração no servidor.** No GitHub, commits "órfãos" podem ficar acessíveis por hash por um tempo e em caches. Se o vazamento é grave, abra um ticket no GitHub Support pedindo a remoção de refs em cache / garbage collection. Forks já feitos mantêm o histórico — não há como apagar fork dos outros; só reforça o passo 1.
4. **Re-proteja a branch.** Force-push costuma exigir desabilitar branch protection temporariamente; reabilite depois.

---

## Passo 4 — Prevenir o próximo vazamento

- **`.gitignore` correto** desde o início:
  ```gitignore
  .env
  .env.*
  !.env.example
  *.pem
  serviceAccountKey.json
  *-firebase-adminsdk-*.json
  ```
- **`.env.example`** com chaves de exemplo (valores fake) pra documentar quais variáveis existem, sem vazar as reais.
- **Pre-commit hook** que roda o scanner antes de cada commit:
  ```bash
  # .git/hooks/pre-commit
  python scripts/escanear.py . || {
    echo "Faro encontrou possíveis segredos. Commit abortado."
    exit 1
  }
  ```
  (ou via [pre-commit framework](https://pre-commit.com/), ou ferramentas como `gitleaks` / `trufflehog` no CI.)
- **Secret scanning do GitHub** ligado (Settings → Code security). Ele avisa e, com push protection, bloqueia o push de segredos conhecidos.
- **Limite de gasto** nos provedores de IA/cloud — transforma um vazamento em susto, não em fatura de milhares.
- **Cuidado redobrado com `NEXT_PUBLIC_*`:** nunca coloque segredo numa variável com esse prefixo. Ela vai pro bundle do browser.

---

## Resumo de bolso

1. **Rotacione** a chave no provedor. Sempre. Primeiro.
2. **Remova** do código → variável de ambiente / secret manager.
3. **Limpe o histórico** com `git filter-repo` ou BFG, force-push, avise o time. ("Apagar o commit" não limpa o passado.)
4. **Previna:** `.gitignore`, `.env.example`, pre-commit hook, secret scanning, limite de gasto.

A decisão de quando rotacionar uma chave de produção (que pode derrubar serviço) é sua. O Faro mostra o risco e o caminho — você escolhe a hora.
