# Plano de Projeto — [Nome do Projeto]

> Gerado com a skill **Planta** (Engenho · Rodrigo Munhoz Reis).
> Plano antes do código. Este documento define **o que construir, em que ordem e com qual stack** — antes de uma linha de código.
> Data: [AAAA-MM-DD] · Autor do plano: [nome]

---

## 1. Problema

**A dor que isto resolve (1 frase):**
> [Qual problema real, específico, alguém tem hoje.]

**Quem sente essa dor:**
> [Perfil específico. "Todo mundo" não é resposta.]

**O que essa pessoa faz hoje, sem o produto:**
> [A solução atual — planilha, WhatsApp, concorrente, nada. Se não há dor sentida hoje, o plano para aqui.]

**Por que vale resolver agora:**
> [Frequência da dor × intensidade × disposição de pagar/usar.]

---

## 2. Usuário

**Usuário primário (o primeiro a usar):**
> [Um perfil. Nome, contexto, nível técnico.]

**A primeira ação de valor** (o que ele precisa conseguir fazer para perceber que valeu):
> [Ex.: "publicar o primeiro orçamento em menos de 5 minutos".]

**Como ele chega no produto:**
> [Canal de entrada — indicação, busca, anúncio, comunidade. Relevante para o que o MVP precisa ter.]

---

## 3. MVP — o mínimo que entrega valor

> O menor produto que um usuário real usa e que resolve a dor da seção 1.

**Must-haves (sem isto não há produto):**

| # | Funcionalidade | Por que é essencial |
|---|----------------|---------------------|
| 1 | [ex.: cadastro/login] | [destrava o uso] |
| 2 | [ex.: criar X] | [é a ação de valor] |
| 3 | [ex.: ver/compartilhar X] | [fecha o ciclo de valor] |

**Critério de sucesso do MVP:**
> [Métrica única e observável. Ex.: "10 usuários criam e compartilham pelo menos 1 X na primeira semana".]

---

## 4. Fora de escopo (por enquanto)

> Cortado de propósito para entregar valor mais rápido. **Não é "nunca" — é "agora não".**

| Item cortado | Por que ficou de fora do MVP |
|--------------|------------------------------|
| [ex.: app mobile nativo] | [web resolve a dor; nativo é otimização] |
| [ex.: painel de admin] | [dá pra operar no console por enquanto] |
| [ex.: integração com Z] | [poucos usuários precisam; valida depois] |
| [ex.: dark mode, i18n, gamificação] | [estética/retenção, não valor central] |

---

## 5. Stack e Arquitetura

> A stack mais simples que entrega o MVP e aguenta o primeiro ano real. (Recomendação detalhada: skill **Bússola**.)

| Camada | Escolha | Por quê (1 linha) |
|--------|---------|-------------------|
| Frontend / Fullstack | [ex.: Next.js (App Router)] | [um framework, SSR + API juntos] |
| Hospedagem | [ex.: Vercel] | [deploy automático do Git, escala sob demanda] |
| Auth | [ex.: Firebase Auth] | [login pronto, sem reinventar] |
| Banco de dados | [ex.: Firestore] | [rápido de começar, escala sem servidor] |
| Arquivos | [ex.: Firebase Storage] | [uploads sem infra própria] |
| Pagamento | [ex.: Stripe / não há no MVP] | [se houver cobrança] |
| Outros | [ex.: API de IA, e-mail] | [integrações externas] |

**Modelo de dados (alto nível):**
> [Quais coleções/tabelas e como se relacionam. Ex.: `users` 1—N `projetos` 1—N `orcamentos`.]

**Decisões com trade-off (atenção):**
> [Ex.: "Firestore é ótimo para começar, mas cobra por read — paginar listas desde o início." Ligar com a seção 7.]

---

## 6. Fases / Marcos (ordem de execução)

> Ordenadas por **dependência** (o que destrava o resto) e **risco** (atacar cedo o que pode furar).
> Uma fase só termina quando dá pra mostrar funcionando.

### Fase 0 — Fundação
- **Objetivo:** repositório, deploy vazio no ar, auth funcionando.
- **Entregável testável:** "hello world" autenticado em produção.
- **Pronto quando:** [dá pra logar e ver uma tela vazia no domínio real].

### Fase 1 — Núcleo de valor
- **Objetivo:** a ação de valor da seção 2, ponta a ponta.
- **Entregável testável:** [usuário consegue fazer X de verdade].
- **Pronto quando:** [critério observável].

### Fase 2 — Completar o fluxo
- **Objetivo:** tornar usável por um usuário real (estados de erro/vazio, edição, etc.).
- **Entregável testável:** [fluxo completo sem becos sem saída].
- **Pronto quando:** [critério observável].

### Fase 3 — Monetização / nice-to-haves prioritários *(se no MVP)*
- **Objetivo:** [ex.: cobrança, ou o primeiro nice-to-have que move a agulha].
- **Entregável testável:** [critério].
- **Pronto quando:** [critério observável].

---

## 7. Riscos e onde o custo pode explodir

**Riscos de produto / mercado:**

| Risco | Gatilho | Mitigação |
|-------|---------|-----------|
| [ninguém tem a dor de verdade] | [poucos usam após o lançamento] | [validar com 5 usuários antes da Fase 1] |
| [usuário não entende a primeira ação] | [abandono no onboarding] | [reduzir a 1 tela; testar com 3 pessoas] |

**Riscos técnicos:**

| Risco | Gatilho | Mitigação |
|-------|---------|-----------|
| [dependência de API externa] | [API cai/muda preço] | [isolar atrás de uma camada própria] |

**Onde o custo pode explodir** (vibecoding na stack de referência):

| Fonte de custo | Gatilho | Como evitar no desenho |
|----------------|---------|------------------------|
| Firestore (reads) | listas recarregando, listeners abertos, sem paginação | paginar, cachear, limitar queries |
| API de IA (tokens) | uso por usuário sem teto | limite por usuário, cache de respostas |
| E-mail / SMS / storage / egress | volume cresce e ninguém olha | monitorar, definir alertas de custo |
| Vercel (funções/bandwidth) | plano errado para o tráfego | revisar plano antes de divulgar |

---

## 8. Próximo passo

> O menor passo concreto para começar.

**Primeira coisa a construir:** [a menor peça da Fase 0].
**Próxima skill:** [ex.: Canteiro — scaffold blindado.]

---

> **A decisão é sua.** Este é o plano recomendado: escopo enxuto, ordem por dependência e risco, custos mapeados. O que entra e o que fica de fora do MVP é decisão do dono do produto.
