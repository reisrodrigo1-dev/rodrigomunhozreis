# Perguntas de Descoberta

> Referência da skill **Planta**. Use no Passo 1 (descoberta).
> Princípio: **valide a dor antes de validar a solução.** Ideias chegam embrulhadas em solução ("quero um app com IA que…"). Seu trabalho é desembrulhar até achar a dor real e quem a sente.

## Como usar este banco

- **Não despeje todas de uma vez.** Pergunte em blocos curtos; comece pelas essenciais (marcadas com ⭐), aprofunde conforme as respostas pedirem.
- **Persiga a dor, não a feature.** Se a pessoa responde com solução ("um botão que…"), volte: *"e qual problema isso resolve pra ela?"*.
- **Desconfie de "todo mundo" e "vai ser tipo o [empresa]".** Empurre para o específico: *uma* pessoa, *uma* dor.
- **Se as essenciais não têm resposta** (quem sente a dor, o que faz hoje), a ideia ainda não está pronta para construir — está pronta para conversar com usuários. Diga isso. É parte do valor da Planta.

---

## Bloco 1 — Problema (a dor real)

- ⭐ **Qual problema exato isto resolve?** Descreva em uma frase, sem mencionar a solução.
- ⭐ **Quem tem esse problema hoje?** (Um perfil específico, não "todo mundo".)
- ⭐ **O que essa pessoa faz hoje, sem o seu produto?** (Planilha? WhatsApp? Concorrente? Nada?)
- Com que **frequência** essa dor aparece? (Toda hora, toda semana, raramente?)
- **Quão grande é a dor?** É um incômodo ou um problema que custa dinheiro/tempo/sono?
- Por que **as soluções atuais não bastam**? O que falta nelas?
- Você **já sentiu essa dor pessoalmente**, ou está supondo que outros sentem?
- Se isto não existisse, **alguém sentiria falta**? Quem reclamaria primeiro?

## Bloco 2 — Usuário

- ⭐ **Quem é a primeira pessoa que vai usar isto?** (Perfil: papel, contexto, nível técnico.)
- Quantas dessas pessoas você **conhece ou consegue alcançar** hoje?
- Onde elas **já estão** (comunidade, app, lugar) — como você chega até elas?
- Qual o **nível técnico** delas? (Muda como a interface e o onboarding precisam ser.)
- Elas **pagariam** por uma solução? Quanto? Já pagam por algo parecido?
- Existe mais de um tipo de usuário (ex.: quem cria e quem consome)? **Qual vem primeiro?**

## Bloco 3 — Sucesso (como saberemos que funcionou)

- ⭐ **Qual é a primeira ação de valor?** O que o usuário precisa conseguir fazer para pensar "isso é útil"?
- Como você vai **saber, em números, que deu certo** nas primeiras semanas? (Ex.: X usuários fizeram Y.)
- Qual seria um **sinal claro de fracasso** — algo que, se acontecer, diz que a ideia não cola?
- Daqui a 3 meses, **o que precisa ser verdade** para valer a pena continuar?
- Você quer **validar a ideia** ou já está convicto e quer construir? (Muda a profundidade do MVP.)

## Bloco 4 — Restrições

- ⭐ Qual o **prazo**? Existe uma data ou evento (lançamento, investidor, cliente esperando)?
- Qual o **orçamento** para ferramentas/infra por mês? (Afeta stack e onde o custo pode doer.)
- **Quem vai construir?** Você, um time, IA? Qual o nível técnico de quem põe a mão?
- Há **integração ou ferramenta obrigatória**? (Sistema legado, gateway de pagamento específico, ERP, planilha existente.)
- Há **restrição de dados** — dados pessoais, sigilo, setor regulado (saúde, financeiro, jurídico)?
- Existe **algo que já está pronto** (design, código, conta, base de usuários) que dá pra aproveitar?
- Qual o **apetite a risco**? Prefere validar barato e rápido, ou já investir num produto mais redondo?

---

## Perguntas de aprofundamento (quando precisar cavar)

- "Me conta a **última vez** que você (ou seu usuário) viveu essa dor. O que aconteceu, passo a passo?"
- "Se eu te desse uma **varinha mágica** que resolve só *uma* parte disso, qual parte você escolheria?"
- "O que faria você **desistir** de usar este produto na primeira semana?"
- "Se a versão 1 só pudesse fazer **uma coisa**, qual seria a coisa que justifica existir?"
- "Quem **não** é seu usuário? Para quem isto explicitamente não é?"

## Sinais de alerta nas respostas

- **"É para todo mundo."** → Ainda não há usuário. Empurre para um perfil específico.
- **"Já existe X, mas o meu vai ser melhor."** → Cuidado. *Por que* o atual não basta para o usuário? Sem essa resposta, é só "igual, porém meu".
- **"Eu acho que as pessoas iam querer…"** → Suposição, não dor observada. Recomende conversar com 5 usuários antes da Fase 1.
- **Lista de features como resposta para "qual o problema?"** → Solução sem dor mapeada. Volte ao Bloco 1.
- **Nenhuma restrição de prazo/orçamento/time.** → Provável falta de clareza sobre o esforço real. Vale dimensionar.

> **A decisão é sua.** A Planta faz as perguntas e aponta quando a ideia ainda precisa de validação antes de virar código. Seguir mesmo assim é uma escolha legítima — desde que consciente do risco.
