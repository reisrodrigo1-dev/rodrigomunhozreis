# Escopo de MVP — como definir e CORTAR

> Referência da skill **Planta**. Use no Passo 2 (definir o MVP).
> Princípio: **MVP é o *mínimo* que entrega valor — não a versão pobre, a versão honesta do primeiro valor real.**

O erro número um de quem constrói com IA não é escrever código ruim — é escrever código demais. A velocidade da geração engana: dá pra criar 10 telas num fim de semana, então cria-se. Cada uma dessas telas vira manutenção, bug e suporte para sempre. **Escopo é o inimigo.** Este documento é sobre dizer "não" a tempo.

---

## O que é (e o que NÃO é) um MVP

**MVP (Minimum Viable Product)** é a **menor coisa que um usuário real pode usar e que resolve a dor principal de verdade.**

| MVP é | MVP NÃO é |
|-------|-----------|
| O primeiro corte honesto de valor | Uma versão "de mentira" ou protótipo descartável |
| Estreito e fundo (uma dor, bem resolvida) | Largo e raso (muitas features pela metade) |
| Algo que dá pra usar e medir | Uma demo bonita que não resolve nada |
| Cortado de propósito | "Tudo que a versão final tem, só que menos polido" |

> Metáfora: se a dor é "ir de A a B", o MVP é um **skate**, não um **chassi de carro sem motor**. O skate leva de A a B hoje. O chassi não leva ninguém a lugar nenhum até estar completo.

---

## O teste do MVP (aplicar em cada item)

Para **cada** funcionalidade que veio na ideia, pergunte, nesta ordem:

1. **Se eu remover isto, o usuário ainda resolve a dor principal?**
   - Sim → **fora do MVP.**
   - Não → candidato a must-have, siga.
2. **Isto é preciso para a *primeira* ação de valor, ou para uma ação futura?**
   - Futura → **fora do MVP.**
3. **Existe um jeito mais simples (manual, console, planilha) de fazer isto por enquanto?**
   - Sim → **fora do MVP** (faça manual até doer).
4. **Sem isto, o produto fica inseguro, ilegal ou quebrado?**
   - Sim → **must-have** (auth, regra de dado pessoal, cobrança correta entram aqui).

Sobrou must-have? Ótimo, é o MVP. Todo o resto vai para **fora-de-escopo (por enquanto)** — e isso fica **escrito**.

---

## Must-have vs Nice-to-have

| | Must-have | Nice-to-have |
|---|-----------|--------------|
| Definição | Sem isso **não há produto** | Melhora, mas dá pra viver sem |
| Pergunta-chave | "O usuário consegue resolver a dor sem isso?" → Não | "...sem isso?" → Sim |
| Exemplos típicos | login (se o dado é por usuário), criar o item central, ver/usar o item | dark mode, exportar PDF, notificações, dashboard de métricas, app nativo, i18n |
| Regra | entra no MVP | **default é ficar de fora** até provar que precisa |

**Regra do default:** todo item começa **fora** do MVP. Ele só entra se passar no teste acima. Inverter o default — assumir que tudo entra e cortar o que sobra — é como o escopo incha.

---

## Erros comuns (o escopo inflado)

1. **"Já que estou aqui…"** — adicionar features porque é fácil agora. Cada uma custa para sempre. Pare.
2. **"Tipo o [empresa famosa], só que…"** — querer paridade de features com um produto que tem 10 anos e 500 engenheiros. Eles também começaram com uma feature.
3. **Construir para o usuário avançado que você não tem.** Configurações, permissões granulares, multi-tenant, plugins — tudo isso é otimização para uma escala que ainda não existe.
4. **Confundir polimento com produto.** Animações, onboarding gamificado, 5 temas. Nada disso resolve a dor; tudo isso atrasa a validação dela.
5. **Construir o admin antes do produto.** O painel interno pode esperar — o console do Firebase ou uma planilha resolvem no começo.
6. **Automatizar o que ainda não dói.** Faça manual até a dor de fazer manual justificar o código. (Concierge MVP.)
7. **Plataforma antes de produto.** Querer ser "o marketplace de X" no dia 1, quando ainda não validou que alguém quer um único X.

**Sinais de que o escopo inflou:** a lista de must-haves tem mais de ~5 itens; a Fase 1 não cabe em poucos dias; aparece a frase "mas também precisa de…"; ninguém consegue dizer em uma frase o que o produto faz.

---

## Como cortar (de forma agressiva e honesta)

1. **Liste tudo** que veio na ideia, sem filtro.
2. **Aplique o teste do MVP** item a item.
3. **Mova o cortado para uma lista visível** de fora-de-escopo — não delete, *documente*. Isso protege o foco e evita a briga do "mas a gente não ia fazer X?".
4. **Procure o "ainda não".** A maioria dos cortes não é "nunca", é "depois de validar a dor". Diga isso — corta a ansiedade de quem teve a ideia.
5. **Defenda o corte com a dor.** O argumento sempre volta para a seção Problema: "isso não é preciso para [usuário] resolver [dor]".

> **A decisão é sua.** A Planta recomenda o recorte mais enxuto que ainda entrega valor. Se o dono do produto quiser puxar um nice-to-have para dentro, tudo bem — desde que seja uma escolha consciente, com o custo na mesa, não um acidente.

---

## Exemplos de recorte

### App de orçamentos para prestadores de serviço
- **Ideia completa:** cadastro, criar orçamento, templates, assinatura digital, app mobile, dashboard de conversão, integração com NF-e, chat com cliente, multi-idioma.
- **MVP (must-have):** login · criar orçamento · enviar link do orçamento pro cliente ver.
- **Fora-de-escopo (por enquanto):** templates (copiar do último resolve), assinatura digital, app nativo (web responsivo basta), dashboard, NF-e, chat, multi-idioma.
- **Por quê:** a dor é "fazer e mandar um orçamento de aparência profissional rápido". Tudo no MVP serve essa frase; o resto é otimização.

### SaaS de agendamento para barbearias
- **Ideia completa:** página pública, agendamento online, lembrete por WhatsApp, pagamento antecipado, programa de fidelidade, relatórios, multi-unidade.
- **MVP (must-have):** o barbeiro cadastra horários · o cliente agenda num horário livre · o barbeiro vê a agenda.
- **Fora-de-escopo:** lembrete automático (mandar manual no começo), pagamento antecipado, fidelidade, relatórios, multi-unidade.
- **Por quê:** valida se barbeiro e cliente realmente usam um agendamento online antes de construir tudo em volta.
