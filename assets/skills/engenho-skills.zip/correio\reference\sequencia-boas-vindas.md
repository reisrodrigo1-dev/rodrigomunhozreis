# Sequência de boas-vindas (5 e-mails)

A sequência automática que dispara **depois que a pessoa baixa o e-book** (a isca da Alavanca). São os 5 primeiros e-mails, na ordem certa: entrega -> história/autoridade -> conteúdo útil -> prova -> oferta.

O objetivo da sequência é transformar um e-mail (que você acabou de ganhar) em confiança suficiente para um primeiro convite — sem atropelar. Entrega valor em 4 e-mails antes de ofertar no 5º. Quem entrega primeiro ganha o direito de vender.

**Cadência sugerida:** E1 na hora (imediato), E2 dia +1, E3 dia +3, E4 dia +5, E5 dia +7. Ajuste conforme a maturidade da lista. Cada e-mail tem **um objetivo e um CTA**.

> Para o texto completo de cada tipo, veja `tipos-de-email.md`. Aqui está o **mapa da sequência** com assunto e esqueleto de cada e-mail.

---

## E-mail 1 — Entrega da isca (na hora)

**Objetivo:** cumprir a promessa imediatamente. Entregar o e-book, dizer quem você é em uma frase, setar expectativa da lista.

**Assunto:** Seu e-book chegou (link aqui dentro)
**Assunto alternativo:** Pronto — aqui está o que você pediu

**Esqueleto:**
- Link do e-book nas primeiras linhas (não faça caçar).
- "Eu sou o Rodrigo, escrevo sobre vibecoding com engenharia."
- O que esperar da lista: pouca frequência, uma ideia por vez, sem encheção.
- Micro-CTA: abrir o e-book (e, opcional, responder com o maior desafio).
- **CTA:** baixar/abrir o e-book.
- **P.S.:** peça para responder contando o maior perrengue (alimenta conteúdo futuro e treina o provedor a não jogar no spam).

---

## E-mail 2 — História / autoridade (dia +1)

**Objetivo:** criar conexão e autoridade pela sua história, não pela vaidade. Por que você se importa com isso. Autoridade vem do "eu passei por isso", não do "eu sou o melhor".

**Assunto:** Por que eu parei de confiar no "rodou tá certo"
**Assunto alternativo:** A vez que a IA me entregou uma bomba-relógio

**Esqueleto:**
- Um momento real: onde você travou ou se queimou construindo com IA.
- A virada: o que você percebeu que mudou seu jeito de trabalhar.
- A ponte para a missão: por isso você escreve sobre vibecoding *com engenharia*.
- Sem venda. Só história + valor da lição.
- **CTA:** leve — responder com a história dela, ou ler um artigo relacionado.
- **P.S.:** adianta que no próximo e-mail vem uma técnica prática (cria expectativa).

---

## E-mail 3 — Conteúdo útil (dia +3)

**Objetivo:** entregar uma técnica aplicável hoje. Provar na prática que a lista vale a pena. É o e-mail que consolida o hábito de abrir.

**Assunto:** As 3 perguntas que eu faço pro código da IA
**Assunto alternativo:** Revisão de código da IA em 30 segundos

**Esqueleto:**
- Gancho: o erro de aceitar código só porque rodou.
- A técnica: 3 perguntas concretas (ex.: "isso escala?", "o que quebra se o input vier errado?", "um sênior aprovaria isso no review?").
- Exemplo curto de uma delas pegando um problema real.
- Aplicação: usar hoje, no próximo trecho gerado.
- **CTA:** leve — "experimenta e me conta", ou ler o artigo completo no blog.
- **P.S.:** complemento rápido ou gancho para o E4.

---

## E-mail 4 — Prova (dia +5)

**Objetivo:** mostrar que funciona para outras pessoas, não só para você. Prova social honesta: resultado real, depoimento real, ou um caso concreto. Reduz o "será que é pra mim?".

**Assunto:** "Achei que era só comigo"
**Assunto alternativo:** O que mudou pra quem aplicou isso

**Esqueleto:**
- Apresente um caso/depoimento real (ou um padrão que você viu em vários leitores).
- O antes (o perrengue, igual ao da pessoa) e o depois (o que mudou).
- Conecte ao método/jeito de pensar que você vem ensinando — não a um produto ainda.
- Honestidade: nada de número inflado nem promessa de resultado garantido.
- **CTA:** leve — responder, ou conferir o conteúdo que gerou o resultado.
- **P.S.:** prepara o terreno: "amanhã/em breve tenho uma coisa pra te mostrar".

> Se você ainda não tem depoimento, use um **caso concreto seu** ou um padrão observado ("vejo isso em quase todo mundo que me responde"). Prova honesta vale mais que prova inventada.

---

## E-mail 5 — Oferta (dia +7)

**Objetivo:** o primeiro convite. Apresentar o produto, dizer para quem é (e para quem não é), preço, condição e o que fazer. Vender sem mentir, depois de 4 e-mails de valor.

**Assunto:** Está aberto: o método completo de vibecoding com engenharia
**Assunto alternativo:** Se "dica solta" não basta mais, isso é pra você

**Esqueleto:**
- Conecte aos 4 e-mails anteriores: "te dei várias peças; agora o sistema inteiro".
- O que é e o que a pessoa sai tendo/sabendo.
- Para quem é / para quem **não** é.
- Preço e condição, sem enrolar.
- Prazo ou benefício **real** (condição de quem está na lista, por exemplo).
- **CTA:** um só — link da oferta.
- **P.S.:** tira a objeção mais comum, reforça o prazo real, e lembra: a decisão é dela; o conteúdo continua de qualquer jeito.

---

## Resumo da sequência

| # | Dia | Tipo | Assunto | CTA |
|---|---|---|---|---|
| 1 | 0 (na hora) | Entrega da isca | Seu e-book chegou (link aqui dentro) | Abrir o e-book |
| 2 | +1 | História / autoridade | Por que eu parei de confiar no "rodou tá certo" | Responder / ler |
| 3 | +3 | Conteúdo útil | As 3 perguntas que eu faço pro código da IA | Aplicar / ler artigo |
| 4 | +5 | Prova | "Achei que era só comigo" | Responder / conferir |
| 5 | +7 | Oferta | Está aberto: o método completo... | Link da oferta |

**Regras da sequência:**
- Valor nos 4 primeiros; oferta só no 5º. Não antecipe a venda.
- Cada e-mail aponta um pouco para o próximo (cria expectativa, melhora abertura).
- Se a pessoa comprar no meio, tire-a da sequência de venda (não ofereça de novo o que ela já tem).
- Quem não comprar no E5 entra na nutrição recorrente (newsletter). A venda volta lá na frente, sem pressa. Para o ritmo de novas ofertas, veja a Alavanca (`funil.md`).
