---
name: vitrine
description: Cria landing pages de conversão de oferta única (isca + captura de e-mail), com hero acima da dobra, prova de autoridade, FAQ e CTA — feitas para tráfego pago/orgânico. Use ao criar uma landing, página de captura ou página de oferta.
---

# Vitrine — landing pages de conversão de oferta única

Vitrine monta a **página onde o clique vira e-mail**. Uma oferta, uma ação, zero distração. É a página de destino do funil da Alavanca: o anúncio (pago ou orgânico) traz o tráfego, a Vitrine captura o e-mail, a nutrição faz o resto.

Vitrine **não reinventa** copy nem UI — ela orquestra duas bases e adiciona a anatomia que converte:

- **Copy e funil:** a skill **`alavanca`** (headlines, PAS/AIDA, voz anti-hype, regras de captura/fricção).
- **UI e marca:** a skill **`atelier`** (identidade escuro+âmbar, acessibilidade e segurança de fábrica, classes da casa).
- **Camada Vitrine:** a **estrutura de uma landing de oferta única** que vira e-mail — seção a seção, na ordem certa, com formulário de baixa fricção e rastreamento.

A referência viva é a `/ia-sem-medo` do Rodrigo: hero com formulário acima da dobra, prova de autoridade, FAQ que quebra objeção, CTA final ancorado. Voz PT-BR, direta, sem hype. A decisão é sua.

## Quando usar

Use a Vitrine quando o pedido for uma **página de destino para capturar lead**:

- "Cria uma landing para o meu e-book / checklist / mini-curso grátis."
- "Preciso de uma página de captura de e-mail para o tráfego do anúncio."
- "Monta a página de oferta da isca X."
- "A minha landing não converte, refaz a estrutura."

Não use para: home institucional, blog, página com vários produtos/links, ou página de venda longa de produto pago (isso é outra estrutura). Vitrine é **uma oferta, uma ação**.

## Como usar as bases

Antes de escrever, leia o que importa:

| Preciso de... | Vá em |
|---|---|
| Headline, bullets, FAQ, microcopy do form/botão | `reference/copy-de-conversao.md` (Vitrine) + `alavanca/reference/copywriting.md` |
| Cada seção da landing, o que faz e os erros | `reference/anatomia-landing.md` (Vitrine) |
| Estrutura pronta em Next.js/Tailwind com as classes da marca | `templates/estrutura-landing.md` (Vitrine) |
| Cores, fontes, classes (`glass`, `btn-glow`, `kicker-d`, `text-grad`, `accent`) | `atelier/reference/marca.md` |
| Onde a landing entra no funil, fricção, captura | `alavanca/reference/funil.md` |

## A anatomia da landing que converte

Uma landing de oferta única tem 5 blocos, nesta ordem. Detalhe completo em `reference/anatomia-landing.md`.

1. **Hero + formulário acima da dobra.** Kicker, headline específica, subhead de 1 linha, e o **formulário visível sem rolar**. A pessoa entende a oferta e já pode agir. Sem menu de navegação que tire o foco.
2. **O que você recebe.** 3 a 5 bullets de valor concreto (o que tem dentro da isca, o resultado que ela dá). Especificidade > adjetivo.
3. **Autoridade / prova.** Quem é o autor (Rodrigo, "vibecoding com engenharia"), por que confiar, e prova leve (números, exemplo, mini-depoimento). Sem inventar prova que não existe.
4. **FAQ que quebra objeção.** 4 a 6 perguntas que respondem o "sim, mas…" que segura a pessoa de deixar o e-mail (é grátis mesmo? vou receber spam? é pra mim?).
5. **CTA final ancorado.** Repete a oferta e o formulário (ou um botão que rola pro hero) no fim, para quem leu tudo e decidiu agora.

## Procedimento

1. **Defina UMA oferta.** Uma isca, um benefício central, um público. Se há duas ofertas, são duas landings. Escreva em uma frase: "Página para capturar e-mail de [público] oferecendo [isca] que entrega [resultado]."
2. **Escreva a copy com a Alavanca.** Headline (PAS/AIDA), subhead, bullets de valor, FAQ de objeções, microcopy do form e do botão. Use `reference/copy-de-conversao.md` para os padrões prontos. Continuidade de promessa: a landing entrega o que o anúncio prometeu.
3. **Monte a UI com o Atelier.** Tema escuro premium (ink/amber/paper, Fraunces/Inter), classes `glass`, `btn-glow`, `kicker-d`, `text-grad`, `accent`. Hero e formulário acima da dobra. Acessibilidade e segurança de fábrica (contraste ≥ 4.5:1, foco visível, alvos ≥ 44px, labels nos inputs). Estrutura de seções em `templates/estrutura-landing.md`.
4. **Formulário de baixa fricção.** Só **e-mail** (e, no máximo, primeiro nome). **NUNCA peça telefone numa isca grátis** — telefone mata conversão. Um campo a mais é uma queda de conversão a mais. Botão com verbo + benefício ("Quero o e-book grátis"), nunca "Enviar".
5. **Validação com feedback — nunca silenciosa.** E-mail inválido mostra mensagem clara abaixo do campo. Sucesso confirma na tela (estado de sucesso ou página de obrigado). Carregando desabilita o botão e mostra que está processando. Erro de envio diz o que fazer. Silêncio é a pior conversão.
6. **Rastreamento.** Instale o Pixel (Meta) e/ou GA, e dispare o evento de conversão **no sucesso do envio** (Lead/CompleteRegistration), não no clique. Sem isso você não sabe o CPL e a Alavanca não consegue otimizar o anúncio.
7. **Entregue** o código + 1 nota curta do que dá pra testar (A/B de headline, de CTA). A decisão é sua.

## Regras (não-negociáveis)

- **1 oferta só.** Uma página, uma isca, um público. Duas ofertas = duas landings.
- **1 CTA, repetido.** A mesma ação do começo ao fim. Nada de "baixe o e-book" e "fale no WhatsApp" na mesma página — escolher é fricção.
- **Sem telefone na isca grátis.** E-mail (e nome, opcional). Telefone numa isca grátis derruba a conversão e a pessoa nem te conhece ainda.
- **Sem menu/links que tirem o foco** acima da dobra. A única saída fácil é converter.
- **Continuidade de promessa.** O que o anúncio diz, a headline confirma, a isca entrega. Quebrar isso mata conversão (e SEO).
- **Validação nunca silenciosa.** Todo estado (erro, carregando, sucesso) tem feedback visível.
- **Rastreamento no sucesso**, não no clique. Sem evento de conversão, não há otimização.

---

Vitrine monta a página que transforma clique em e-mail. Uma oferta, uma ação, prova honesta, objeção quebrada. A decisão é sua.
