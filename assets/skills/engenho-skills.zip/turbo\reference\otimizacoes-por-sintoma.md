# Otimizações por sintoma — catálogo "sintoma → conserto"

Vá direto no sintoma que você **mediu** no passo 1. Cada bloco vai do conserto de maior impacto para o menor. Aplique **um por vez** e remeça.

> Regra: não aplique nada daqui que você não confirmou ser o gargalo. Otimização sem medição é complexidade gratuita.

---

## LCP alto — "a página demora a aparecer"

**Imagem de hero / maior elemento:**
- Use **`next/image`** em vez de `<img>` — ele já faz resize, formato moderno e lazy-load automático.
- No elemento do LCP (o hero acima da dobra), marque **`priority`** — assim ele pré-carrega em vez de esperar a fila.
- Sirva em **WebP/AVIF** (o `next/image` faz isso por padrão) e no **tamanho certo** — não mande uma imagem 4000px para um slot de 800px. Use `sizes` para o navegador escolher.
- Defina **`width`/`height`** (ou `fill` + container com `aspect-ratio`) — também resolve o CLS de tabela.

**Fonte:**
- Use **`next/font`** (`next/font/google` ou `next/font/local`) — ele auto-hospeda a fonte, elimina a request externa e aplica `font-display: swap` + `size-adjust` para não bloquear nem causar reflow.
- **`preload`** apenas as fontes usadas acima da dobra; evite carregar 6 pesos quando você usa 2.

**Caminho crítico:**
- **Pré-carregue** o recurso do LCP (imagem/CSS crítico).
- Remova **CSS e JS render-blocking** — adie script não-essencial (`next/script` com `strategy="lazyOnload"` ou `afterInteractive`).
- Se a página é CSR puro, mova para **Server Component / SSR + ISR** para a página chegar já pintada.
- Corte **TTFB** (ver bloco de query lenta) — ele faz parte do LCP.

---

## Bundle JS grande — "muito JavaScript, demora a ficar interativo"

Confirme primeiro com `@next/bundle-analyzer` (`ANALYZE=true npm run build`) e a tabela de "First Load JS" do `next build`.

- **Dynamic import / code-splitting** — carregue sob demanda o que não é necessário no primeiro paint:
  ```js
  import dynamic from 'next/dynamic'
  const Grafico = dynamic(() => import('@/components/Grafico'), { ssr: false })
  ```
  Ótimo para modais, gráficos, editores, mapas — coisas que só aparecem após interação.
- **Tree-shaking de verdade** — importe só o que usa. `import { debounce } from 'lodash'` ainda pode puxar muito; prefira `lodash-es` ou `import debounce from 'lodash/debounce'`. Evite `import * as`.
- **Troque dependências gordas** — moment → date-fns/dayjs; lodash inteiro → função pontual; biblioteca de ícones inteira → só os ícones usados.
- **Mova lógica para o servidor** — em App Router, mantenha componentes como **Server Components** por padrão; só marque `'use client'` o que precisa de interatividade. Server Component = zero JS no cliente.
- **Cuidado com barrel files** (`index.ts` que reexporta tudo) — podem inflar o bundle ao impedir tree-shaking. Importe do caminho direto.
- **Audite scripts de terceiros** (analytics, chat, tag manager) — costumam ser os maiores ofensores. Carregue com `next/script` `strategy="afterInteractive"`/`lazyOnload`.

---

## CLS alto — "o layout pula"

- **Reserve espaço para toda mídia** — `width`/`height` em imagens, `aspect-ratio` em containers de vídeo/iframe. Com `next/image`, passar `width`/`height` (ou `fill`) já reserva.
- **Caixa fixa para ads/embeds/banners** que carregam depois — defina `min-height` no slot.
- **`next/font`** elimina o reflow de troca de fonte (FOUT) com `size-adjust`.
- **Skeletons do mesmo tamanho** do conteúdo final — um skeleton menor que o conteúdo causa shift quando os dados chegam.
- **Não injete conteúdo acima do visível** depois do load (banner de cookie/alerta) sem reservar espaço — prefira overlay (position fixed) que não empurra layout.
- **Anime só `transform` e `opacity`**, nunca `width`/`height`/`top`/`left`.

---

## Query lenta / TTFB alto — "o servidor demora a responder"

- **N+1** — você busca uma lista e, para cada item, faz outra query. Conserto: buscar tudo de uma vez (batch / `in` / join), ou desnormalizar o dado que você sempre precisa junto.
- **Falta de índice** — query que filtra/ordena por campo sem índice varre tudo. No Firestore, queries compostas exigem **índice composto** (o erro do console te dá o link para criar). Crie o índice.
- **Paginação** — nunca carregue uma coleção inteira. Use `limit()` + cursor (`startAfter`) no Firestore, ou paginação por cursor no backend. Lista sem paginar é lenta **e** cara (lê N docs).
- **Cache / ISR** — se o dado não muda a cada request, não recompute a cada request:
  - **ISR no Next.js**: `export const revalidate = 60` (ou `fetch(url, { next: { revalidate: 60 } })`) — serve do cache e revalida em background.
  - **Cache de dados** (`unstable_cache` / `React.cache`) para deduplicar leituras dentro de uma request.
  - Cache de borda na **CDN da Vercel** via headers (`Cache-Control`, `s-maxage`, `stale-while-revalidate`).
- **Tire a query do caminho crítico** — o que não é essencial para o primeiro paint pode ser **streamado** (Suspense / `loading.tsx`) ou buscado no cliente depois.
- **Cold start** — rotas serverless pouco acessadas "acordam" devagar; **Edge Runtime** reduz isso e aproxima o servidor do usuário.
- **Contadores agregados** — em vez de ler 5.000 docs para contar/somar, mantenha um documento agregado atualizado por trigger/transação.

---

## Re-render excessivo no React — "digito e a tela engasga"

Confirme no **React DevTools → Profiler** (grave a interação, veja quem renderou e quanto custou).

- **Suba o estado o mínimo necessário** — estado que muda muito (input controlado) num componente lá no topo re-renderiza a árvore inteira. Isole-o num componente filho pequeno.
- **`React.memo`** em componentes pesados que recebem as mesmas props — mas só onde o Profiler mostrou custo. Memoizar tudo não ajuda e atrapalha a leitura.
- **`useMemo`/`useCallback`** para estabilizar valores/funções passados a filhos memoizados ou usados em deps de efeito — de novo, onde foi medido necessário.
- **Não crie objeto/array/função inline** como prop de componente memoizado (`style={{...}}`, `onClick={() => ...}`) — quebra a memoização a cada render.
- **Virtualize listas grandes** — renderizar 1.000+ linhas mata o INP. Use virtualização (TanStack Virtual / react-window) para renderizar só o visível.
- **`useTransition` / `useDeferredValue`** para atualizações não urgentes (filtrar uma lista enquanto digita) — mantém o input responsivo.
- **Debounce** em handlers que disparam muito (busca enquanto digita, scroll, resize).
- **Não derive estado que dá para calcular no render** — estado redundante = render extra para sincronizar.

---

## Imagens pesadas — "as imagens seguram a página"

- **`next/image`** sempre — resize automático, **WebP/AVIF**, `srcset` responsivo e lazy-load nativo de graça.
- **`priority`** só no LCP (acima da dobra); o resto fica **lazy** (padrão).
- **Sirva no tamanho exibido** — use `sizes` para o navegador baixar a variante certa por viewport.
- **Comprima** antes (ou deixe o pipeline do `next/image`/CDN comprimir) — qualidade 75–80 costuma ser indistinguível e muito menor.
- **`placeholder="blur"`** melhora a percepção sem custar peso.
- **CDN/cache** para o egress (também corta custo — ver Termômetro).

---

## Atalho de decisão

| Sintoma medido | Comece por |
|---|---|
| LCP alto, TTFB ok | Imagem do hero (`next/image` + `priority`), fonte (`next/font`) |
| TTFB alto | Cache/ISR, índice, paginação, Edge Runtime |
| INP alto / engasgo | Bundle (dynamic import), re-render (Profiler), virtualizar lista |
| CLS / layout pulando | Reservar espaço (dimensão, aspect-ratio, `next/font`) |
| First Load JS grande | Code-split, tree-shaking, Server Components, podar terceiros |
| Lista/tela de dados lenta | N+1, índice, paginação, contador agregado |
