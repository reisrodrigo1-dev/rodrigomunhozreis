---
name: lupa
description: Depura um erro com método — reproduz, lê o console/network (F12), isola a causa, forma hipótese, aplica o menor conserto e verifica. Use quando deu erro no sistema, algo não funciona, a tela quebrou, ou para investigar um bug com método (em vez de chutar).
---

# Lupa — caçador de bugs (do erro ao conserto, com método)

Lupa é o oposto do vibecoding às cegas. Quando algo quebra, a tentação é chutar: "deve ser isso", muda uma linha, recarrega, torce. Às vezes funciona. Quase sempre cria três bugs novos e queima uma hora.

Depuração de verdade é **sistemática**: você reproduz, coleta evidência, isola a causa, forma uma hipótese testável, aplica o menor conserto possível e verifica de verdade. É um método, não sorte. Este skill te dá o método e te ensina a devolver o contexto certo para a IA consertar junto.

A decisão final é sua. Lupa te dá o caminho — quem aperta o gatilho é você.

## Quando usar

- "Deu erro no sistema" / "apareceu uma tela branca" / "parou de funcionar"
- Um botão não faz nada, um formulário não envia, dados não aparecem
- Erro no console, requisição falhando, deploy quebrou em produção mas funcionava local
- Você precisa **achar** o bug antes de pedir pra IA consertar (e dar o contexto certo)
- Hidratação/SSR do Next reclamando, 401/403 do Firebase, CORS, chunk 404 depois de deploy

Se você ainda não sabe **onde** está o erro, comece aqui. Não peça conserto pra IA antes de ter evidência — IA sem evidência também chuta.

## A regra de ouro

> **Não chute. Bissecte.**

Você nunca "acha" onde está o bug por intuição quando o sistema é grande. Você **corta o problema ao meio** repetidamente até sobrar um culpado óbvio. Cada passo abaixo serve pra estreitar o cerco com fato, não com fé.

## Procedimento — 6 passos

### 1. Reproduzir o erro de forma consistente

Antes de qualquer coisa: **faça o erro acontecer de novo, na hora que você quiser.** Um bug que você não consegue reproduzir é um bug que você não consegue consertar (só pode torcer).

- Anote a sequência exata de cliques/ações que leva ao erro.
- Confirme: acontece **sempre** ou **às vezes**? Se for às vezes, o que muda entre as vezes? (usuário logado x deslogado, dado específico, primeira vez x recarregando, mobile x desktop, conexão lenta?)
- Reproduza no mesmo ambiente onde apareceu (mesmo navegador; produção x local importa).
- Se não reproduzir, você ainda não entende o bug. Volte e varie uma coisa por vez até achar o gatilho.

Um bug reproduzível em 3 passos já está meio resolvido.

### 2. Coletar evidência (F12)

Abra o **DevTools** (tecla F12, ou Ctrl+Shift+I). Aqui mora a verdade. Quatro fontes:

- **Console** — a mensagem de erro e o **stack trace** (a pilha de chamadas que levou ao erro). Leia a primeira linha vermelha **de cima pra baixo**: o nome do erro, a mensagem, e o arquivo:linha onde estourou.
- **Network** — recarregue com a aba aberta. Procure linhas **vermelhas** (status 4xx/5xx). Clique na requisição que falhou e olhe: status, a aba **Response** (o que o servidor respondeu) e **Payload/Request** (o que você mandou).
- **A mensagem completa** — copie o texto **inteiro** do erro, não só "deu erro". A IA precisa do texto literal.
- **O que mudou por último** — qual foi a última coisa que você (ou a IA) alterou antes de quebrar? Esse é o suspeito número um. `git diff`, último deploy, mudou env var, instalou pacote.

Detalhe de como ler cada um: veja `reference/ler-o-erro.md`.

### 3. Isolar a causa (bissectar, não chutar)

Agora você estreita o cerco. **Corte o problema ao meio** e descubra de que lado está:

- **Frontend ou backend?** O erro aparece no Console (JS do navegador) ou na aba Network (a chamada ao servidor voltou erro)? Isso já divide o mundo em dois.
- **Quando começou?** Funcionava ontem? `git log` / `git bisect` — volte commits até achar o que quebrou.
- **Os dados ou o código?** Testa com outro usuário/registro. Se quebra só com um dado específico, o bug está no tratamento daquele caso (null, vazio, formato diferente).
- **Comente/desligue metade.** Isola um componente, uma chamada, uma função por vez. Se sumir o erro, o culpado estava na parte que você desligou.

A cada corte, você elimina metade dos suspeitos. Em poucos cortes sobra um.

### 4. Formar uma hipótese testável

Antes de mudar código, escreva uma frase no formato:

> "Eu acho que o erro acontece porque **[causa]**. Se eu **[fizer X]**, então **[Y]** deve acontecer."

Hipótese boa é **falsificável**: dá pra provar que está errada. "Acho que o `user` chega `undefined` porque o `await` foi esquecido; se eu logar `user` antes da linha 42, deve aparecer `undefined`." Aí você testa **só isso**. Se a hipótese cair, ótimo — eliminou uma causa, forme a próxima. Não pule pra "vou mudar várias coisas e ver".

### 5. Aplicar o MENOR conserto

Conserto bom é **cirúrgico**. Mude o mínimo necessário pra atacar a causa que você provou no passo 4 — não "limpe" código em volta, não refatore "já que estou aqui", não troque três coisas de uma vez.

- Uma mudança por vez. Se mudar várias e funcionar, você não sabe qual resolveu (e não aprendeu nada).
- Trate a **causa**, não o sintoma. Esconder o erro com `try/catch` vazio ou `?.` em tudo não conserta — empurra o problema pra frente.
- Se o conserto ficou grande e arriscado, provavelmente a hipótese estava incompleta. Volte ao passo 3.

### 6. Verificar de verdade

"Sumiu da tela" **não** é verificação. Confirme que consertou:

- Refaça **exatamente** os passos do passo 1. O erro tem que sumir fazendo o que o causava.
- Olhe o Console e o Network de novo: zero erro novo? A requisição voltou 200 com o dado certo?
- Teste o caso oposto e os vizinhos: o que funcionava antes continua funcionando? (não trocou um bug por outro)
- Se for produção: deploy e refaça o teste **em produção** (funcionar local não garante prod).

Só feche o caso quando o erro não reproduz mais **e** nada novo quebrou.

## Como devolver o contexto certo pra IA

A IA é ótima consertando — péssima adivinhando. A diferença entre "não consegui" e "resolvido em 1 tentativa" é o contexto que você dá. Mande:

1. **A mensagem de erro completa e literal** (copie do Console, inteira, com o stack trace).
2. **O que você estava fazendo** quando deu (os passos do passo 1).
3. **O que mudou por último** (o diff, o deploy, a env var).
4. **O que você já tentou** e o que aconteceu em cada tentativa (pra IA não repetir).
5. **O trecho de código relevante** (o arquivo:linha que o stack apontou).
6. **Sua hipótese**, se tiver ("acho que é X porque Y").

Modelo pronto pra preencher: `templates/relatorio-de-bug.md`. Mande o relatório preenchido pra IA — não "deu erro, arruma aí".

## Material de apoio

- `reference/ler-o-erro.md` — como ler stack trace, Console, aba Network e os erros de hidratação/SSR do Next.
- `reference/erros-comuns.md` — catálogo dos erros mais frequentes: o que significam e como consertar.
- `templates/relatorio-de-bug.md` — modelo pra descrever o bug (pra você e pra IA).
