# Catálogo de Code Smells

Smells são sinais de que algo está frágil — nem sempre um bug, mas quase sempre um bug esperando. O Crivo usa este catálogo na **Camada 2 (Ler)**. Cada smell traz: como reconhecer, por que dói, exemplo (TypeScript/Next.js/Firebase) e o conserto.

> Regra de bolso: smell não é crime. É um alerta. Você decide se conserta agora, num commit futuro, ou se naquele caso é aceitável. O Crivo aponta; a decisão é sua.

---

## 1. Função gigante (faz coisa demais)

**Reconhecer:** função com 100+ linhas, muitos `if` aninhados, vários "e também faz...".

**Dói porque:** difícil de ler, testar e reusar. Bug se esconde no meio. Mudança em uma parte arrisca outra.

**Exemplo:**
```ts
async function processarPedido(req) {
  // valida input... (20 linhas)
  // calcula frete... (30 linhas)
  // aplica desconto... (25 linhas)
  // salva no banco... (20 linhas)
  // dispara email... (15 linhas)
}
```

**Conserto:** quebrar por responsabilidade.
```ts
async function processarPedido(req) {
  const dados = validarPedido(req);
  const frete = calcularFrete(dados);
  const total = aplicarDesconto(dados, frete);
  const pedido = await salvarPedido(dados, total);
  await notificarCliente(pedido);
  return pedido;
}
```

---

## 2. Duplicação (copia-e-cola)

**Reconhecer:** o mesmo bloco aparece 2–3 vezes com pequenas variações.

**Dói porque:** corrigir um bug exige lembrar de todas as cópias. Uma fica pra trás e diverge.

**Exemplo:**
```ts
const userA = await db.collection("users").doc(idA).get();
if (!userA.exists) throw new Error("não achou");
const userB = await db.collection("users").doc(idB).get();
if (!userB.exists) throw new Error("não achou");
```

**Conserto:** extrair função.
```ts
async function getUser(id: string) {
  const snap = await db.collection("users").doc(id).get();
  if (!snap.exists) throw new Error(`usuário ${id} não encontrado`);
  return snap.data();
}
const userA = await getUser(idA);
const userB = await getUser(idB);
```

---

## 3. Nomes ruins (ou mentirosos)

**Reconhecer:** `data`, `temp`, `x`, `handleStuff`, ou pior — `getUser()` que também salva.

**Dói porque:** você lê o nome e confia. Nome mentiroso induz ao erro de quem usa.

**Exemplo:**
```ts
function getUser(id) {        // diz "get"...
  const u = fetchUser(id);
  u.lastSeen = Date.now();
  saveUser(u);                // ...mas escreve no banco
  return u;
}
```

**Conserto:** o nome diz a verdade.
```ts
function touchUserAndReturn(id) { ... }   // ou separar leitura de escrita
```

---

## 4. Tratamento de erro ausente (ou engolido)

**Reconhecer:** `await` sem `try/catch`, `.catch(() => {})`, `catch {}` vazio.

**Dói porque:** falha vira tela branca, estado corrompido, ou erro silencioso impossível de diagnosticar.

**Exemplo:**
```ts
const user = await getUser(id);   // e se rejeitar?
return user.email;                // estoura sem contexto

try { await salvar(x); } catch {} // engoliu o erro
```

**Conserto:** tratar com intenção.
```ts
try {
  const user = await getUser(id);
  return user.email;
} catch (err) {
  logger.error("falha ao buscar usuário", { id, err });
  throw new AppError("USER_FETCH_FAILED");
}
```

---

## 5. `any` / tipos frouxos

**Reconhecer:** `any`, `as any`, `// @ts-ignore`, objeto sem tipo, `Function`.

**Dói porque:** o TypeScript para de te proteger exatamente onde você mais precisa. O erro só aparece em runtime.

**Exemplo:**
```ts
function salvar(dados: any) {
  return db.collection("x").add(dados);  // qualquer lixo entra
}
```

**Conserto:** tipar de verdade e validar na borda.
```ts
import { z } from "zod";
const Pedido = z.object({ itemId: z.string(), qtd: z.number().int().positive() });
type Pedido = z.infer<typeof Pedido>;

function salvar(dados: unknown) {
  const pedido = Pedido.parse(dados);   // valida no runtime
  return db.collection("pedidos").add(pedido);
}
```

---

## 6. Efeito colateral escondido

**Reconhecer:** função "pura" no nome que muta argumento, escreve em global, dispara request, ou mexe no DOM.

**Dói porque:** quem chama não espera. Bugs de ação à distância são os mais difíceis de achar.

**Exemplo:**
```ts
function formatar(lista) {
  lista.sort();          // muta o array de quem chamou!
  return lista.join(", ");
}
```

**Conserto:** não mutar entrada; deixar efeito explícito.
```ts
function formatar(lista: string[]) {
  return [...lista].sort().join(", ");   // cópia, sem efeito colateral
}
```

---

## 7. N+1 (query no loop)

**Reconhecer:** `for`/`map` que faz uma consulta ao banco/API a cada iteração.

**Dói porque:** 1 lista de 500 itens = 500 idas ao banco. Lento e caro (no Firebase, custa leitura por documento).

**Exemplo:**
```ts
for (const id of ids) {
  const doc = await db.collection("users").doc(id).get();  // N consultas
  resultado.push(doc.data());
}
```

**Conserto:** buscar em lote.
```ts
const snaps = await db.getAll(...ids.map(id => db.collection("users").doc(id)));
const resultado = snaps.map(s => s.data());
// ou: query com where("id", "in", lote) em blocos de 10/30
```

---

## 8. Valores mágicos

**Reconhecer:** número ou string solto no meio do código sem explicação (`* 0.13`, `=== 3`, `"PENDENTE"`).

**Dói porque:** ninguém sabe o que significa nem onde mais aparece. Mudar a regra vira caça ao tesouro.

**Exemplo:**
```ts
if (pedido.status === 3) total *= 1.13;   // 3? 1.13?
```

**Conserto:** nomear.
```ts
const TAXA_ICMS = 0.13;
enum StatusPedido { Pendente = 1, Pago = 2, Faturado = 3 }
if (pedido.status === StatusPedido.Faturado) total *= 1 + TAXA_ICMS;
```

---

## 9. Dead code

**Reconhecer:** função nunca chamada, `import` não usado, ramo inalcançável, código comentado.

**Dói porque:** confunde quem lê ("isso é usado?"), incha o bundle, esconde a intenção real.

**Exemplo:**
```ts
// const antigo = calcularVelho(x);   // deixa "por garantia"
function calcularVelho(x) { ... }      // ninguém chama
```

**Conserto:** apagar. O Git lembra do que existiu — não precisa comentar "por via das dúvidas".

---

## 10. Condição complexa / negação dupla

**Reconhecer:** `if (!(!a && b) || c)`, expressão booleana que você precisa ler 3 vezes.

**Dói porque:** fácil errar a lógica e mais fácil ainda errar ao mexer depois.

**Exemplo:**
```ts
if (!(!user.ativo && user.bloqueado) || user.admin) { ... }
```

**Conserto:** dar nome às partes.
```ts
const contaUtilizavel = user.ativo || !user.bloqueado;
const podeEntrar = contaUtilizavel || user.admin;
if (podeEntrar) { ... }
```

---

## 11. Booleano-armadilha (`if (!valor)`)

**Reconhecer:** `if (!valor)` quando `valor` pode ser `0`, `""` ou `false` legítimos.

**Dói porque:** `0` e `""` são válidos, mas caem no mesmo balde de `null`/`undefined`.

**Exemplo:**
```ts
function aplicarDesconto(valor) {
  if (!valor) return preco;       // valor = 0 (sem desconto) cai aqui errado
  return preco - valor;
}
```

**Conserto:** ser explícito sobre "ausente".
```ts
if (valor == null) return preco;   // só null/undefined
```

---

## 12. Promise não aguardada (`await` esquecido)

**Reconhecer:** chamada async sem `await`, `.then` sem `.catch`, `forEach` com função async dentro.

**Dói porque:** o código segue antes de terminar; erro vira "unhandled rejection"; ordem fura.

**Exemplo:**
```ts
items.forEach(async (i) => { await salvar(i); });  // não espera nada
return "ok";                                        // retorna antes de salvar
```

**Conserto:**
```ts
await Promise.all(items.map((i) => salvar(i)));     // espera de verdade
return "ok";
```

---

## 13. Estado derivado duplicado (React)

**Reconhecer:** `useState` que copia uma prop ou outro estado e tenta manter em sincronia com `useEffect`.

**Dói porque:** as duas fontes divergem. Bug clássico de "a tela mostra o valor velho".

**Exemplo:**
```tsx
const [nome, setNome] = useState(user.nome);  // congela no primeiro render
```

**Conserto:** derivar direto, sem duplicar.
```tsx
const nome = user.nome;                         // sempre atual
// se precisa transformar: const inicial = useMemo(() => fmt(user.nome), [user.nome]);
```
