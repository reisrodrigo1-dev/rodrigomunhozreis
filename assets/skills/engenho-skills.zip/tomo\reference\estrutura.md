# Estrutura de um e-book da casa

Esqueleto que funciona (baseado em "IA Sem Medo" e "Vibecoding para CEOs"). Adapte ao tema; nem todo bloco é obrigatório.

## Ordem padrão
1. **Capa** — kicker + título (2 linhas) + subtítulo-promessa específico + assinatura + tags (o que tem dentro).
2. **Sumário** — 5 a 10 capítulos numerados + caixa "Como usar este guia".
3. **Capítulos de base** (3–6) — a teoria mínima necessária, didática.
4. **Método** (se aplicável) — P.R.O.M.P.T.E.R., Protocolo de 5 Camadas, ou o método do tema.
5. **Parte prática** — biblioteca de prompts e/ou plano de N dias.
6. **CTA final** — próximo passo + oferta (link para /materiais, /robos, mentoria).

## Componentes disponíveis (classes do template)
| Bloco | Classe | Para quê |
|---|---|---|
| Capa escura | `.page.cover` / `.cover-inner` | Abertura que "vende" |
| Capítulo | `.page` + `.chapnum` + `.kicker` + `h2` + `.lead` | Corpo do conteúdo |
| Destaque/citação | `.box.amber` (com `font-serif`) | Frase memorável |
| Nota/aviso | `.box` / `.box.warn` | Observação, cuidado |
| Grade de ideias | `.cards` > `.card` | 2–4 conceitos lado a lado |
| Comparativo | `table` | Situação → resultado |
| Método | `.peder` > `.row` (L + h4 + p) | As 8 letras P.R.O.M.P.T.E.R. |
| Biblioteca de prompts | `.cat` + `.prompt` (`.pn`/`.pt`/`.pmeta`/`.pq`) | Prompts copiáveis |
| Plano | `.day` (d + h4 + p) | Roteiro de N dias |
| Rodapé | `.foot` | Marca + nº da página |

## Voz e didática
- **Abertura forte** (`.lead`): comece pelo que mais importa ou pelo que mais assusta.
- **Metáforas concretas:** "IA é um estagiário brilhante que entrega rápido — e você confere".
- **Frase-chave por capítulo:** uma citação memorável na `.box.amber`.
- **Mostre a conta:** tabelas comparativas convencem ("bom + IA = imbatível").
- **Sem hype:** nada de "isso vai mudar sua vida". Especificidade vende mais.
- **Sempre devolve a decisão ao leitor:** "a IA sugere, você confere e decide".

## Prompt da biblioteca (formato)
Cada `.pq` deve ser um prompt P.R.O.M.P.T.E.R. real:
- `<b>Papel:</b>` em negrito no começo.
- Lacunas a personalizar em `<span class="ph">[entre colchetes]</span>`.
- Logo acima, `.pmeta` com **Quando usar:**.
Construa os prompts com a skill **Forja**.

## Checklist final
- [ ] Capa com promessa específica (não genérica).
- [ ] Sumário bate com os capítulos.
- [ ] Cada prompt é colável e funciona sozinho.
- [ ] Números de página nos `.foot`.
- [ ] CTA final com 1 oferta clara.
- [ ] Abre bem no navegador e imprime certo em A4 (testar Ctrl+P).
- [ ] CSS intacto (identidade da marca).
