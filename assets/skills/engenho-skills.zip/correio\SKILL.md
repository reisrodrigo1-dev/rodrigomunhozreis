---
name: correio
description: Escreve e-mails e newsletters de nutrição na voz do Rodrigo (sem hype, com valor real), do boas-vindas à conversão. Use ao escrever um e-mail, uma sequência de boas-vindas, uma newsletter ou um e-mail de oferta para uma lista que baixou um e-book (isca).
---

# Correio

O Correio escreve **e-mails e newsletters de nutrição** na voz do Rodrigo Munhoz Reis — autor da linha "vibecoding com engenharia". A pessoa baixou um e-book (a isca) e entrou na lista. A partir daí, os e-mails nutrem o relacionamento: entregam valor real, constroem confiança e, quando faz sentido, abrem espaço para a oferta. Sem hype, sem clickbait, sem forçar a venda. A decisão é sempre da pessoa que lê.

A voz é PT-BR, direta, honesta, escaneável. Trata o leitor como adulto inteligente. Prefere ensinar a empurrar. Vende sem mentir.

## Visão geral

A maioria das listas morre por dois motivos opostos: ou a pessoa some porque o conteúdo é vazio (só "compra, compra"), ou a pessoa nunca vira cliente porque você nunca convida. O Correio resolve os dois fazendo o básico bem feito:

```
e-book baixado (isca da Alavanca)
   -> e-mail de boas-vindas (entrega o que prometeu, na hora)
   -> nutrição: conteúdo útil de verdade, 1 ideia por e-mail
   -> ponte: conecta o conteúdo ao problema que o produto resolve
   -> oferta: convite claro, honesto, com prazo real ou benefício real
   -> reengajamento: reativa quem esfriou, sem drama
```

Cada e-mail tem **um objetivo** e **uma ação**. O conteúdo carrega a venda; a venda não atropela o conteúdo. Quem entrega valor primeiro ganha o direito de ofertar depois.

O Correio é o "depois" do funil da **Alavanca**. A Alavanca traz a pessoa (pago -> e-book -> e-mail). O Correio cuida do e-mail em diante: a nutrição que transforma e-mail em confiança e confiança em venda.

## Quando usar esta skill

Use o Correio quando o usuário quiser:

- **Escrever um e-mail** para a lista (qualquer tipo).
- **Montar a sequência de boas-vindas** pós-download do e-book (as primeiras 5 mensagens automáticas).
- **Escrever uma newsletter** recorrente de nutrição/conteúdo.
- **Escrever um e-mail de oferta/lançamento** (abertura de carrinho, condição, prazo).
- **Reengajar** uma base parada (quem não abre há semanas).
- **Melhorar uma linha de assunto** ou um e-mail que está com baixa abertura/clique.

Não use para: copy de anúncio pago ou de landing (use a **Alavanca**, `reference/copywriting.md`), design de template visual de e-mail (use uma skill de design), ou texto de redes sociais.

## Como usar a base

Esta skill é uma **base pesquisável**. Antes de escrever, leia o arquivo de `reference/` relevante — eles têm estrutura, regras e exemplos completos na voz do Rodrigo.

| Arquivo | Use quando for |
|---|---|
| `reference/tipos-de-email.md` | Escrever qualquer e-mail avulso. Tem cada tipo (boas-vindas/entrega, nutrição, ponte, lançamento, reengajamento) com objetivo, estrutura e exemplo completo. Leia este PRIMEIRO. |
| `reference/sequencia-boas-vindas.md` | Montar a sequência automática de 5 e-mails que dispara depois do download do e-book. Tem assunto e esqueleto de cada um. |
| `reference/assuntos.md` | Escrever ou melhorar linhas de assunto. Tem o método (curiosidade, específico, sem clickbait) e 20+ exemplos com o porquê de cada. |

Quando a estratégia do funil entrar (qual isca, quando ofertar, como ler abertura/clique como métrica), consulte a **Alavanca** (`funil.md`, `metricas.md`, `copywriting.md`).

## Tipos de e-mail

Detalhe completo em `reference/tipos-de-email.md`. Resumo:

1. **Boas-vindas / entrega da isca** — dispara na hora do cadastro. Entrega o e-book prometido sem rodeio, diz quem você é em uma linha e o que esperar da lista. Cumpre a promessa antes de qualquer coisa.
2. **Nutrição / conteúdo** — o feijão com arroz da lista. Uma ideia útil por e-mail, aplicável hoje. Constrói autoridade ensinando, não se gabando.
3. **Ponte para oferta** — conecta um problema real (que o conteúdo já vinha tratando) à solução que o produto oferece. Prepara o terreno sem abrir a venda ainda.
4. **Lançamento / oferta** — o convite direto. Diz o que é, para quem é, quanto custa, até quando, e o que fazer. Honesto sobre o que entrega e sobre o que não entrega.
5. **Reengajamento** — para quem parou de abrir. Pergunta direta ("ainda quer receber?"), reentrega valor, e respeita quem quer sair.

## Procedimento para escrever um e-mail

1. **Defina o objetivo do e-mail.** Antes de escrever uma palavra: o que esta mensagem precisa conseguir? (entregar a isca / ensinar uma coisa / levar ao clique / vender). Um e-mail, um objetivo.
2. **Uma ideia por e-mail.** Não empilhe três dicas e dois links. Escolha a ideia mais útil e desenvolva só ela. O resto vira outro e-mail.
3. **Escreva o corpo primeiro, o assunto depois.** O assunto promete o que o corpo entrega. Escrever o assunto antes leva a clickbait. Veja `reference/assuntos.md`.
4. **Corpo curto e escaneável.** Abertura que entra direto no assunto (sem "espero que esteja tudo bem"). Parágrafos de 1-3 linhas. Frases curtas. Uma quebra de linha respira. Mobile-first: a maioria lê no celular.
5. **Um CTA só.** Uma ação por e-mail, repetida no máximo em dois lugares (corpo + P.S.), mas sempre a mesma ação. Dois CTAs concorrentes = nenhum clique.
6. **P.S. estratégico.** Muita gente lê o P.S. antes do corpo. Use para reforçar o CTA, adicionar um motivo (prazo, bônus) ou um toque humano. Nunca desperdice.
7. **Releia em voz alta.** Se soa a robô de marketing, reescreva. A voz é de gente que respeita o leitor. Corte hype, superlativo vazio e urgência falsa.

## Regras

- **1 objetivo por e-mail.** Se precisa de dois, são dois e-mails.
- **1 CTA por e-mail.** Sempre a mesma ação. Pode repetir, não pode competir.
- **Assunto honesto.** O assunto entrega o que o corpo cumpre. Curiosidade sim, mentira não. Nada de "URGENTE", "última chance" falsa, ou promessa que o e-mail não paga.
- **Mobile-first.** Frases e parágrafos curtos, links claros, sem depender de imagem para entender. Assunto que cabe em ~40 caracteres no celular.
- **Texto escaneável.** Quem bate o olho tem que pegar a ideia. Parágrafos curtos, espaço em branco, no máximo uma lista. Negrito com parcimônia, só no que importa.
- **Valor antes da venda.** Entregue algo útil em quase todo e-mail. Ofereça quando fizer sentido, não em todo envio.
- **Sem hype.** Sem "revolucionário", "segredo que ninguém conta", "método infalível". Promete o que cumpre, descreve o que entrega.
- **A decisão é da pessoa.** Convide, mostre o porquê, dê o caminho — e respeite o "não" e o "agora não". Inclusive deixe o descadastro fácil.

---

O Correio nutre com valor real e vende com honestidade. Ensina primeiro, convida depois. A decisão é de quem lê.
