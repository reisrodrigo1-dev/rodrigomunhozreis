# LGPD aplicada a software — Bastião

A LGPD (Lei 13.709/2018) rege o tratamento de **dados pessoais** no Brasil. Este guia traduz o essencial para quem **constrói produtos de software** — sem juridiquês, com o que dá pra fazer no código e no produto. Não é parecer jurídico: para casos sensíveis, consulte um advogado/DPO. **A decisão é sua.**

> Conformidade aprofundada e processos: skill **Salvaguarda**. Aqui é o mínimo viável de segurança de dados.

---

## 1. O que conta como dado pessoal

**Dado pessoal** = qualquer informação que identifique ou possa identificar uma pessoa.

| Categoria | Exemplos |
|---|---|
| Identificadores diretos | nome, e-mail, telefone, CPF, RG, endereço |
| Identificadores online | IP, cookies, device id, geolocalização |
| Comportamental | histórico de navegação, compras, cliques |
| **Sensível** (proteção reforçada) | saúde, biometria, orientação sexual, religião, opinião política, dado de criança/adolescente |

**Regra prática:** se você consegue ligar o registro a *uma pessoa*, é dado pessoal. Dado **sensível** e dado de **menores** exigem cuidado e base legal mais estrita.

---

## 2. Mapa de dados (faça isto primeiro)

Antes de proteger, saiba **o que você tem**. Monte uma tabela viva do seu produto:

| Dado | Onde é coletado | Onde fica armazenado | Por que (finalidade) | Quem acessa | Quanto tempo guarda |
|---|---|---|---|---|---|
| E-mail | cadastro | Firestore `users` | login, contato | app, suporte | enquanto conta ativa |
| IP | logs | Vercel/logs | segurança, antifraude | dev | 90 dias |
| Cartão | checkout | **Stripe (não no seu banco)** | cobrança | — | gerido pelo Stripe |

Esse mapa responde quase tudo que a LGPD pede: finalidade, retenção, terceiros e acesso.

---

## 3. Os 5 pilares no produto

### a) Base legal
Todo tratamento precisa de uma justificativa legal. As mais comuns em SaaS:
- **Consentimento** — usuário concordou explicitamente (ex.: marketing, cookies não essenciais).
- **Execução de contrato** — necessário para entregar o serviço (ex.: e-mail para criar conta).
- **Legítimo interesse** — necessidade legítima sem ferir direitos (ex.: log de segurança/antifraude); exige avaliação.
- **Obrigação legal** — exigência de lei (ex.: guardar nota fiscal).

> Não use "consentimento" para tudo. Para o que é essencial ao serviço, a base costuma ser **execução de contrato**.

### b) Consentimento (quando aplicável)
- **Livre, informado e específico.** Nada de checkbox pré-marcado nem consentimento "guarda-chuva".
- Granular: marketing ≠ cookies de analytics ≠ termos do serviço.
- Registrável: guarde **quando** e **a quê** a pessoa consentiu.

```ts
// registro de consentimento — auditável
await db.collection('consents').add({
  uid, purpose: 'marketing_email',
  granted: true, version: 'privacy-2026-01',
  at: FieldValue.serverTimestamp(),
  ip: hash(ip), // hash, não o IP cru
});
```

### c) Minimização
Colete **só o necessário** para a finalidade. Não peça CPF/telefone se não usa. Cada campo a mais é passivo de risco. (Liga direto ao item #10 de `vulnerabilidades.md`.)

### d) Retenção
Defina por quanto tempo guarda cada dado e **apague/anonimize** quando a finalidade acaba.
```ts
// exemplo: anonimizar conta deletada em vez de manter PII
await userRef.update({
  name: 'Usuário removido', email: null, phone: null,
  deletedAt: FieldValue.serverTimestamp(),
});
```
Logs com IP/PII: defina expiração (ex.: 90 dias).

### e) Terceiros (operadores)
Todo serviço que processa dados dos seus usuários é um **operador**: Firebase/Google, Vercel, Stripe, provedores de e-mail, analytics. Você deve:
- Saber **quais** são e **que dado** cada um recebe (está no mapa do item 2).
- Listá-los na política de privacidade.
- Preferir quem oferece DPA (Data Processing Agreement) e processa fora do escopo sensível (ex.: deixe **cartão com o Stripe**, não no seu banco).

---

## 4. Direitos do titular (o usuário pode pedir)

A pessoa pode pedir, e você deve atender em prazo razoável:
- **Acesso/portabilidade** — uma cópia dos dados dela (ex.: endpoint de export em JSON).
- **Correção** — corrigir dado errado.
- **Eliminação** — apagar dados (respeitando o que a lei obriga manter).
- **Revogação de consentimento** — desligar marketing, etc.

Tenha, no mínimo, um **canal claro** (e-mail/DPO) e, idealmente, botões de "baixar meus dados" e "excluir minha conta".

```ts
// export de dados do titular
export async function GET() {
  const user = await requireUser();
  const dados = await coletarTudoDoUsuario(user.uid); // perfil, posts, consentimentos...
  return new Response(JSON.stringify(dados, null, 2), {
    headers: { 'Content-Type': 'application/json',
               'Content-Disposition': 'attachment; filename="meus-dados.json"' },
  });
}
```

---

## 5. Segurança como dever legal

A LGPD exige **medidas de segurança** adequadas. Na prática, é o que o resto do Bastião cobre:
- Controle de acesso (regras de banco, autorização por dono) → evita vazamento.
- Criptografia em trânsito (HTTPS) e segredos protegidos.
- Logs sem PII; mínimo de dado coletado.
- Plano de resposta a incidente: se vazar dado pessoal com risco, a LGPD exige **comunicar a ANPD e os titulares** em prazo razoável. Saiba quem aciona e como.

---

## 6. Checklist LGPD mínimo

- [ ] Mapa de dados feito (o que, onde, por quê, quem, quanto tempo).
- [ ] Base legal definida para cada tratamento.
- [ ] Coleta minimizada (só o necessário).
- [ ] Consentimento granular e registrável onde aplicável (sem checkbox pré-marcado).
- [ ] Política de Privacidade publicada, listando operadores (Firebase, Vercel, Stripe...).
- [ ] Dados sensíveis e de menores com cuidado reforçado.
- [ ] Cartão/pagamento delegado a provedor (não no seu banco).
- [ ] Canal para direitos do titular (acesso, correção, exclusão, revogação).
- [ ] Retenção definida + rotina de exclusão/anonimização.
- [ ] Segurança técnica (regras, auth, HTTPS, logs limpos) — ver `padroes-seguros.md`.
- [ ] Plano de resposta a incidente (comunicar ANPD + titulares).
