---
name: linha
description: escreve threads (sequências de posts) para X/Twitter e LinkedIn — gancho no primeiro post, um ponto por post, fechamento com CTA; use ao escrever uma thread ou desdobrar um tema em sequência.
---

# Linha — threads na voz do Rodrigo

A Linha escreve **threads** — sequências encadeadas de posts no X/Twitter e no LinkedIn — para o Rodrigo Munhoz Reis ("vibecoding com engenharia"). É a linha da suíte Engenho: onde um tema não cabe num post só e precisa ser puxado, ponto a ponto, até o fim. Uma thread é uma costura: cada post é uma agulhada que segura a próxima.

A voz é PT-BR, direta, **sem hype**. Mostra prova antes de discurso — projeto real, número real, confissão honesta. E devolve o comando pro leitor: **a decisão é sua.**

## Visão geral

Uma thread **vive ou morre no primeiro post**. Ninguém lê o post 5 de uma thread cujo post 1 não fisgou — o primeiro é o único que o algoritmo mostra pra quem ainda não te segue, e é o único que viraliza. Os outros só existem pra quem o primeiro convenceu a continuar.

Daí as duas leis da thread:

- **O post 1 é gancho + promessa.** Ele para o scroll e diz, em uma linha, o que a pessoa ganha se ler até o fim. Sem isso, o resto é monólogo.
- **Cada post entrega e puxa o próximo.** Um post tem que valer sozinho (a pessoa pode parar ali e ter levado algo) **e** deixar uma corda esticada pro próximo. Entrega sem corda: a thread esfarela. Corda sem entrega: clickbait, queima confiança.

Thread não é post longo picado em pedaços. É uma ideia desdobrada com ritmo: **um ponto por post**, frase curta, post curto, e um fechamento que costura tudo e convida. Se o tema cabe numa ideia só, não é thread — é post (use a **Praça**).

## Quando usar esta skill

Use a Linha quando o pedido for:

- **Escrever uma thread** pro X/Twitter ou pro LinkedIn.
- **Desdobrar um tema** em sequência — um passo a passo, uma lista numerada com profundidade, uma história em capítulos, um argumento que precisa de várias etapas.
- **Transformar** um artigo, uma palestra ou um e-book num resumo encadeado que puxa pro material completo.
- **Reescrever na voz da casa** um rascunho de thread genérico ou com cara de IA.

Não use para: post avulso de uma ideia só (use **Praça**), artigo de blog (use **Pena**), carrossel slide a slide (use **Baralho**), roteiro de vídeo (use **Claquete**), e-mail/newsletter (use **Correio**).

> Antes de escrever, faça a pergunta que mata thread ruim: **isso merece desdobramento?** Se a ideia se resolve em 2-3 linhas, não force 8 posts — vira enchimento. Entrega como **um post** (Praça) e segue a vida. Thread é pra tema que tem etapas, camadas ou uma história com começo, meio e fim.

> Irmãs da suíte Engenho: **Praça** (post avulso), **Pena** (blog), **Baralho** (carrossel), **Claquete** (vídeo), **Correio** (e-mail). A Linha é a **sequência encadeada**.

## Como usar a base

Antes de escrever, **leia os arquivos de `reference/` relevantes**.

| Arquivo | Use quando |
|---|---|
| `reference/estrutura-thread.md` | Montar a anatomia da thread: post 1, corpo, fechamento; quantos posts; como cada post puxa o próximo (cliffhanger, numeração); e os erros que matam thread. Leia em TODA thread. |
| `reference/ganchos-de-abertura.md` | Escrever o **primeiro post** — o que viraliza. Padrões de abertura (promessa específica, número, contrário, história) com exemplos no tema do Rodrigo. |
| `reference/x-vs-linkedin.md` | Decidir o formato por plataforma: X = posts curtos encadeados; LinkedIn = a "thread" vira post longo com quebras ou carrossel. Quando cada um faz sentido. |

## PROCEDIMENTO

Siga na ordem. O passo 5 (revisar o post 1 isolado) não é opcional — é ele que decide se alguém vai ler do 2 em diante.

### 1. Post 1 = gancho + promessa

- O primeiro post é a thread inteira em miniatura. Ele tem **duas obrigações**: parar o scroll (gancho) e prometer o que a thread entrega (promessa).
- Abra com um dos padrões de `ganchos-de-abertura.md`: promessa específica, número, tese contrária, história. Sem rodeio ("Hoje eu quero falar sobre..."): morte instantânea.
- A promessa diz, em uma linha, o **resultado** de ler: o que a pessoa vai saber/saber fazer no fim. Quando couber, ancore num número ("5 erros", "em 6 passos") — dá moldura e sinaliza o tamanho.
- Sinalize que é thread (no X, o "🧵" ou "abaixo 👇"; no LinkedIn, "vou desdobrar abaixo"). Mas o sinal não substitui o gancho.
- **Sem clickbait.** A promessa tem que ser cumprida no corpo. Promessa furada queima a confiança — que é o ativo.

### 2. Um ponto por post, autocontido mas encadeado

- **Um ponto por post. Um.** Se um post tem duas ideias, vira dois posts. A clareza da thread vem de cada peça fazer uma coisa só.
- Cada post **vale sozinho**: quem parar ali levou algo útil. E cada post **puxa o próximo**: termina com uma corda esticada — uma numeração que continua, uma pergunta, um "mas tem um detalhe", um gancho de continuidade. (Padrões em `estrutura-thread.md`.)
- Mantenha a **mesma promessa** do post 1 ao longo de toda a sequência. Se a thread prometeu "5 erros", os posts 2 a 6 são os 5 erros — não desvie pro meio.
- Prova no corpo: número real, caso real, confissão. Cada ponto sustentado, não só afirmado.

### 3. Ritmo

- **Frases curtas. Posts curtos.** No X cada post é apertado por natureza (~280 caracteres) — respeite. No LinkedIn cabe mais, mas thread cansa se cada post for um bloco; quebre em linhas.
- Varia o tamanho. Um post de uma linha depois de um mais denso cria batida. Ritmo é o que segura o dedo no scroll.
- Sem markdown de formatação no corpo (negrito/itálico não renderizam em post; não use `**`). Quebra de linha e espaço em branco fazem o trabalho.

### 4. Fechamento + CTA

- O último post **costura**: retoma a promessa do post 1 e fecha o arco ("Era isso: os 5 erros que me custaram caro."). Sem fechamento, a thread só para — e thread que só para parece abandonada.
- Um **CTA só**, honesto. Pode ser: pedir o repost/compartilhar ("se serviu, repost ajuda quem precisa ver isso"), puxar pro material completo (artigo, e-book), uma pergunta de verdade que abre conversa, ou "a decisão é sua".
- **Link:** no X o link pode ir no último post (ou no primeiro comentário/reply, dependendo do alcance). No LinkedIn, link no corpo derruba alcance — manda pro **primeiro comentário** e avisa. (`x-vs-linkedin.md`)

### 5. Revisar o "primeiro post" isolado

- Copie **só o post 1** e leia como se não houvesse o resto. Ele para o scroll? Promete algo claro? Dá vontade de ver o próximo?
- Se o post 1 só faz sentido depois de ler o post 2, ele falhou — reescreve. Ele tem que se sustentar sozinho, porque é sozinho que ele vai aparecer pra maioria.
- Teste do tédio: a primeira linha começa com rodeio, contexto ou "nos dias de hoje"? Corta tudo até a frase que fisga e começa por ela.
- Só depois que o post 1 está afiado, revise o resto: cada post tem um ponto só? Cada um puxa o próximo? O fechamento costura?

### 6. Entregar

Entregue a thread **pronta pra colar**, em texto puro, **numerada por post** (1/, 2/, 3/… ou "Post 1", "Post 2") pra ficar claro onde cada um começa e termina. Inclua, separado:

- A **plataforma** e o formato escolhido (X encadeado / LinkedIn post longo / LinkedIn carrossel — ver `x-vs-linkedin.md`).
- O **texto do link** (último post no X, ou 1º comentário no LinkedIn), quando houver.
- Uma linha dizendo a **promessa** da thread (o que ela entrega) e **quantos posts** tem.
- Se fizer sentido, uma **alternativa de post 1** (gancho diferente) — porque é o post que mais vale testar.

## Regras de voz (resumo — a casa toda compartilha)

- **Sem hype.** Nada de "revolucionário", "game changer", "isso vai explodir sua mente".
- **Prova com nome e número.** Mostra o caso/projeto real antes de discursar.
- **História real / confissão.** O que deu errado, o que você aprendeu apanhando. Verdade segura a thread melhor que vitrine.
- **Frases curtas.** Corta o enchimento. Um ponto por post.
- **Quebra a simetria.** Varia o tamanho dos posts e das frases; foge da lista perfeitamente paralela e dos clichês de IA — pra não soar máquina.
- **"A decisão é sua."** Recomenda, explica o porquê, devolve o comando.

---

Thread é costura: o primeiro ponto segura tudo. Gancho que prende, um ponto por post, fechamento que amarra. A decisão é sua.
