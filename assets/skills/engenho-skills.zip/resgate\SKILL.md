---
name: resgate
description: guia de resposta a incidente — vazou segredo/dado, ataque, perda de dado? conter, comunicar, restaurar; e estratégia de backup pra não perder dados; use em incidente de segurança/perda ou ao planejar backup.
---

# Resgate

> A hora do incidente não é a hora de improvisar. É a hora de seguir o método
> que você montou quando estava calmo.
>
> — Rodrigo Munhoz Reis, *vibecoding com engenharia*

## Visão geral

Resgate é o que você faz quando o sino toca: vazou uma chave de API, um dado
pessoal ficou exposto, uma conta foi comprometida, um banco corrompeu, o sistema
caiu. E é também o que você faz **antes** disso acontecer, pra não perder dados
quando acontecer — porque vai acontecer.

Duas coisas precisam estar na sua cabeça quando o incidente chega:

1. **Calma é técnica, não temperamento.** Pânico faz você apagar a evidência,
   rotacionar a chave errada, comunicar cedo demais (ou tarde demais) e quebrar
   mais coisa do que o incidente original. A calma vem de ter um **método** pra
   seguir. É pra isso que esta skill existe: pra você não pensar "o que eu faço
   agora?" no pior momento possível.

2. **A maior parte do estrago é evitável antes.** Backup que ninguém testou não é
   backup, é esperança. Chave que está só na cabeça de uma pessoa some com ela.
   Metade do Resgate é trabalho que se faz com o sistema saudável — a seção de
   **BACKUP** abaixo.

O procedimento de resposta tem cinco passos, sempre na mesma ordem:
**CONTER → AVALIAR → COMUNICAR → REMEDIAR → APRENDER.** A ordem importa. Conter
vem antes de entender, porque enquanto você investiga o sangramento continua.

Resgate faz parte da suíte **Engenho**. As irmãs que mais conversam com ela:

- **Bastião** — segurança. Define o padrão seguro que, quando furado, vira o
  incidente que o Resgate apaga. Pós-incidente, Bastião fecha a porta de volta.
- **Faro** — caça segredo vazado no repositório. Quando o incidente é "vazou uma
  chave", Faro acha onde, e o Resgate diz o que fazer com ela (rotacionar já).
- **Cofre** — regras do Firebase. Quando o incidente é "banco aberto", o conter
  do Resgate é fechar a regra; o Cofre entrega a regra certa.
- **Sentinela** — observabilidade. É o sentinela que **te avisa** do incidente
  antes do cliente. Quando o alerta dele dispara, o Resgate começa.

A decisão é sua. O Resgate mostra o método e os prazos; o quão fundo você vai em
cada passo depende do tamanho do incidente e do seu estágio.

## Quando usar

Use o Resgate quando:

- **Vazou um segredo** — chave de API, senha, `.env` que foi pro Git, token num
  log, credencial num print compartilhado.
- **Um dado pessoal ficou exposto** — coleção aberta, endpoint sem auth, link
  público com PII, e-mail/CPF de usuários acessível por quem não devia.
- **Uma conta foi comprometida** — login de admin invadido, sessão sequestrada,
  acesso indevido ao painel da Vercel/Firebase/GitHub.
- **Perdeu ou corrompeu dado** — delete acidental, migração que zerou uma coleção,
  bug que sobrescreveu registros, ransomware.
- **O sistema caiu** — indisponibilidade, fora do ar, erro 500 em massa.
- **Você quer se preparar** — planejar backup, definir plano de restauração,
  guardar segredos direito **antes** de precisar. (Vá direto pra seção BACKUP.)

Não é pra: debugar um bug comum sem impacto de segurança ou perda (use **Lupa**),
nem pra revisar segurança preventivamente (use **Bastião** / **Cofre**).

## Antes de tudo: respire e abra um registro

Trinta segundos. Antes do primeiro comando:

- **Abra um documento de incidente** (um arquivo, um canal, qualquer lugar). Vai
  anotar **horário e ação** de cada passo. Isso vira a linha do tempo do
  post-mortem e te protege legalmente (a LGPD pede registro).
- **Não apague nada ainda.** Log, registro de acesso, o commit que vazou — isso é
  evidência do alcance. Preserve antes de limpar.
- **Não comunique antes de conter e avaliar.** Aviso baseado em achismo gera mais
  dano que silêncio de 1 hora. (Exceção: se há risco contínuo a terceiros, peça
  ajuda já.)

## Procedimento de resposta a incidente

Cinco passos, nessa ordem. O playbook por tipo de incidente, com os **primeiros
15 minutos** de cada, está em `reference/playbook-incidente.md` — vá nele assim
que souber o tipo.

### 1. CONTER — parar o sangramento

Objetivo único: **fazer o dano parar de crescer.** Não é consertar a causa, não é
entender tudo. É estancar. Conter primeiro porque cada minuto a chave vazada
continua válida, o banco continua aberto, o atacante continua dentro.

Os três gestos de contenção, conforme o tipo:

- **Rotacionar o segredo.** Vazou chave/token/senha? Gere uma nova e **revogue a
  antiga** no provedor (Firebase, Vercel, GitHub, gateway de pagamento, etc.).
  Rotacionar sem revogar a antiga não contém nada — a chave velha ainda abre a
  porta. Atualize o `.env`/Secrets e redeploy.
- **Fechar a regra / o acesso.** Dado exposto por regra aberta? Publique uma regra
  restritiva **agora** (com o **Cofre**). Endpoint sem auth? Derrube a rota ou
  ponha um gate. Conta comprometida? Revogue as sessões e troque a senha/MFA.
- **Tirar do ar (se preciso).** Quando o vazamento é ativo e você não consegue
  fechar cirurgicamente, é legítimo derrubar a feature ou o app. Um app fora do ar
  por 20 minutos é melhor que um app vazando dado por 2 horas. Use feature flag,
  rollback de deploy, ou modo manutenção.

Anote a hora de cada gesto. Sangramento estancado? Passe para avaliar.

### 2. AVALIAR — medir o alcance

Agora que parou de crescer, descubra **o tamanho.** Sem isso você não sabe a quem
comunicar nem o que remediar. Responda, com evidência (log, registro de acesso),
não com chute:

- **O que exatamente vazou/quebrou?** Qual chave, quais campos, quais coleções,
  qual sistema. Seja específico: "vazou a chave do Firebase Admin" é diferente de
  "vazou uma chave".
- **Por quanto tempo ficou exposto?** Desde quando até quando. Define a janela de
  risco.
- **Foi acessado por quem não devia?** Distinga **exposição** (estava acessível)
  de **acesso confirmado** (alguém leu/baixou). Os logs dizem. Se não há log, trate
  como acessado — pessimismo aqui é prudência.
- **Quem foi afetado?** Quantos usuários, quais dados deles. **Tem dado pessoal no
  meio?** (nome, e-mail, CPF, telefone, endereço, pagamento, localização). Isso
  decide se vira obrigação de LGPD no passo 3.

Escreva uma frase de alcance: *"A chave X ficou exposta de DD/MM HH:MM a DD/MM
HH:MM; dá acesso a Y; há indício de acesso por terceiro: sim/não; afeta N usuários
e os dados pessoais Z."* Essa frase guia tudo daqui pra frente.

### 3. COMUNICAR — avisar quem precisa, no prazo

Comunicar é parte da resposta, não cortesia. E quando há dado pessoal, é **lei**.
Defina três coisas: **quem avisar, o que dizer, em quanto tempo.**

- **Você / o time.** Já está acontecendo (o documento de incidente). Se há time,
  defina quem responde a quê.
- **Os usuários afetados.** Avise se o dado deles foi exposto, principalmente se
  há risco pra eles (ex.: senha vazada → forçar troca; e-mail vazado → alertar
  sobre phishing). Seja claro e sem rodeio: o que aconteceu, o que você já fez, o
  que **eles** devem fazer. Não minimize nem invente.
- **ANPD (Autoridade Nacional de Proteção de Dados) — LGPD.** Se houve **incidente
  de segurança com dado pessoal que possa acarretar risco ou dano relevante** aos
  titulares, o controlador **deve comunicar a ANPD e os titulares**. Desde a
  Resolução CD/ANPD nº 15/2024, o prazo é de **3 dias úteis** a partir do
  conhecimento do incidente. A comunicação descreve a natureza dos dados, os
  titulares afetados, as medidas técnicas adotadas e os riscos. Na dúvida sobre se
  é "relevante", documente a análise — a omissão é o que pune.
- **Terceiros e provedores.** Se o vazamento envolve um serviço (Stripe, um
  parceiro), avise-os; eles podem ter obrigações próprias.

Modelo de comunicação e o detalhamento de prazos estão no playbook. Quando o
incidente toca LGPD a fundo, a **Salvaguarda** ajuda a estruturar a resposta legal.

### 4. REMEDIAR — consertar a causa raiz

Contenção é curativo; remediação é cirurgia. Aqui você fecha o buraco **de
verdade**, pra não repetir amanhã.

- **Conserte a causa, não o sintoma.** A chave vazou porque o `.env` não estava no
  `.gitignore`? Não basta rotacionar — corrija o `.gitignore`, e **limpe o
  histórico do Git** (a chave continua no histórico mesmo depois do commit de
  remoção; veja Faro). O banco estava aberto porque a regra ficou em modo de teste?
  Publique a regra certa **e** crie o hábito de revisar com o Cofre antes do deploy.
- **Restaure o que se perdeu.** Se houve perda/corrupção de dado, agora é a hora
  do restore — siga `reference/backup-e-restauracao.md`. Restaure pra um ambiente
  isolado primeiro, valide, depois promova. Nunca restaure por cima do que sobrou
  sem antes copiar o estado atual.
- **Confirme que conteve.** Depois de remediar, **verifique**: a chave antiga
  realmente não funciona mais? A regra publicada bate com o arquivo? A sessão
  revogada caiu mesmo? Remediação não confirmada é só intenção. (É o espírito da
  skill **verification-before-completion**: evidência antes de afirmar.)
- **Reforce a vigilância.** Adicione o alerta que teria pego isso mais cedo
  (Sentinela). Todo incidente que te pegou de surpresa vira um sentinela novo.

### 5. APRENDER — post-mortem sem caça às bruxas

O incidente acabou; o valor dele, não. O post-mortem transforma a dor em sistema
que não repete o erro. Use o modelo em `templates/post-mortem.md`.

A regra de ouro: **sem culpa, sem caça às bruxas (blameless).** O objetivo não é
achar quem errou — é achar **o que no sistema deixou o erro acontecer**. Pessoas
erram; sistemas bem feitos absorvem o erro humano. Se a cultura pune o autor, a
próxima pessoa vai esconder o próximo incidente, e aí você perde a chance de
aprender. Foque na pergunta certa: *"o que deixou isso ser possível?"* em vez de
*"de quem foi a culpa?"*.

Um bom post-mortem tem: o que aconteceu, o impacto real (números), a causa raiz
(pergunte "por quê" até o fundo), a linha do tempo (com horários — daí o registro
do passo 0), e as **ações concretas** com responsável e prazo. Post-mortem sem
ação é diário; com ação, é prevenção.

## BACKUP — o trabalho que se faz ANTES

A melhor resposta a incidente de perda de dado é não ter o que resgatar porque o
backup já está pronto e testado. **Faça isso com o sistema saudável.** O guia
completo está em `reference/backup-e-restauracao.md`. Os pilares:

- **Backup do Firestore.** Configure **exports agendados** (scheduled export) do
  Firestore para um bucket do Cloud Storage. Não confie só no painel — automatize.
  Defina retenção (ex.: diário por 30 dias, mensal por 1 ano).
- **Código no Git, com histórico protegido.** O código é backup se estiver
  versionado e **fora da sua máquina** (GitHub privado). Proteja a branch
  principal e habilite a recuperação de tags/releases.
- **Segredos guardados em cofre.** As variáveis de ambiente e chaves **não** estão
  no Git (e ainda bem). Então precisam de um backup próprio: um gerenciador de
  segredos / cofre de senhas. Segredo que só existe na Vercel sem cópia some se a
  conta cair.
- **Regra 3-2-1.** Três cópias dos dados, em dois tipos de mídia/lugar diferentes,
  uma delas fora do site (offsite). Aplicado ao seu mundo: o dado em produção + um
  export agendado no Storage + uma cópia em outro provedor/conta.
- **Teste o restore.** Backup que nunca foi restaurado não é backup. Agende um
  exercício: restaure num ambiente isolado, confirme que os dados voltam íntegros,
  cronometre quanto demora. Esse número é o seu RTO real — saber dele no exercício
  é muito melhor que descobri-lo no incidente.

Defina dois alvos antes de precisar: **RPO** (quanto dado você aceita perder — ex.:
"no máximo as últimas 24h") e **RTO** (em quanto tempo você precisa estar de pé —
ex.: "2 horas"). Eles dizem com que frequência fazer backup e quão pronto o restore
precisa estar.

## Referências

- `reference/playbook-incidente.md` — passo a passo por tipo de incidente (segredo
  vazado, dado pessoal exposto, conta comprometida, perda/corrupção, indisponibilidade),
  cada um com os **primeiros 15 minutos**.
- `reference/backup-e-restauracao.md` — estratégia de backup (Firestore export
  agendado, Git, segredos em cofre), regra 3-2-1, RPO/RTO e como testar o restore.
- `templates/post-mortem.md` — modelo de post-mortem blameless pronto pra preencher.
