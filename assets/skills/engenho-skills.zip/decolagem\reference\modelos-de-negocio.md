# Modelos de Negócio

Como você ganha dinheiro com o que construiu. O modelo errado mata um produto bom; o certo faz um produto mediano sobreviver. Escolha pela **natureza do problema que você resolve** e pelo **estágio** em que está — não pela moda.

Antes de tudo, uma verdade: você pode combinar modelos (ex.: serviço agora para ter caixa, produto recorrente depois). Mas comece com **um** modelo principal claro. Misturar tudo no dia 1 confunde o cliente e você.

---

## Visão rápida: qual modelo para qual situação

| Modelo | Você ganha quando... | Faz sentido se... | Cuidado |
|---|---|---|---|
| Assinatura (SaaS recorrente) | O cliente paga todo mês/ano | O problema volta sempre; seu produto entrega valor contínuo | Precisa entregar valor todo mês ou o cliente cancela |
| Pagamento único (one-time) | O cliente paga uma vez | O valor é entregue de uma vez; problema pontual | Você recomeça do zero a cada venda |
| Freemium | Grátis para muitos, pago por alguns | Você consegue muito volume barato e há motivo claro para upgrade | A maioria nunca paga; custa servir os grátis |
| Marketplace | Você conecta dois lados e cobra comissão | Há oferta e demanda fragmentadas que se beneficiam de um intermediário | Problema do ovo e da galinha: precisa dos dois lados ao mesmo tempo |
| Infoproduto | Vende conhecimento empacotado (curso, e-book, comunidade) | Você tem expertise que outros querem aprender | Mercado lotado; depende de audiência/autoridade |
| Serviço / consultoria | Vende seu tempo e entrega feito | Você quer caixa rápido e aprender o problema a fundo | Não escala: seu tempo é o teto |
| Licença / uso (usage-based) | Cliente paga pelo quanto consome | O uso varia muito entre clientes; custo seu cresce com uso | Receita imprevisível; difícil de prever caixa |

---

## Assinatura recorrente (SaaS / membership)

**O que é:** o cliente paga de forma recorrente (mensal ou anual) para continuar usando.

**Quando faz sentido:**
- O problema que você resolve **volta sempre** (organizar finanças, agendar posts, gerenciar clientes, etc.).
- Seu produto entrega valor de forma contínua, não só uma vez.
- Você consegue manter o cliente engajado mês após mês.

**Por que é o queridinho:** receita previsível. Saber que entra X todo mês transforma o negócio — você planeja, contrata, investe. Um cliente vale muito mais ao longo do tempo (ver LTV em `metricas-de-negocio.md`).

**O lado difícil:** você precisa **continuar entregando valor**, sempre. No mês em que o cliente não enxergar valor, ele cancela (isso é churn). Assinatura é um casamento, não um date.

**Erro comum:** forçar assinatura num problema pontual. Se o cliente resolve o problema e não precisa mais, ele vai cancelar — e com razão. Só use recorrente se o valor for recorrente.

---

## Pagamento único (one-time)

**O que é:** o cliente paga uma vez e leva o produto/resultado.

**Quando faz sentido:**
- O valor é entregue de uma vez (um template, uma ferramenta que resolve algo pontual, um produto digital).
- O problema não volta, ou volta tão raramente que assinatura irritaria.

**Vantagem:** simples de vender e de entender. Sem promessa de entrega contínua.

**Desvantagem central:** você **recomeça do zero a cada venda**. Vendeu 100 mês passado? Mês que vem precisa vender 100 de novo só para empatar. Não há base que se acumula. Por isso muitos produtos one-time evoluem para incluir algo recorrente (atualizações, suporte, comunidade).

**Combinação comum:** produto único na porta de entrada + algo recorrente depois (ex.: vende a ferramenta uma vez, oferece um plano de atualizações/suporte mensal).

---

## Freemium

**O que é:** uma versão grátis para muitos, com recursos pagos para quem quer mais.

**Quando faz sentido:**
- Você consegue atender muitos usuários grátis a **custo baixo** (se cada usuário grátis te custa caro, freemium te quebra).
- Existe um **motivo claro e natural** para o usuário fazer upgrade (limite de uso, recurso premium que ele realmente vai querer).
- Você tem como alcançar volume grande (porque só uma fração pequena vai pagar — tipicamente poucos por cento).

**A armadilha:** freemium parece marketing grátis, mas não é. Você está pagando para servir gente que talvez nunca pague. Só funciona se o grátis **puxa** o pago, não se ele substitui o pago. Se o seu grátis já resolve tudo, ninguém faz upgrade.

**Alternativa mais segura para quem começa:** em vez de freemium, ofereça **teste grátis por tempo limitado** (trial). O cliente experimenta o produto pago inteiro por alguns dias e decide. Costuma converter melhor e custa menos que sustentar um plano grátis para sempre.

**Regra prática:** no início, evite freemium. Cobre desde cedo. Cobrar valida o negócio; dar de graça adia a verdade.

---

## Marketplace

**O que é:** você não cria o produto — você conecta quem oferece com quem procura, e cobra uma comissão ou taxa.

**Quando faz sentido:**
- Existe oferta e demanda **fragmentadas** que se beneficiam de um lugar central (ex.: freelancers e clientes, donos de imóvel e hóspedes).
- Você consegue agregar confiança, descoberta ou facilidade que os dois lados sozinhos não teriam.

**O problema clássico — ovo e galinha:** ninguém quer entrar num marketplace vazio. Vendedores não vêm sem compradores; compradores não vêm sem vendedores. Você tem que resolver **um lado primeiro**, geralmente na unha (trazer manualmente a oferta inicial, ou garantir demanda concentrada num nicho).

**Aviso honesto:** marketplace é dos modelos mais difíceis de tirar do chão. Para quem acabou de construir algo sozinho, costuma ser cedo demais. Considere começar atendendo **um lado só** (ser você mesmo a oferta) antes de virar intermediário.

---

## Infoproduto

**O que é:** você empacota conhecimento e vende — curso, e-book, mentoria, comunidade paga.

**Quando faz sentido:**
- Você tem expertise real que outras pessoas querem aprender.
- Você tem (ou consegue construir) uma audiência que confia em você.

**Vantagem:** margem alta (produz uma vez, vende muitas), e ajuda a construir autoridade — o que alimenta seus outros produtos.

**Desvantagem:** mercado saturado de promessas. Vender infoproduto depende muito de **autoridade e audiência**, não só do conteúdo. Sem distribuição, o melhor curso do mundo não vende. E há o risco reputacional de virar "mais um vendendo curso" se o conteúdo não entregar.

**Encaixe com vibecoding:** documentar e ensinar como você construiu algo é um infoproduto natural — e reforça sua autoridade técnica.

---

## Serviço / consultoria (feito-para-você)

**O que é:** você entrega o resultado feito, cobrando por projeto ou por hora/retainer.

**Quando faz sentido:**
- Você precisa de **caixa rápido** e ainda está aprendendo o problema do cliente.
- O cliente quer o resultado, não a ferramenta.

**Por que é subestimado no começo:** serviço te dá **dinheiro agora** e, mais importante, te coloca dentro do problema do cliente. Você aprende exatamente o que dói, com quem dói e quanto vale resolver. Esse aprendizado é ouro para depois transformar em produto.

**O teto:** serviço não escala — seu tempo é limitado. Você troca horas por dinheiro. É ótimo para começar e financiar a construção de algo escalável, mas não confunda "estou ocupado e faturando" com "tenho um negócio que cresce sozinho".

**Caminho comum e saudável:** começa como serviço (aprende o problema + faz caixa) → transforma o que se repete em produto → migra para recorrente.

---

## Licença / por uso (usage-based)

**O que é:** o cliente paga conforme o quanto usa (por requisição, por unidade, por volume).

**Quando faz sentido:**
- O uso **varia muito** de cliente para cliente, e cobrar um valor fixo seria injusto para um lado.
- Seu próprio custo cresce com o uso (ex.: você paga por processamento/API por trás).

**Vantagem:** alinha o que o cliente paga com o valor que ele extrai. Cliente pequeno paga pouco, grande paga muito.

**Desvantagem:** receita **imprevisível** e mais difícil de explicar na hora da venda. O cliente fica inseguro com "quanto vou pagar no fim do mês?". Muitas vezes o melhor é combinar: um valor base previsível + cobrança por uso acima de um limite.

---

## Como escolher (resumo de decisão)

1. **O problema é recorrente ou pontual?** Recorrente → tende a assinatura. Pontual → tende a único.
2. **Você precisa de caixa agora?** Sim → considere serviço para começar, enquanto constrói o produto.
3. **Seu custo cresce com o uso?** Sim → considere componente por uso.
4. **Você consegue volume enorme e barato?** Não → fuja de freemium; cobre desde cedo.
5. **Você depende de dois lados (oferta e demanda)?** Sim → marketplace, e prepare-se para resolver um lado primeiro.

Na dúvida e começando, o par mais comum e seguro é: **serviço para aprender e faturar → produto recorrente para escalar.** A decisão é sua, mas comece com um modelo só e deixe o problema do cliente, não a moda, decidir.
