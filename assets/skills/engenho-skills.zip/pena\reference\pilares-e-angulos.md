# Pilares de conteúdo e ângulos

Todo post nasce de um **pilar** (sobre o que falamos) e de um **ângulo** (a tese deste post). Pilar dá consistência — e consistência constrói autoridade de site no Google e na cabeça do leitor. Ângulo dá foco — um post, uma ideia.

Regra: **um post pertence a um pilar.** Se está em dois, ainda não tem foco.

---

## Os pilares do Rodrigo

### 1. Segurança em IA *(o fosso)*
O diferencial. Vibecoding rápido sem segurança é bomba-relógio: segredo no código, regra de Firebase aberta, dependência envenenada, dado de usuário exposto.

- **Intenção típica:** "como deixar meu app de IA seguro", "vazamento de chave de API".
- **Prova:** Bastião, Cofre, Faro, Quarentena, Crivo — e casos reais (com nome/link).
- **Ângulos:** o erro que ninguém revisa; a vulnerabilidade que o LLM gera por padrão; LGPD para quem vibecoda; a revisão em 5 camadas.

### 2. O método (P.R.O.M.P.T.E.R. + Protocolo de 5 Camadas)
A engenharia por trás do "vibecoding com engenharia". Prompt como artefato de engenharia, revisão em camadas.

- **Intenção típica:** "como fazer um bom prompt", "como revisar código de IA".
- **Prova:** Forja (prompts), Crivo (revisão), o e-book/material do método.
- **Ângulos:** anatomia de um prompt que funciona; por que prompt ruim gera código inseguro; as 5 camadas explicadas com exemplo.

### 3. Vibecoding (a prática)
O que é, o que não é, como fazer com rigor. Desfazer o preconceito de que vibecoding é desleixo.

- **Intenção típica:** "o que é vibecoding", "vibecoding vale a pena".
- **Ângulos:** vibecoding não é no-code; do protótipo ao produto; os 3 erros do iniciante; quando NÃO usar IA.

### 4. IA & carreira
O profissional diante da IA. Sem alarmismo, sem utopia. O que muda, o que fazer.

- **Intenção típica:** "IA vai substituir programadores", "como me preparar para IA".
- **Ângulos:** quem usa IA com método vs. quem só copia; a habilidade que sobra; o portfólio na era da IA.

### 5. Primeiros passos
Para quem está começando a construir com IA. Acolhedor, concreto, sem intimidar.

- **Intenção típica:** "como começar a programar com IA", "primeiro projeto com IA".
- **Ângulos:** seu primeiro app em um fim de semana; as ferramentas que importam (e as que não); o caminho mínimo do zero ao no ar.

### 6. Post ancorado em notícia *(transversal)*
Não é um tema; é uma **técnica** que atravessa os outros pilares. Pega um fato recente de IA e conecta ao método. Detalhe abaixo.

---

## A técnica do post ancorado em notícia

A jogada de autoridade mais forte: **transformar atualidade em prova do método.** Quando algo de IA vira manchete, é a chance de mostrar que o seu método previa/resolveria aquilo. A notícia traz o tráfego (gente buscando o tema quente); o método entrega o valor.

### Como fazer

1. **Pegue um fato recente e real.** Lançamento de modelo, vazamento, falha pública, número novo, mudança de política. Tem que ter **fonte e data**. Se não tem o link, use WebSearch ou peça — **nunca invente notícia.**
2. **Escolha a lição.** O que esse fato revela? Geralmente cai em um dos pilares (quase sempre segurança ou método).
3. **Conecte ao método.** Como o P.R.O.M.P.T.E.R., o Protocolo de 5 Camadas ou o vibecoding com engenharia mudaria aquele resultado — ou o que o leitor deve fazer agora por causa disso.
4. **CTA suave** para o material/post que aprofunda.

### Estrutura do post
```
## O que aconteceu        (a notícia: fato, fonte, data)
## O que isso revela       (a lição por trás do fato)
## Como o método muda isso (conexão concreta com P.R.O.M.P.T.E.R. / 5 Camadas / vibecoding)
## Conclusão               (fecha a tese + CTA suave + "a decisão é sua")
```

### Regras
- **Janela curta:** notícia rende mais nos primeiros dias. Escreva enquanto está quente.
- **A notícia é o gancho, não o conteúdo.** Não vire um portal de notícias. 30% fato, 70% método.
- **Sem oportunismo vazio.** A conexão com o método tem que ser honesta, não forçada.
- **Atualize o "recente".** Hoje é 2026 — use fatos do período certo; não chame de "recente" algo de anos atrás.

### Exemplos de títulos por pilar

**Segurança:**
- "O que o vazamento da [empresa] ensina sobre revisar código gerado por IA"
- "[Modelo] passou a escrever código sozinho. Quem vai revisar?"

**Método:**
- "[Empresa] lançou [recurso]. O P.R.O.M.P.T.E.R. já dizia por que isso importa"
- "A falha do [agente de IA] que um prompt bem-feito teria evitado"

**Vibecoding:**
- "[Ferramenta] virou manchete. Vibecoding com engenharia explica o hype"

**IA & carreira:**
- "[Empresa] demitiu/contratou por causa de IA. O que isso muda pra você"
- "[Número] de vagas pedem IA. A habilidade que ninguém está olhando"

**Primeiros passos:**
- "Saiu o [modelo/ferramenta] grátis. Seu primeiro projeto pode ser hoje"

> Substitua os `[colchetes]` por dados reais e datados. Sem fato verificável, não publique como notícia.

## Banco de ângulos rápidos (não-notícia)

- **O erro comum:** "Os 3 erros que todo [perfil] comete ao [ação]"
- **O contraintuitivo:** "Por que [prática aceita] está errada"
- **O passo a passo:** "Como [resultado] em [tempo/etapas]"
- **A comparação honesta:** "[A] vs [B]: quando usar cada um"
- **O bastidor/caso:** "Como construí [projeto real] com IA — e o que deu errado"
- **O mito:** "Vibecoding é [mito]? O que realmente acontece"
