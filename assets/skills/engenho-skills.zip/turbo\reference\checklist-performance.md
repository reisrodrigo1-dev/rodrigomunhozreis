# Checklist de performance — priorizado por impacto (Next.js / Vercel / Firebase)

Use de cima para baixo. Os itens estão **ordenados por impacto típico** — os primeiros movem mais o número. Marque o que já está feito, ataque o primeiro que não está. Sempre **meça antes e depois**.

> Não rode o checklist inteiro de uma vez. Meça, ache o gargalo, pegue o item correspondente, conserte, remeça.

---

## Nível 0 — Medir (faça antes de qualquer item abaixo)

- [ ] Rodei **Lighthouse em modo mobile + throttling** e anotei LCP, CLS, INP, TTFB.
- [ ] Olhei **field data** (PageSpeed Insights / CrUX ou `useReportWebVitals`) — o que o usuário real sente.
- [ ] Li a tabela **First Load JS** do `next build`.
- [ ] Olhei a aba **Network** ordenada por tempo e achei a request do caminho crítico.
- [ ] Tenho um **baseline** escrito para comparar no fim.

---

## Alto impacto — atacar primeiro

**Renderização (Next.js App Router)**
- [ ] Páginas são **Server Components** por padrão; `'use client'` só onde há interatividade real.
- [ ] Páginas com dado cacheável usam **ISR** (`export const revalidate = N`) em vez de SSR a cada request.
- [ ] Conteúdo não-crítico é **streamado** com `loading.tsx` / `<Suspense>` em vez de bloquear o primeiro paint.
- [ ] Páginas estáticas são **estáticas de fato** (sem `cookies()`/`headers()`/`no-store` desnecessário forçando dynamic rendering).

**Imagens**
- [ ] Toda imagem usa **`next/image`** (não `<img>`).
- [ ] A imagem do **LCP** (hero acima da dobra) tem **`priority`**.
- [ ] Imagens têm **`width`/`height`** ou `fill` + `aspect-ratio` (mata LCP **e** CLS).
- [ ] Formato **WebP/AVIF** e tamanho responsivo (`sizes`).

**Bundle JS**
- [ ] Rodei **`@next/bundle-analyzer`** e não há dependência gorda/duplicada surpresa.
- [ ] Componentes pesados não-críticos (modais, gráficos, mapas, editores) usam **`dynamic()`** import.
- [ ] Imports são **pontuais** (`lodash/debounce`, não `lodash` inteiro; ícones individuais, não a lib toda).
- [ ] **Scripts de terceiros** usam `next/script` com `afterInteractive`/`lazyOnload`.

**Dados / Firestore**
- [ ] Nenhuma tela carrega **coleção inteira** — tudo paginado (`limit` + cursor).
- [ ] Sem **N+1** (não há query dentro de loop por item).
- [ ] Queries que filtram/ordenam têm **índice** (criei os índices compostos que o Firestore pediu).
- [ ] Contagens/somatórios usam **documento agregado**, não leitura de N docs.

---

## Médio impacto

**Fontes**
- [ ] Uso **`next/font`** (auto-hospedado, sem reflow, sem request externa).
- [ ] Carrego só os **pesos/estilos usados**; `preload` só nas fontes acima da dobra.

**Cache / Edge (Vercel)**
- [ ] Respostas cacheáveis têm **headers de cache** (`s-maxage`, `stale-while-revalidate`).
- [ ] Rotas que se beneficiam rodam no **Edge Runtime** (menos cold start, mais perto do usuário).
- [ ] Leituras repetidas dentro de uma request são **dedupadas** (`React.cache` / `unstable_cache`).

**React (interatividade / INP)**
- [ ] Estado que muda muito (inputs) está **isolado** em componente pequeno, não no topo da árvore.
- [ ] **Listas grandes (1000+)** são virtualizadas.
- [ ] Atualizações não urgentes usam **`useTransition`/`useDeferredValue`**; handlers ruidosos têm **debounce**.
- [ ] `memo`/`useMemo`/`useCallback` aplicados **onde o Profiler mostrou custo** — não em tudo.

**CLS**
- [ ] Espaço reservado para **ads/embeds/banners** que carregam depois.
- [ ] Skeletons têm o **mesmo tamanho** do conteúdo final.
- [ ] Animações usam só **`transform`/`opacity`**.

---

## Baixo impacto / refinamento

- [ ] `placeholder="blur"` em imagens grandes para melhor percepção.
- [ ] Prefetch de rotas prováveis (o `<Link>` do Next já faz por padrão em viewport).
- [ ] Comprimir respostas (a Vercel já faz gzip/brotli; conferir em assets próprios).
- [ ] Remover CSS não usado (aba **Coverage** do DevTools).
- [ ] Conferir que **não há `console.log`/debug pesado** em produção.

---

## Fechamento — Medir de novo

- [ ] Rodei **as mesmas medições** do Nível 0, nas mesmas condições.
- [ ] LCP / CLS / INP / TTFB / First Load JS melhoraram vs. baseline.
- [ ] **Nada piorou** (ex.: ganhei LCP mas não estourei CLS).
- [ ] Se o número não mexeu, **revertí** — era o gargalo errado.

---

## Cruzamento com custo (Termômetro)

Estes itens melhoram performance **e** cortam a fatura — vale priorizar:
- **Paginação + fim do N+1** no Firestore → menos leituras (a unidade que mais explode a conta).
- **Cache/ISR** → menos recomputação de servidor e menos leituras de banco.
- **`next/image` + CDN/cache** → menos egress (caro na Vercel).
- **Bundle menor** → menos bandwidth servido.

Quando um conserto aparece nas duas listas, ele é dinheiro **e** velocidade. Para a estimativa de custo, chame o **Termômetro**.
