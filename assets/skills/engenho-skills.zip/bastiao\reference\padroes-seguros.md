# Padrões Seguros — Bastião

Receituário de **padrões prontos** por área, para colar e adaptar. Stack de referência: Next.js (App Router) + Firebase + Vercel + GitHub. Cada bloco tem o **porquê** e o **código**.

Índice: [Regras de Firestore](#firestore) · [Regras de Storage](#storage) · [Variáveis de ambiente e .gitignore](#env) · [Autenticação e autorização](#auth) · [Validação de input (Zod)](#validacao) · [Headers de segurança no next.config](#headers) · [CORS seguro](#cors) · [Rate limiting](#ratelimit) · [Repositório privado e segredos no Git](#repo) · [Travar dependências](#deps) · [Cookies de sessão](#cookies) · [Checklist de produção](#checklist)

---

<a id="firestore"></a>
## 1. Regras de Firestore — negar por padrão, validar com `hasOnly`

**Por quê:** regras são a **última linha** entre o banco e a internet. Comece fechado, libere por dono, e valide o **formato** do que entra (não só quem entra).

```js
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // ---- funções utilitárias ----
    function signedIn() { return request.auth != null; }
    function isOwner(uid) { return signedIn() && request.auth.uid == uid; }
    function isString(v, max) { return v is string && v.size() <= max; }

    // ---- usuários: só o dono lê/edita o próprio doc ----
    match /users/{uid} {
      allow read: if isOwner(uid);

      allow create: if isOwner(uid)
        // só estes campos podem existir (bloqueia role:"admin" etc.):
        && request.resource.data.keys().hasOnly(['name','email','createdAt'])
        && isString(request.resource.data.name, 80)
        && isString(request.resource.data.email, 120);

      allow update: if isOwner(uid)
        // só name/bio podem MUDAR; o resto fica imutável:
        && request.resource.data.diff(resource.data).affectedKeys().hasOnly(['name','bio']);

      allow delete: if isOwner(uid);
    }

    // ---- posts: leitura pública, escrita só do autor ----
    match /posts/{postId} {
      allow read: if true;
      allow create: if signedIn()
        && request.resource.data.authorId == request.auth.uid
        && isString(request.resource.data.title, 140);
      allow update, delete: if signedIn()
        && resource.data.authorId == request.auth.uid;
    }

    // ---- fecha tudo que não foi explicitamente liberado ----
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

**Princípios:**
- `if false` no catch-all garante que qualquer coleção nova nasce fechada.
- `hasOnly` no **create** bloqueia campos extras (anti mass assignment).
- `diff().affectedKeys().hasOnly([...])` no **update** congela campos sensíveis (role, saldo).
- Valide tipo/tamanho — regra também é validação de dados.
- Teste com o **Firestore Emulator** (`@firebase/rules-unit-testing`) antes de subir.

---

<a id="storage"></a>
## 2. Regras de Storage — tipo, tamanho e dono

```js
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {

    match /avatars/{uid}/{file} {
      allow read: if true; // avatar público
      allow write: if request.auth != null
        && request.auth.uid == uid
        && request.resource.size < 2 * 1024 * 1024
        && request.resource.contentType.matches('image/(png|jpeg|webp)');
    }

    match /private/{uid}/{file} {
      allow read, write: if request.auth != null && request.auth.uid == uid;
    }

    match /{allPaths=**} {
      allow read, write: if false; // fecha o resto
    }
  }
}
```
Sirva uploads de usuário de um **bucket/domínio separado** sem cookie de sessão; force download para tipos arriscados.

---

<a id="env"></a>
## 3. Variáveis de ambiente e `.gitignore`

**Regra de ouro:** `NEXT_PUBLIC_*` = público (vai pro navegador). Tudo o mais fica no servidor.

`.gitignore` mínimo:
```gitignore
# segredos
.env
.env.local
.env.*.local
*.pem
*.key
*serviceAccount*.json
firebase-adminsdk-*.json

# build/deps
node_modules/
.next/
```

`.env.local` (NUNCA commitado):
```bash
# públicas (OK no bundle) — config do Firebase client é pública por design
NEXT_PUBLIC_FIREBASE_API_KEY=...
NEXT_PUBLIC_FIREBASE_PROJECT_ID=...

# privadas (NUNCA NEXT_PUBLIC_) — só server-side
FIREBASE_ADMIN_PRIVATE_KEY=...
STRIPE_SECRET_KEY=...
OPENAI_API_KEY=...
```

Crie um `.env.example` (esse SIM commitado) com as **chaves sem valores**, para documentar.

Blindar segredo no servidor — quebra o build se vazar pro cliente:
```ts
// lib/server-secrets.ts
import 'server-only'; // erro de compilação se importado em código client
export const stripeKey = process.env.STRIPE_SECRET_KEY!;
```

> **A "API key" do Firebase client é pública por natureza** (identifica o projeto, não autoriza nada). O que protege seu Firebase são as **regras** e o **App Check** — não esconder essa chave.

---

<a id="auth"></a>
## 4. Autenticação e autorização — validar no servidor

```ts
// lib/firebase-admin.ts
import { initializeApp, getApps, cert } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';

const app = getApps()[0] ?? initializeApp({
  credential: cert({
    projectId: process.env.FIREBASE_PROJECT_ID,
    clientEmail: process.env.FIREBASE_CLIENT_EMAIL,
    privateKey: process.env.FIREBASE_ADMIN_PRIVATE_KEY?.replace(/\\n/g, '\n'),
  }),
});
export const adminAuth = getAuth(app);
```

```ts
// lib/require-user.ts — usar no topo de toda rota/ação protegida
import { cookies } from 'next/headers';
import { adminAuth } from './firebase-admin';

export async function requireUser() {
  const session = (await cookies()).get('session')?.value;
  if (!session) throw new Response('Não autenticado', { status: 401 });
  try {
    return await adminAuth.verifySessionCookie(session, true); // checa assinatura + revogação
  } catch {
    throw new Response('Sessão inválida', { status: 401 });
  }
}
```

```ts
// route handler protegido + autorização por dono
export async function DELETE(req: Request, { params }: { params: { id: string }}) {
  const user = await requireUser();
  const ref = db.collection('orders').doc(params.id);
  const snap = await ref.get();
  if (!snap.exists || snap.data()!.ownerId !== user.uid)
    return new Response('Não encontrado', { status: 404 });
  await ref.delete();
  return new Response(null, { status: 204 });
}
```

**Autorização por papel (admin):** use **custom claims** do Firebase (`adminAuth.setCustomUserClaims(uid, { admin: true })`), verificadas no token no servidor — nunca um campo editável no Firestore nem flag no client.

---

<a id="validacao"></a>
## 5. Validação de input com Zod

**Por quê:** todo input é suspeito. Schema valida tipo, formato e tamanho num lugar só, e tipa o dado.

```ts
import { z } from 'zod';

const CriarPost = z.object({
  title: z.string().min(1).max(140),
  body: z.string().max(5000),
  tags: z.array(z.string().max(20)).max(5).optional(),
});

export async function POST(req: Request) {
  const json = await req.json().catch(() => null);
  const parsed = CriarPost.safeParse(json);
  if (!parsed.success)
    return Response.json({ error: 'Dados inválidos' }, { status: 400 });

  const data = parsed.data; // tipado e seguro a partir daqui
  // ...
}
```
Valide **na borda** (entrada do servidor) e **de novo** na regra do banco. Nunca confie em validação só do client.

---

<a id="headers"></a>
## 6. Headers de segurança no `next.config`

```js
// next.config.mjs
const csp = [
  "default-src 'self'",
  "script-src 'self' 'unsafe-inline'",      // ajuste conforme suas libs; mire remover unsafe-inline
  "style-src 'self' 'unsafe-inline'",
  "img-src 'self' data: https:",
  "connect-src 'self' https://*.googleapis.com https://*.firebaseio.com",
  "frame-ancestors 'none'",                  // anti-clickjacking
  "base-uri 'self'",
  "form-action 'self'",
].join('; ');

const securityHeaders = [
  { key: 'Strict-Transport-Security', value: 'max-age=63072000; includeSubDomains; preload' },
  { key: 'X-Content-Type-Options', value: 'nosniff' },
  { key: 'X-Frame-Options', value: 'DENY' },
  { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
  { key: 'Permissions-Policy', value: 'camera=(), microphone=(), geolocation=()' },
  { key: 'Content-Security-Policy', value: csp },
];

export default {
  async headers() {
    return [{ source: '/:path*', headers: securityHeaders }];
  },
};
```
Comece com CSP em modo `Content-Security-Policy-Report-Only` para não quebrar o app, ajuste, depois aplique. Na Vercel, dá pra setar headers também via `vercel.json`.

---

<a id="cors"></a>
## 7. CORS seguro (API route)

```ts
const ALLOW = new Set(['https://app.seudominio.com', 'https://seudominio.com']);

function corsHeaders(origin: string | null) {
  const h = new Headers();
  if (origin && ALLOW.has(origin)) {
    h.set('Access-Control-Allow-Origin', origin);
    h.set('Access-Control-Allow-Credentials', 'true');
    h.set('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    h.set('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    h.set('Vary', 'Origin');
  }
  return h;
}

export async function OPTIONS(req: Request) {
  return new Response(null, { status: 204, headers: corsHeaders(req.headers.get('origin')) });
}
```
Nunca `Access-Control-Allow-Origin: *` junto de credenciais.

---

<a id="ratelimit"></a>
## 8. Rate limiting (Upstash — funciona em serverless)

```ts
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

export const loginLimiter = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(5, '1 m'),
  prefix: 'rl:login',
});

export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for')?.split(',')[0] ?? 'anon';
  const { success, reset } = await loginLimiter.limit(ip);
  if (!success)
    return new Response('Muitas tentativas. Tente mais tarde.', {
      status: 429, headers: { 'Retry-After': String(Math.ceil((reset - Date.now())/1000)) },
    });
  // ... lógica
}
```
Aplique em login, OTP, "esqueci a senha", endpoints de IA/e-mail e qualquer API pública. Some com o **Firewall/WAF da Vercel** para proteção de borda.

---

<a id="repo"></a>
## 9. Repositório privado e segredos no Git

- **Repo privado por padrão** até ter certeza do que está exposto. No GitHub: Settings → Danger Zone → Change visibility.
- **Branch protection** na `main`: exigir PR, revisão e checks.
- **Secret scanning** + **Push protection** do GitHub: bloqueia push de segredo conhecido (Settings → Code security).
- Se um segredo foi commitado: **rotacione a chave primeiro** (o histórico já pode ter sido clonado), depois limpe o histórico com `git filter-repo` ou BFG.
- Use **GitHub Secrets** / variáveis de ambiente da Vercel para CI/CD — nunca segredo em arquivo versionado.

---

<a id="deps"></a>
## 10. Travar dependências

```bash
npm ci          # instala EXATAMENTE o lockfile (use em CI e deploy)
npm audit       # checa vulnerabilidades conhecidas
npm audit fix   # corrige o que dá automaticamente
```
- **Commite o `package-lock.json`.** Ele garante a mesma árvore em todo lugar.
- Evite `latest`/ranges largos em libs sensíveis; suba major com teste.
- Habilite **Dependabot** (`.github/dependabot.yml`) para alertas e PRs de atualização.
- Antes de adicionar pacote: confira nome exato (typosquatting), manutenção e downloads. Considere `npm install --ignore-scripts` para pacote desconhecido.

```yaml
# .github/dependabot.yml
version: 2
updates:
  - package-ecosystem: "npm"
    directory: "/"
    schedule: { interval: "weekly" }
```

---

<a id="cookies"></a>
## 11. Cookies de sessão seguros

```ts
import { cookies } from 'next/headers';
import { adminAuth } from '@/lib/firebase-admin';

// troca o ID token do client por um session cookie httpOnly
export async function POST(req: Request) {
  const { idToken } = await req.json();
  const expiresIn = 60 * 60 * 24 * 5 * 1000; // 5 dias
  const session = await adminAuth.createSessionCookie(idToken, { expiresIn });
  (await cookies()).set('session', session, {
    httpOnly: true,   // JS não lê (anti-XSS no roubo de sessão)
    secure: true,     // só HTTPS
    sameSite: 'lax',  // anti-CSRF básico
    maxAge: expiresIn / 1000,
    path: '/',
  });
  return new Response(null, { status: 204 });
}
```
Nunca guarde o token em `localStorage` (acessível por XSS). Cookie `httpOnly` é o padrão seguro.

---

<a id="checklist"></a>
## 12. Checklist de produção (rodar antes de cada deploy)

- [ ] `firestore.rules` e `storage.rules` sem `if true`; catch-all `if false`; testadas no emulator.
- [ ] Nenhum segredo no Git (`git ls-files` limpo); nenhum segredo atrás de `NEXT_PUBLIC_`.
- [ ] Toda rota/dado sensível valida sessão **no servidor**; autorização por dono/claim.
- [ ] Todo input validado com schema na borda.
- [ ] Headers de segurança + CSP ativos.
- [ ] CORS com allowlist; sem `*` + credenciais.
- [ ] Rate limit em login e APIs sensíveis.
- [ ] `npm audit` sem vulnerabilidade alta/crítica; lockfile commitado.
- [ ] Logs sem PII/segredo; erros genéricos em produção.
- [ ] PII só o necessário; consentimento e base legal definidos (ver `lgpd.md`).
- [ ] Repo privado/protegido; secret scanning ligado.
