# Copy de conversão para landing de oferta única

Copy de landing tem um alvo: a pessoa **deixar o e-mail**. Tudo aqui — headline, bullets, FAQ, microcopy — empurra pra essa única ação, na voz "vibecoding com engenharia": direta, específica, sem hype. A decisão é sempre do leitor.

Para as fórmulas (PAS, AIDA) e a voz anti-hype completa, leia `alavanca/reference/copywriting.md`. Aqui estão os padrões **prontos pra landing**.

---

## Headlines (hero)

A headline faz 80% do trabalho. Ela para o scroll e diz, específica, o que a pessoa ganha. Uma ideia só. Promete o que a isca entrega (continuidade de promessa com o anúncio).

**Padrões que funcionam:**

| Padrão | Exemplo |
|---|---|
| Como [resultado] sem [dor] | "Como divulgar o que você criou sem queimar orçamento em anúncio" |
| [Número] [coisas] para [resultado] | "5 erros de landing que derrubam sua conversão (e como evitar)" |
| O guia/checklist de [tema] para quem [contexto] | "O checklist de 12 itens para tirar seu protótipo do ar de teste" |
| A forma certa de [tarefa] quando você [contexto] | "A forma certa de capturar leads quando você constrói sozinho com IA" |
| Pergunta que nomeia a dor | "Cansado de pagar por clique e não ficar nem com o e-mail?" |

**Exemplos ruins (não fazer):**
- "Transforme seu negócio com IA" → genérico, não nomeia nada.
- "O melhor e-book sobre marketing do Brasil" → superlativo vazio.
- "Descubra o segredo que ninguém conta" → curiosidade sem substância, cheira a hype.

**Regras:** específica > genérica; número e detalhe > adjetivo; promete só o que entrega; uma ideia por headline.

---

## Subheads (1 linha sob a headline)

A subhead completa a headline: pra quem é e qual o resultado concreto. Uma frase.

- "E-book grátis para quem vibecoda e quer transformar tráfego pago em base de e-mail — não em dinheiro queimado."
- "O passo a passo que uso pra montar páginas que capturam e-mail de verdade. Direto ao ponto, sem teoria."
- "Pra quem constrói sozinho com IA e trava na hora de divulgar."

**Erro:** repetir a headline com outras palavras, ou empilhar adjetivo ("incrível, completo, definitivo").

---

## Bullets de valor ("o que você recebe")

Cada bullet liga **conteúdo → benefício**. Específico. 3 a 5 deles.

**Estrutura:** [o que é/contém] *para* [resultado que dá].

- "**Checklist de 12 itens** para tirar a cara de protótipo da sua landing antes de gastar com tráfego."
- "**O modelo de funil pago → e-book → e-mail** que transforma clique em ativo que você possui."
- "**Os 5 erros de formulário** que derrubam conversão — e o ajuste de cada um."
- "**Exemplos reais de headline** que param o scroll, prontos pra adaptar."
- "**Um critério simples** pra decidir quando matar um anúncio em vez de jogar mais dinheiro."

**Erros:**
- "Conteúdo exclusivo e atualizado" → diz nada.
- "12 páginas de PDF" → feature sem benefício.
- "Dicas incríveis que vão mudar sua vida" → hype.

---

## Copy de autoridade / prova

Mostra competência **entregando**, não se elogiando. 2-3 frases.

- "Sou Rodrigo Munhoz Reis. Trabalho com 'vibecoding com engenharia': construir rápido com IA, mas com método — pra que o que você cria realmente rode, converta e venda. Aqui está parte do que uso no dia a dia."
- Prova honesta: "Já são [X] pessoas na base." / "Esse é o mesmo funil por trás da /ia-sem-medo." / Só o que for verdade.

**Regra:** prova específica e verificável, ou nenhuma. Inventar número mata a confiança.

---

## FAQ de objeções (4 a 6)

Cada par quebra uma trava de conversão. Pergunta na voz da pessoa, resposta curta e honesta.

> **É grátis mesmo?**
> É. Você deixa seu e-mail e recebe o material na hora, sem custo. Sem pegadinha de "cartão pra liberar".

> **Vou receber spam?**
> Não. Você recebe o material e, de vez em quando, conteúdo útil sobre o tema. Cancela quando quiser, num clique — e eu não vendo nem passo seu e-mail pra ninguém.

> **Isso é pra mim?**
> É pra você se constrói coisas com IA e trava na hora de divulgar e capturar leads. Se você já tem um funil rodando azeitado, talvez não precise.

> **Preciso saber programar ou ter experiência?**
> Não. O material é direto e prático — dá pra aplicar mesmo começando agora.

> **Como recebo depois de assinar?**
> Chega no seu e-mail em segundos. Se não vier, confere o spam (e me avisa que eu resolvo).

> **E se eu achar que não valeu?**
> É grátis, então você não perde nada. E pode sair da lista quando quiser, sem precisar justificar.

**Erros:** FAQ de suporte ("esqueci a senha"), resposta defensiva/longa, deixar a objeção óbvia ("vou receber spam?") sem resposta.

---

## Microcopy do formulário

**Labels** (sempre presentes, não só placeholder):
- Nome (opcional): "Seu primeiro nome"
- E-mail: "Seu melhor e-mail"

**Placeholders** (apoio, não substituem label):
- "Como você quer ser chamado" / "voce@email.com"

**Reforço de baixo risco** (sob o botão):
- "Grátis. Sem spam. Cancela quando quiser."
- "Seu e-mail está seguro. Só uso pra te mandar o material e conteúdo útil."

**Nunca peça telefone numa isca grátis.** Cada campo extra derruba conversão; telefone derruba muito. E-mail (e, no máximo, primeiro nome) basta.

---

## Microcopy do botão (CTA)

Verbo + benefício, na primeira pessoa do desejo. **Nunca "Enviar"** ou "Cadastrar".

**Bons:**
- "Quero o e-book grátis"
- "Baixar o checklist agora"
- "Me manda o material"
- "Quero acesso grátis"

**Ruins:** "Enviar", "Cadastrar", "Inscrever-se", "Continuar" — frios, não dizem o que a pessoa ganha.

---

## Microcopy dos estados (validação nunca silenciosa)

- **E-mail inválido:** "Confere o e-mail — parece que falta algo (ex.: voce@email.com)."
- **Campo vazio:** "Preciso do seu e-mail pra te mandar o material."
- **Carregando:** botão vira "Enviando..." e fica desabilitado.
- **Sucesso:** "Pronto! Já mandei pro seu e-mail. Se não chegar em 2 min, confere o spam." (ou redireciona pra página de obrigado).
- **Erro de envio:** "Algo deu errado por aqui. Tenta de novo em alguns segundos?"

Silêncio é a pior conversão. Todo estado fala com a pessoa.

---

## Página de obrigado (opcional, mas recomendada)

Depois do sucesso, leve a uma página curta de obrigado:
- Confirma a entrega ("Tá no seu e-mail. Confere o spam se não vier.").
- Reforça a próxima ação (abrir o material) ou já oferece o próximo passo do funil — sem fricção.
- É também onde dispara o evento de conversão (Pixel/GA), confirmando o Lead.

---

A copy boa de landing é honesta e específica. Promete o que entrega, mostra prova que é verdade, quebra a objeção e pede uma ação só. A decisão é sua.
