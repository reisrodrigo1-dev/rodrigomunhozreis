# Guia de auditoria: comandos npm e como ler a saída

Comandos para auditar dependências de um projeto npm e o que olhar em cada saída. Roda na raiz do projeto (onde está o `package.json`).

---

## `npm audit` — vulnerabilidades conhecidas

```bash
npm audit                 # relatório completo
npm audit --omit=dev      # ignora devDependencies (foco no que vai pra produção)
npm audit --json          # saída estruturada, para processar
npm audit --audit-level=high   # só falha/lista de high pra cima
```

**Como ler a saída:**

- Cada vulnerabilidade traz **severidade** (`critical` / `high` / `moderate` / `low`), o **pacote afetado**, o **caminho** (`node_modules/a > node_modules/b`) e a **correção sugerida**.
- O resumo final mostra a contagem por severidade. Exemplo:
  `5 vulnerabilities (2 moderate, 3 high)`.
- **Severidade ≠ urgência.** Pondere onde o pacote roda: um `high` numa lib que vai pro servidor exposto importa mais que um `critical` num pacote de dev que só roda no seu build local.
- **Olhe o caminho.** Se a vulnerabilidade está numa transitiva (`a > b > c`), você não atualiza `c` direto — atualiza o pai, ou usa `overrides`.
- **Limitação:** o audit só conhece o que já está catalogado (advisories publicados). Não pega um pacote recém-comprometido cujo aviso ainda não saiu. Por isso ele é necessário mas não substitui a avaliação manual de pacotes novos.

**Corrigir:**

```bash
npm audit fix             # aplica correções compatíveis (sem quebrar semver)
npm audit fix --dry-run   # mostra o que faria, sem aplicar
npm audit fix --force     # PERIGO: sobe major versions, pode quebrar o projeto
```

Nunca rode `--force` no automático. Rode o `--dry-run` primeiro, leia, e suba majors um a um testando.

Para uma transitiva que o pai não atualiza, force pelo `package.json`:

```json
{ "overrides": { "pacote-vulneravel": "1.2.4" } }
```

---

## `npm outdated` — o que está atrasado

```bash
npm outdated
```

Mostra, para cada pacote desatualizado:

| Coluna | Significado |
|---|---|
| `Current` | versão instalada agora (no `node_modules`) |
| `Wanted` | maior versão que o range do `package.json` permite |
| `Latest` | versão mais nova publicada no npm |

**Como ler:**

- `Current` < `Wanted`: o lockfile está atrás do que o seu range já permitiria — um `npm install`/`update` te atualiza dentro do semver.
- `Wanted` < `Latest`: existe versão nova fora do seu range (geralmente um major). Subir exige editar o `package.json` e testar.
- **`Current` muito atrás de `Latest` há muito tempo** pode indicar pacote abandonado *ou* um que você travou de propósito — saiba qual é o caso.

Atualizar com critério, não em massa. Cada bump é uma chance de pegar um release comprometido (ver caso Axios em `../reference/riscos-supply-chain.md`).

---

## `npm ls` — a árvore real instalada

```bash
npm ls                     # árvore completa (verbosa)
npm ls --depth=0           # só dependências diretas
npm ls <pacote>            # mostra quem trouxe esse pacote (a cadeia)
npm ls --all               # tudo, incluindo transitivas profundas
```

**Usos:**

- `npm ls <pacote>` é a ferramenta para entender **por que** uma transitiva está no projeto — mostra o caminho do pai até ela. Essencial ao reagir a um advisory: "estou exposto ao pacote X? quem o trouxe?".
- `npm ls --depth=0` dá o retrato das dependências diretas para revisar contra o `package.json`.
- **`invalid` / `extraneous` / `UNMET DEPENDENCY`** na saída = inconsistência entre `package.json`, lockfile e `node_modules`. Sinal de que alguém instalou fora do fluxo. Reinstale limpo (ver abaixo).

---

## Verificar o lockfile

O lockfile (`package-lock.json` no npm) registra a árvore exata instalada. É a peça central da defesa.

**Checagens:**

1. **Existe e está commitado?** Sem lockfile, não há reprodutibilidade nem proteção contra update automático. Se não existe:
   ```bash
   npm install        # gera o package-lock.json
   git add package-lock.json
   ```
2. **`package.json` e lockfile batem?** Use `npm ci` para verificar — ele falha se divergirem:
   ```bash
   npm ci             # instala EXATAMENTE o lockfile; erro se package.json não casa
   ```
   Use `npm ci` em CI/CD e deploy. Use `npm install` só quando for deliberadamente adicionar/atualizar algo.
3. **Reinstalação limpa** quando a árvore está inconsistente:
   ```bash
   rm -rf node_modules
   npm ci
   ```
   (No Windows/PowerShell: `Remove-Item -Recurse -Force node_modules; npm ci`.)
4. **Revisar o diff do lockfile no PR.** Quando o lockfile muda, confira que a mudança corresponde a um pacote que você adicionou/atualizou de propósito. Mudança de lockfile inexplicada merece investigação.

---

## Inspecionar um pacote sem instalar

Útil na fase de quarentena (avaliar pacote novo):

```bash
npm view <pacote>                 # metadados gerais
npm view <pacote> versions        # histórico de versões publicadas
npm view <pacote> time            # datas de cada publicação (vê ritmo/abandono)
npm view <pacote> maintainers     # mantenedores
npm view <pacote> repository      # link do repositório
npm view <pacote> dependencies    # o que ele arrasta
npm view <pacote> scripts         # tem postinstall? o que roda no install?
```

Cruze com o checklist de `../reference/avaliar-pacote.md`. `npm view <pacote> time` é especialmente útil: revela tanto abandono (última publicação anos atrás) quanto o padrão suspeito de "parado por muito tempo e de repente um release novo".

---

## Rotina sugerida de auditoria

```bash
npm ci                    # 1. instala limpo a partir do lockfile
npm ls --depth=0          # 2. confere dependências diretas
npm outdated              # 3. vê o que está atrasado
npm audit --omit=dev      # 4. vulnerabilidades conhecidas no que vai pra produção
npm audit                 # 5. visão completa, incluindo dev
```

Depois: revisar versões soltas no `package.json`, avaliar updates com critério (não no automático), e tratar achados conforme severidade **e** onde o pacote roda.
