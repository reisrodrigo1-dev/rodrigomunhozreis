#!/usr/bin/env python3
"""
scan-basico.py — Triagem de segurança do Bastião (vibecoding com engenharia).

Faz uma varredura RÁPIDA e SUPERFICIAL do repositório atrás de dois dos riscos
mais graves do vibecoding:

  1) Segredos vazados   -> chaves de API, tokens, private keys, credenciais.
  2) Regras de banco abertas -> 'allow ... if true' / 'allow read, write;' em *.rules.

NÃO é um scanner completo nem substitui revisão humana. É a Camada 2 (LER) do
Protocolo de 5 Camadas: pega o óbvio, rápido, para você priorizar.

Uso:
    python scan-basico.py [caminho]      # padrão: diretório atual
    python scan-basico.py . --json       # saída em JSON

A decisão é sua: o scan aponta; você confirma e corrige.
"""

from __future__ import annotations
import sys
import os
import re
import json
import argparse

# ---------------------------------------------------------------------------
# Padrões de SEGREDO (regex). Cada um: (rótulo, regex, prioridade).
# ---------------------------------------------------------------------------
SECRET_PATTERNS = [
    ("Chave privada (PEM)",            re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH |DSA |PGP )?PRIVATE KEY-----"), "CRITICO"),
    ("AWS Access Key ID",              re.compile(r"\bAKIA[0-9A-Z]{16}\b"), "CRITICO"),
    ("Google API key",                 re.compile(r"\bAIza[0-9A-Za-z\-_]{35}\b"), "ALTO"),
    ("Stripe secret/live key",         re.compile(r"\b(?:sk|rk)_(?:live|test)_[0-9A-Za-z]{16,}\b"), "CRITICO"),
    ("OpenAI/Anthropic key",           re.compile(r"\bsk-(?:proj-|ant-)?[0-9A-Za-z\-_]{20,}\b"), "CRITICO"),
    ("GitHub token",                   re.compile(r"\bgh[pousr]_[0-9A-Za-z]{36,}\b"), "CRITICO"),
    ("Slack token",                    re.compile(r"\bxox[baprs]-[0-9A-Za-z\-]{10,}\b"), "ALTO"),
    ("JWT (token assinado)",           re.compile(r"\beyJ[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\.[A-Za-z0-9_\-]{10,}\b"), "MEDIO"),
    ("Atribuicao de segredo no codigo", re.compile(r"(?i)(?:api[_-]?key|secret|password|passwd|private[_-]?key|access[_-]?token|client[_-]?secret)\s*[:=]\s*['\"][^'\"\s]{8,}['\"]"), "ALTO"),
    ("Segredo atras de NEXT_PUBLIC_",  re.compile(r"(?i)NEXT_PUBLIC_[A-Z0-9_]*(?:SECRET|PRIVATE|PASSWORD|TOKEN|SERVICE_ACCOUNT)"), "CRITICO"),
]

# Sinais de que provavelmente é placeholder/exemplo (reduz falso positivo).
PLACEHOLDER = re.compile(r"(?i)(your|seu|sua|example|exemplo|placeholder|xxxx|<.*>|\.\.\.|change[_-]?me|dummy|sample|fake|test123)")

# ---------------------------------------------------------------------------
# Padrões de REGRA ABERTA (.rules do Firebase).
# ---------------------------------------------------------------------------
OPEN_RULE_PATTERNS = [
    ("allow ... if true",        re.compile(r"allow\s+[a-z,\s]+:\s*if\s+true\b"), "CRITICO"),
    ("allow sem condicao",       re.compile(r"allow\s+(?:read|write|create|update|delete)(?:\s*,\s*(?:read|write|create|update|delete))*\s*;"), "CRITICO"),
    ("allow apenas auth != null", re.compile(r"allow\s+[a-z,\s]+:\s*if\s+request\.auth\s*!=\s*null\s*;"), "MEDIO"),
]

# Arquivos suspeitos de NUNCA deverem estar versionados.
SENSITIVE_FILENAMES = re.compile(
    r"(?i)(^\.env(\.|$)|serviceaccount.*\.json$|firebase-adminsdk.*\.json$|\.pem$|\.p12$|id_rsa$|\.pfx$)"
)

# Diretórios/arquivos que ignoramos.
SKIP_DIRS = {".git", "node_modules", ".next", "dist", "build", ".vercel",
             "coverage", "out", ".turbo", "__pycache__", ".cache"}
SKIP_EXT = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".ico", ".svg", ".pdf",
            ".woff", ".woff2", ".ttf", ".otf", ".mp4", ".mp3", ".zip", ".lock"}
MAX_BYTES = 2_000_000  # ignora arquivos > ~2MB (provavelmente binário/build)

COLOR = {"CRITICO": "\033[91m", "ALTO": "\033[93m", "MEDIO": "\033[96m", "RESET": "\033[0m"}


def iter_files(root: str):
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            ext = os.path.splitext(name)[1].lower()
            if ext in SKIP_EXT:
                continue
            full = os.path.join(dirpath, name)
            try:
                if os.path.getsize(full) > MAX_BYTES:
                    continue
            except OSError:
                continue
            yield full, name


def scan_file(full: str, name: str):
    findings = []
    rel = full

    # 1) Arquivo sensível versionado pelo nome.
    if SENSITIVE_FILENAMES.search(name):
        findings.append({
            "tipo": "arquivo-sensivel", "prioridade": "CRITICO", "arquivo": rel,
            "linha": 0, "detalhe": f"Arquivo possivelmente sensivel no repo: {name}",
            "trecho": name,
        })

    is_rules = name.endswith(".rules") or "rules" in name and name.endswith((".rules", ".json")) and "firestore" in name.lower()

    try:
        with open(full, "r", encoding="utf-8", errors="ignore") as f:
            lines = f.readlines()
    except (OSError, UnicodeError):
        return findings

    for i, line in enumerate(lines, start=1):
        # 2) Segredos.
        for label, rx, prio in SECRET_PATTERNS:
            m = rx.search(line)
            if m:
                snippet = m.group(0)
                if PLACEHOLDER.search(line) and label != "Segredo atras de NEXT_PUBLIC_":
                    continue  # provavelmente exemplo
                findings.append({
                    "tipo": "segredo", "prioridade": prio, "arquivo": rel,
                    "linha": i, "detalhe": label,
                    "trecho": (snippet[:40] + "...") if len(snippet) > 43 else snippet,
                })

        # 3) Regras abertas (em qualquer arquivo .rules).
        if name.endswith(".rules"):
            for label, rx, prio in OPEN_RULE_PATTERNS:
                if rx.search(line):
                    findings.append({
                        "tipo": "regra-aberta", "prioridade": prio, "arquivo": rel,
                        "linha": i, "detalhe": label, "trecho": line.strip()[:80],
                    })
    return findings


def main():
    parser = argparse.ArgumentParser(description="Bastiao - scan basico de seguranca")
    parser.add_argument("path", nargs="?", default=".", help="diretorio a escanear")
    parser.add_argument("--json", action="store_true", help="saida em JSON")
    args = parser.parse_args()

    root = os.path.abspath(args.path)
    all_findings = []
    files_scanned = 0
    for full, name in iter_files(root):
        files_scanned += 1
        all_findings.extend(scan_file(full, name))

    order = {"CRITICO": 0, "ALTO": 1, "MEDIO": 2}
    all_findings.sort(key=lambda f: (order.get(f["prioridade"], 9), f["arquivo"], f["linha"]))

    if args.json:
        print(json.dumps({"escaneados": files_scanned, "achados": all_findings},
                         ensure_ascii=False, indent=2))
        sys.exit(1 if all_findings else 0)

    print(f"\nBastiao - scan basico  |  {files_scanned} arquivos analisados em {root}\n")
    if not all_findings:
        print("  Nenhum achado obvio. (Isto NAO garante seguranca - rode a revisao completa.)\n")
        sys.exit(0)

    counts = {}
    for f in all_findings:
        counts[f["prioridade"]] = counts.get(f["prioridade"], 0) + 1

    for f in all_findings:
        c = COLOR.get(f["prioridade"], "")
        r = COLOR["RESET"]
        local = f["arquivo"] + (f":{f['linha']}" if f["linha"] else "")
        print(f"  {c}[{f['prioridade']}]{r} {f['detalhe']}")
        print(f"      {local}")
        print(f"      > {f['trecho']}\n")

    resumo = "  ".join(f"{COLOR.get(k,'')}{k}: {v}{COLOR['RESET']}"
                       for k, v in sorted(counts.items(), key=lambda kv: order.get(kv[0], 9)))
    print(f"Resumo: {resumo}")
    print("\nProximo passo: confirme cada achado e corrija do CRITICO ao MEDIO.")
    print("Consulte reference/vulnerabilidades.md e reference/padroes-seguros.md.")
    print("A decisao e sua.\n")
    sys.exit(1)


if __name__ == "__main__":
    main()
