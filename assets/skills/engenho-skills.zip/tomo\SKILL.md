---
name: tomo
description: Cria e-books e guias em HTML no padrão editorial do Rodrigo (capa escura, miolo claro, prompts copiáveis, plano de N dias, anatomia P.R.O.M.P.T.E.R.) — prontos para ler, imprimir em A4 e entregar como material gratuito. Use ao criar um e-book, guia prático, material rico ou companion de palestra.
---

# Tomo — criador de e-books

Produz e-books/guias em **HTML único** no estilo dos materiais do Rodrigo (ex.: "IA Sem Medo", "Vibecoding para CEOs"): tema editorial claro para leitura/impressão, **capa escura premium**, prompts clicáveis que copiam ao toque, e componentes prontos (cards, tabelas, caixas, plano de dias, biblioteca de prompts).

## Quando usar
- Criar um e-book, guia prático ou material rico gratuito (isca de captura).
- Companion de palestra/curso.
- Transformar um conteúdo (post, aula, método) em um material entregável e bonito.

## Bases que ela usa
- **Cânone / ui-ux-pro-max** — para decisões de design/legibilidade.
- **Forja** — para construir os prompts da biblioteca pelo método P.R.O.M.P.T.E.R.
- **Alavanca** — para o CTA final converter (oferta clara, sem hype).
- **`templates/ebook-template.html`** — o esqueleto fiel com todo o CSS da marca.

## Procedimento
1. **Defina o esqueleto de conteúdo** (ver `reference/estrutura.md`): título + promessa, público, sumário (5–10 capítulos), e quais blocos entram (método, biblioteca de prompts, plano de N dias, CTA).
2. **Escreva na voz da casa:** PT-BR, direta, didática, sem hype, "a decisão é sua". Especificidade > adjetivo. Use a metáfora certa (ex.: "IA é um estagiário brilhante que você confere").
3. **Monte o HTML** a partir de `templates/ebook-template.html`, preenchendo os `{{...}}` e repetindo os blocos (capítulo, `.prompt`, `.day`) conforme o conteúdo. NÃO altere o CSS — ele é a identidade.
4. **Prompts** (se houver biblioteca): construa cada um com **Forja**, marque o papel em `<b>` e as lacunas a ajustar com `<span class="ph">[...]</span>`. Eles ficam copiáveis no clique (JS já incluso).
5. **Capa e rodapés:** preencha a capa (kicker, título em 2 linhas, subtítulo-promessa, tags) e o número de página nos `.foot`.
6. **Entregue** o arquivo `.html` (salvar em `public/biblioteca/` no site, e ligar em `src/lib/materials.ts`).

## Regras de qualidade
- Um material = uma promessa clara. Não tente ensinar tudo.
- Tudo que for "100 prompts" precisa ser prompt **de verdade**, pronto pra colar.
- Imprimível: o template já cuida de quebras de página A4 (`@media print`). Não quebre isso.
- Capa escura, miolo claro — o contraste é proposital (a capa "vende", o miolo "lê").

## Princípio
Material gratuito é prova de generosidade e competência. Entregue algo que a pessoa **guardaria mesmo se fosse pago**.
