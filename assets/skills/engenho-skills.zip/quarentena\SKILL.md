---
name: quarentena
description: Audita as dependências do projeto (versões soltas, pacotes vulneráveis, risco de supply-chain) e ajuda a avaliar um pacote novo antes de instalar. Use ao revisar dependências, antes de instalar algo novo, ou ao endurecer a segurança.
---

# Quarentena

Auditor de dependências e defesa de supply-chain para projetos Node/Next.js com npm.

## Visão geral: o vetor que ninguém olha

Você revisa o seu código. Revisa o PR do colega. Mas quando roda `npm install`, está executando código de centenas de pessoas que você nunca viu, em versões que você não escolheu uma a uma, com scripts que rodam na sua máquina sem você ler uma linha.

Um projeto Next.js típico tem 5 a 15 dependências diretas no `package.json` e **mil ou mais** dependências transitivas no `node_modules`. Cada uma é um ponto de entrada. O código que você escreveu é a menor parte do que roda em produção.

Supply-chain é o ataque que não precisa furar a sua aplicação: ele entra pela porta da frente, junto com um update que você mesmo pediu. Não é teoria. O caso **Axios 2026** (conta de mantenedor invadida, código malicioso injetado num release oficial e publicado no npm como atualização legítima) mostrou que "biblioteca popular e confiável" não é garantia nenhuma — popularidade é justamente o que torna o alvo atraente.

Esta skill trata dependência como o que ela é: **código de terceiros que você está prestes a executar com os seus privilégios.** A regra-base é desconfiança: todo pacote novo entra em quarentena antes de ser aprovado, e o que já está instalado é auditado periodicamente.

## Quando usar

- **Revisão periódica** das dependências de um projeto (mensal, ou antes de um deploy importante).
- **Antes de instalar um pacote novo** — especialmente um que você não conhece, achou num tutorial, ou que a IA sugeriu.
- **Ao endurecer a segurança** de um projeto (hardening), preparar para auditoria ou compliance.
- **Depois de um incidente** ou alerta público (CVE, aviso de pacote comprometido) — para checar se você está exposto.
- **Ao herdar um projeto** que você não escreveu e precisa entender o que está rodando ali dentro.

## Procedimento

Siga na ordem. Os passos 1-3 e 5 servem para auditar o que já existe; o passo 4 é para avaliar algo novo.

### 1. Ler o `package.json` e o lockfile

Abra o `package.json` e leia as seções `dependencies`, `devDependencies`, `peerDependencies` e — importante — `scripts`. Confirme se existe lockfile (`package-lock.json` para npm; `pnpm-lock.yaml` / `yarn.lock` se for outro gerenciador).

O que observar:

- **Não tem lockfile?** Sinal de alerta sério. Sem lockfile, cada `install` pode trazer versões diferentes e não há registro do que está realmente instalado. Recomende gerar e commitar.
- **`scripts` com `postinstall` / `preinstall` / `install`** apontando para pacotes de terceiros — esses rodam código automaticamente no install. Anote para investigar.
- **Quantidade e propósito** de cada dependência. Tem coisa que poderia ser uma função de 10 linhas? Tem pacote que ninguém lembra por que está ali?

### 2. Sinalizar versões soltas em libs críticas

No `package.json`, cada versão tem um prefixo que define o que o npm pode instalar:

| Notação | Significado | Risco |
|---|---|---|
| `1.2.3` | exata — só essa versão | baixo |
| `~1.2.3` | permite patches: `1.2.x` | médio |
| `^1.2.3` | permite minors: `1.x.x` | **alto** |
| `*` / `latest` | qualquer versão | **crítico** |

O problema do `^` e `~`: um update malicioso publicado como `1.2.4` ou `1.3.0` entra automaticamente no próximo `install` de quem usa `^1.2.3`. Foi exatamente esse o vetor de propagação no caso Axios — quem tinha range aberto puxou o release comprometido sem pedir.

**Regra:** o lockfile protege contra isso *desde que* seja respeitado (`npm ci`, não `npm install`). Mas em libs críticas — qualquer coisa que toca rede, autenticação, crypto, build, ou roda no servidor — prefira **versão exata** no `package.json` também, como segunda camada. Sinalize cada `^`/`~`/`*` em dependência crítica e recomende travar.

### 3. Rodar e interpretar o `npm audit`

Rode `npm audit` (detalhes de comandos e leitura de saída em `scripts/auditar.md`).

Ao interpretar:

- **Severidade** (`critical` > `high` > `moderate` > `low`) indica gravidade, não urgência. Um `critical` numa dependência de dev que só roda no seu build local é menos urgente que um `high` numa lib que roda no servidor exposto.
- **Olhe o caminho** (`node_modules/a > node_modules/b`): a vulnerabilidade pode estar numa dependência transitiva que você nem instalou diretamente.
- **`npm audit fix`** resolve o que dá com bumps compatíveis. **Não rode `npm audit fix --force` no automático** — ele sobe major versions e pode quebrar o projeto. Avalie antes.
- Audit cobre vulnerabilidades *conhecidas e catalogadas*. Não detecta um pacote recém-comprometido cujo CVE ainda não saiu. Por isso ele é necessário, mas não suficiente — o passo 4 cobre o resto.

### 4. Avaliar um pacote NOVO antes de instalar (quarentena)

Antes de `npm install <pacote>`, passe pelo checklist de `reference/avaliar-pacote.md`. Os sinais de reputação a checar:

- **Idade** — pacote criado há poucos dias/semanas é suspeito por padrão.
- **Downloads** — volume semanal coerente com a popularidade alegada. Número baixo em algo "famoso" pode ser typosquatting.
- **Mantenedores** — quantos são, são reconhecíveis, o pacote depende de uma única pessoa?
- **Repositório** — existe link para o repo? O repo é real, ativo, bate com o que o pacote diz fazer? Sem repositório público é red flag.
- **Última atualização** — abandonado (anos sem update) ou suspeito (publicado agora, do nada, depois de muito tempo parado — pode ser conta comprometida).
- **Nome** — confira caractere por caractere contra o pacote que você realmente quer (ver typosquatting em `reference/riscos-supply-chain.md`).

Decisão: **aprovar, reprovar ou buscar alternativa.** Na dúvida, reprova. Um pacote que você não consegue justificar não entra.

### 5. Travar versões e usar lockfile

Fechamento da auditoria, recomende:

1. **Commitar o lockfile.** Ele é parte do código, não artefato descartável.
2. **Usar `npm ci` em CI/CD e deploy** em vez de `npm install` — `ci` instala exatamente o que está no lockfile e falha se o `package.json` divergir; `install` pode atualizar dentro dos ranges.
3. **Travar versão exata** das libs críticas no `package.json` (tirar `^`/`~`).
4. **Revisar o lockfile no PR** quando ele muda — uma mudança de lockfile que não corresponde a um pacote que você adicionou de propósito merece olhar.
5. **Reauditar periodicamente** e sempre que um alerta público sair.

## Arquivos de apoio

- `reference/riscos-supply-chain.md` — os tipos de ataque (typosquatting, conta comprometida, transitiva, postinstall, abandono), o caso Axios em detalhe, e como mitigar cada um.
- `reference/avaliar-pacote.md` — checklist objetivo de aprovar/reprovar um pacote novo.
- `scripts/auditar.md` — guia dos comandos (`npm audit`, `npm outdated`, `npm ls`, checagem de lockfile) e como ler a saída.
