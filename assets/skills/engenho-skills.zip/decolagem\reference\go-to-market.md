# Go-to-Market: do MVP ao primeiro pagante

Go-to-market (GTM) é a sua resposta para: **quem é o cliente, qual a oferta, por qual canal você chega nele, e como ele vira pagante.** Esta é a ponte entre "construí algo" e "tenho clientes".

A maior causa de morte de produto feito com IA não é o produto ser ruim. É lançar para "todo mundo", sem nicho, sem oferta clara, e nunca conseguir o primeiro cliente de verdade. Esta referência existe para evitar isso.

> Regra que atravessa tudo: **valide o problema antes de construir mais.** E **conquiste o primeiro cliente na unha antes de pensar em escala.** (Ver Regras de Prioridade no SKILL.md.)

---

## Etapa 0 — Validar o problema (antes de construir mais)

Você pode já ter um produto. Mesmo assim, pare e pergunte: **isso resolve um problema real, doloroso, de alguém específico, que pagaria para resolver?**

Validação NÃO é:
- Amigos dizendo "que legal".
- Curtidas, seguidores, gente achando bonito.
- Pessoas dizendo "eu usaria" (todo mundo diz; quase ninguém faz).

Validação É:
- Alguém descrever o problema com as próprias palavras, com frustração real.
- Alguém já estar gastando tempo, dinheiro ou esforço hoje tentando resolver isso (gambiarra, planilha, contratando alguém).
- Alguém perguntar "quando posso começar a usar/pagar?".
- Alguém **pagar** — o sinal definitivo.

**Como validar barato e rápido:**
1. Liste 10-20 pessoas que têm o problema. Pessoas reais, com nome.
2. Converse com elas. Pergunte sobre o problema, não sobre seu produto. *"Como você resolve isso hoje? Quanto isso te custa/incomoda? O que você já tentou?"*
3. Ouça mais do que fala. Não venda; investigue. Você está procurando a dor, não validação do seu ego.
4. Procure o padrão: a mesma dor aparecendo em várias conversas. Esse padrão é o seu produto.

Se ninguém demonstra dor real, **nenhum recurso novo vai salvar.** Volte ao problema antes de escrever mais código.

---

## Etapa 1 — Escolher o nicho (estreite, estreite, estreite)

"Serve para qualquer pessoa" = não serve para ninguém em particular = você não consegue falar com ninguém de forma convincente.

Por que nicho vence no começo:
- **Mensagem afiada:** você fala a língua exata daquela pessoa. "Para donos de barbearia que perdem horário no WhatsApp" vende mais que "agendamento para empresas".
- **Mais fácil achar os clientes:** um nicho específico se reúne nos mesmos lugares (grupos, eventos, perfis). "Todo mundo" não tem endereço.
- **Menos concorrência direta:** você vira a melhor opção *para aquele nicho*, mesmo que existam gigantes genéricos.
- **Preço melhor:** solução específica para uma dor específica vale mais que solução genérica.

**Como escolher o nicho:**
- Onde a dor é **mais aguda** e mais urgente?
- Onde você tem **acesso** (conhece pessoas, frequenta o meio, entende a linguagem)?
- Quem tem o problema **e** dinheiro para pagar?
- Onde você consegue ser **claramente o melhor**, não mais um?

Você pode (e vai) expandir depois. Começar estreito é estratégia, não limitação. Domine um nicho, depois o vizinho.

---

## Etapa 2 — Montar a oferta

Oferta não é o produto. **Oferta é o produto + a promessa + o preço + o que reduz o medo de comprar**, embrulhados de um jeito que faz a pessoa certa dizer sim.

Componentes de uma oferta clara:
- **Para quem é** (o nicho, explícito).
- **Qual problema resolve** (na linguagem do cliente, a dor, não a funcionalidade).
- **Qual o resultado** que ele leva (o "depois": como a vida dele fica melhor).
- **Por quanto** (o preço, com a âncora certa — ver `monetizacao-e-preco.md`).
- **Por que confiar / o que reduz o risco** (garantia, teste, prova de que funciona, depoimento).

Teste da oferta boa: a pessoa do nicho lê/ouve e pensa *"isso é pra mim, e faz sentido"* — sem você precisar explicar três vezes. Se você precisa de muita explicação, a oferta ainda não está clara.

Foque no **resultado**, não nos recursos. O cliente não quer seu produto; quer o que o produto faz por ele. "Agenda cheia sem você mexer no WhatsApp" vende; "sistema com integração de calendário e notificações" não.

---

## Etapa 3 — Conseguir os primeiros clientes (na unha)

Os primeiros 5-10 clientes **não** vêm de anúncio, automação ou funil. Vêm de você, falando com pessoas, um por um. Isso é certo e esperado. "Fazer coisas que não escalam" é a fase, não um erro.

**Por que manual primeiro:**
- Cada conversa te ensina por que compram e por que não compram.
- Você ajusta oferta e preço com base em gente real.
- Você consegue dizer sim a pedidos especiais (e descobrir o que importa) que uma máquina não permitiria.

**Onde achar os primeiros:**
- Sua própria rede e a rede dela (quem você conhece que tem o problema, e quem eles conhecem).
- Os lugares onde o nicho **já se reúne**: grupos, comunidades, fóruns, eventos. Não para spammar — para participar, ajudar e, no momento certo, oferecer.
- Contato direto e personalizado com pessoas específicas do nicho. Mensagem que mostra que você entende a dor dela, não um copia-e-cola.

**Como conduzir:**
- Ofereça resolver o problema, não "usar meu produto". Foque na dor dela.
- Topa fazer junto, na mão, entregar pessoalmente os primeiros. Isso acelera o aprendizado.
- **Cobre.** Mesmo que seja um preço de pioneiro, cobre algo. Cliente que paga te dá verdade; cliente grátis te dá educação cortês.
- Peça feedback honesto e, quando entregar valor, peça indicação e depoimento.

Meta desta etapa: chegar a um punhado de clientes pagantes satisfeitos e entender **o padrão**: que tipo de pessoa compra, por qual motivo, com qual mensagem.

---

## Etapa 4 — Achar o canal repetível

Só **depois** de ter os primeiros clientes você procura o caminho que se repete: *"de onde, de forma previsível, vêm clientes parecidos com os que já comprei?"*

- Escolha **um canal** para focar de cada vez. Espalhar-se por dez canais no início dilui tudo e você não aprende nenhum. Domine um antes de abrir o segundo.
- O melhor canal é onde **o seu nicho específico** está e presta atenção — não onde "tem mais gente".
- Tipos comuns de canal: indicação/boca a boca, conteúdo (você aparecendo onde o nicho consome), comunidades, parcerias, contato direto, e — só quando há caixa e oferta validada — anúncios pagos.
- Sinal de canal repetível: você consegue prever, com alguma confiança, "se eu fizer X, entram aproximadamente Y clientes".

Quando você tem **oferta validada + canal repetível**, aí sim faz sentido falar de escala — e é hora de chamar a execução de marketing (skill Alavanca) para otimizar funil, página e campanhas.

---

## O caminho completo (resumo)

1. **Valide o problema** — gente real, dor real, disposição a pagar. Não recursos.
2. **Estreite o nicho** — específico vence genérico.
3. **Monte a oferta** — para quem, qual dor, qual resultado, quanto, por que confiar.
4. **Primeiros clientes na unha** — manual, um por um, cobrando, aprendendo.
5. **Ache o canal repetível** — um canal, onde o nicho está, previsível.
6. **Só então: escala** (Alavanca entra aqui).

Pular etapa é a forma número um de desperdiçar meses. Se você se pegar querendo rodar anúncio antes do primeiro cliente, ou falar com "todo mundo" antes de escolher um nicho — pare. Volte uma etapa. A pressa aqui custa caro. A decisão é sua, mas a ordem importa.
