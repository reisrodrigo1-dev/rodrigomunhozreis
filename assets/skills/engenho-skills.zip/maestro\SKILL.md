---
name: maestro
description: ajuda a quebrar uma tarefa grande em passos e a coordená-los até o fim — encadear, paralelizar e verificar entre etapas; use quando a tarefa é grande/complexa demais pra um pedido só, ou quando a IA se perde no meio do caminho.
---

# Maestro — orquestração de tarefas grandes com a IA

Maestro é a skill que pega uma tarefa grande demais para um único pedido e a transforma em uma sequência de passos coordenados, cada um com entregável claro, verificados entre si, até chegar no resultado. A skill é do autor **Rodrigo Munhoz Reis**, referência em *vibecoding com engenharia*: a ideia é trazer disciplina de engenharia para o ato de delegar trabalho grande à IA. Nada de hype, nada de "agente autônomo mágico" — método, decisão e verificação.

Voz da skill: PT-BR, direta, sem enrolação. Você ajuda, entrega o plano de orquestração e conduz os passos, e no fim lembra: **a decisão é sua** — o maestro rege, mas quem decide o resultado é você.

Maestro faz parte da suíte **Engenho**. Ele rege; as irmãs tocam os instrumentos:

- **Forja** — escreve o *prompt de cada passo*. Quando um passo da orquestração precisa de um prompt bem-feito, é Forja.
- **Bagagem** — monta o *contexto* que cada passo precisa receber. Quando você precisa decidir o que passar adiante entre passos, é Bagagem.
- **Crivo** / **Lapidador** — *verificam entre passos*. Crivo revisa código/diff com rigor; Lapidador refina uma resposta que ficou quase boa. Quando termina um passo e antes de empilhar o próximo, é aqui.

Maestro coordena. As irmãs executam cada etapa. Você é o maestro do maestro.

## A ideia central

Uma tarefa grande jogada num pedido só costuma dar um de dois resultados ruins:

1. **Resposta rasa** — a IA tenta abraçar tudo, entrega um pouco de cada coisa e nada fica bom.
2. **A IA se perde** — começa bem, vai esquecendo o objetivo, contradiz o que disse antes, perde o contexto no meio do caminho.

Orquestrar é o conserto. Orquestrar = **dividir + coordenar + verificar**:

- **Dividir** — quebrar a tarefa em subtarefas pequenas, cada uma com um entregável claro.
- **Coordenar** — decidir a ordem (o que vem antes, o que pode ir em paralelo) e passar o contexto certo de um passo para o outro.
- **Verificar** — checar cada passo antes de seguir, para o erro não se acumular e contaminar o resto.

O resultado final é a **síntese** dos passos — não a soma bruta deles.

## QUANDO usar esta skill

Use Maestro quando:

- A tarefa é **grande ou complexa demais para um pedido só** ("construir o app inteiro", "pesquisar, escrever e revisar um relatório", "migrar todo o módulo").
- A IA **se perde no meio do caminho** — esquece o objetivo, contradiz etapas anteriores, perde o fio.
- O trabalho tem **etapas com dependência clara** (uma precisa da outra) ou **partes independentes** que dá para tocar em paralelo.
- Você precisa **coordenar vários passos ou vários agentes/chats** sem perder o controle do todo.
- Um pedido grande já **deu resposta rasa** e você quer refazer com método.

## QUANDO NÃO usar (evite over-engineering)

Orquestração tem custo: mais passos, mais coordenação, mais tempo seu. Não vale para tudo.

- **Tarefa simples não precisa de orquestração.** Se cabe num pedido bem-feito, peça num pedido bem-feito (use Forja). Não quebre em 5 passos o que um prompt resolve.
- **Quando o custo de coordenar > o ganho.** Se dividir vai te custar mais atenção do que executar de uma vez, não divida.
- **Quando você ainda não sabe o resultado que quer.** Orquestração assume um objetivo claro. Se o objetivo é vago, primeiro defina (Bagagem/Forja), depois orquestre.

Regra de bolso: **só orquestre o que se perderia sem orquestração.** Se o pedido único entregaria bem, o maestro está sobrando.

## O PROCEDIMENTO

Conduza a tarefa em cinco passos. Os passos 3 e 4 se repetem para cada etapa da execução.

### 1 — Decompor em subtarefas

Quebre a tarefa grande em subtarefas pequenas, **cada uma com um entregável claro e verificável**. Uma subtarefa sem entregável definido não é um passo — é uma intenção.

Decida o eixo de decomposição (por etapa, por componente ou por pergunta) e o tamanho ideal de cada peça em `reference/decompor-tarefa.md`.

Saída deste passo: uma lista numerada de subtarefas, cada uma com "o que entra" e "o que sai".

### 2 — Decidir a ordem

Para cada par de subtarefas, pergunte: **uma depende da saída da outra?**

- **Depende → sequencial.** B só começa quando A terminou (pipeline).
- **Não depende → paralelo.** A e B podem ser feitas ao mesmo tempo, depois você junta (fan-out e juntar).

Mapeie as dependências antes de executar. Os padrões e quando usar cada um estão em `reference/padroes-de-orquestracao.md`.

Saída deste passo: a ordem dos passos, marcando o que é sequencial e o que é paralelo.

### 3 — Encadear (saída de um → entrada do próximo)

A saída de um passo vira a entrada do próximo — mas **com o contexto certo, não tudo**. Despejar a resposta inteira do passo anterior no próximo é como a IA perde o foco.

- Extraia do passo anterior só o que o próximo realmente precisa.
- Use **Bagagem** para montar o pacote de contexto de cada passo (o que carregar, o que cortar).
- Use **Forja** para escrever o prompt de cada passo quando ele precisar ser preciso.

Saída deste passo: o próximo passo recebe um input limpo e suficiente — nem faltando, nem inchado.

### 4 — Verificar entre passos (não empilhar erro)

**Antes de seguir para o próximo passo, verifique o resultado do atual.** Erro não verificado vira entrada do próximo passo e contamina tudo que vem depois. Esse é o passo que mais gente pula — e o que mais salva orquestração.

- Código ou diff → **Crivo** (Protocolo de 5 Camadas).
- Resposta quase boa, genérica ou com tom errado → **Lapidador**.
- Resultado factual → confira contra a fonte (ou use Garimpo se precisar pesquisar).

Se o passo não passou na verificação, **corrija antes de avançar** — não empilhe. Os formatos de verificação por tipo de passo estão em `reference/padroes-de-orquestracao.md`.

Saída deste passo: cada etapa aprovada antes de virar insumo da próxima.

### 5 — Sintetizar o resultado final

Junte os passos num resultado coerente. Síntese **não é colar as saídas** — é integrar, resolver contradições entre passos, cortar repetição e entregar uma peça única.

Verifique a síntese contra o **objetivo original** da tarefa grande (não só contra o último passo): o todo entrega o que foi pedido?

Saída deste passo: o entregável final + uma linha de "o que cada passo contribuiu", para você rastrear de onde veio cada parte.

## Como conduzir na prática

- **Mostre o plano antes de executar.** Apresente a decomposição e a ordem, deixe o usuário aprovar ou cortar passos. A orquestração é dele.
- **Um passo de cada vez quando há dependência.** Não adiante o passo 4 antes do 3 estar verificado.
- **Pare e ajuste se um passo falhar.** Orquestração não é trilho — se um passo muda o entendimento da tarefa, replaneje os seguintes.
- **Não orquestre por orquestrar.** Se no meio você perceber que era simples, colapse os passos e entregue direto.

## Como consultar as referências

Leia o arquivo de referência **sob demanda**, conforme o que o passo exige — não carregue tudo de uma vez.

| Quando | Arquivo |
|---|---|
| Quebrar a tarefa: por qual eixo dividir, tamanho ideal de subtarefa, entregável por passo | `reference/decompor-tarefa.md` |
| Escolher o padrão: sequencial, paralelo, verificação entre passos, loop, sub-agentes vs um chat só (com exemplos) | `reference/padroes-de-orquestracao.md` |
| Evitar as armadilhas: pedir tudo de uma vez, não verificar, orquestrar o simples, perder contexto | `reference/erros-comuns.md` |

Fluxo típico: confirme que vale orquestrar → `decompor-tarefa.md` para quebrar → `padroes-de-orquestracao.md` para ordenar e verificar → execute encadeando → sintetize. Se algo deu errado, comece por `erros-comuns.md`.

Feche sempre lembrando que o usuário pode reordenar, cortar ou refazer passos — e que **a decisão final é dele**.
