# Backup e restauração

Backup é o trabalho que se faz com o sistema saudável pra que o incidente de perda
de dado tenha resposta pronta. **Backup que ninguém testou não é backup, é
esperança.** Este guia cobre o que copiar, com que regra, e como provar que o
restore funciona.

## Dois números pra decidir antes de tudo: RPO e RTO

Defina estes dois alvos **antes** de configurar qualquer coisa — eles dizem com
que frequência fazer backup e quão pronto o restore precisa estar.

- **RPO (Recovery Point Objective) — quanto dado você aceita perder.** Se o RPO é
  "24h", você precisa de backup pelo menos diário; tudo entre o último backup e o
  incidente se perde. Produto transacional pede RPO menor (horas); um blog tolera
  um dia.
- **RTO (Recovery Time Objective) — em quanto tempo você precisa estar de pé.** Se
  o RTO é "2h", o restore precisa estar testado e cronometrado pra caber nisso. RTO
  só é real se você já mediu quanto o restore demora num exercício.

Escreva os dois. "RPO 24h, RTO 4h" é uma decisão de engenharia; "a gente tem
backup" não é.

## O que copiar (e como, na stack Next.js + Firebase + Vercel)

### 1. Firestore — export agendado

O dado vivo do app. Não confie em export manual quando lembrar; **agende.**

- Use o **export agendado do Firestore** (managed export) para um bucket do **Cloud
  Storage**. Dá pra agendar via Cloud Scheduler + Cloud Function ou pelo recurso de
  backup gerenciado do Firestore.
- Comando base do export manual (pra entender e pra rodar sob demanda):
  ```bash
  gcloud firestore export gs://SEU_BUCKET_DE_BACKUP/$(date +%Y-%m-%d)
  ```
- **Retenção em camadas:** ex. diário mantido por 30 dias, mensal por 12 meses.
  Configure regra de ciclo de vida (lifecycle) no bucket pra apagar o que expira —
  senão a conta de Storage cresce sem parar.
- **Bucket separado e protegido.** O backup não pode morar no mesmo lugar que pode
  ser apagado pelo mesmo incidente. Bucket dedicado, acesso restrito, de preferência
  com versionamento de objeto ligado.

### 2. Código — Git, fora da sua máquina

O código é backup **se** estiver versionado e remoto.

- Repositório **privado** no GitHub (a base já vem assim com o **Canteiro**).
- **Proteja a branch principal** (branch protection): sem force-push, sem delete,
  PR obrigatório. Isso evita que um erro apague o histórico.
- Use **tags/releases** para marcar versões estáveis — é a elas que você volta num
  rollback de código.
- Lembre: o repositório **não guarda os segredos** (e não deve). Eles têm backup
  próprio — veja abaixo.

### 3. Segredos e variáveis de ambiente — cofre

As env vars e chaves não estão no Git. Então, se a conta da Vercel cair ou alguém
apagar as variáveis, elas somem. Backup próprio:

- Guarde uma cópia das variáveis num **gerenciador de segredos / cofre de senhas**
  (1Password, Bitwarden, Google Secret Manager, etc.).
- **Nunca** no Git, nunca num doc compartilhado em texto puro, nunca num print.
- Documente **onde cada chave foi gerada** (qual provedor, qual conta) — pra
  rotacionar rápido num incidente você precisa saber onde ir. (Isso conversa com o
  passo de remediação do Resgate.)
- Inventário mínimo: nome da variável, pra que serve, onde é gerada/rotacionada,
  quem tem acesso.

### 4. Configuração de infra

O que não é código nem dado, mas reconstrói o sistema: regras do Firebase
(`firestore.rules`, `storage.rules` — versionadas no Git, com o **Cofre**),
`firebase.json`, configuração de domínio/DNS, e os passos de setup do projeto.
Documente o suficiente pra recriar o ambiente do zero.

## Regra 3-2-1

A regra clássica, traduzida pro seu mundo:

- **3 cópias** dos dados — a de produção conta como uma.
- **2 mídias/lugares diferentes** — não adianta três cópias no mesmo bucket que um
  comando apaga junto.
- **1 cópia offsite** — fora do site/provedor principal. Se o projeto inteiro do
  Firebase cair ou for comprometido, essa cópia sobrevive.

Aplicado: **(1)** dado em produção no Firestore + **(2)** export agendado num bucket
de Storage dedicado + **(3)** uma cópia periódica em **outra conta/provedor**
(download do export pra outro storage, outra conta Google, ou armazenamento frio).

## Testar o restore — o passo que ninguém faz e todo mundo precisa

Um backup nunca restaurado tem chance real de estar corrompido, incompleto, ou em
formato que você não sabe reimportar. Descobrir isso no incidente é o pior momento.
**Agende um exercício de restore** (trimestral, no mínimo):

1. **Restaure pra um ambiente ISOLADO** — outro projeto Firebase de teste, ou uma
   coleção temporária. **Nunca** restaure por cima de produção como teste.
   ```bash
   gcloud firestore import gs://SEU_BUCKET_DE_BACKUP/AAAA-MM-DD --project=PROJETO_DE_TESTE
   ```
2. **Valide a integridade:** os documentos voltaram? As contagens batem? Os campos
   estão completos? Abra alguns registros e confira. Backup que importa mas vem com
   metade dos campos vazios não te salva.
3. **Cronometre.** Quanto tempo levou do "preciso restaurar" ao "está de pé e
   válido"? Esse número é o seu **RTO real.** Se ele é maior que o RTO que você
   prometeu, ou o backup melhora ou a promessa muda.
4. **Anote o procedimento** enquanto faz. No incidente real você não vai querer
   redescobrir os comandos sob pressão — vai querer seguir um passo a passo que já
   funcionou.
5. **Limpe o ambiente de teste** ao fim (e confira que não deixou dado pessoal
   exposto nele).

## Checklist de preparação

- [ ] RPO e RTO definidos e escritos.
- [ ] Export agendado do Firestore para bucket dedicado, com retenção.
- [ ] Bucket de backup com acesso restrito e versionamento ligado.
- [ ] Código em repo privado, branch principal protegida, releases marcadas.
- [ ] Segredos com cópia em cofre + inventário de onde cada um é gerado.
- [ ] Regras e config de infra versionadas/documentadas.
- [ ] Cópia offsite (3-2-1) configurada.
- [ ] Exercício de restore feito ao menos uma vez, RTO real medido e procedimento
      anotado.
- [ ] Próximo exercício de restore agendado.
