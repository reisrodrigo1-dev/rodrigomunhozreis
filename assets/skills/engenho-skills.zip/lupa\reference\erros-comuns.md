# Catálogo de erros comuns — o que significa e como consertar

Os bugs que mais aparecem em stack Next.js + Firebase + Vercel + JS no navegador. Para cada um: **a mensagem**, **o que significa**, **como confirmar** e **como consertar**. Use junto com `ler-o-erro.md`.

---

## 1. `TypeError: undefined is not a function` / `x is not a function`

**Significa:** você chamou algo como função, mas aquilo não é uma função (é `undefined`, ou outra coisa).

**Causas comuns:**
- Erro de digitação no nome do método (`.fitler` em vez de `.filter`).
- Import errado: importou default quando era nomeado, ou vice-versa.
- O objeto chegou `undefined`, então `objeto.metodo()` vira `undefined()`.
- Versão de biblioteca onde aquele método não existe (ou foi renomeado).

**Confirmar:** vá ao arquivo:linha do stack. Logue o objeto **antes** da chamada: `console.log(typeof objeto, objeto)`.

**Consertar:** corrija o nome/import; garanta que o objeto não é `undefined` antes de chamar (e descubra **por que** estava undefined — não só blinde com `?.`).

---

## 2. `Cannot read properties of undefined (reading 'X')`

**Significa:** você tentou ler `.X` de algo que era `undefined` (ou `null`).

**Causa clássica:** dado assíncrono que ainda não chegou. No primeiro render `user` é `undefined`; você acessa `user.nome` → estoura. Ou a API retornou um formato diferente do que você esperava.

**Confirmar:** logue o objeto-pai antes do acesso. Olhe na aba Network se a resposta veio no formato que você assume.

**Consertar:**
- Trate o estado de carregamento: `if (!user) return <Loading/>` antes de usar `user.nome`.
- Use optional chaining **com intenção**: `user?.nome` — mas só depois de entender por que veio vazio.
- Garanta o `await` (veja item "await esquecido").

---

## 3. Hydration mismatch (Next.js)

**Mensagem:** `Hydration failed because the initial UI does not match what was rendered on the server.`

**Significa:** o HTML do servidor não bateu com o primeiro render do cliente.

**Causas e conserto:** detalhado em `ler-o-erro.md` (seção SSR). Resumo: nada de `Date.now()`, `Math.random()`, `window`, `localStorage` fora do `useEffect`; corrija HTML mal aninhado; teste em aba anônima pra descartar extensão.

---

## 4. CORS — `blocked by CORS policy`

**Mensagem:** `Access to fetch at 'https://api.exemplo.com' from origin 'https://meuapp.com' has been blocked by CORS policy: No 'Access-Control-Allow-Origin' header is present`

**Significa:** o navegador bloqueou a resposta porque o **servidor** não autorizou seu domínio a ler aquela API. CORS é uma proteção do navegador; quem tem que liberar é o **servidor da API**, não o frontend.

**Confirmar:** na aba Network a requisição aparece (às vezes como `(failed)` ou com erro de CORS), e o Console mostra a mensagem acima.

**Consertar:**
- **Se a API é sua** (rota do Next, função no Firebase/servidor): adicione os headers CORS na resposta — `Access-Control-Allow-Origin` com seu domínio (ou `*` em dev), e responda ao **preflight** `OPTIONS`.
- **Se a API é de terceiros:** você não controla o CORS dela. Chame-a pelo **seu backend** (uma rota/proxy server-side) e o frontend fala só com seu backend. Servidor não sofre CORS.
- **Não** é resolvido com extensão "disable CORS" — isso só mascara no seu navegador; quebra pra todo mundo.

---

## 5. Firebase `permission-denied` (401/403)

**Mensagem:** `FirebaseError: Missing or insufficient permissions.` (Firestore) ou status **401/403** na Network.

**Significa:**
- **401:** ninguém está autenticado (sem token, ou token expirado/inválido).
- **403 / permission-denied:** o usuário está logado, mas as **Security Rules** não permitem ele ler/escrever aquele documento.

**Confirmar:** veja se há usuário logado (`auth.currentUser`). Na aba Network, a Response do Firestore costuma dizer `PERMISSION_DENIED`. Abra suas **Firestore Rules** e leia a condição da coleção em questão.

**Consertar:**
- **Não autenticado:** garanta o login antes de acessar dados protegidos; aguarde o estado de auth resolver (`onAuthStateChanged`) antes de consultar — consultar antes do auth carregar é causa frequente de 401 falso.
- **Sem permissão:** ajuste as **Security Rules** pra permitir o acesso legítimo (ex.: `allow read: if request.auth.uid == resource.data.ownerId`). **Nunca** "conserte" abrindo tudo (`allow read, write: if true`) — isso vaza seu banco pra internet inteira.
- Lembre: as Rules são a sua segurança de verdade. Trate-as como código, não como obstáculo.

---

## 6. 404 de chunk / "Loading chunk failed" (deploy)

**Mensagem:** `ChunkLoadError: Loading chunk N failed` ou 404 em um arquivo `.js` com hash (ex.: `/_next/static/chunks/4f3c.js`).

**Significa:** o usuário está com uma versão **antiga** da página aberta (HTML que aponta pra arquivos JS do build anterior), mas você fez um **novo deploy** e os arquivos antigos não existem mais no servidor. A página pede um chunk que sumiu → 404.

**Confirmar:** acontece logo depois de um deploy; some quando o usuário dá **hard refresh** (Ctrl+Shift+R). Na Network, um arquivo `_next/static/...` volta 404.

**Consertar:**
- No curto prazo: hard refresh resolve pra você testar.
- No produto: trate o `ChunkLoadError` recarregando a página automaticamente (um handler que dá `window.location.reload()` quando detecta esse erro).
- Na Vercel isso é minimizado porque ela mantém assets de deploys recentes, mas abas abertas há muito tempo ainda batem nisso. Não é bug no seu código — é cache de versão.

---

## 7. Variável de ambiente ausente (env)

**Sintomas:** `undefined` onde devia ter uma URL/chave; "API key not found"; funciona local mas quebra na Vercel; `process.env.MINHA_VAR` vem vazio.

**Significa:** a env var não está definida **naquele ambiente** (ou tem o prefixo errado).

**Confirmar:** logue `process.env.NOME_DA_VAR`. Se vier `undefined`, ela não chegou.

**Consertar (Next + Vercel):**
- **Local:** defina no arquivo `.env.local` (que **não** vai pro git). Reinicie o `npm run dev` depois de editar — env só carrega no boot.
- **Vercel:** adicione a variável em **Project → Settings → Environment Variables**, escolhendo os ambientes (Production/Preview/Development), e **faça redeploy** — variáveis novas não entram em deploys já feitos.
- **Frontend x backend:** no Next, só variáveis com prefixo **`NEXT_PUBLIC_`** ficam disponíveis no navegador. Sem o prefixo, a var existe só no servidor. Se você lê uma chave no client e ela vem `undefined`, provavelmente falta o `NEXT_PUBLIC_`.
- **Segurança:** chaves secretas (service account, API keys privadas) **não** levam `NEXT_PUBLIC_` — elas não podem ir pro navegador. Use-as só server-side.

---

## 8. `await` esquecido (Promise não resolvida)

**Sintomas:** o dado chega "vazio" ou `undefined` mesmo a API funcionando; você vê `Promise { <pending> }` no log; ordem das coisas sai errada; `[object Promise]` na tela.

**Significa:** você chamou uma função assíncrona mas **não esperou** ela terminar — pegou a Promise em vez do valor.

**Confirmar:** logue o resultado. Se aparecer `Promise { <pending> }` em vez do dado, faltou `await`.

**Consertar:**
- Coloque `await` antes da chamada assíncrona (e marque a função externa como `async`): `const dados = await buscarDados()`.
- Ou trate a Promise com `.then(dados => ...)`.
- Cuidado com `array.map(async ...)`: isso devolve um array de Promises; use `await Promise.all(...)` pra esperar todas.
- `useEffect` não pode ser `async` direto — declare uma função async dentro dele e chame-a.

---

## 9. Bônus: erros que parecem misteriosos mas têm causa boba

- **"Funciona local, quebra em produção":** quase sempre é **env var faltando na Vercel**, diferença de **case** em nome de arquivo (Linux é case-sensitive, Windows/Mac não — `Header.jsx` ≠ `header.jsx`), ou código que usa `window` no servidor.
- **Tela branca, nada no Console:** veja se o erro estourou **durante o SSR** (olhe o terminal do `npm run dev` / os logs da função na Vercel, não só o navegador).
- **"Não acontece nada" ao clicar:** o handler não está ligado, uma condição barrou antes, ou um erro silencioso. Logue dentro do handler pra confirmar que ele roda.
- **Erro só no celular:** Safari/iOS é mais rígido; pode ser uma API JS não suportada ou um problema de viewport. Teste no DevTools com emulação mobile.
- **CORS "às vezes":** pode ser o preflight `OPTIONS` não tratado em métodos não-GET.

---

## Como usar este catálogo

1. Pegue a **mensagem literal** do Console/Network (passo 2 do método).
2. Procure por ela (ou por um trecho) aqui.
3. Siga "confirmar" antes de "consertar" — **não pule a confirmação**, senão você volta a chutar.
4. Aplique o **menor** conserto e **verifique** (passos 5 e 6 do método).
5. Não achou aqui? Monte o `templates/relatorio-de-bug.md` e leve pra IA com a evidência completa.
