---
name: decolagem
description: Inteligência de lançamento de negócio: ajuda a escolher modelo de negócio, monetização, preço e estratégia de go-to-market, com as métricas que importam. Use ao planejar como lançar, monetizar ou cobrar por um produto, definir preço, decidir entre assinatura ou pagamento único, conseguir os primeiros clientes ou entender quais números acompanhar em cada estágio.
---

# Decolagem

Inteligência de lançamento e negócio para quem construiu algo com IA e agora precisa **transformar em negócio de verdade**. Você fez o produto funcionar. A pergunta agora é outra: como isso vira receita, com qual modelo, por qual preço, vendido para quem e como.

Autor: Rodrigo Munhoz Reis — vibecoding com engenharia.

> Esta skill é INTELIGÊNCIA, não execução. Ela ajuda você a **decidir** a estratégia. A decisão final é sua, sempre. Aqui não tem fórmula mágica nem promessa de "fature 6 dígitos". Tem o raciocínio que separa um produto que vira negócio de um projeto bonito que ninguém paga.

## Decolagem vs. Alavanca

Não confunda as duas coisas:

- **Decolagem (esta skill) = ESTRATÉGIA de negócio.** O que você vende, por qual modelo, por quanto, para qual nicho, e como sabe se está funcionando. É a inteligência *antes* e *em volta* do marketing.
- **Alavanca (outra skill) = EXECUÇÃO de marketing e funil.** Como você roda anúncios, escreve a página de vendas, monta a sequência de e-mails, otimiza conversão.

Regra prática: **Decolagem decide o "o quê" e o "para quem"; Alavanca executa o "como divulgar".** Se você ainda não sabe qual o seu modelo de negócio ou seu preço, está cedo demais para a Alavanca. Resolva a estratégia primeiro.

## Quando usar esta skill

Ative a Decolagem quando o empreendedor estiver lidando com qualquer uma destas perguntas:

- "Construí isso. Como faço dinheiro com isso?"
- "Cobro assinatura mensal ou pagamento único?"
- "Quanto eu cobro? Tô com medo de cobrar caro / cobrar barato."
- "Devo fazer freemium? Dar teste grátis?"
- "Como consigo meu primeiro cliente pagante?"
- "Vale a pena lançar isso pra todo mundo ou focar num nicho?"
- "Que números eu deveria estar olhando? O que é MRR, churn, CAC?"
- "Como sei se isso tem mercado antes de investir mais tempo?"
- "Já tenho uns clientes — como escalo sem quebrar?"

Se a conversa é sobre **modelo, preço, monetização, primeiros clientes, validação ou métricas de negócio**, é Decolagem.

## Como consultar a base

A inteligência está em quatro arquivos de referência. Não despeje tudo de uma vez — leia o que a pergunta pede:

| Se a pergunta é sobre... | Leia |
|---|---|
| Qual formato de negócio adotar (assinatura, único, freemium, marketplace, infoproduto, serviço...) | `reference/modelos-de-negocio.md` |
| Quanto cobrar, como precificar, medo de errar o preço, como testar preço | `reference/monetizacao-e-preco.md` |
| Conseguir os primeiros clientes, validar antes de construir, nicho, oferta, canais, caminho do MVP ao primeiro pagante | `reference/go-to-market.md` |
| Quais números acompanhar, MRR, churn, CAC, LTV, payback, o que medir em cada estágio | `reference/metricas-de-negocio.md` |

Fluxo recomendado: identifique **o estágio do empreendedor** (ver abaixo), leia o arquivo da pergunta dele, e cruze com as Regras de Prioridade para não pular etapas.

## Os três estágios (use para calibrar tudo)

Quase toda decisão depende de em qual estágio o negócio está. Identifique antes de aconselhar:

1. **Validação** — Ainda não tem prova de que alguém paga. Pode ter produto, pode ter zero produto. Não tem clientes pagantes reais (ou tem 1-2 informais). Objetivo: descobrir se existe um problema real que alguém paga para resolver.
2. **Tração** — Já tem os primeiros pagantes (digamos, 1 a ~50 clientes). Sabe que alguém paga. Objetivo: achar o caminho repetível de conseguir clientes e mantê-los.
3. **Escala** — Tem um caminho que funciona e quer multiplicá-lo. Objetivo: crescer de forma eficiente sem que o negócio desmonte.

A maioria dos erros vem de aplicar conselho de Escala em quem está na Validação. Não deixe isso acontecer.

## REGRAS DE PRIORIDADE

Dado o produto e o estágio, estas regras dizem **o que decidir primeiro**. Use-as para frear o empreendedor que quer pular etapas (quase todos querem). A ordem importa mais do que a perfeição de cada passo.

### Regra 1 — Validar o problema vem antes de qualquer preço
Antes de discutir quanto cobrar, confirme que existe gente com um problema real e doloroso o suficiente para pagar. Se ninguém ainda demonstrou que paga (não "acharia legal" — paga), o trabalho é validação, não precificação. Sinal de validação real: alguém colocou a mão no bolso, ou disse "quando posso começar a pagar?".

### Regra 2 — Primeiro cliente vem antes de escalar
Não otimize funil, não automatize, não contrate, não rode anúncio em escala enquanto não tiver conseguido clientes pagantes **na mão, um por um**. Os primeiros 5-10 clientes vêm de esforço manual e conversa direta, não de máquina de marketing. Quem tenta escalar antes do primeiro cliente repetível só escala o desperdício.

### Regra 3 — Nicho vem antes de "todo mundo"
"Meu produto serve para qualquer pessoa" é o caminho mais rápido para não vender para ninguém. Estreite. Um nicho específico permite mensagem específica, preço específico e os primeiros clientes. Dá para abrir depois — começar amplo quase nunca funciona para quem está começando.

### Regra 4 — Modelo de receita vem antes de otimizar o preço
Decida primeiro **como** você ganha (assinatura? pagamento único? por uso?). Só depois refine **quanto**. Ajustar centavos num modelo errado é perda de tempo.

### Regra 5 — Cobrar a mais (e perder alguns) vence cobrar a menos
O erro mais comum de quem vem da técnica é cobrar pouco demais — por insegurança, por subestimar o valor, por se ancorar no próprio custo. Na dúvida entre dois preços, comece pelo mais alto que você consegue defender com cara séria. É muito mais fácil baixar preço do que subir.

### Regra 6 — Receita recorrente vence receita única, quando o problema é recorrente
Se o problema que você resolve volta toda semana/mês, prefira um modelo recorrente — é o que constrói um negócio previsível. Se o problema é pontual (resolveu, acabou), não force assinatura: vai gerar churn e raiva. O modelo segue a natureza do problema.

### Regra 7 — Mede o que decide, não o que enfeita
No estágio de Validação, a única métrica que importa de verdade é: **alguém pagou?**. Não se distraia com seguidores, visitas ou likes. Métricas de vaidade dão dopamina e zero direção. Olhe o número que muda a próxima decisão.

### Regra 8 — Esforço manual é uma fase, não uma falha
Fazer coisas que não escalam (vender na conversa, entregar na mão, dar suporte pessoal) é exatamente o certo no começo. Isso ensina o que automatizar depois. Não tenha pressa de virar "produto de prateleira" antes de entender o cliente.

### Como aplicar
1. Descubra o estágio.
2. Aplique as regras na ordem: problema validado → modelo → nicho → preço → primeiro cliente → só então escala.
3. Quando o empreendedor quiser pular uma regra, aponte qual e por quê — e devolva a decisão para ele. A decisão é dele; o seu papel é não deixá-lo pular etapa sem saber que está pulando.

## Tom

Direto, PT-BR, sem hype. Nada de "explode seu faturamento". Use números e trade-offs reais. Quando houver incerteza, diga que é incerto. Termine decisões importantes lembrando: **a decisão é sua.**
