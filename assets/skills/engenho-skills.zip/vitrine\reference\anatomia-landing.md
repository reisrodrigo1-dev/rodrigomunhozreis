# Anatomia de uma landing que converte

Uma landing de oferta única tem **um único trabalho**: transformar o clique em e-mail. Tudo que não serve a esse trabalho é fricção. Aqui está cada seção — o que ela faz, como acertar e os erros que matam conversão.

A ordem importa. A pessoa lê de cima pra baixo e decide em segundos. A estrutura abaixo é a mesma da `/ia-sem-medo`: hero+form acima da dobra → o que recebe → autoridade → FAQ → CTA final.

---

## 0. Antes de tudo: a regra do foco

A landing **não é a home**. Ela não tem menu de navegação, não tem links pro blog, não tem rodapé cheio de seções, não tem "fale conosco no WhatsApp". A única saída fácil da página é **converter** (deixar o e-mail). Cada link extra é uma porta de fuga.

- **Acima da dobra, zero distração.** Sem header com 6 itens de menu. No máximo o logo (sem link que saia da página) e talvez um âncora que rola pro form.
- **Uma oferta.** Uma isca, um benefício, um público. Se você tem dois e-books, são duas landings.
- **Um CTA**, repetido. A mesma ação do topo ao fim.

---

## 1. Hero + formulário (acima da dobra)

**O que faz:** é a seção que decide tudo. Em poucos segundos a pessoa precisa entender (a) o que é a oferta, (b) por que ela importa, e (c) como pegar — e o "como pegar" (o formulário) tem que estar **visível sem rolar**.

**Componentes:**
- **Kicker** (`kicker-d`): rótulo curto em caixa alta, âmbar, que contextualiza ("E-BOOK GRÁTIS", "GUIA PARA QUEM VIBECODA"). Ancora a promessa.
- **Headline** (Fraunces, `text-grad`): a frase que para o scroll. Específica, uma ideia só, promete o que a isca entrega. (Padrões em `copy-de-conversao.md`.)
- **Subhead** (1 linha, Inter, `text-paper/70`): completa a headline em uma frase — pra quem é, qual o resultado.
- **Formulário** (`glass`): e-mail (e nome opcional) + botão `btn-glow`. Acima da dobra. Esse é o ponto de conversão principal.
- **Reforço de baixo risco** sob o botão (microcopy `text-paper/55`): "Grátis. Sem spam. Cancela quando quiser."

**Como acertar:**
- O formulário tem que aparecer **no primeiro view**, sem rolar — em desktop e em mobile. Em mobile, isso significa headline curta e form logo abaixo.
- Layout de duas colunas no desktop (texto à esquerda, card do form à direita) ou form centralizado abaixo do texto. O importante é que o campo de e-mail esteja na primeira tela.
- A headline e o anúncio que trouxe a pessoa têm que **bater** (continuidade de promessa).

**Erros comuns:**
- Formulário só lá embaixo, depois de 3 telas de rolagem. A pessoa some antes de chegar.
- Headline genérica ("Transforme seu negócio"). Não nomeia dor nem resultado.
- Carrossel/vídeo pesado que empurra o form pra baixo da dobra e atrasa o carregamento.
- Menu de navegação no topo levando pra outras páginas — porta de fuga.
- Pedir muitos campos aqui (telefone, empresa, cargo). Cada campo derruba conversão.

---

## 2. O que você recebe

**O que faz:** transforma "deixar o e-mail" numa troca clara. A pessoa pergunta "o que eu ganho com isso?" — esta seção responde com **valor concreto**, não adjetivo.

**Componentes:**
- Título curto da seção ("O que tem dentro", "O que você leva").
- **3 a 5 bullets de valor**, cada um com um ícone/marcador âmbar e uma frase específica: o que a isca contém **e** o resultado que aquilo dá.
- Opcional: prévia visual da isca (capa do e-book, print do checklist) num card `glass`.

**Como acertar:**
- Cada bullet liga **conteúdo → benefício**: "Checklist de 12 itens *para tirar o protótipo do ar de teste*" — não só "checklist".
- Especificidade vende: número, passo, exemplo. "5 erros que queimam orçamento" > "dicas valiosas".
- 3 a 5 bullets. Menos parece raso, mais vira lista que ninguém lê.

**Erros comuns:**
- Bullets vagos ("conteúdo exclusivo", "dicas incríveis") — não dizem nada.
- Listar features sem o benefício ("12 páginas em PDF" — e daí?).
- Parede de texto em vez de bullets escaneáveis.
- Prometer aqui mais do que a isca entrega (quebra a continuidade de promessa).

---

## 3. Autoridade / prova

**O que faz:** responde "por que eu confiaria em você pra deixar meu e-mail?". É onde entra o autor e a prova de que a oferta vale.

**Componentes:**
- **Quem é o autor:** Rodrigo Munhoz Reis, "vibecoding com engenharia" — em 2-3 frases que estabelecem competência **mostrando**, não se autoelogiando (o que faz, o que construiu, por que sabe disso).
- **Prova leve e honesta:** um número real (alunos, projetos, anos), um mini-depoimento, um exemplo concreto, logos onde apareceu. Só o que for verdade.
- Foto ou marca do autor num card `glass`, para dar rosto à autoridade.

**Como acertar:**
- Prova **específica e verificável** > superlativo. "Mais de X pessoas baixaram" só se for real.
- Conecte a autoridade à oferta: a pessoa precisa confiar **neste tema**, não num currículo genérico.
- Se ainda não há prova social (lançamento novo), use autoridade por competência e método — sem inventar números.

**Erros comuns:**
- Inventar depoimento ou número. Mata a confiança no instante em que cheira a falso.
- Autoelogio vazio ("o maior especialista do Brasil"). Mostre, não diga.
- Prova desconectada da oferta (prêmios de outra área).
- Bloco gigante de biografia. Ninguém leu pra isso.

---

## 4. FAQ que quebra objeção

**O que faz:** a pessoa quase converteu, mas tem um "sim, mas…". A FAQ existe pra **derrubar a última objeção** — não pra dar suporte. Cada pergunta é uma trava de conversão que você está removendo.

**Componentes (4 a 6 perguntas), normalmente em accordion `glass`:**
- **É grátis mesmo?** → confirma, tira o medo de pegadinha.
- **Vou receber spam / vão vender meu e-mail?** → política clara, baixo risco.
- **É pra mim?** → qualifica o público ("é pra você se...").
- **Quanto tempo leva / como recebo?** → expectativa clara (chega no e-mail na hora).
- **Preciso saber programar / ter experiência?** → remove a barreira de entrada.
- **E se não for útil?** → reversão de risco (cancela quando quiser, sem custo).

**Como acertar:**
- Pense nas objeções **reais** desse público específico e responda de frente.
- Respostas curtas, honestas, no tom da voz (sem hype). Cada resposta reforça a baixa fricção.
- Ordene da objeção mais comum pra menos comum.

**Erros comuns:**
- FAQ de suporte ("como recupero minha senha") em vez de FAQ de objeção.
- Respostas defensivas ou longas demais.
- Não responder a objeção óbvia ("vou receber spam?") — ela fica na cabeça e segura o e-mail.
- Perguntas que plantam dúvida que a pessoa nem tinha.

---

## 5. CTA final ancorado

**O que faz:** pega quem leu tudo e decidiu agora. Repete a oferta e dá o ponto de conversão de novo, no fim, sem fazer a pessoa rolar de volta pro topo.

**Componentes:**
- Reafirmação curta da oferta (1 headline + 1 linha).
- **O mesmo formulário** do hero (e-mail + `btn-glow`) **ou** um botão grande que rola suave de volta pro form do hero.
- Reforço de baixo risco repetido ("Grátis. Sem spam.").

**Como acertar:**
- Mesma oferta, mesmo CTA do hero — consistência. Não introduza uma ação nova aqui.
- O CTA tem que estar "ancorado": a pessoa não pode chegar no fim e não ter onde clicar.
- Em páginas longas, vale um CTA flutuante/sticky discreto em mobile que sempre leva ao form.

**Erros comuns:**
- Terminar a página sem CTA (a pessoa decidiu e não tem onde agir).
- CTA final diferente do hero ("agora fale no WhatsApp") — confunde e divide a decisão.
- Mandar de volta pro topo sem rolagem suave, fazendo a pessoa procurar o form.

---

## Resumo da estrutura

```
[ HERO + FORM ]      ← acima da dobra. headline + subhead + e-mail + botão. zero distração.
[ O QUE RECEBE ]     ← 3-5 bullets: conteúdo → benefício. específico.
[ AUTORIDADE/PROVA ] ← quem é o autor + prova honesta. confiança.
[ FAQ ]              ← 4-6 objeções quebradas. tira o "sim, mas".
[ CTA FINAL ]        ← repete oferta + form. ancorado. mesma ação.
```

Uma oferta. Um CTA. Captura de baixa fricção. Prova que é verdade. Objeção quebrada. É isso que converte clique em e-mail.
