# Roteiro de palestra — modelo preenchível

> Preencha de cima pra baixo. Não pule a "ideia central": ela comanda o resto.
> Apague as instruções em _itálico_ conforme for preenchendo.

---

## Cabeçalho

- **Título da palestra:** _(provisório serve — o título final sai do gancho)_
- **Evento / público:** _quem está na sala? o que eles já sabem? o que dói neles?_
- **Duração:** _ex.: 30 min_
- **Data:**

---

## 1. A UMA ideia central

> A frase que você quer que a plateia repita no corredor. Uma só.

**Ideia central:**
_(ex.: "Vibecoding sem engenharia é dívida técnica disfarçada de velocidade.")_

---

## 2. A transformação prometida

> Complete a frase. Se não couber, tem ideias demais — corte.

**No fim, a plateia vai acreditar / saber / conseguir** ___________________________,
**que antes não** ___________________________.

---

## 3. A história real (o fio condutor)

> Qual caso/erro/virada do Rodrigo carrega essa ideia? A confissão costuma ser o melhor gancho.

- **A cena:** _onde/quando aconteceu_
- **A confissão (onde apanhei):**
- **A virada (o que mudou):**
- **O resultado:**

---

## 4. O arco (preencha cada seção)

### 4.1 Gancho / promessa — ~10%
- **A fisgada** _(cena / número / pergunta)_:
- **A promessa** _(a transformação em 1 frase)_:

### 4.2 Tensão / problema — ~20%
- **A dor nomeada** _(específica, "isso é comigo")_:
- **A confissão** _(onde o Rodrigo errou/apanhou)_:
- **O custo de não resolver**:

### 4.3 Virada / método — ~15%
- **A ideia central, dita limpa**:
- **O método / princípio**:
- **O reframe** _(o problema sob nova luz)_:

### 4.4 Prova com exemplos reais — ~40%
> Escolha 2–3. Cada prova deve apontar de volta pra ideia central.

- **Prova 1** _(caso / número / demo)_: situação → o que fiz → resultado → aprendizado
- **Prova 2**:
- **Prova 3** _(opcional)_:

### 4.5 Chamada / próximo passo — ~15%
- **Recapitulação em 1 frase** _(retoma o gancho)_:
- **O CTA — UMA ação possível hoje**:
- **A devolução da escolha**: _"A decisão é sua."_

---

## 5. Os slides (1 ideia por slide + nota de fala)

> Pouco texto na tela; a fala mora na nota. Use o tipo de slide certo (frase / número / imagem / gráfico / antes-depois).

| # | Parte do arco | O que aparece na tela (1 ideia) | Tipo | Nota de fala (o que dizer + transição) |
|---|---------------|--------------------------------|------|----------------------------------------|
| 1 | Gancho | _capa: título Fraunces_ | capa | |
| 2 | Gancho | _número/cena em âmbar_ | número/imagem | |
| 3 | Tensão | | | |
| 4 | Tensão | _confissão_ | imagem/frase | |
| 5 | Virada | _ideia central, palavra-chave em âmbar_ | frase | |
| 6 | Prova | _número grande_ | número | |
| 7 | Prova | _antes/depois_ | antes-depois | |
| 8 | Prova | | gráfico | |
| 9 | Chamada | _frase-síntese_ | frase | |
| 10 | Chamada | _o CTA_ | frase | |

> _Adicione/remova linhas. A prova costuma ocupar o maior número de slides._

---

## 6. CTA final

- **A ação (uma):**
- **Por que do tamanho da plateia:**
- **Fecho:** _"A decisão é sua."_

---

## 7. Notas de produção

- **Tempo total alvo:** ___ min — confira a soma dos blocos.
- **Onde respirar / pausar:** _marque as frases que precisam de silêncio depois._
- **Demo / vídeo:** _precisa de tela, internet, backup?_
- **Visual:** gerar com a skill `slides` na marca — fundo `ink #070608`, texto `paper #F4EFE6`, destaque `amber #E8A33D`, títulos Fraunces, corpo Inter.
