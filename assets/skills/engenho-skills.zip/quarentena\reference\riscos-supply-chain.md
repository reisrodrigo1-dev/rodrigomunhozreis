# Riscos de supply-chain

Os principais vetores de ataque via dependências, com como reconhecer e como mitigar cada um. Supply-chain é o ataque que entra junto com um pacote que você mesmo instalou — não precisa furar a sua aplicação, basta comprometer algo que ela já confia.

---

## 1. Typosquatting

**O que é:** o atacante publica um pacote com nome quase idêntico a um popular, contando com erro de digitação ou cópia descuidada. Exemplos do padrão: `cross-env` vs `crossenv`, `lodash` vs `lodahs`, `react-dom` vs `reactdom`, `@types/node` vs `types-node`. Quem digita errado ou copia de um tutorial mal escrito instala o pacote do atacante — que costuma replicar a funcionalidade real para não levantar suspeita, enquanto roda o payload no postinstall.

**Como reconhecer:**
- Nome com letra trocada, hífen a mais/menos, ou escopo (`@org/`) faltando/sobrando.
- Downloads muito abaixo do esperado para um nome "famoso".
- Criado recentemente, sem repositório, com descrição genérica.

**Como mitigar:**
- Confira o nome **caractere por caractere** contra o repositório oficial antes de instalar — nunca copie de tutorial ou de resposta de IA sem conferir.
- Instale pelo nome canônico que aparece na documentação oficial do projeto.
- Desconfie de pressa: "só rodar esse install rapidinho" é onde o typosquat pega.

---

## 2. Conta de mantenedor comprometida

**O que é:** o atacante não cria um pacote novo — ele invade a conta npm de quem mantém um pacote **legítimo e popular** (via phishing, credencial vazada, token roubado ou ausência de 2FA) e publica um release malicioso com o nome real, na conta real. Para quem instala, é uma atualização oficial. É o vetor mais perigoso porque contorna toda a sua intuição: o pacote é confiável, o nome está certo, o histórico é bom.

### Caso Axios 2026 (exemplo real)

O Axios é um dos clientes HTTP mais usados do ecossistema JavaScript — dezenas de milhões de downloads por semana, presente em uma fração enorme dos projetos Node/Next.js, frequentemente como dependência transitiva de outras libs.

A conta de um mantenedor foi comprometida e código malicioso foi injetado em um release publicado no npm como atualização oficial. Por ser uma lib tão difundida e quase sempre declarada com range aberto (`^1.x`), o release comprometido se propagou sozinho: todo projeto que rodou `npm install` sem lockfile travado, ou que recriou o lockfile, puxou a versão maliciosa **sem nenhuma ação deliberada do desenvolvedor**. O payload rodava no contexto da aplicação, com acesso ao que a aplicação tinha acesso — variáveis de ambiente, tokens, requisições.

A lição: **popularidade não é segurança.** Quanto mais usado o pacote, mais atraente o alvo e maior o raio de explosão. "É o Axios, todo mundo usa" é exatamente o raciocínio que o ataque explora.

**Como reconhecer:**
- Release novo que aparece fora do ritmo normal do projeto.
- Mudanças no `scripts` (postinstall surgindo do nada), arquivos minificados/ofuscados novos, dependências adicionadas sem explicação no changelog.
- Avisos públicos (GitHub Security Advisories, npm, comunidade) — geralmente é assim que se descobre.

**Como mitigar:**
- **Lockfile commitado + `npm ci`** no deploy: instala exatamente a versão auditada, não pega update automático.
- **Versão exata** em libs críticas no `package.json`, como segunda camada além do lockfile.
- **Não atualizar no dia zero.** Deixe um release "descansar" alguns dias antes de adotar; a maioria dos comprometimentos é detectada rápido pela comunidade.
- Ao subir versão, **leia o que mudou** (changelog, diff do lockfile) em vez de subir cego.
- Monitore advisories dos pacotes que você usa de verdade.

---

## 3. Dependência transitiva

**O que é:** você instala A, que depende de B, que depende de C. Você nunca escolheu C, talvez nem saiba que ele existe — mas o código dele roda na sua aplicação. A maioria esmagadora do que está no seu `node_modules` é transitiva. O comprometimento de uma transitiva profunda atinge você sem nunca aparecer no seu `package.json`.

**Como reconhecer:**
- `npm ls <pacote>` mostra a cadeia que trouxe um pacote.
- `npm audit` aponta o caminho (`a > b > c`) onde está a vulnerabilidade.
- A diferença entre poucas dependências diretas e centenas/milhares no `node_modules` é toda transitiva.

**Como mitigar:**
- Prefira dependências diretas com **árvore enxuta** — menos sub-dependências, menos superfície.
- Use o lockfile para travar também as transitivas (ele registra a árvore inteira).
- `overrides` no `package.json` (npm) permite forçar uma versão segura de uma transitiva sem esperar o pacote-pai atualizar.
- Ao escolher entre duas libs equivalentes, a que arrasta menos dependências é a mais segura.

---

## 4. Script de postinstall malicioso

**O que é:** o npm executa automaticamente os scripts `preinstall`, `install` e `postinstall` de um pacote durante a instalação — **antes de você rodar qualquer linha do seu código.** Um pacote malicioso usa isso para rodar o payload no exato momento do `npm install`: roubar variáveis de ambiente, ler `.env`, exfiltrar tokens de CI, instalar backdoor. É o mecanismo que dá "ação imediata" ao typosquat e à conta comprometida.

**Como reconhecer:**
- Campo `scripts` do pacote com `postinstall`/`preinstall`/`install` chamando node em arquivo ofuscado, baixando algo da rede, ou rodando shell.
- Avisos do npm sobre scripts de lifecycle durante o install.

**Como mitigar:**
- **`npm config set ignore-scripts true`** (ou `npm install --ignore-scripts`) desliga a execução automática de scripts de dependências. Cuidado: alguns pacotes legítimos precisam deles (ex.: compilação nativa) — avalie caso a caso, idealmente liberando só os necessários.
- Em CI, rode install com `--ignore-scripts` sempre que possível e nunca exponha segredos de produção no ambiente de build mais do que o necessário.
- Mantenha `.env` e segredos fora do alcance do processo de install (não injete tokens de produção num build que instala dependências).

---

## 5. Pacote abandonado

**O que é:** o pacote não é malicioso — está morto. Sem mantenedor ativo, vulnerabilidades não são corrigidas, e a própria conta/repositório fica vulnerável a sequestro (um abandonado popular é alvo fácil para o vetor #2). Dependência abandonada é dívida de segurança acumulando juros.

**Como reconhecer:**
- Última publicação há anos.
- Issues e PRs abertos sem resposta, repositório arquivado.
- `npm outdated` mostra a lib muito atrás e sem release recente.
- CVEs abertos sem fix disponível.

**Como mitigar:**
- Prefira pacotes com manutenção ativa e mais de um mantenedor.
- Substitua abandonados por alternativas vivas — ou, se a função for pequena, internalize (escreva você mesmo as 10-30 linhas em vez de carregar uma dependência morta).
- Reavalie periodicamente: o que estava vivo quando você adotou pode ter morrido.

---

## Princípios gerais de defesa

1. **Desconfiança como padrão** — todo pacote é código de terceiro rodando com os seus privilégios até prova em contrário.
2. **Lockfile commitado + `npm ci`** — a base de tudo; sem isso, nenhuma das outras medidas se sustenta.
3. **Versão exata em libs críticas** — segunda camada contra propagação automática de release comprometido.
4. **Menos é mais** — cada dependência removida é superfície de ataque eliminada de graça.
5. **Não atualizar no dia zero** — deixe releases descansarem; a comunidade detecta a maioria dos comprometimentos em dias.
6. **Auditar periodicamente e em incidentes** — `npm audit` + revisão manual, não só na crise.
