# X vs. LinkedIn — a thread muda de forma

"Thread" significa coisas diferentes em cada plataforma. No X é uma sequência de posts curtos encadeados. No LinkedIn, o que se chama de thread na prática vira **um post longo com quebras** ou **um carrossel**. Escrever a mesma coisa nas duas é errar nas duas. Aqui está como cada uma funciona e quando cada formato faz sentido.

---

## X / Twitter — posts curtos encadeados

A thread nativa do X. Cada post (~280 caracteres) é uma agulhada; o "thread" os costura em fio. É o formato canônico de thread.

**Como funciona:**

- **Post curto por natureza.** ~280 caracteres por post obrigam concisão — o que casa com "um ponto por post". Use o limite a seu favor: ele força o corte do enchimento.
- **Encadeamento nativo.** Você responde no próprio post pra continuar o fio. A numeração (1/, 2/… ou "1 de 7") ajuda quem chega no meio a se localizar.
- **O post 1 é tudo.** No X o alcance vem de quem reposta o primeiro post. Os internos quase não aparecem isolados. Gaste o tempo no post 1.
- **Link:** pode ir no último post da thread, ou num reply separado. Há quem diga que link no corpo derruba alcance no X também — quando o alcance importa muito, manda o link num reply ao final e avisa ("link abaixo").
- **Ritmo visual:** posts de uma linha entre posts mais densos criam batida. Emojis com parcimônia (um marcador, não confete).
- **Tamanho:** 4 a 12 posts. Acima disso, raramente segura no X — a atenção é mais curta que no LinkedIn.

**Quando o X faz sentido:** tema que se quebra bem em pedaços pequenos (lista, passos, tese desenvolvida em etapas), público dev/tech/builder, e quando você quer o efeito de "fio" que convida ao repost.

---

## LinkedIn — a "thread" vira post longo ou carrossel

O LinkedIn **não tem thread nativa encadeada** como o X. Comentar a própria publicação em sequência tem alcance fraco e fica confuso. Então uma "thread" no LinkedIn assume uma de duas formas:

### Opção A — post longo único (com quebras)

O desdobramento vira **um post só**, longo, com as 1-2 primeiras linhas como gancho (é o que aparece antes do "ver mais") e o corpo escaneável, separado por quebras de linha — cada "post" da thread vira um bloco do texto.

**Como funciona:**

- **Primeira linha = post 1 da thread.** O "ver mais" depende dela. É o gancho + promessa, exatamente como o post 1 no X. Se ela não fisga, ninguém abre o resto.
- **Corpo escaneável.** Cada ponto vira um bloco curto (1-3 linhas) separado por linha em branco. Marcadores ("→", "—") ajudam. Sem markdown (negrito/itálico não renderizam; não use `**`).
- **Tamanho:** até ~1.300-1.500 caracteres rendem bem. Mais que isso, considere carrossel.
- **Fechamento + CTA** no fim do post, como no X.
- **Link no primeiro comentário.** LinkedIn derruba o alcance de post com link no corpo. Escreva "link no primeiro comentário" no texto e entregue o comentário separado.
- **Hashtags:** 3-5 relevantes no fim, sem spam.

**Quando faz sentido:** a maioria das threads no LinkedIn. Tom de autoridade, lê-se como um mini-artigo, e o formato é nativo da plataforma.

### Opção B — carrossel (documento/PDF)

Quando o desdobramento é visual, tem muitos pontos paralelos, ou você quer mais permanência, a "thread" vira um **carrossel** — um slide por ponto.

**Quando faz sentido:** lista numerada com peso visual, passo a passo que ganha com diagrama, conteúdo que você quer que circule como material. **Nesse caso, não é trabalho da Linha — passe pra `Baralho`** (a skill de carrossel slide a slide). A Linha decide *que* o formato é carrossel; a Baralho monta.

---

## Tabela de decisão

| Situação | Formato |
|---|---|
| Público dev/tech, tema em pedaços pequenos, quer repost | **X** — posts encadeados |
| LinkedIn, mini-artigo de autoridade, texto puro | **LinkedIn** — post longo único |
| LinkedIn, lista visual / muitos pontos / material pra circular | **Carrossel** → passa pra `Baralho` |
| Mesma ideia nas duas redes | **Duas versões** — X encadeado + LinkedIn post longo. Não copia-cola. |

---

## Adaptar de uma rede pra outra (não é copy-paste)

- **Do X pro LinkedIn:** junte os posts num texto corrido com quebras. O post 1 do X vira a primeira linha do LinkedIn. Solte um pouco a concisão extrema do X — no LinkedIn cabe respiro. Tire numeração "1/7" (que é gramática de X) ou troque por marcadores.
- **Do LinkedIn pro X:** quebre os blocos em posts de ~280 caracteres, um ponto cada. Aperte as frases. Adicione numeração e o "🧵". O que era um parágrafo de 4 linhas pode virar 2 posts.
- **Em qualquer direção:** a **promessa** (post 1) e o **fechamento** se mantêm. O que muda é o ritmo, o tamanho do bloco e onde vai o link.

Entregue sempre dizendo **qual plataforma** e **qual formato** — porque a mesma thread tem corpos diferentes em cada casa.
