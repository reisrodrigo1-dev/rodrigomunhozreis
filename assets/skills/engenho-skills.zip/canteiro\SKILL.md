---
name: canteiro
description: Inicia um projeto novo já com a estrutura e os defaults de segurança certos (gitignore, env, regras de banco fechadas, headers, repositório privado). Use ao criar a base de um projeto novo na stack Next.js + Firebase.
---

# Canteiro

Canteiro é a fundação. Antes de subir parede, você prepara o terreno: marca o que é estrutura, isola o que é sujo, e garante que ninguém vai cair no buraco depois. Em software é a mesma coisa — só que o buraco é um segredo vazado no Git ou um banco aberto pro mundo.

Esta skill inicia um projeto novo **já blindado**. Não é "segurança depois". É segurança de fábrica: as regras de banco nascem fechadas, o `.gitignore` já protege os segredos antes do primeiro commit, e o repositório nasce privado.

Princípio: **regra de banco segura ANTES de qualquer dado. Segredo nunca entra no Git.**

## Quando usar

- Você vai começar um projeto novo na stack Next.js (App Router) + Firebase + Vercel + Tailwind + GitHub.
- Você quer a base montada certa de uma vez, sem ter que "lembrar de fechar o Firestore depois".
- Você está num MVP ou protótipo que pode virar produção — então não dá pra começar inseguro "porque é só teste".

Não use se o projeto já existe e está rodando — aí você quer uma auditoria/hardening, não um canteiro.

## Visão geral do que essa skill monta

1. Projeto Next.js (App Router, TypeScript) com Tailwind.
2. Firebase configurado com **regras de Firestore/Storage fechadas desde o primeiro segundo**.
3. `.gitignore` correto (ignora `.env*`, `.next`, `node_modules`, credenciais).
4. `.env.example` com as chaves públicas do Firebase (sem valores reais) + `.env.local` que NUNCA vai pro Git.
5. Headers de segurança no `next.config`.
6. Repositório **privado** no GitHub, com o primeiro commit já limpo (zero segredo).

## PROCEDIMENTO

Siga na ordem. A ordem importa: o `.gitignore` e as regras de banco vêm **antes** de qualquer commit ou deploy.

### Passo 1 — Criar o projeto Next.js

```bash
npx create-next-app@latest meu-projeto --typescript --app --tailwind --eslint --src-dir --import-alias "@/*"
cd meu-projeto
```

Isso já entrega App Router, TypeScript, Tailwind e ESLint. Se o CLI perguntar algo fora dessas flags, aceite os defaults.

### Passo 2 — Travar o `.gitignore` ANTES de qualquer coisa

Antes de criar `.env`, antes de instalar Firebase, antes de commitar: garanta que o `.gitignore` protege os segredos.

- Abra `templates/gitignore.txt` desta skill.
- Substitua/complemente o `.gitignore` do projeto com esse conteúdo.
- Confirme que `.env*` e arquivos de credencial (ex.: `*-firebase-adminsdk-*.json`) estão lá.

> Por quê primeiro: se você criar um `.env.local` com chave e fizer `git add .` antes do `.gitignore` estar certo, o segredo já entrou no histórico. Reverter isso é cirurgia. Evite.

### Passo 3 — Variáveis de ambiente

- Crie `.env.example` na raiz a partir de `templates/env.example.txt`. Esse arquivo **vai** pro Git — é o mapa de quais variáveis existem, sem valores.
- Copie para o arquivo real, que **não** vai pro Git:

```bash
cp .env.example .env.local
```

- Preencha o `.env.local` com os valores reais do seu projeto Firebase (Console do Firebase → Configurações do projeto → Seus apps → SDK do Firebase).

Regra: variáveis `NEXT_PUBLIC_*` são expostas no navegador — só coloque ali a config pública do Firebase (apiKey de cliente, etc., que são identificadores, não segredos). **Chave de service account / Admin SDK nunca é `NEXT_PUBLIC_` e nunca fica em arquivo dentro do repo.**

### Passo 4 — Firebase com regras FECHADAS desde o início

Instale e inicialize:

```bash
npm install firebase
npm install -g firebase-tools   # se ainda não tiver
firebase login
firebase init firestore         # (e storage, se for usar)
```

Quando o `firebase init` perguntar pelo arquivo de regras, aponte para `firestore.rules`. **Antes de criar qualquer documento**, substitua o conteúdo por `templates/firestore.rules` desta skill — que nega tudo por padrão.

Crie também o cliente Firebase em `src/lib/firebase.ts` lendo as variáveis do `.env.local` (ver lista de arquivos abaixo).

Publique as regras fechadas:

```bash
firebase deploy --only firestore:rules
```

> Por quê: o Firestore em modo "test mode" fica **aberto pra qualquer um ler e escrever** por 30 dias. Muita gente esquece e vaza dados. Comece fechado e abra cada coleção conscientemente quando tiver Auth.

### Passo 5 — Headers de segurança no `next.config`

Abra `templates/next.config.headers.md` e cole o bloco `headers()` no `next.config.js`/`next.config.mjs`. Isso adiciona:

- `X-Content-Type-Options: nosniff`
- `X-Frame-Options: DENY` (anti-clickjacking)
- `Referrer-Policy: strict-origin-when-cross-origin`
- `Permissions-Policy` (corta câmera/microfone/geolocalização por padrão)
- `Strict-Transport-Security` (HSTS)

### Passo 6 — Repositório PRIVADO no GitHub

Antes do primeiro push, confirme que não há segredo rastreado:

```bash
git status            # nenhum .env.local, nenhum *.json de credencial
git rm --cached .env.local 2>/dev/null   # caso tenha escapado
```

Crie o repo já privado e suba:

```bash
git init
git add .
git commit -m "chore: canteiro inicial com defaults de seguranca"
gh repo create meu-projeto --private --source=. --remote=origin --push
```

> Privado por padrão. Você abre depois se quiser — o contrário (fechar um repo que já vazou) não existe.

### Passo 7 — Deploy na Vercel com variáveis no painel

- Importe o repo na Vercel.
- Cadastre as variáveis de ambiente no painel da Vercel (Settings → Environment Variables) — os mesmos nomes do `.env.example`, com os valores reais. **Nunca** commite os valores.
- Faça o deploy.

## Arquivos que essa skill cria/preenche

| Arquivo | Origem (template) | Vai pro Git? |
|---|---|---|
| `.gitignore` | `templates/gitignore.txt` | Sim |
| `.env.example` | `templates/env.example.txt` | Sim |
| `.env.local` | cópia do `.env.example`, com valores reais | **Não** |
| `firestore.rules` | `templates/firestore.rules` | Sim |
| `next.config.js` (headers) | `templates/next.config.headers.md` | Sim |
| `src/lib/firebase.ts` | snippet abaixo | Sim |

### Snippet: `src/lib/firebase.ts`

```ts
import { initializeApp, getApps, getApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
};

// Evita reinicializar em hot-reload do Next.
const app = getApps().length ? getApp() : initializeApp(firebaseConfig);

export const db = getFirestore(app);
export const auth = getAuth(app);
export default app;
```

## Checklist do dia zero

Antes de considerar o canteiro pronto, rode `reference/checklist-inicial.md`. Resumo do que não pode faltar:

- [ ] `.gitignore` protegendo `.env*` **antes** do primeiro commit.
- [ ] `firestore.rules` fechado e publicado **antes** de qualquer dado.
- [ ] Nenhum segredo rastreado (`git status` limpo).
- [ ] Headers de segurança no `next.config`.
- [ ] Repositório **privado**.
- [ ] Variáveis reais só no `.env.local` e no painel da Vercel.

Regra de ouro do Canteiro: **se você está em dúvida se algo é segredo, trate como segredo.**
