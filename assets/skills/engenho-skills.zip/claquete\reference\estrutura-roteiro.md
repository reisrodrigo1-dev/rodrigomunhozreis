# Estrutura de roteiro — a casa

Estrutura padrão (Reels/Shorts/YouTube curto). Adapte o tempo ao formato.

## 1. Gancho (0–3s) — *obriga a ficar*
Uma frase que cria curiosidade ou contradiz o senso comum. Sem "fala galera".
- Padrões: número surpreendente · erro comum · confissão · promessa específica.
- Ex.: "Código feito por IA tem quase 3x mais falhas de segurança que o humano."

## 2. Tensão (3–15s) — *o problema real*
Mostre o custo de não saber. Específico, não genérico. Pode ser uma história curta (sua).
- Ex.: "A maioria sobe pra produção sem ler o que a IA escreveu. Até o dia que vaza."

## 3. Método (15–40s) — *a virada*
A solução com método — o seu diferencial. Passos claros, não "use IA".
- Ex.: "O segredo não é a ferramenta, é o processo: ler, blindar, testar, versionar."

## 4. Prova (40–55s) — *credibilidade*
Mostre, não prometa. Exemplo real, nome, link, resultado concreto.
- Ex.: "Rodo empresas reais 100% com IA — em produção, com clientes pagantes."

## 5. CTA suave (últimos segundos)
Convite sem pressão. Um só CTA.
- Ex.: "Tem um guia gratuito com o método. Link na bio."

## Regras de voz
- Frases curtas. Especificidade > adjetivo. Sem hype, sem "isso vai explodir sua mente".
- Confissão e história real prendem mais que dica genérica.
- Um vídeo = uma ideia. Não tente ensinar tudo.

## Anti-padrões
- Gancho fraco ("hoje vou falar sobre…"). · Encher de jargão. · Prometer o impossível. · CTA múltiplo no fim.
