# Google Ads — montar o anúncio de busca (Search)

Como estruturar uma campanha de **Rede de Pesquisa (Search)** no Google. Foco no que preencher. A escolha de quando usar Google vs Meta é da Alavanca — resumo: use Google Search quando a pessoa **já procura** a solução (intenção alta).

## A diferença que muda tudo: intenção

No Meta você **interrompe** alguém que não estava pensando no assunto — então precisa criar o desejo. No Google Search você **atende** alguém que digitou o problema agora — a intenção já existe, o lead é mais quente. Isso muda como você escreve e como segmenta:

- Meta = você escolhe o **público** (quem é a pessoa).
- Google = você escolhe a **busca** (o que a pessoa quer agora).

Por isso, no Google o trabalho central não é "quem", é **qual palavra-chave** e **qual palavra-chave você NÃO quer**.

## A estrutura

```
CAMPANHA           -> tipo "Rede de Pesquisa", orçamento, lances
   GRUPO DE ANÚNCIOS -> um tema/intenção + suas palavras-chave
      ANÚNCIO         -> anúncio responsivo (títulos + descrições)
      EXTENSÕES       -> sitelinks, frases de destaque, etc. (nível campanha/grupo)
```

Regra: **um grupo de anúncios = uma intenção**. Não jogue palavras-chave de temas diferentes no mesmo grupo, senão os títulos não casam com a busca e o índice de qualidade cai.

## 1. Palavras-chave (intenção)

Liste o que alguém com o problema digitaria. Agrupe por intenção. Exemplo no tema do Rodrigo (isca = e-book de vibecoding):

- Grupo "aprender a construir com IA": `como criar um app com IA`, `programar usando inteligência artificial`, `criar sistema sem saber programar`, `vibecoding`.
- Grupo "no-code / sem programar": `como fazer um software sem programar`, `criar SaaS sem programador`.

### Tipos de correspondência
Controlam o quão perto a busca real precisa estar da sua palavra:

- **Ampla** (`palavra`): pega variações amplas. Mais alcance, **mais desperdício** — exige lista de negativas forte. Evite no início.
- **De frase** (`"palavra-chave"`): a busca contém a ideia na ordem. Bom equilíbrio para começar.
- **Exata** (`[palavra-chave]`): a busca é praticamente a frase. Mais controle, menos volume. Use para os termos de maior intenção.

Recomendação de teste: comece com **frase + exata** nos termos mais quentes. Ampla só depois, com negativas bem montadas.

## 2. Palavras-chave NEGATIVAS (protege o orçamento)

Este é o passo que mais gente pula e mais dinheiro salva. Negativas dizem ao Google **para o que você NÃO quer pagar**. Sem elas, você paga por cliques de quem nunca vai converter.

Negativas universais para uma isca paga (não vende nada caro, é grátis):

- `grátis` quando você cobra — ou o oposto: se a isca é grátis e você NÃO vende nada na sequência, cuidado com quem busca preço.
- `curso gratis`, `download pirata`, `crackeado`, `torrent` — quem quer pirataria não vira lead.
- `emprego`, `vaga`, `salário`, `como ser programador` — busca de carreira, não de ferramenta.
- `o que é` quando você quer ação, não só definição (avalie — às vezes topo de funil quer isso).
- Nomes de concorrentes que você não quer disputar, marcas alheias, termos genéricos demais.

Revise o **relatório de termos de pesquisa** depois de rodar: ele mostra o que as pessoas realmente digitaram. Toda busca irrelevante que apareceu vira uma negativa nova. Isso é manutenção contínua.

## 3. Anúncio responsivo de pesquisa (RSA)

O Google hoje usa o **anúncio responsivo**: você fornece vários títulos e descrições, e ele combina e testa automaticamente. Você preenche:

| Campo | Quantidade | Limite | Recomendação |
|---|---|---|---|
| **Títulos** (headlines) | até 15 (forneça ≥ 8) | 30 caracteres cada | Misture: a palavra-chave ("Criar app com IA"), a oferta ("E-book grátis"), o benefício ("Sem saber programar"), prova ("Método, não hype"). |
| **Descrições** | até 4 (forneça ≥ 3) | 90 caracteres cada | Expanda a promessa + CTA. "Baixe o guia de vibecoding com engenharia. Direto ao ponto, sem enrolação." |
| **URL final** | 1 | — | A landing de captura (Vitrine), com UTM (`?utm_source=google&utm_campaign=ebook-vibecoding`). |
| **Caminho de exibição** | 2 | 15 cada | Enfeite a URL exibida: `seusite.com/ebook/vibecoding`. |

Dicas:
- Inclua a **palavra-chave principal em pelo menos 2-3 títulos** — casar título com busca sobe o **Índice de Qualidade** e baixa o custo por clique.
- Você pode **fixar** um título numa posição (ex.: a oferta sempre na posição 1), mas fixar demais tira a vantagem do teste automático. Fixe pouco.
- Capriche nos primeiros: o Google mostra geralmente 2-3 títulos por vez.

## 4. Extensões / recursos (sitelinks e companhia)

Recursos (antigas "extensões") aumentam o tamanho e a taxa de clique do anúncio sem custo extra. Adicione o máximo que fizer sentido:

- **Sitelinks** — links extras abaixo do anúncio. Ex.: "O que é vibecoding", "Sobre o método", "Baixar o e-book", "Para founders". Cada um pode levar a uma seção/landing.
- **Frases de destaque** (callouts) — frases curtas sem link: "Download imediato", "Sem enrolação", "Método com engenharia", "Feito por quem constrói".
- **Snippets estruturados** — listas por categoria. Ex.: cabeçalho "Tipos" → "Apps, SaaS, automações".
- **Telefone / formulário de lead** — se fizer sentido capturar direto.

Quanto mais recursos relevantes, maior o anúncio na página e melhor a CTR — o Google também usa isso no ranking.

## 5. Orçamento e lances de teste

- **Orçamento:** comece com **R$ 20 a 50/dia**. O Google pode gastar até ~2x o diário em dias de pico, compensando em outros — olhe o gasto médio do período, não o dia isolado.
- **Estratégia de lance no teste:** comece em **"Maximizar cliques"** (ou CPC manual com teto) para juntar dados de tráfego barato. Só migre para lances inteligentes (**Maximizar conversões / CPA desejado**) **depois** que o acompanhamento de conversão estiver instalado e com volume — lance inteligente sem dados de conversão é chute caro.
- **Acompanhamento de conversão:** instale o **tag de conversão** (Google Ads ou via GA4 importado) disparando no evento de captura do e-mail (página de obrigado). Sem isso, você otimiza no escuro.
- **Janela:** rode **3 a 7 dias** e junte volume antes de julgar. Search costuma dar sinal mais rápido que o Meta porque a intenção é maior.

## Checklist antes de publicar

- [ ] Tipo de campanha = Rede de Pesquisa (só Search, sem "Display" marcado por padrão)
- [ ] Grupos separados por intenção
- [ ] Palavras-chave em frase/exata nos termos quentes
- [ ] **Lista de negativas** montada
- [ ] RSA com ≥ 8 títulos e ≥ 3 descrições, palavra-chave nos títulos
- [ ] Sitelinks + callouts + snippets adicionados
- [ ] URL = landing de captura, com UTM
- [ ] Acompanhamento de conversão instalado
- [ ] Orçamento R$ 20–50/dia, lance "Maximizar cliques" no teste

A escrita dos títulos/descrições (gancho/prova/CTA) está em `copy-de-anuncio.md`. A leitura do resultado é com o **Painel**.
