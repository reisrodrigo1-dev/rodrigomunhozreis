# Estrutura de landing — pronta para montar (Next.js + Tailwind)

Esqueleto de seções **na ordem que converte**, com as classes da marca da casa (`glass`, `btn-glow`, `kicker-d`, `text-grad`, `accent`). Copie a estrutura, troque o texto pela copy real (de `copy-de-conversao.md`) e ajuste no Atelier. Tema escuro premium: `ink #070608`, `amber #E8A33D`, `paper #F4EFE6`, fontes Fraunces (títulos) / Inter (corpo).

> As classes `glass`, `btn-glow`, `kicker-d`, `text-grad`, `accent`, `btn-dark-ghost` são utilitários do projeto definidos no CSS/Tailwind da casa (ver `atelier/reference/marca.md`). Os snippets abaixo assumem que elas existem.

---

## Ordem das seções

```
1. Hero + Form      (acima da dobra — converte aqui)
2. O que você recebe (3-5 bullets de valor)
3. Autoridade/Prova  (quem é o autor + prova honesta)
4. FAQ               (4-6 objeções quebradas)
5. CTA final         (repete oferta + form, ancorado)
```

Sem header de navegação com links de fuga. No máximo o logo. A única saída fácil é converter.

---

## Página (App Router)

```tsx
// app/[isca]/page.tsx
import { Hero } from "@/components/landing/Hero";
import { OQueRecebe } from "@/components/landing/OQueRecebe";
import { Autoridade } from "@/components/landing/Autoridade";
import { FAQ } from "@/components/landing/FAQ";
import { CTAFinal } from "@/components/landing/CTAFinal";

export const metadata = {
  title: "Headline da oferta — Rodrigo Munhoz Reis",
  description: "Subhead específica que bate com o anúncio. Continuidade de promessa.",
};

export default function LandingPage() {
  return (
    <main className="min-h-screen bg-ink text-paper antialiased">
      <Hero />
      <OQueRecebe />
      <Autoridade />
      <FAQ />
      <CTAFinal />
    </main>
  );
}
```

---

## 1. Hero + Form (acima da dobra)

```tsx
// components/landing/Hero.tsx
import { CaptureForm } from "./CaptureForm";

export function Hero() {
  return (
    <section className="relative mx-auto grid max-w-6xl gap-10 px-6 py-16 md:grid-cols-2 md:items-center md:py-24">
      {/* Coluna de copy */}
      <div>
        <p className="kicker-d mb-4">E-book grátis · para quem vibecoda</p>
        <h1 className="text-grad font-fraunces text-4xl font-semibold leading-tight md:text-5xl">
          Como divulgar o que você criou sem queimar orçamento em anúncio
        </h1>
        <p className="mt-5 max-w-md text-lg text-paper/70">
          O passo a passo que transforma clique pago em base de e-mail — não em dinheiro queimado.
        </p>
      </div>

      {/* Coluna do formulário — visível sem rolar */}
      <div className="glass rounded-2xl p-6 md:p-8">
        <h2 className="font-fraunces text-xl font-medium">
          Baixe grátis agora
        </h2>
        <p className="mt-1 text-sm text-paper/55">
          Chega no seu e-mail em segundos.
        </p>
        <CaptureForm location="hero" className="mt-5" />
      </div>
    </section>
  );
}
```

---

## Formulário de captura (baixa fricção + validação + tracking)

Só e-mail (nome opcional). **Sem telefone.** Todo estado tem feedback. Evento de conversão dispara **no sucesso**.

```tsx
// components/landing/CaptureForm.tsx
"use client";

import { useState } from "react";

type Status = "idle" | "loading" | "success" | "error";

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

export function CaptureForm({
  location,
  className = "",
}: {
  location: string; // "hero" | "cta-final" — pra saber de onde converteu
  className?: string;
}) {
  const [nome, setNome] = useState("");
  const [email, setEmail] = useState("");
  const [erro, setErro] = useState<string | null>(null);
  const [status, setStatus] = useState<Status>("idle");

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErro(null);

    // Validação com feedback — nunca silenciosa
    if (!email.trim()) {
      setErro("Preciso do seu e-mail pra te mandar o material.");
      return;
    }
    if (!EMAIL_RE.test(email)) {
      setErro("Confere o e-mail — parece que falta algo (ex.: voce@email.com).");
      return;
    }

    setStatus("loading");
    try {
      const res = await fetch("/api/lead", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ nome, email, location }),
      });
      if (!res.ok) throw new Error("falhou");

      // Tracking: dispara o evento de conversão NO SUCESSO, não no clique
      window.fbq?.("track", "Lead");
      window.gtag?.("event", "generate_lead", { location });

      setStatus("success");
    } catch {
      setStatus("error");
    }
  }

  if (status === "success") {
    return (
      <div className={`glass rounded-xl p-5 text-center ${className}`}>
        <p className="font-fraunces text-lg">Pronto! Já mandei pro seu e-mail.</p>
        <p className="mt-1 text-sm text-paper/55">
          Se não chegar em 2 min, confere o spam.
        </p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} noValidate className={`space-y-3 ${className}`}>
      {/* Nome — opcional */}
      <div>
        <label htmlFor="nome" className="mb-1 block text-sm text-paper/70">
          Seu primeiro nome <span className="text-paper/40">(opcional)</span>
        </label>
        <input
          id="nome"
          type="text"
          value={nome}
          onChange={(e) => setNome(e.target.value)}
          placeholder="Como você quer ser chamado"
          className="min-h-[44px] w-full rounded-lg border border-paper/15 bg-ink/40 px-4 text-paper placeholder:text-paper/30 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/40"
        />
      </div>

      {/* E-mail — obrigatório. NUNCA telefone numa isca grátis. */}
      <div>
        <label htmlFor="email" className="mb-1 block text-sm text-paper/70">
          Seu melhor e-mail
        </label>
        <input
          id="email"
          type="email"
          inputMode="email"
          autoComplete="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          aria-invalid={!!erro}
          aria-describedby={erro ? "email-erro" : undefined}
          placeholder="voce@email.com"
          className="min-h-[44px] w-full rounded-lg border border-paper/15 bg-ink/40 px-4 text-paper placeholder:text-paper/30 focus:border-amber focus:outline-none focus:ring-2 focus:ring-amber/40"
        />
        {erro && (
          <p id="email-erro" className="mt-1 text-sm text-amber-light">
            {erro}
          </p>
        )}
      </div>

      <button
        type="submit"
        disabled={status === "loading"}
        className="btn-glow min-h-[44px] w-full rounded-lg font-medium disabled:cursor-not-allowed disabled:opacity-70"
      >
        {status === "loading" ? "Enviando..." : "Quero o e-book grátis"}
      </button>

      {status === "error" && (
        <p className="text-sm text-amber-light" role="alert">
          Algo deu errado por aqui. Tenta de novo em alguns segundos?
        </p>
      )}

      <p className="text-center text-xs text-paper/55">
        Grátis. Sem spam. Cancela quando quiser.
      </p>
    </form>
  );
}
```

---

## 2. O que você recebe

```tsx
// components/landing/OQueRecebe.tsx
const ITENS = [
  "Checklist de 12 itens para tirar a cara de protótipo da sua página.",
  "O modelo de funil pago → e-book → e-mail que transforma clique em ativo.",
  "Os 5 erros de formulário que derrubam conversão — e o ajuste de cada um.",
  "Exemplos reais de headline que param o scroll, prontos pra adaptar.",
];

export function OQueRecebe() {
  return (
    <section className="mx-auto max-w-3xl px-6 py-16">
      <p className="kicker-d mb-3">O que tem dentro</p>
      <h2 className="font-fraunces text-3xl font-semibold">O que você leva</h2>
      <ul className="mt-8 space-y-4">
        {ITENS.map((item) => (
          <li key={item} className="flex gap-3">
            <span aria-hidden className="mt-1 text-amber">▸</span>
            <span className="text-paper/85">{item}</span>
          </li>
        ))}
      </ul>
    </section>
  );
}
```

---

## 3. Autoridade / Prova

```tsx
// components/landing/Autoridade.tsx
export function Autoridade() {
  return (
    <section className="mx-auto max-w-4xl px-6 py-16">
      <div className="glass grid gap-8 rounded-2xl p-8 md:grid-cols-[auto,1fr] md:items-center">
        {/* Foto / marca do autor */}
        <img
          src="/rodrigo.jpg"
          alt="Rodrigo Munhoz Reis"
          className="h-28 w-28 rounded-2xl object-cover"
        />
        <div>
          <p className="kicker-d mb-2">Quem fez isso</p>
          <p className="text-lg text-paper/85">
            Sou <span className="accent">Rodrigo Munhoz Reis</span>. Trabalho com
            vibecoding com engenharia — construir rápido com IA, mas com método,
            pra que o que você cria realmente rode, converta e venda.
          </p>
          {/* Prova honesta — só o que for verdade */}
          <p className="mt-3 text-sm text-paper/55">
            Esse é o mesmo funil por trás da /ia-sem-medo.
          </p>
        </div>
      </div>
    </section>
  );
}
```

---

## 4. FAQ (objeções)

```tsx
// components/landing/FAQ.tsx
const PERGUNTAS = [
  { q: "É grátis mesmo?", a: "É. Você deixa o e-mail e recebe na hora, sem custo e sem pegadinha de cartão." },
  { q: "Vou receber spam?", a: "Não. Você recebe o material e, de vez em quando, conteúdo útil. Cancela quando quiser, num clique." },
  { q: "Isso é pra mim?", a: "É pra você se constrói com IA e trava na hora de divulgar e capturar leads." },
  { q: "Preciso saber programar?", a: "Não. É direto e prático — dá pra aplicar mesmo começando agora." },
  { q: "Como recebo?", a: "Chega no seu e-mail em segundos. Se não vier, confere o spam." },
];

export function FAQ() {
  return (
    <section className="mx-auto max-w-2xl px-6 py-16">
      <p className="kicker-d mb-3">Antes de você decidir</p>
      <h2 className="font-fraunces text-3xl font-semibold">Perguntas frequentes</h2>
      <div className="mt-8 space-y-3">
        {PERGUNTAS.map(({ q, a }) => (
          <details key={q} className="glass group rounded-xl p-5">
            <summary className="cursor-pointer list-none font-medium text-paper marker:hidden">
              {q}
            </summary>
            <p className="mt-2 text-paper/70">{a}</p>
          </details>
        ))}
      </div>
    </section>
  );
}
```

---

## 5. CTA final (ancorado)

Mesma oferta, mesmo CTA do hero. Repete o form (ou rola pro hero).

```tsx
// components/landing/CTAFinal.tsx
import { CaptureForm } from "./CaptureForm";

export function CTAFinal() {
  return (
    <section className="mx-auto max-w-2xl px-6 py-20 text-center">
      <h2 className="text-grad font-fraunces text-3xl font-semibold md:text-4xl">
        Pega o material grátis e para de queimar orçamento
      </h2>
      <p className="mt-3 text-paper/70">
        Deixa o e-mail e ele chega em segundos.
      </p>
      <div className="glass mx-auto mt-8 max-w-md rounded-2xl p-6 text-left">
        <CaptureForm location="cta-final" />
      </div>
    </section>
  );
}
```

---

## Rastreamento (Pixel + GA)

No `app/layout.tsx`, carregue os scripts com `next/script`. O evento de conversão é disparado **no sucesso do form** (já no `CaptureForm` acima), não no clique.

```tsx
// app/layout.tsx (trecho)
import Script from "next/script";

// dentro de <body>, antes do fechamento:
<Script id="meta-pixel" strategy="afterInteractive">{`
  !function(f,b,e,v,n,t,s){/* snippet do Meta Pixel */}
  fbq('init', 'SEU_PIXEL_ID'); fbq('track', 'PageView');
`}</Script>

<Script src="https://www.googletagmanager.com/gtag/js?id=G-XXXX" strategy="afterInteractive" />
<Script id="ga" strategy="afterInteractive">{`
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date()); gtag('config', 'G-XXXX');
`}</Script>
```

Tipos pra `window.fbq` / `window.gtag` (evita erro de TS):

```ts
// types/tracking.d.ts
interface Window {
  fbq?: (...args: unknown[]) => void;
  gtag?: (...args: unknown[]) => void;
}
```

---

## Checklist antes de publicar

- [ ] **1 oferta, 1 CTA**, repetido do hero ao fim.
- [ ] **Formulário acima da dobra**, visível sem rolar (desktop e mobile).
- [ ] **Só e-mail** (nome opcional). **Sem telefone.**
- [ ] **Validação com feedback** em todos os estados (erro, carregando, sucesso).
- [ ] **Sem menu/links de fuga** acima da dobra.
- [ ] **Headline bate com o anúncio** (continuidade de promessa).
- [ ] **Evento de conversão no sucesso** (Pixel/GA), não no clique.
- [ ] Acessibilidade: labels nos inputs, foco visível, contraste ≥ 4.5:1, alvos ≥ 44px.

A decisão é sua.
