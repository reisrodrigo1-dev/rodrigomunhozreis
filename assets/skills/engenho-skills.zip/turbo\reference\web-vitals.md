# Web Vitals — o que são, metas e o que causa cada um

As **Core Web Vitals** são as três métricas que o Google usa para medir a experiência real de carregamento, estabilidade e interatividade de uma página — e que entram no ranking de busca. Some a elas o **TTFB**, que não é uma Core Web Vital, mas é o número que segura todas as outras quando o servidor é lento.

Meça sempre em **mobile com throttling** (lab) e, de preferência, com **field data** (CrUX / `useReportWebVitals`), porque é o que o usuário real sente. Desktop com fibra mente.

As metas abaixo são os limiares do Google: **"bom"** é a meta; **"precisa melhorar"** é zona de atenção; **"ruim"** é prioridade.

---

## LCP — Largest Contentful Paint

**O que é:** o tempo até o **maior elemento visível** da dobra terminar de renderizar — normalmente a imagem do hero, um banner, ou o bloco de texto principal. É a métrica de "quão rápido a página *parece* pronta".

**Metas:**
- Bom: **< 2,5s**
- Precisa melhorar: 2,5s – 4,0s
- Ruim: > 4,0s

**O que costuma causar LCP alto:**
- **Imagem de hero pesada ou sem otimização** — PNG/JPG gigante, sem dimensão definida, sem formato moderno (WebP/AVIF), sem `priority`. Causa nº 1.
- **TTFB alto** — se o servidor demora a responder, o LCP nunca vai ser bom (LCP inclui o TTFB).
- **Fonte web bloqueante** — texto invisível esperando a fonte baixar (FOIT) ou fonte carregada tarde atrasa o LCP de texto.
- **Recurso crítico tarde na waterfall** — a imagem/CSS do LCP só começa a baixar depois de muita coisa na frente (JS bloqueante, CSS render-blocking, redirects).
- **CSR puro** — a página chega vazia e o JS precisa baixar+executar+buscar dados antes de pintar qualquer coisa.

**Por onde atacar:** otimizar a imagem do LCP (`next/image` + `priority`), pré-carregar o recurso crítico, reduzir TTFB (cache/ISR), `next/font` para fonte sem bloqueio.

---

## CLS — Cumulative Layout Shift

**O que é:** mede **quanto o layout "pula"** durante o carregamento — o conteúdo se mexe enquanto você lê ou tenta clicar. É uma pontuação sem unidade (quanto menor, melhor), não um tempo.

**Metas:**
- Bom: **< 0,1**
- Precisa melhorar: 0,1 – 0,25
- Ruim: > 0,25

**O que costuma causar CLS alto:**
- **Imagem/vídeo sem dimensão reservada** — o navegador não sabe o tamanho, pinta o que vem depois, e empurra tudo quando a mídia chega.
- **Anúncios, embeds e iframes** que carregam depois e ocupam um espaço que não estava reservado.
- **Fonte que troca de tamanho** (FOUT) — a fonte de fallback tem métrica diferente da web font e o texto reflui quando a final carrega.
- **Conteúdo injetado acima do que já está visível** — banner de cookie, alerta, skeleton que vira conteúdo de altura diferente.
- **Animações que mudam layout** (animar `width`/`height`/`top` em vez de `transform`).

**Por onde atacar:** sempre declarar `width`/`height` (ou `aspect-ratio`) em mídia; reservar caixa para ads/embeds; `next/font` com `size-adjust`; animar só `transform`/`opacity`.

---

## INP — Interaction to Next Paint

**O que é:** mede a **responsividade** — o tempo entre o usuário interagir (clicar, tocar, digitar) e a tela **pintar a resposta**. Substituiu o antigo FID em 2024 e é mais exigente: olha *todas* as interações da sessão, não só a primeira. Engasgo ao digitar/clicar = INP ruim.

**Metas:**
- Bom: **< 200ms**
- Precisa melhorar: 200ms – 500ms
- Ruim: > 500ms

**O que costuma causar INP alto:**
- **Main thread travada por JavaScript** — handler de evento que roda muito código síncrono; o navegador não consegue pintar enquanto o JS roda.
- **Bundle grande / muito JS de terceiros** — scripts pesados disputam a thread principal.
- **Re-render excessivo no React** — um clique dispara o re-render de uma árvore enorme (estado global mal posicionado, sem virtualização em listas grandes).
- **Trabalho pesado no handler** — ordenar/filtrar milhares de itens, parsear JSON gigante, layout thrashing (ler+escrever DOM em loop) na hora do clique.
- **Long tasks** (tarefas > 50ms) bloqueando a resposta.

**Por onde atacar:** quebrar long tasks (dividir trabalho, `useTransition`, debounce), reduzir/adiar JS, virtualizar listas, mover cálculo pesado para fora do caminho da interação (web worker, servidor), cortar re-renders desnecessários.

---

## TTFB — Time To First Byte

**O que é:** o tempo entre o navegador pedir a página e receber o **primeiro byte** da resposta do servidor. Não é Core Web Vital, mas é a **fundação**: TTFB alto empurra LCP e tudo mais. Inclui DNS, conexão, e o tempo do servidor gerar a resposta.

**Metas (referência):**
- Bom: **< 0,8s**
- Precisa melhorar: 0,8s – 1,8s
- Ruim: > 1,8s

**O que costuma causar TTFB alto:**
- **Render no servidor sem cache** — toda request recomputa a página (SSR puro) ou faz queries lentas antes de responder.
- **Query lenta no caminho da request** — o servidor espera o banco antes de mandar o primeiro byte (N+1, falta de índice, coleção sem paginar).
- **Cold start de função serverless** — a função "acorda" do zero (comum em rotas pouco acessadas / runtimes pesados).
- **Distância geográfica / falta de CDN/edge** — servidor longe do usuário, sem cache de borda.
- **Redirects em cadeia** antes de chegar ao conteúdo.

**Por onde atacar:** cache de página (ISR / `revalidate`, headers de cache na CDN da Vercel), Edge Runtime para reduzir cold start e distância, tirar query lenta do caminho crítico (cache, índice, paginação), eliminar redirects.

---

## Como ler o conjunto

| Métrica | Mede | Meta "bom" | Família de causa |
|--------|------|-----------|------------------|
| **LCP** | Quão rápido aparece | < 2,5s | Imagem/hero, fonte, TTFB, recurso crítico tarde |
| **CLS** | Quão estável fica | < 0,1 | Mídia/ads/fonte sem espaço reservado |
| **INP** | Quão rápido responde | < 200ms | JS na main thread, re-render, bundle |
| **TTFB** | Quão rápido o servidor responde | < 0,8s | SSR sem cache, query lenta, cold start, sem CDN |

Regra de leitura: **TTFB alto** → conserte o servidor primeiro (ele segura o LCP). **LCP alto com TTFB ok** → é recurso de carregamento (imagem/fonte/CSS). **INP alto** → é JavaScript/cliente. **CLS alto** → é espaço não reservado. Ataque a família da métrica que estourou — não tente consertar tudo de uma vez.
