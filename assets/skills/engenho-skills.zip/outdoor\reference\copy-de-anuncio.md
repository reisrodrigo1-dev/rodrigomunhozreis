# Copy de anúncio — gancho, prova, CTA

Como escrever o texto de um anúncio que faz a pessoa **clicar para baixar a isca**. Vale para Meta (texto principal/título) e Google (títulos/descrições). A copy da landing de destino é da Vitrine; aqui é só o anúncio.

Lembre da regra central: **o anúncio não vende, o anúncio compra o clique.** Não tente fechar a venda no texto. Tente fazer a pessoa querer a isca grátis. Menos é mais.

## A anatomia: gancho → prova → CTA

Todo anúncio bom tem três partes, mesmo que curtas:

1. **Gancho** — para o dedo. Toca um problema reconhecível ou faz uma promessa específica. É a parte mais importante; se o gancho falha, ninguém lê o resto.
2. **Prova** — dá um motivo para acreditar. Método, número, autoridade, demonstração.
3. **CTA** — diz a única ação. Clara, uma só.

No Meta, isso entra no texto principal (gancho nas primeiras ~125 letras) + título (a oferta) + botão (a ação). No Google, espalha-se entre os títulos e descrições.

## Fórmulas de gancho

### A) Gancho de problema (PAS — Problema, Agitação, Solução)
Nomeie a dor que a pessoa sente. Quem se reconhece, para.

> "Você usa IA pra programar e o código quebra do nada — e você nem sabe por quê."
> (problema) → "Sem entender o que o modelo fez, cada bug vira um chute." (agitação) → "Tem um jeito de construir com IA sem virar refém dela. Baixe o guia." (solução/CTA)

Para anúncio curto, muitas vezes só o problema + a saída já basta.

### B) Promessa específica
Genérico ("aprenda IA") é ignorado. **Específico** ("construa um app funcional com IA em um fim de semana, sem saber programar") para o dedo. Quanto mais concreta a promessa — o quê, em quanto tempo, para quem — melhor.

> "Construa seu primeiro sistema com IA neste fim de semana — sem escrever código sozinho."

### C) Pergunta direta
Uma pergunta que só o público-alvo responde "sim".

> "Cansado de tutorial de IA que só funciona no vídeo e quebra no seu projeto?"

### D) Contraste / quebra de expectativa
Vai contra o senso comum. Bom para a voz anti-hype.

> "IA não vai substituir você. Mas quem usa IA com método vai passar quem usa no chute."

## Fórmulas de prova

A prova responde "por que acreditar?". Escolha a que você realmente tem:

- **Método nomeado:** "Pelo método P.R.O.M.P.T.E.R. e o Protocolo de 5 Camadas." (prova de que existe sistema, não achismo)
- **Número concreto:** "47 prompts prontos", "um plano de 7 dias", "12 erros que quebram um app feito com IA".
- **Autoridade/origem:** "Escrito por quem constrói software com IA todo dia, não por quem só fala sobre."
- **Demonstração:** mostrar o resultado (no criativo/imagem — trabalho do Banner) vale mais que adjetivo.

Sem prova, o anúncio é só promessa — e promessa sem prova soa como hype, que é exatamente o que afasta esse público.

## Fórmulas de CTA

Um CTA, claro, com o que a pessoa recebe e a ausência de fricção:

- "Baixe o e-book grátis — download imediato."
- "Pega o guia gratuito (é só o e-mail)."
- "Quero o método → baixar agora."

Evite CTA vago ("saiba mais sobre nós") e evite empilhar ações ("baixe, siga e compartilhe"). Uma ação.

## Voz anti-hype (a voz do Rodrigo)

O público são founders/empreendedores que **desconfiam de promessa fácil**. Hype os afasta. Regras:

- **Sem promessa milagrosa.** Nada de "fique rico", "domine a IA em 1 dia", "o segredo que ninguém conta". Mata a confiança na hora.
- **Sem urgência falsa.** Não invente "últimas vagas" ou contador se não é verdade. Isca grátis não tem escassez crível.
- **Específico > superlativo.** "Construa um app neste fim de semana" vence "a melhor forma de aprender IA do mundo".
- **Fala de gente, não de marketeiro.** Frase curta, direta, como você explicaria para um amigo. Sem "alavanque seu potencial".
- **Honestidade sobre o esforço.** "Não é mágica, é método" funciona melhor com esse público do que "fácil e automático".
- **Devolve a decisão.** O tom respeita a inteligência de quem lê: aqui está o que é, decida você.

### Antes e depois

| Hype (evitar) | Anti-hype (usar) |
|---|---|
| "Domine a IA e fature alto sem esforço!" | "Construa com IA sem fazer besteira. Baixe o guia." |
| "O segredo que os experts escondem 🤫🔥" | "O método que eu uso pra não quebrar o código com IA." |
| "Vagas limitadas! Garanta já!" | "E-book grátis. Download imediato, sem pegadinha." |
| "Revolucione seu negócio com IA!" | "12 erros que quebram um app feito com IA — e como evitar." |

## Variações para testar

Nunca rode um anúncio só. Rode **2 a 3 variações** mudando **uma** coisa por vez, para saber o que funcionou. O que vale mais a pena variar, em ordem:

1. **O gancho** (problema vs promessa vs pergunta) — é o que mais muda a CTR.
2. **A oferta no título** ("e-book" vs "guia" vs "checklist" — mesmo conteúdo, palavra diferente).
3. **O criativo/imagem** (trabalho do Banner, mas o teste é seu).

Mantenha **público e destino iguais** entre as variações — senão você não sabe se o que mudou foi a copy ou o público. Leia o resultado no **Painel**: o gancho com maior CTR e menor custo por visualização da landing vence; pause os outros e crie novas variações em cima do vencedor.

## Exemplos prontos — tema do Rodrigo (e-book de vibecoding)

### Meta — variação A (gancho de problema)
- **Texto principal:** "Você manda a IA escrever o código, funciona na hora — e quebra três dias depois. Sem entender o que o modelo fez, cada bug vira chute. Dá pra construir com IA sem virar refém dela: é método, não sorte. Peguei tudo num e-book grátis."
- **Título:** "E-book grátis: vibecoding com engenharia"
- **Descrição:** "Download imediato. Sem enrolação."
- **CTA:** Baixar

### Meta — variação B (promessa específica)
- **Texto principal:** "Construa seu primeiro sistema com IA neste fim de semana — sem precisar saber programar, e sem o código desmoronar na primeira mudança. O guia mostra o passo a passo com método."
- **Título:** "Construa com IA, sem fazer besteira"
- **Descrição:** "Guia gratuito. É só o e-mail."
- **CTA:** Saiba mais

### Meta — variação C (contraste / anti-hype)
- **Texto principal:** "IA não vai te substituir. Mas quem usa IA com método passa quem usa no chute. Esse e-book é o método: como construir software com IA sem virar refém da ferramenta. De graça."
- **Título:** "Vibecoding com engenharia"
- **CTA:** Baixar

### Google — títulos (RSA, 30 caracteres)
- "E-book Grátis: Construir c/ IA"
- "Criar App com IA Sem Programar"
- "Vibecoding com Engenharia"
- "Método, Não Hype"
- "Construa Sem Quebrar o Código"
- "Guia Gratuito de IA p/ Founders"
- "Download Imediato"
- "Para Quem Constrói com IA"

### Google — descrições (90 caracteres)
- "Baixe o guia de vibecoding com engenharia. Construa software com IA, com método. Grátis."
- "Pare de chutar quando o código quebra. Aprenda a construir com IA sem virar refém dela."
- "Download imediato, sem enrolação. Feito por quem constrói com IA todo dia, não por quem só fala."

Ajuste cada exemplo à isca real e à oferta. O destino é sempre a landing de captura (Vitrine), com UTM para o Painel ler.
