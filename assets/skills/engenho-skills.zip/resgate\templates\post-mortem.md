# Post-mortem — [título curto do incidente]

> **Regra de ouro: sem culpa, sem caça às bruxas (blameless).**
> O objetivo não é descobrir *de quem foi a culpa*, é descobrir *o que no sistema
> deixou o erro acontecer*. Pessoas erram; sistemas bem feitos absorvem o erro.
> Se a cultura pune o autor, o próximo incidente será escondido — e aí você perde
> a chance de aprender. Escreva tudo aqui no tom de "como o sistema falhou", nunca
> "fulano falhou".

---

## Resumo

- **Data/hora do incidente:** [início] → [resolução]
- **Duração:** [quanto tempo de impacto]
- **Tipo:** [segredo vazado / dado pessoal exposto / conta comprometida / perda de
  dado / indisponibilidade]
- **Severidade:** [P1 crítico / P2 / P3]
- **Quem respondeu:** [pessoas]
- **Status:** [resolvido / mitigado / em acompanhamento]

Uma frase: *o que aconteceu, em linguagem simples.*

---

## O que aconteceu

Descreva o incidente do ponto de vista de quem foi afetado e de quem respondeu.
Sem jargão desnecessário. O que parou de funcionar / o que ficou exposto / o que
se perdeu.

---

## Impacto

Números, não adjetivos.

- **Usuários afetados:** [quantos / quais]
- **Dados envolvidos:** [quais campos; havia dado pessoal? sensível?]
- **Tempo de exposição/indisponibilidade:** [de … até …]
- **Houve acesso indevido confirmado?** [sim/não — com base em quê (logs)]
- **Comunicação LGPD necessária?** [sim/não — se sim, ANPD e/ou titulares
  comunicados em (data); prazo de 3 dias úteis cumprido?]
- **Impacto financeiro/reputacional, se houver:** […]

---

## Linha do tempo

Use os horários que você anotou durante o incidente (o registro do passo 0 do
Resgate). Cada linha: horário — fato/ação.

| Horário | O que aconteceu / ação tomada |
|---|---|
| HH:MM | [como o incidente começou / quando começou de fato] |
| HH:MM | [como foi detectado — alerta do Sentinela? cliente avisou?] |
| HH:MM | [contenção — o que se fez pra estancar] |
| HH:MM | [avaliação — alcance medido] |
| HH:MM | [comunicação — quem foi avisado] |
| HH:MM | [remediação — causa raiz consertada] |
| HH:MM | [resolução — sistema normal e confirmado] |

---

## Causa raiz

Pergunte "por quê?" até chegar no fundo — não pare no sintoma. Exemplo da
profundidade esperada:

> Sintoma: o banco ficou aberto.
> Por quê? A regra estava em modo de teste.
> Por quê? O deploy subiu sem revisar as regras.
> Por quê? Não havia passo de revisão de regras antes do deploy.
> **Causa raiz:** o processo de deploy não tinha um gate de segurança pras regras.

Descreva aqui a causa raiz **do sistema/processo**, não a ação de uma pessoa.

- **Causa imediata:** [o gatilho]
- **Causa raiz:** [a condição do sistema que permitiu]
- **Por que não foi pego antes:** [faltou alerta? teste? revisão?]

---

## O que funcionou bem

Post-mortem também celebra o que segurou a queda — pra repetir.

- [ex.: o alerta do Sentinela disparou antes do cliente reclamar]
- [ex.: o backup estava em dia e o restore foi rápido]

---

## Ações

A parte que transforma dor em prevenção. Cada ação precisa de **responsável** e
**prazo** — senão é só intenção. Mire a causa raiz, não o sintoma.

| Ação | Tipo | Responsável | Prazo | Status |
|---|---|---|---|---|
| [ex.: adicionar revisão de regras (Cofre) ao checklist de deploy] | Prevenção | [nome] | [data] | A fazer |
| [ex.: criar alerta de coleção acessada sem auth (Sentinela)] | Detecção | [nome] | [data] | A fazer |
| [ex.: configurar export agendado do Firestore (Resgate/backup)] | Resiliência | [nome] | [data] | A fazer |
| [ex.: forçar MFA em todas as contas de admin (Escudo)] | Prevenção | [nome] | [data] | A fazer |

---

## Aprendizados

Uma a três frases do que o time leva desse incidente. O que vamos fazer diferente
porque isso aconteceu. (E lembre: o incidente que te pegou de surpresa vira um
sentinela novo.)
