---
name: palco
description: Estrutura palestras e apresentações na voz e identidade do Rodrigo — do roteiro narrativo aos slides. Use ao preparar uma palestra, talk, apresentação ou aula.
---

# Palco — palestras e apresentações na voz da casa

Palco transforma uma ideia em **palestra que prende**: do roteiro narrativo aos slides na identidade do Rodrigo. Ele cuida da *narrativa* e da *direção de palco*; o visual e o motor de apresentação vêm das bases.

Palco **não reinventa** a geração de slides nem o design. Ele se apoia em três bases e adiciona a camada de narrativa e voz:

- **Motor de apresentação:** a skill **`slides`** (gera as apresentações em HTML).
- **Inteligência de design:** a skill **`canone`** (estilos, paletas, tipografia, regras de UX).
- **Marca:** a skill **`atelier`** (`reference/marca.md` — cores, tipografia, voz, efeitos).
- **Camada Palco:** estrutura narrativa, direção de fala, notas e CTA na voz do Rodrigo.

A voz é a do autor **Rodrigo Munhoz Reis** — "vibecoding com engenharia": PT-BR, direta, sem hype. **Prova antes do discurso. A decisão é sua.**

## Quando usar

Quando o pedido for preparar uma **palestra, talk, keynote, apresentação, aula ou pitch** — qualquer coisa que vá ser falada de pé, na frente de gente, com slides atrás. Se o pedido é só "monte uns slides" sem fala, ainda vale: Palco garante que os slides sigam uma narrativa, não uma lista.

## Visão geral

Uma boa palestra não é informação organizada — é **uma transformação conduzida**. A plateia entra acreditando uma coisa e sai acreditando outra, porque você a levou por um caminho. Palco existe pra montar esse caminho antes de abrir o editor de slides.

Dois erros matam palestra: (1) **muitas ideias** — ninguém lembra de sete coisas; lembram de uma; (2) **slide como teleprompter** — texto demais na tela, plateia lendo em vez de ouvindo. Palco ataca os dois: força **uma ideia central** e trata o slide como **apoio visual**, não como roteiro.

## Estrutura narrativa de uma palestra que prende

O arco tem cinco partes. Cada uma faz um trabalho específico. (Detalhe e tempos em `reference/estrutura-palestra.md`.)

1. **Gancho / promessa** — abre com uma cena, um número ou uma pergunta que cria curiosidade, e promete a transformação. Nada de "hoje vou falar sobre...". Em vez de agenda, uma fisgada.
2. **Tensão / problema** — nomeia a dor real de quem está na sala. A plateia precisa pensar "isso é comigo". Aqui entra a **confissão**: o Rodrigo conta onde ele mesmo errou ou apanhou. Vulnerabilidade real cria confiança.
3. **Virada / método** — o ponto de virada. Apresenta a ideia central, a tese, o método. É o "e se desse pra fazer diferente". Aqui a palestra muda de marcha.
4. **Prova com exemplos reais** — **prova antes do discurso.** Mostra que funciona: caso real, antes/depois, número, demonstração, história concreta. Sem prova, virada é só opinião.
5. **Chamada / próximo passo** — fecha com **uma** ação clara e do tamanho da plateia. Recapitula a ideia central em uma frase e devolve a escolha: **a decisão é sua.**

O fio que costura tudo é **uma história real**. Storytelling não é enfeite: é o que faz a plateia lembrar. Uma palestra técnica sem história é uma aula; com história, é uma palestra.

## Procedimento

1. **Defina a UMA ideia central e a transformação prometida.** Escreva em uma frase: "No fim, a plateia vai acreditar/saber/conseguir ___, que antes não ___." Se não couber em uma frase, a palestra tem ideias demais — corte.
2. **Escolha a história real.** Qual caso, erro ou virada do Rodrigo carrega essa ideia? A confissão (onde ele apanhou) costuma ser o melhor gancho.
3. **Monte o arco.** Distribua o conteúdo nas cinco partes. Marque onde entra a tensão, onde vira, onde está a prova. Defina tempo por bloco (ver `reference/estrutura-palestra.md`).
4. **Escreva os slides — 1 ideia por slide.** Pouco texto, visual forte. O slide reforça a fala, não a substitui. (Regras em `reference/design-de-slides.md`.)
5. **Prepare as falas / notas.** Para cada slide, uma nota de fala: o que dizer, a transição pro próximo, a pausa onde a frase precisa "respirar". Slide ≠ teleprompter — a fala mora na nota, não na tela.
6. **Defina o CTA.** Uma ação, clara, possível de fazer ainda hoje. Recapitule a ideia central e feche com "a decisão é sua".
7. **Gere os slides com a skill `slides`** no visual da marca (ver abaixo) e entregue **roteiro + slides + notas**. No fim, 1 nota curta do que dá pra apertar. A decisão é dele.

Para preencher antes de gerar, use `templates/roteiro-palestra.md`.

## Como gerar os slides na marca

1. **Consulte `canone`** para o padrão de design e `atelier`/`reference/marca.md` para os tokens exatos.
2. **Gere com a skill `slides`**, mas force a identidade do Rodrigo:
   - **Cores:** fundo `ink` `#070608`; texto `paper` `#F4EFE6`; destaque `amber` `#E8A33D` (número-gancho, palavra-chave, CTA).
   - **Tipografia:** títulos em **Fraunces** (serifada de alto contraste, peso 500–700); corpo em **Inter**; itálico editorial em **Instrument Serif** para um realce pontual.
   - **Densidade:** uma ideia por slide; muito respiro; âmbar só no que importa.
3. **Acessibilidade é regra:** contraste ≥ 4.5:1, tipografia grande (legível do fundo da sala), hierarquia por tamanho/peso/espaço — não só por cor.
4. **Saída:** apresentação HTML pronta pra projetar, com notas de fala por slide.

## Regras

- **Menos é mais.** Uma ideia central, uma ideia por slide, um CTA. Corte o que não serve à transformação.
- **Slide não é teleprompter.** Se a plateia consegue ler tudo, não precisa de você. Texto na tela é apoio; o conteúdo está na sua boca.
- **História real prende.** Comece pela cena, não pela agenda. Confissão > currículo.
- **Prova antes do discurso.** Mostre que funciona antes de defender por que funciona.
- **A decisão é sua.** Feche devolvendo a escolha à plateia — sem empurrão, sem hype.

## Princípio

Palestra boa é **uma ideia conduzida com prova**, não informação despejada. O slide ilumina; quem convence é a história. Premium, escuro, âmbar no que importa — e a plateia saindo diferente de como entrou.
