# Monetização e Preço

Preço é a decisão mais subestimada de quem vem da técnica. Você passou meses construindo e dois minutos pensando no preço — e o preço é o que define se tem negócio. Esta é a parte que mais dá medo e onde mais gente erra. Vamos com calma.

A verdade central: **preço não é matemática do seu custo. É o valor que você entrega ao cliente.** Quem precifica pelo custo deixa dinheiro na mesa e ainda comunica "isto vale pouco".

---

## Os três jeitos de pensar preço

### 1. Preço por custo (evite usar sozinho)
Você soma o que gastou e adiciona uma margem. Simples, mas **errado como base** para produto digital. Por quê? Seu custo de servir mais um cliente costuma ser quase zero, então o custo não tem relação com o valor. Se você cobra por custo, cobra de menos — sempre.

Use o custo apenas como **piso** (não vender abaixo disso), nunca como referência principal.

### 2. Preço por valor (o jeito certo na maioria dos casos)
Você cobra com base no **quanto vale para o cliente** resolver o problema. Pergunta-chave: *"O que acontece com o cliente se ele NÃO resolver isso? Quanto isso custa a ele?"*

Exemplo de raciocínio: se o seu produto economiza 5 horas por semana de alguém cujo trabalho vale dinheiro, ou se evita um prejuízo de milhares, o preço se ancora **nesse valor**, não no seu custo de servidor.

Preço por valor exige que você conheça o cliente e o problema dele — por isso a fase de serviço/conversa (ver `go-to-market.md`) é tão útil: ela te ensina o valor real.

### 3. Preço por uso
Você cobra conforme o consumo. Útil quando o valor entregue varia muito entre clientes. Bom para alinhar pagamento com valor, ruim para previsibilidade. Detalhado em `modelos-de-negocio.md`.

---

## Como ancorar o preço

Ancoragem é o ponto de referência que o cliente usa para julgar se seu preço é caro ou barato. Você controla essa âncora.

- **Ancore no valor, não no produto.** "Isto te economiza R$ X por mês" faz R$ 97 parecer barato. "Mais um app de R$ 97" parece caro. Mesmo preço, percepção oposta.
- **Ancore na alternativa cara.** Compare com o que o cliente gastaria sem você: contratar alguém, fazer na mão, o prejuízo de não resolver. Seu preço fica pequeno ao lado disso.
- **Use planos para criar referência (tiers).** Quando há três opções, a do meio parece a escolha sensata e a de cima faz a do meio parecer barata. Sem âncora alta, todo preço parece alto.
- **Âncora de tempo:** preço anual com desconto faz o mensal parecer caro e empurra para o anual (que melhora seu caixa e reduz churn).

---

## Estrutura de planos (tiers)

A maioria dos negócios recorrentes usa 2-3 planos. Não mais que isso no começo — excesso de opção paralisa.

Padrão que funciona:
- **Plano de entrada:** resolve o essencial, preço acessível, traz quem está testando a água.
- **Plano principal (o que você quer vender):** o de melhor custo-benefício aparente, desenhado para ser a escolha óbvia. Posicione-o no meio.
- **Plano alto:** para quem precisa de mais (mais volume, mais recursos, mais suporte). Serve também de âncora: faz o plano principal parecer barato. Sempre vai aparecer alguém que compra o caro — e você teria perdido essa receita sem oferecê-lo.

Diferencie os planos por algo que **cresce com o valor que o cliente extrai** (volume de uso, número de usuários, recursos avançados), não por mesquinharia que irrita.

---

## O erro número 1: cobrar pouco

Quem vem da engenharia quase sempre cobra **menos do que deveria**. As causas:

- **Síndrome do impostor:** "quem sou eu para cobrar isso?". O cliente não paga pelo seu currículo, paga pelo problema resolvido.
- **Ancoragem no próprio custo:** "me custou quase nada hospedar, então é justo cobrar pouco". Errado — ver acima.
- **Medo de ouvir não:** preço baixo parece reduzir a rejeição. Na prática, **preço baixo atrai cliente ruim** (que reclama mais, paga menos, sai mais rápido) e comunica baixo valor.
- **Confundir acessível com barato:** dá para ser acessível ao cliente certo sem ser barato.

Por que cobrar pouco é perigoso:
- Margem apertada deixa você sem caixa para melhorar o produto e atender bem.
- É **muito mais difícil subir preço** depois (clientes antigos reclamam) do que começar mais alto.
- Preço baixo demais gera desconfiança: "se é tão bom, por que é tão barato?".

**Regra prática:** escolha o maior preço que você consegue dizer **com a cara séria**, olhando o cliente no olho. Se você cora ao falar o preço, talvez ele ainda esteja baixo demais, não alto.

---

## O outro lado: quando o preço está alto demais

Sinais de que passou do ponto:
- Quase ninguém compra **e** quem recusa diz claramente "é o preço".
- Muita gente demonstra interesse, chega até o fim e desiste no valor.

Atenção: poucos "achei caro" são **normais e saudáveis**. Se *ninguém* acha caro, você provavelmente está cobrando de menos. O objetivo não é agradar todo mundo — é encontrar quem valoriza o suficiente para pagar bem.

---

## Como testar preço (sem chutar para sempre)

Você não acerta o preço de primeira. Ninguém acerta. Você **descobre** testando:

1. **Comece mais alto do que o confortável.** É mais fácil dar desconto/baixar do que subir. Se vender fácil demais no preço inicial, é sinal de que dava para cobrar mais.
2. **Ofereça e observe a reação real.** O que importa não é o que dizem em pesquisa ("eu pagaria"), é o que fazem quando o botão de pagar aparece. Pesquisa mente; carteira não.
3. **Teste com novos clientes, não mexa nos antigos.** Suba o preço para quem entra agora; mantenha os atuais no preço deles (grandfathering). Assim você testa sem revoltar a base.
4. **Mude uma coisa por vez.** Se mudar preço, plano e oferta juntos, não saberá o que funcionou.
5. **Use objeções como dado.** Por que recusaram? "Caro" pode significar "não entendi o valor" (problema de comunicação, não de preço). Investigue antes de baixar.
6. **Teste âncoras e estruturas, não só o número.** Às vezes o mesmo preço vende muito mais com um plano de comparação ao lado, ou cobrado anualmente.

---

## Truques honestos de monetização

- **Cobre antes de estar "pronto".** Pedir pagamento valida o negócio melhor que qualquer pesquisa. Se ninguém paga pela versão atual, mais recursos raramente resolvem.
- **Desconto anual:** troca um desconto pequeno por caixa adiantado e menos churn. Quase sempre vale.
- **Aumente preço com o tempo, para novos clientes.** Conforme o produto melhora, o preço de entrada sobe. Quem entrou antes ganha o preço antigo — e fica feliz por isso.
- **Não compita por preço.** Se a sua única vantagem é ser mais barato, alguém sempre será mais barato. Compita por valor, nicho ou atendimento.

---

## Resumo de decisão

1. Defina o **piso** (seu custo) — só para não vender no prejuízo.
2. Defina a **âncora** (o valor para o cliente / a alternativa cara) — daqui sai o preço de verdade.
3. Escolha o **maior preço defensável** com a cara séria.
4. Monte **2-3 planos**, com o do meio sendo o alvo.
5. **Teste com quem entra**, observe a carteira (não a boca), ajuste.
6. Lembre: errar para cima é corrigível; errar para baixo machuca o negócio inteiro.

A decisão de quanto cobrar é sua. Mas se você está em dúvida entre dois números, a Decolagem recomenda o mais alto — quase sempre é o certo para quem está começando.
