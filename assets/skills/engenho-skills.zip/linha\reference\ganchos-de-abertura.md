# Ganchos de abertura — o primeiro post da thread

O primeiro post é 80% do trabalho. É o único que aparece pra quem não te segue, o único que o algoritmo testa, o único que viraliza. Os outros posts só existem pra quem o primeiro convenceu a continuar. Por isso o post 1 tem duas obrigações ao mesmo tempo:

1. **Gancho** — parar o scroll.
2. **Promessa** — dizer, em uma linha, o que a thread entrega (o resultado de ler até o fim).

Regra de ouro: **a promessa do post 1 é um contrato.** O corpo da thread paga. Clickbait fisga uma vez e queima a confiança — que é o ativo do Rodrigo. Sem hype no gancho: "isso vai mudar sua vida" não é gancho, é alarme falso.

Abaixo, os padrões que funcionam, cada um com exemplos no tema do Rodrigo (vibecoding, IA, segurança, método, carreira em tech). A diferença pro post avulso (Praça): aqui o gancho **também sinaliza que vem uma sequência** e, de preferência, o tamanho dela.

---

## 1. Promessa específica

Diga, sem rodeio, o que a pessoa vai levar se ler até o fim. Específico, mensurável, com resultado claro. É o padrão mais honesto e o que melhor casa com a voz da casa.

**Por que funciona:** promete um retorno concreto pelo tempo investido. A pessoa lê porque sabe o que ganha.

Exemplos:
- "Como revisar código que a IA escreveu sem entender de programação. O processo que uso em todo projeto, em 5 passos. 🧵"
- "Subir um app pra produção com IA sem vazar os dados dos usuários. O checklist que eu queria ter tido no meu primeiro projeto. 👇"
- "Vou te mostrar como transformar uma ideia vaga num app funcional em um fim de semana — e onde quase todo mundo se enrola no caminho."

Cuidado: promessa específica obriga entrega específica. Se você não tem os 5 passos de verdade, escolhe outro padrão.

---

## 2. Número

Um número na primeira linha que também é a moldura da thread. Específico, não redondo demais. O cérebro para em número — e o número diz quantos posts vêm.

**Por que funciona:** específico = crível, e a contagem cria uma promessa aritmética (faltam X). Bom para listas.

Exemplos:
- "7 erros que cometi vibecoding e que provavelmente você tá cometendo agora. O número 4 me custou 3 dias de retrabalho. 🧵"
- "Revisei 40 projetos feitos com IA no último mês. 31 tinham a chave de API exposta no front. Os 4 padrões que se repetem — e como evitar cada um. 👇"
- "5 prompts que mudaram como eu construo software com IA. Nenhum tem mágica. Todos têm método."

Cuidado: número inventado destrói a confiança na hora. Se não tem o dado, não usa. E o corpo tem que entregar exatamente aquele número de pontos.

---

## 3. Tese contrária

Comece dizendo o oposto do que todo mundo repete. Cria atrito — a pessoa precisa saber por que você discorda, e a thread é a defesa do argumento.

**Por que funciona:** quebra o piloto automático e promete um ponto de vista, não mais do mesmo. A thread vira o desenvolvimento da tese.

Exemplos:
- "Programar com IA não te deixa mais rápido. Te deixa mais perigoso. Vou explicar por quê — e o que fazer a respeito. 🧵"
- "‘Qualquer um consegue criar um app agora.’ Sim. E é exatamente esse o problema. Abro a thread. 👇"
- "Vibecoding sem engenharia não é liberdade. É dívida técnica em tempo real. Deixa eu mostrar onde a conta chega."

Cuidado: a tese tem que se sustentar no corpo, post a post. Não é provocação vazia — é argumento que você defende com prova.

---

## 4. História

Abra no meio de uma cena real — uma confissão, um erro, um momento de virada. A thread conta o resto. É o padrão que mais gera verdade, e verdade segura a leitura.

**Por que funciona:** história ativa a curiosidade narrativa (o que aconteceu depois?). Confissão gera identificação — e o Rodrigo fala apanhando, não do pódio.

Exemplos:
- "Subi meu primeiro app com uma regra de banco aberta. Qualquer um lia os dados de qualquer usuário. Levei 3 dias pra perceber. O que aprendi naquela semana virou meu método. 🧵"
- "Gerei 600 linhas de código em 20 minutos e me senti um gênio. Depois passei 2 horas entendendo por que metade não devia existir. A thread é sobre essas 2 horas. 👇"
- "Um cliente me perguntou se o app dele era seguro. Eu não sabia responder. Foi aí que parei de só gerar código e comecei a ler. Conto a virada abaixo."

Cuidado: história precisa de payoff. Se você abre uma cena, o corpo tem que pagar — o que aconteceu, o que aprendeu. Não abandona o leitor na metade da cena.

---

## Como escolher o padrão

- Tema é uma **lista**? → Número.
- Você tem uma **opinião forte** que contraria o senso comum? → Tese contrária.
- Tem um **caso real / cicatriz**? → História (o mais forte na voz do Rodrigo).
- Quer ser **direto e útil** sem firula? → Promessa específica.

Pode combinar: História + Número é uma dupla poderosa ("Subi meu primeiro app com 3 erros graves. O terceiro vazou os dados de todo mundo."). História dá verdade; número dá moldura.

---

## Antes de seguir: o teste do post 1 isolado

Copie só o post 1 e leia como se a thread não existisse. Pergunte:

1. **Para o scroll?** A primeira linha fisga ou começa com rodeio?
2. **Promete algo claro?** Dá pra dizer numa frase o que a pessoa ganha lendo?
3. **Sustenta-se sozinho?** Faz sentido sem o post 2? (Se depende do próximo pra fazer sentido, falhou.)
4. **Dá vontade de ver o próximo?**

Se qualquer resposta for não, reescreve. É o post que mais vale o seu tempo — e o único que a maioria vai ver.
