# Avaliar um pacote novo (checklist de quarentena)

Use antes de rodar `npm install <pacote>`. Objetivo: decidir **aprovar, reprovar ou buscar alternativa.** Na dúvida, reprova — um pacote que você não consegue justificar não entra.

Fonte de dados: página do pacote no npm (`npmjs.com/package/<nome>`), o repositório vinculado, e `npm view <nome>` no terminal.

---

## Passo 0: eu preciso mesmo disso?

Antes de avaliar o pacote, avalie a necessidade. A dependência mais segura é a que você não instala.

- [ ] A função justifica uma dependência, ou são poucas linhas que eu escrevo direto?
- [ ] Já não existe algo equivalente no projeto ou na stdlib (Node, Web APIs)?
- [ ] O ganho compensa carregar essa árvore de dependências para sempre?

Se a resposta for "dá pra fazer sem", pare aqui.

---

## Checklist de reputação

Marque cada item. Vermelho não reprova sozinho, mas vários vermelhos somam.

### Nome e identidade
- [ ] Nome conferido **caractere por caractere** contra a documentação oficial (anti-typosquatting).
- [ ] Escopo (`@org/`) correto, se aplicável.
- [ ] Descrição condiz com o que eu quero — não é genérica nem copiada.

### Idade e atividade
- [ ] Pacote existe há tempo suficiente (meses/anos, não dias).
- [ ] Última publicação recente o bastante para indicar manutenção viva.
- [ ] **Atenção ao padrão suspeito:** muito tempo parado e de repente um release novo — pode ser conta comprometida. Não confunda "ativo" com "publicou agora do nada".

### Adoção
- [ ] Downloads semanais coerentes com a popularidade alegada.
- [ ] Volume baixo em algo que "todo mundo usa" = bandeira vermelha (possível typosquat).
- [ ] Usado por projetos reconhecíveis (dependents).

### Mantenedores
- [ ] Mais de um mantenedor, ou um mantenedor reconhecível/confiável.
- [ ] Pacote não depende inteiramente de uma única pessoa anônima (bus factor + risco de conta única comprometida).

### Repositório
- [ ] Link de repositório público existe e funciona. (Sem repo = bandeira vermelha forte.)
- [ ] O repo é real e ativo: commits recentes, issues respondidas, não arquivado.
- [ ] O código do repo bate com o que o pacote diz fazer (não é fachada).
- [ ] Tem licença declarada e compatível com o seu uso.

### Conteúdo e comportamento
- [ ] **`scripts`** do pacote: tem `postinstall`/`preinstall`/`install`? Se sim, o que ele faz? (Ver risco de postinstall em `riscos-supply-chain.md`.)
- [ ] Árvore de dependências enxuta — quantas sub-dependências ele arrasta? (`npm view <nome> dependencies`)
- [ ] Tamanho do pacote coerente com o propósito (algo "simples" com megabytes ou dezenas de deps merece olhar).
- [ ] Sem dependências obviamente abandonadas ou suspeitas na cadeia.

### Segurança conhecida
- [ ] Sem CVEs/advisories críticos abertos sem correção.
- [ ] Versão que vou instalar não está numa janela de comprometimento reportado.

---

## Decisão

**APROVAR** quando: nome confere, repositório real e ativo, adoção e idade saudáveis, sem scripts de install suspeitos, árvore enxuta, sem advisories abertos.

**BUSCAR ALTERNATIVA** quando: a função é necessária mas este pacote falha em reputação — procure uma lib equivalente mais sólida, ou internalize se for pequeno.

**REPROVAR** quando: sem repositório, criado há pouco com baixa adoção, nome suspeito, postinstall obscuro, mantenedor único anônimo, ou qualquer combinação que você não consiga justificar para outra pessoa.

---

## Ao instalar (depois de aprovar)

1. Instale a **versão exata** se for lib crítica: `npm install <nome>@<versão> --save-exact` (ou tire o `^` do `package.json` depois).
2. Considere `--ignore-scripts` se não houver necessidade legítima de scripts de install.
3. **Revise o diff do lockfile** — confirme que só entrou o que você esperava e que as transitivas fazem sentido.
4. Rode `npm audit` logo após instalar.
5. Commite `package.json` e lockfile juntos, no mesmo commit, com a justificativa da dependência na mensagem.
