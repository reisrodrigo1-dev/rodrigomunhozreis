# Ler o erro — stack trace, Console, Network e SSR do Next

O DevTools (F12) é onde está a verdade. Esta referência te ensina a ler cada parte.

---

## Abrindo o DevTools

- **F12**, ou **Ctrl+Shift+I** (Windows/Linux), ou **Cmd+Option+I** (Mac).
- As abas que importam pra depurar: **Console**, **Network** (Rede), **Sources** (Fontes) e às vezes **Application** (Aplicação, pra ver cookies/localStorage/token).
- Mantenha o DevTools **aberto antes** de reproduzir o erro — o Network só registra o que aconteceu com a aba aberta.

---

## Lendo o stack trace (a pilha de chamadas)

Quando o JS quebra, o navegador imprime no Console um **stack trace**: a sequência de funções que estava rodando, da mais recente (em cima) pra mais antiga (embaixo).

Exemplo:

```
Uncaught TypeError: Cannot read properties of undefined (reading 'nome')
    at renderUser (UserCard.jsx:12:18)
    at ProfilePage (ProfilePage.jsx:34:5)
    at renderWithHooks (react-dom.development.js:14985)
```

Como ler:

1. **Primeira linha = o que aconteceu.** `TypeError: Cannot read properties of undefined (reading 'nome')` → você tentou ler `.nome` de algo que era `undefined`.
2. **Segunda linha = onde aconteceu, no SEU código.** `at renderUser (UserCard.jsx:12:18)` → arquivo `UserCard.jsx`, **linha 12**, coluna 18. **Esse é o ponto de partida.** Abra esse arquivo nessa linha.
3. **Linhas seguintes = como você chegou lá.** Quem chamou `renderUser`? O `ProfilePage`. Útil pra entender o fluxo.
4. **Ignore as linhas de bibliotecas** (`react-dom`, `node_modules`, `webpack`). O bug quase sempre está no **seu** arquivo — o primeiro da pilha que você reconhece.

Dica: clique no link azul do arquivo:linha no Console — o DevTools te leva direto ao código na aba Sources.

### Stack trace minificado (produção)

Em produção o código vem minificado e o stack vira sopa de letrinhas (`at a (main.4f3c.js:1:90324)`). Soluções:

- Rode o mesmo erro **em ambiente de desenvolvimento** (`npm run dev`), onde o stack é legível.
- Ou habilite **source maps** no build pra o navegador remapear pro código original.

---

## Lendo o Console

- **Vermelho = erro** (algo quebrou). **Amarelo = warning** (aviso; nem sempre é o bug, mas leia — hidratação do Next aparece como warning).
- Leia o erro **de cima pra baixo**: nome do erro, mensagem, stack.
- Se houver muitos erros, o **primeiro** geralmente é a causa raiz; os outros costumam ser consequência. Conserte o de cima primeiro e recarregue.
- Use o filtro do Console pra esconder ruído e o campo de busca pra achar uma mensagem específica.
- Você pode digitar no Console pra **investigar**: `console.log(minhaVariavel)`, ou inspecionar o valor de algo na hora do erro com um breakpoint.

### `console.log` é seu aliado (não tenha vergonha)

Espalhe `console.log('chegou aqui', variavel)` no fluxo pra ver **o que está acontecendo de verdade**: qual valor a variável tem, se a função foi chamada, em que ordem. Depurar é tornar visível o invisível. Tire os logs depois.

---

## Lendo a aba Network (Rede)

É aqui que você vê as conversas entre o navegador e os servidores (suas APIs, o Firebase, terceiros).

1. Abra a aba **Network**, marque **Preserve log** (Preservar log) e **recarregue** a página enquanto reproduz o erro.
2. Procure linhas **vermelhas** ou com **status** na faixa de erro. Coluna **Status**:

| Status | Significa | Onde está o problema |
|---|---|---|
| **200 / 201 / 204** | Deu certo | (sem erro de rede) |
| **301 / 302 / 304** | Redirecionou / cache | Geralmente ok |
| **400** | Bad Request — você mandou algo inválido | **Seu** payload (frontend) |
| **401** | Unauthorized — não autenticado | Token ausente/expirado |
| **403** | Forbidden — autenticado, mas sem permissão | Regras de acesso (ex.: Firestore rules) |
| **404** | Not Found — rota/arquivo não existe | URL errada, ou chunk de deploy antigo |
| **422** | Dados não processáveis | Validação no backend reprovou seu payload |
| **429** | Too Many Requests | Rate limit; você chamou demais |
| **500** | Erro interno do servidor | **Backend** quebrou (veja logs do servidor) |
| **502 / 503 / 504** | Gateway/indisponível/timeout | Servidor fora, sobrecarregado ou lento |

Regra prática: **4xx = a culpa é do pedido (cliente).** **5xx = a culpa é do servidor.**

3. Clique na requisição que falhou. Abas importantes:
   - **Headers** — URL, método (GET/POST), status, e os headers enviados (inclusive o `Authorization`).
   - **Payload / Request** — o que **você mandou** (corpo da requisição, query params). Confira se mandou o que devia.
   - **Response / Preview** — o que **o servidor respondeu**. Em erro, o backend costuma mandar uma mensagem aqui ("permission-denied", "missing field email"). **Leia essa mensagem** — ela diz a causa.
   - **Timing** — quanto demorou (útil pra timeouts/504).

4. Requisição **não aparece**? Então o código nem chegou a chamar a API — o bug está **antes**, no frontend (condição que não passou, função não chamada).

---

## Erros de hidratação e SSR do Next.js

O Next renderiza HTML no **servidor** (SSR) e depois o React "assume" esse HTML no **navegador** (hidratação). Se o que o servidor gerou **não bate** com o que o cliente gera no primeiro render, dá **hydration mismatch**.

Mensagem típica:

```
Error: Hydration failed because the initial UI does not match what was rendered on the server.
Text content does not match server-rendered HTML.
```

Causas comuns e o conserto:

- **Valores que mudam entre servidor e cliente:** `Date.now()`, `new Date()`, `Math.random()`, `window`, `localStorage`. No servidor não existe `window`; o valor muda. → Renderize o conteúdo dinâmico **só no cliente** (ex.: com um estado `mounted` ativado no `useEffect`) ou use `next/dynamic` com `{ ssr: false }`.
- **Ler `window`/`document`/`localStorage` direto no corpo do componente.** No servidor isso é `undefined` e quebra. → Acesse dentro de `useEffect` (só roda no cliente) ou cheque `typeof window !== 'undefined'`.
- **HTML inválido aninhado** (ex.: `<div>` dentro de `<p>`, `<p>` dentro de `<p>`). O navegador "conserta" o HTML e o que sobra não bate com o do servidor. → Corrija o aninhamento.
- **Extensões do navegador** que mexem no HTML (tradutores, Grammarly) também causam mismatch. → Teste numa aba anônima sem extensões pra descartar.

Outros erros de SSR/Next:

- **`window is not defined` / `document is not defined` / `localStorage is not defined`** no terminal do build/servidor: você usou uma API do navegador no servidor. Mesmo conserto: só no cliente.
- **`Text content does not match`**: subconjunto do mismatch — algum texto difere. Quase sempre data/hora/random.
- **`Error: Cannot read properties of undefined`** durante SSR mas não no client: um dado que existe no navegador (token, contexto) não existe no servidor.

Regra mental: **o servidor não tem navegador.** Nada de `window`, `document`, `localStorage`, datas "agora" ou random fora do `useEffect`.

---

## Checklist rápido de leitura

1. Console: qual a primeira linha vermelha? Qual arquivo:linha do **seu** código ela aponta?
2. Network: tem requisição vermelha? Que status? O que diz a aba **Response**?
3. O erro é JS no navegador (Console) ou resposta de servidor (Network)? Isso decide frontend x backend.
4. É Next reclamando de hidratação? Procure data/random/`window` fora do `useEffect`.
5. Copiou a mensagem **inteira** pra mandar pra IA? (não só "deu erro")
