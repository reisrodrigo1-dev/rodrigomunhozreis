# Tipos de e-mail

Cada tipo abaixo tem: **objetivo**, **estrutura** e um **exemplo completo** na voz do Rodrigo. A voz é direta, PT-BR, sem hype. Trata o leitor como adulto. Ensina antes de vender. Um e-mail, um objetivo, um CTA.

Regra geral de formato para todos:
- Abertura entra direto no assunto (nada de "espero que esteja tudo bem com você").
- Parágrafos de 1 a 3 linhas. Frases curtas. Mobile-first.
- Um CTA, repetido no máximo no corpo + P.S., sempre a mesma ação.
- P.S. nunca é desperdiçado.

---

## 1. Boas-vindas / entrega da isca

**Objetivo:** cumprir a promessa na hora. A pessoa acabou de pedir o e-book; o e-mail entrega o e-book, diz quem você é em uma frase e o que esperar da lista. Nada mais. É o e-mail que define se ela vai abrir os próximos.

**Estrutura:**
1. Entrega imediata: o link do e-book, logo nas primeiras linhas. Não faça caçar.
2. Uma frase de quem você é e por que escreveu aquilo.
3. O que esperar: com que frequência você escreve e sobre o quê.
4. Um micro-CTA de início (abrir o e-book / responder dizendo o maior desafio).
5. P.S. com uma instrução prática (marcar como "não é spam" / responder este e-mail).

**Regra específica:** o CTA principal é **consumir a isca**, não comprar nada. Vender aqui queima a confiança que você ainda nem construiu.

**Exemplo completo:**

> **Assunto:** Seu e-book chegou (link aqui dentro)
>
> Aqui está o que você pediu:
>
> **[Baixar o e-book →]**
>
> Eu sou o Rodrigo. Escrevo sobre construir software com IA sem abrir mão de engenharia de verdade — o que estou chamando de "vibecoding com engenharia".
>
> Esse e-book é o melhor ponto de partida. Tira uma meia hora, lê com calma.
>
> Sobre a lista: você vai receber um e-mail meu de vez em quando, com uma ideia útil de cada vez. Sem encheção, sem "compra agora" toda semana. Quando eu tiver algo para oferecer, vou ser direto e você decide.
>
> Por enquanto, só uma coisa: abre o e-book.
>
> Abraço,
> Rodrigo
>
> **P.S.** Me responde aqui contando qual é hoje o seu maior perrengue construindo com IA. Eu leio todas e isso ajuda a escolher sobre o que escrever.

---

## 2. Nutrição / conteúdo

**Objetivo:** entregar valor real. Uma ideia útil, aplicável hoje. Constrói autoridade ensinando, não se gabando. É a maioria dos e-mails da lista — é o que mantém a pessoa abrindo.

**Estrutura:**
1. Gancho: uma observação, um erro comum, uma pergunta — algo que faz querer continuar.
2. A ideia: explique uma coisa só, bem explicada, com exemplo concreto.
3. Aplicação: o que a pessoa faz com isso hoje.
4. CTA leve: ler um artigo do blog, responder, ou só "experimenta e me conta". Sem venda.
5. P.S. com um complemento ou um gancho para o próximo e-mail.

**Regra específica:** não venda. Se você sempre ensina de graça, no dia que ofertar, a pessoa ouve. Pode mencionar o produto en passant, mas o CTA não é comprar.

**Exemplo completo:**

> **Assunto:** O bug que a IA esconde de você
>
> Tem um erro que quase todo mundo comete vibecodando, e ele é silencioso: aceitar o código que a IA gerou só porque rodou.
>
> Rodar não é estar certo. É só estar sem erro de sintaxe.
>
> Semana passada eu peguei um trecho que a IA escreveu pra mim, funcionando bonito na tela. Só que ele fazia uma chamada no banco dentro de um loop. Cem itens, cem consultas. Em produção, com mil usuários, ia derreter.
>
> A IA não errou de propósito. Ela só não sabia o contexto que você não deu.
>
> O hábito que muda o jogo é simples: antes de aceitar, faça uma pergunta a si mesmo — "se um júnior tivesse escrito isso, o que eu apontaria no code review?". Aplique isso ao código da IA. Você vai pegar 80% dos problemas em 30 segundos.
>
> Experimenta no próximo trecho que ela te gerar hoje.
>
> Abraço,
> Rodrigo
>
> **P.S.** No próximo e-mail eu mostro as 3 perguntas que eu sempre faço pra esse "code review da IA". Salva fácil de guardar.

---

## 3. Ponte para oferta

**Objetivo:** conectar um problema real (que o conteúdo já vinha tratando) à solução que o produto resolve — **sem ainda abrir a venda**. Prepara o terreno. Faz a pessoa pensar "eu queria resolver isso de forma estruturada".

**Estrutura:**
1. Nomeie o problema maior por trás dos e-mails recentes.
2. Mostre o limite de resolver isso sozinho/no improviso.
3. Aponte que existe um jeito estruturado de resolver (sem ainda vender).
4. CTA: pode ser "responde se isso é o seu caso" ou avisar que vem algo. Aquece, não fecha.
5. P.S. que planta a semente do que vem.

**Regra específica:** ponte não é venda disfarçada. É honestidade: "isso que estou ensinando aos pedaços tem uma forma completa". Não dê o preço nem o link ainda.

**Exemplo completo:**

> **Assunto:** Por que dica solta não vira competência
>
> Nos últimos e-mails eu te dei várias coisas: como revisar o código da IA, como dar contexto, como não cair na armadilha do "rodou logo tá certo".
>
> Tudo útil. Mas eu preciso ser honesto sobre uma coisa.
>
> Dica solta resolve o problema do dia. Ela não te dá um método. E é o método que faz você confiar no que entrega, parar de retrabalhar e construir mais rápido sem medo.
>
> Eu mesmo passei anos juntando truque aqui e ali até perceber que o que faltava não era mais truque — era um sistema pra pensar. Quando organizei isso, tudo mudou de patamar.
>
> Estou montando exatamente esse sistema, do começo ao fim, num material só. "Vibecoding com engenharia" de verdade, na ordem certa.
>
> Não é hoje. Mas se "juntar dica solta" é o seu momento agora, me responde só com um "sou eu". Ajuda eu calibrar o que estou preparando.
>
> Abraço,
> Rodrigo
>
> **P.S.** Quem está na lista vai saber primeiro e em melhor condição. Você não precisa fazer nada além de abrir os próximos.

---

## 4. Lançamento / oferta

**Objetivo:** o convite direto. Diz o que é, para quem é, quanto custa, até quando, e o que fazer. Honesto sobre o que entrega **e sobre o que não entrega**. Vende sem mentir.

**Estrutura:**
1. Direto ao ponto: está aberto, é isto.
2. O que é e o que a pessoa sai sabendo/tendo.
3. Para quem é — e para quem **não** é (isso aumenta a confiança).
4. Preço e condição, sem enrolar.
5. Prazo/limite **real** (data verdadeira, vagas verdadeiras — nunca falsa).
6. CTA claro, um botão/link.
7. P.S. que reforça o prazo ou tira a objeção mais comum.

**Regra específica:** urgência só se for verdade. "Até domingo" tem que fechar domingo. Se não há prazo real, não invente — venda pelo valor. Diga para quem não é; quem se exclui sozinho não pede reembolso depois.

**Exemplo completo:**

> **Assunto:** Está aberto: o método completo de vibecoding com engenharia
>
> Abri hoje o que vinha preparando: o material completo de **vibecoding com engenharia**.
>
> É o sistema inteiro, na ordem certa: como dar contexto pra IA, como revisar o que ela gera, como manter qualidade sem virar gargalo, e como construir rápido sem rezar pra não quebrar em produção.
>
> **Para quem é:** quem já usa IA pra codar e quer parar de torcer pra dar certo — quer um método pra confiar no que entrega.
>
> **Para quem não é:** quem está procurando um atalho mágico pra não precisar entender o que faz. Aqui não tem atalho; tem método. Se você quer só copiar e colar sem pensar, esse material vai te frustrar.
>
> **Investimento:** R$ 297, à vista ou parcelado.
>
> **Prazo:** as inscrições fecham **domingo, 22/06, às 23h59**. Depois disso, fecha de verdade.
>
> **[Quero o método →]**
>
> Se for o seu momento, entra. Se não for, sem problema — os e-mails de conteúdo continuam.
>
> Abraço,
> Rodrigo
>
> **P.S.** A dúvida mais comum: "preciso já saber programar?". Precisa do básico — saber ler código e mexer num projeto. Se você já vibecoda, você tem o básico. Domingo, 23h59, fecha.

---

## 5. Reengajamento

**Objetivo:** reativar quem parou de abrir, ou limpar a lista com respeito. Pergunta direta, reentrega de valor, e a porta de saída fácil. Lista limpa abre mais; respeitar quem quer sair também é honestidade.

**Estrutura:**
1. Reconheça o sumiço sem culpar ("faz um tempo que você não abre").
2. Pergunta direta: ainda quer receber?
3. Reentregue um valor rápido (um link bom, a melhor dica recente).
4. Dois caminhos claros: ficar (clicar/responder) ou sair (link de descadastro).
5. P.S. sem drama, humano.

**Regra específica:** nada de chantagem emocional ("vou sentir sua falta", "última chance pra sempre"). Respeite. Quem fica depois disso é quem realmente lê.

**Exemplo completo:**

> **Assunto:** Te tiro da lista?
>
> Reparei que faz um tempo que você não abre meus e-mails. Tudo bem — caixa de entrada lotada acontece.
>
> Mas eu prefiro escrever pra quem quer ler. Então, pergunta direta: você ainda quer receber?
>
> Se sim, é só clicar aqui que eu te mantenho:
>
> **[Quero continuar recebendo →]**
>
> E pra não vir de mãos vazias, esse aqui é o e-mail que mais ajudou gente nas últimas semanas — como fazer o "code review da IA" em 30 segundos:
>
> **[Ler isso →]**
>
> Se não fizer mais sentido, sem ressentimento: o link de descadastro está aqui embaixo e funciona em um clique.
>
> Abraço,
> Rodrigo
>
> **P.S.** Se você não fizer nada, eu vou parar de te enviar daqui a uns dias — pra não lotar sua caixa à toa. Mas a porta fica aberta: é só responder qualquer e-mail meu quando quiser voltar.
