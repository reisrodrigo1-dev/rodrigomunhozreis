# SEO on-page para posts (alinhado ao guia do Google)

Esta referência é a aplicação, para **posts de blog**, do que a Alavanca já cobre em `reference/seo.md` (Search Essentials / guia de conteúdo útil do Google). Não reescreve aquilo — foca no que muda quando o conteúdo é um artigo de autoridade. Leia os dois.

Princípio que rege tudo: **conteúdo útil, feito para pessoas (people-first), por quem tem experiência real.** O Google premia isso (E-E-A-T) e despromove texto inflado feito só para rankear. Para "vibecoding com engenharia", isso significa conteúdo de quem **faz de verdade** — não texto genérico de IA.

## 1. Intenção de busca primeiro

Antes do título, antes do gancho: **qual a intenção de quem busca?**

- **Informacional** ("o que é vibecoding") → post explica e ensina.
- **Comparativa** ("vibecoding vs no-code") → post compara com honestidade.
- **Transacional/decisão** ("como começar a programar com IA") → post entrega passo a passo acionável.

O post inteiro responde a essa intenção. Se a pessoa busca "como" e você entrega só teoria, ela sai — e o Google percebe (taxa de rejeição). Escreva para satisfazer a busca, não para falar o que você queria falar.

Pergunta de ouro do Google: **depois de ler, a pessoa sai sabendo o suficiente para resolver o problema?** Se sim, o SEO trabalha a seu favor.

## 2. Título (`<title>` / H1)

- **Único e descritivo** por post. Diz o assunto de forma clara e específica.
- **Termo importante no começo**, natural.
- **50–60 caracteres** (não corta no resultado).
- **Não empilhe palavras-chave.** Um título humano.
- O H1 da página e o `<title>` podem ser o mesmo. Um H1 por página.

## 3. Headings (H2/H3)

- Organizam o texto como **sumário lógico**. Hierarquia: H1 → H2 → H3, sem pular.
- Cada H2 é uma **subpergunta** que alguém poderia buscar. Isso ajuda a rankear para variações e a ganhar rich results.
- Use a linguagem do leitor nos headings (as palavras que ele digitaria), sem stuffing.

## 4. Meta description / excerpt

- **Resumo curto e honesto** do post (120–155 car.). Não é fator direto de ranqueamento, mas **influencia o CTR** no resultado.
- Uma por post, descrevendo aquele conteúdo. Nunca duplicada.
- Convite honesto ao clique — sem clickbait que a página não cumpre (clickbait aumenta rejeição e derruba o resultado).

## 5. URL

- **Legível e descritiva:** `/blog/metodo-prompter` em vez de `/p?id=8472`.
- Curta, com a palavra-chave, com hífens. Sem datas/IDs desnecessários.

## 6. Links internos (o que mais rende em blog)

- Conecte posts entre si e para a **isca/material** com **âncora descritiva** (o texto do link diz para onde leva — não "clique aqui").
- Distribui autoridade, ajuda o Google a entender relações, mantém o leitor no site e **alimenta o funil** (do post para a captura de e-mail).
- Meta prática por post: **2–4 links internos** — pelo menos um para um material/isca e um ou dois para posts relacionados.
- **Não invente URLs.** Se não souber a real, use placeholder explícito (`/link-do-post`) e sinalize.

## 7. E-E-A-T (Experiência, Expertise, Autoridade, Confiabilidade)

O diferencial do Rodrigo e o que o Google mais valoriza num blog:

- **Experiência:** mostre que você **fez**. Projeto real com nome e link, print, número que você mediu. "Eu rodei isso e aconteceu X" vale mais que "estudos mostram que...".
- **Expertise:** método nomeado (P.R.O.M.P.T.E.R., Protocolo de 5 Camadas), explicado por quem domina.
- **Autoridade:** consistência de tema (os pilares) e cross-link entre posts constroem autoridade do site no assunto.
- **Confiabilidade:** fonte para afirmação forte, sem promessa milagrosa, com a decisão devolvida ao leitor.

## 8. Dados e fontes

- Afirmação forte → **fonte real** (doc oficial, estudo, notícia datada, ou projeto próprio).
- **Nunca invente número, estudo ou citação.** Se não tem a fonte, não usa o número. Use WebSearch quando precisar de fato recente (post ancorado em notícia).

## Erros a evitar

- **Keyword stuffing:** repetir o termo de forma artificial **prejudica** e é spam. A palavra aparece sozinha quando o conteúdo é bom.
- **Conteúdo fino / inflado para "dar volume":** texto genérico sem profundidade nem experiência real. Google despromove. Corte enchimento.
- **Clickbait:** título/excerpt que a página não cumpre.
- **Títulos e metas duplicados** entre posts.
- **Cara de IA:** simetria perfeita, listas paralelas demais, adjetivos vazios, "no mundo de hoje". (Ver `voz.md`.)

## Checklist de SEO on-page (post)

- [ ] Intenção de busca identificada e atendida
- [ ] Título único, termo no começo, 50–60 car., sem stuffing
- [ ] Excerpt/meta única e honesta, 120–155 car.
- [ ] Um H1; H2/H3 em hierarquia lógica, headings com a linguagem do leitor
- [ ] URL legível e descritiva
- [ ] 2–4 links internos com âncora descritiva (post + isca)
- [ ] E-E-A-T: experiência real, método nomeado, prova com nome/link
- [ ] Toda afirmação forte tem fonte (nada inventado)
- [ ] Conteúdo útil de verdade (escreveria isso sem o Google existir?)
- [ ] Sem keyword stuffing, sem clickbait, sem enchimento, sem cara de IA
