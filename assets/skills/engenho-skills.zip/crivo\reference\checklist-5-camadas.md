# Checklist das 5 Camadas

Checklist operacional do Protocolo de 5 Camadas do Crivo. Passe por todos os itens relevantes ao trecho em revisão. Item marcado como problema vira achado no parecer, com `arquivo:linha`, impacto e conserto.

> Ordem importa: cada camada assume a anterior resolvida. Não blinde o que você não entendeu; não teste o que você não leu.

---

## Camada 1 — Entender

> Saber o que o código faz antes de julgar se faz bem.

### O que o código faz
- [ ] Consigo resumir em 1–2 frases o que esse trecho faz.
- [ ] O que ele faz **bate com a intenção da tarefa** (o que deveria fazer).
- [ ] Não há código que faz *mais* do que foi pedido (escopo inflado pela IA).
- [ ] Não há código que faz *menos* (parte da tarefa silenciosamente ignorada).

### Entradas e saídas
- [ ] Identifiquei todas as **entradas**: parâmetros, props, query/params, body, dados do banco, env.
- [ ] Identifiquei todas as **saídas**: retorno, escrita no banco, render, navegação, side effects.
- [ ] Sei quais saídas são **observáveis por fora** (resposta de API, mutação de estado global, log).

### Dependências
- [ ] Listei imports e libs externas usadas neste trecho.
- [ ] Listei variáveis de ambiente que ele consome (`process.env.*`).
- [ ] Listei chamadas externas: API, Firebase/Firestore, fetch, SDK de terceiros.
- [ ] Sei quais hooks/contextos React ele depende (auth, sessão, providers).
- [ ] Toda dependência usada está realmente disponível no ambiente onde isso roda (server vs client no Next.js).

### Premissas (candidatas a furo)
- [ ] Listei as premissas que o código trata como verdade ("usuário logado", "campo nunca null", "lista ordenada", "id sempre existe").
- [ ] Cada premissa tem como ser violada na vida real? (anote para as Camadas 2 e 3)
- [ ] O código roda no contexto certo? (Server Component vs Client Component, edge vs node, build vs runtime)

**Sai daqui com:** parágrafo de entendimento + lista de premissas. Desalinhamento com a intenção já é achado.

---

## Camada 2 — Ler

> Caçar erro de lógica e dívida de legibilidade.

### Lógica — fluxo feliz
- [ ] Segui o caminho principal linha a linha; a conta/transformação fecha.
- [ ] O valor de retorno é o tipo e o formato que quem chama espera.
- [ ] Não há ramo do `if/else`/`switch` que nunca é alcançado ou que cai no lugar errado.

### Lógica — edge cases
- [ ] `null` / `undefined` em cada entrada: tratado?
- [ ] String vazia `""`, número `0`, `false` — não estão sendo confundidos com "ausente" (cuidado com `if (!valor)`).
- [ ] Array/objeto vazio: o código não quebra nem assume "tem pelo menos 1".
- [ ] Lista com 1 item e lista enorme: ambos OK (sem off-by-one, sem custo explosivo).
- [ ] Número negativo, data no limite, fuso horário: tratados onde fazem sentido.
- [ ] Concorrência/duplo clique: a mesma ação disparada duas vezes não corrompe o estado.

### Condições e loops
- [ ] Sem off-by-one (`<` vs `<=`, `length` vs `length - 1`).
- [ ] Condições booleanas não estão invertidas; `&&`/`||` corretos.
- [ ] Early return não pula limpeza necessária (fechar conexão, liberar lock).
- [ ] `await` dentro de loop só quando precisa ser sequencial (senão é lentidão).

### Tratamento de erro
- [ ] Toda chamada async tem caminho de falha (`try/catch` ou `.catch`).
- [ ] Erro não é **engolido em silêncio** (catch vazio, `catch { }`).
- [ ] A mensagem de erro ajuda a diagnosticar (sem vazar dado sensível).
- [ ] Falha de uma parte não deixa o sistema em estado inconsistente (escreveu metade).

### Legibilidade e nomes
- [ ] Nomes de variáveis/funções dizem o que são/fazem; sem nome mentiroso.
- [ ] Função tem **uma** responsabilidade; não é um monstro de 200 linhas.
- [ ] Sem duplicação óbvia (mesmo bloco colado 2–3 vezes).
- [ ] Sem valor mágico solto (número/string sem nome explicando o porquê).
- [ ] Sem dead code, sem código comentado "por garantia".
- [ ] Rodei a checklist de `code-smells.md` neste trecho.

**Sai daqui com:** achados de lógica/legibilidade com `arquivo:linha`.

---

## Camada 3 — Blindar

> Assumir que o mundo é hostil e ver o que cede.

### Input do usuário
- [ ] Todo dado externo (form, query, params, body, header, upload) é **validado** antes de usar.
- [ ] Tipos são garantidos em runtime (zod/yup/validação manual), não só no TypeScript (que some no runtime).
- [ ] Tamanho/limite de input controlado (upload gigante, string de 10MB, array com 100k itens).
- [ ] Não confio em `req.body` cru nem em campo hidden do form.

### Autenticação e autorização
- [ ] O código **verifica que o usuário está autenticado** onde precisa.
- [ ] O código verifica que o usuário **pode mexer naquele recurso específico** (authz ≠ auth).
- [ ] Não dá pra acessar o recurso de outro trocando um id na URL/body (IDOR).
- [ ] Operações privilegiadas (admin, billing) checam o papel/role de verdade.
- [ ] A verificação acontece no **servidor**, não só escondendo botão no client.

### Dados sensíveis
- [ ] Senha, token, PII, dado de pagamento **não** vão para log.
- [ ] A resposta ao cliente não devolve campos sensíveis sem necessidade (ex.: hash de senha, dados internos).
- [ ] Dado sensível não fica em estado global/localStorage à toa.

### Segredos
- [ ] **Nenhuma** API key, service account, connection string ou senha hardcoded no código.
- [ ] Segredos vêm de variável de ambiente, e a `NEXT_PUBLIC_*` não carrega nada que deveria ser secreto (tudo `NEXT_PUBLIC_` vaza pro browser).
- [ ] Se achei um segredo no código: **crítico** — sinalizar e rotacionar a chave (remover do arquivo não basta).

### Firebase / banco
- [ ] A operação respeita as **regras de segurança** do Firebase/Firestore.
- [ ] Nenhuma leitura/escrita confia só na validação do client.
- [ ] Query não traz mais dados do que o usuário pode ver (filtro por dono no servidor).

### Superfície de injeção
- [ ] Sem concatenação de input em query SQL/NoSQL (usar parametrização).
- [ ] Sem `dangerouslySetInnerHTML` com conteúdo de origem não confiável.
- [ ] Sem `eval`, `new Function`, ou template de comando shell com dado externo.

### Falha segura
- [ ] Quando dá erro, o código falha **fechado** (nega acesso), não **aberto** (libera por padrão).
- [ ] Timeout/erro de dependência externa não vira "deixa passar".

**Sai daqui com:** achados de segurança/robustez. Segredo hardcoded e furo de authz tendem a **crítico**.

---

## Camada 4 — Testar

> Transformar "funcionou na tela" em "está provado".

### "Funcionou na tela" não é teste
- [ ] Rodar uma vez no happy path **não conta** como testado — anotei o que de fato foi exercitado.
- [ ] Os caminhos NÃO exercitados estão listados.

### Casos que faltam
- [ ] Cada edge case da Camada 2 tem teste (ou está listado como faltando).
- [ ] Cada cenário hostil da Camada 3 (input inválido, sem auth, recurso de outro) tem teste.
- [ ] Caminho de erro testado: rede cai, banco recusa, dependência retorna erro.
- [ ] Estados de UI: loading, vazio, erro, sucesso — todos cobertos (se for componente).

### Regressão
- [ ] Identifiquei o que mais usa essa função/componente/rota.
- [ ] A mudança não quebra um contrato existente (assinatura, formato de retorno, evento).
- [ ] Se há testes existentes, eles ainda passam.

### Checagens automáticas (ver `scripts/checagens.md`)
- [ ] `lint` rodou e passou.
- [ ] `typecheck` rodou e passou (sem `any` mascarando erro).
- [ ] `build` roda sem erro.
- [ ] Suíte de testes roda e passa.

### Reprodutibilidade
- [ ] Não funciona "só na minha máquina/sessão": sem dependência de estado local, cache ou dado que só existe aqui.
- [ ] Variáveis de ambiente necessárias estão documentadas/no `.env.example`.

**Sai daqui com:** lista de testes/checagens faltando, do mais crítico ao menos.

---

## Camada 5 — Versionar

> Garantir que o commit é seguro e contável.

### Segredo no diff
- [ ] Varri o diff inteiro: nenhum `.env`, key, token, senha, service account entrou.
- [ ] Se entrou: **pare** — remover do commit não basta, o segredo precisa ser **rotacionado**.
- [ ] (Apoio: skill **Faro** para varredura de segredos.)

### Escopo do commit
- [ ] O diff faz **uma** coisa coerente (não mistura feature + refactor + reformatação).
- [ ] Dá pra descrever o commit em uma frase sem usar "e".
- [ ] Mudanças não relacionadas foram separadas em outro commit.

### Lixo fora
- [ ] Sem `console.log`/`print` de debug.
- [ ] Sem código comentado "por via das dúvidas".
- [ ] Sem `TODO`/`FIXME` solto que deveria estar resolvido (ou virar issue).
- [ ] Sem arquivo gerado/temporário versionado por engano.
- [ ] Sem dependência adicionada e não usada.

### Mensagem e histórico
- [ ] Mensagem de commit explica o **porquê**, não só o **o quê**.
- [ ] Alguém daqui a 3 meses entende o commit pela mensagem.

### Higiene do repositório
- [ ] `.gitignore` cobre arquivos sensíveis/gerados (`.env*`, `node_modules`, `.next`, etc.).
- [ ] O commit é **reversível** limpo: se quebrar produção, dá pra dar `revert` sem arrastar meio mundo.

**Sai daqui com:** lista do que impede um commit limpo e seguro.
