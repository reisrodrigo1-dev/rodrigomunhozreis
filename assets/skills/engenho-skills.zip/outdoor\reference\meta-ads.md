# Meta Ads — montar o anúncio (Facebook / Instagram)

Como estruturar uma campanha no Meta para capturar e-mail com uma isca. Foco: o que preencher e por quê. A estratégia de canal é da Alavanca; aqui é a montagem.

## A estrutura em 3 níveis

O Meta organiza tudo em três camadas. Entender isso evita 90% da confusão:

```
CAMPANHA          -> define o OBJETIVO (o que o Meta vai otimizar)
   CONJUNTO       -> define PÚBLICO, ORÇAMENTO, POSICIONAMENTO
      ANÚNCIO      -> define o CRIATIVO (imagem/vídeo + texto + CTA)
```

Regra prática para teste: **1 campanha → 1 conjunto → 2 a 3 anúncios** (variações de criativo no mesmo público). Mais que isso pulveriza a verba e atrasa o aprendizado.

## 1. Objetivo da campanha

Você escolhe um objetivo no nível da campanha. Para o funil de isca (baixar e-book numa landing), os dois que importam:

- **Tráfego** — o Meta entrega para quem tem mais chance de clicar e visitar o site. Mais barato, bom para começar a testar mensagem e público. **Otimize a entrega por "visualizações da página de destino" (landing page views)**, não por "cliques no link". A diferença é grande: clique no link conta quem clicou; landing page view conta quem realmente carregou a sua página. É o número que vale para o funil.
- **Leads (conversões)** — o Meta entrega para quem tem mais chance de **converter** (deixar o e-mail). Mais caro por clique, mas otimiza para o resultado real. Exige o **Pixel/Conversions API instalado** e o evento de conversão (ex.: `Lead`) disparando na página de obrigado. Use quando o Tráfego já validou que a oferta converte e você quer escalar a qualidade do lead.

Recomendação prática: **comece em Tráfego** (otimizado por landing page views) para validar barato. Quando estiver convertendo e o Pixel estiver maduro com dados, migre para **Leads**.

Evite, para isca: objetivos de Reconhecimento/Alcance/Engajamento — eles otimizam para visualização e curtida, não para visita qualificada à landing.

## 2. Dark post (anúncio que não aparece no perfil)

Você quase sempre quer um **dark post** (post oculto / "unpublished page post"): o anúncio roda na timeline de quem é segmentado, **mas não fica publicado no feed da sua página**. Isso evita poluir o perfil orgânico com anúncios repetidos e permite rodar várias variações sem encher a página de posts.

Como criar: no **Gerenciador de Anúncios** (não no botão "Impulsionar" do post), ao montar o anúncio escolha **"Criar anúncio"** em vez de **"Usar publicação existente"**. O criativo nasce já como dark post. Para reaproveitar o mesmo post (e acumular curtidas/comentários em um único criativo), use o ID da publicação via "Usar publicação existente" → "Inserir ID da publicação".

O botão "Impulsionar publicação" é o oposto disso: pega um post já no feed e bota verba. Evite para campanhas sérias — dá pouco controle de objetivo, público e otimização.

## 3. Público (no nível do conjunto)

- **Por interesses/comportamento:** combine interesses ligados ao problema que a isca resolve. Para o público do Rodrigo (founders/empreendedores que constroem com IA): *empreendedorismo, startups, no-code, inteligência artificial, ferramentas como ChatGPT/Notion, pequenas empresas, marketing digital.*
- **Tamanho:** mire um público estimado entre **500 mil e alguns milhões**. Pequeno demais encarece a entrega; gigante demais demora a aprender. No teste inicial, prefira **amplo** e deixe o algoritmo refinar — o Meta hoje entrega melhor com público largo + Advantage+.
- **Não empilhe interesses demais** com "restringir público" no teste inicial. Cada camada de restrição encolhe o alcance e atrasa o aprendizado. Comece largo, leia o resultado, depois refine.
- **Localização / idioma:** Brasil, português. Ajuste idade conforme o público (ex.: 25–55).
- **Públicos personalizados / semelhantes (lookalike):** quando você já tiver uma base (lista de e-mails, visitantes do site via Pixel), crie um **lookalike 1%** dela. Costuma ser o público de melhor desempenho — mas só existe depois que você já tem dados. No primeiro anúncio, vá de interesses.

## 4. Posicionamento — Advantage+ (automático)

No nível do conjunto, em "Posicionamentos":

- **Advantage+ (posicionamentos automáticos)** — deixe o Meta distribuir entre Feed, Stories, Reels, etc. **Recomendado no teste**: dá mais superfície para o algoritmo achar conversão barata e você descobre onde seu criativo performa sem chutar.
- **Manual** — só quando você já sabe (pelo Painel) que um posicionamento converte muito melhor, ou quando o criativo só funciona num formato (ex.: vídeo vertical 9:16 só faz sentido em Stories/Reels).

Atenção ao **formato do criativo**: Advantage+ usa vários tamanhos. Garanta versões quadrada (1:1, feed) e vertical (9:16, stories/reels) da arte — isso é trabalho do **Banner**.

## 5. Orçamento de teste

- **Quanto:** **R$ 20 a 50/dia** no conjunto. Orçamento diário (não vitalício) é mais simples de controlar no teste.
- **Onde definir:** pode ser no conjunto (ABO) ou na campanha (CBO/Advantage Campaign Budget). No teste com 1 conjunto, tanto faz; com vários públicos, CBO deixa o Meta mover a verba para o que performa.
- **Otimização da entrega:** **visualizações da página de destino** (em Tráfego) ou **conversão de Lead** (em Leads). Nunca otimize por "cliques no link" para isca — você paga por curiosos que nem carregam a página.
- **Janela:** rode **3 a 7 dias** sem mexer. O Meta tem uma fase de aprendizado (~50 eventos de otimização) em que o custo oscila. Mexer no meio reseta o aprendizado e queima verba.

## 6. Campos do criativo (no nível do anúncio)

Estes são os campos que você de fato preenche. Limites são aproximados e a recomendação é ser mais curto que o limite — o Meta corta com "...Ver mais".

| Campo | O que é | Recomendação |
|---|---|---|
| **Texto principal** (primary text) | O corpo, acima da imagem. É o **gancho**. | As ~125 primeiras letras aparecem antes do "Ver mais". Coloque o gancho + a promessa nelas. Prova e CTA vêm depois. |
| **Título** (headline) | A linha em negrito abaixo da imagem. | Curto e direto, ~40 letras. A oferta concreta: "E-book grátis: vibecoding com engenharia". |
| **Descrição** (link description) | Linha secundária abaixo do título (nem sempre aparece). | Reforço opcional. Ex.: "Download imediato. Sem enrolação." |
| **CTA (botão)** | Botão padronizado do Meta. | Para isca: **"Saiba mais"** ou **"Baixar"**. Evite "Comprar agora" (é grátis). |
| **Mídia** | Imagem ou vídeo. | Arte feita no **Banner**. Versões 1:1 e 9:16. |
| **URL de destino** | Link da landing. | A **landing de captura** (Vitrine), com UTM para o Painel ler depois (ex.: `?utm_source=meta&utm_campaign=ebook-vibecoding`). |

A escrita de cada campo (gancho/prova/CTA e variações) está em `copy-de-anuncio.md`.

## Checklist antes de publicar

- [ ] Objetivo = Tráfego (ou Leads se o Pixel está pronto)
- [ ] Otimização da entrega = visualizações da página de destino (ou Lead)
- [ ] Anúncio criado como **dark post** (via Gerenciador, não "Impulsionar")
- [ ] Público por interesses, amplo, BR/PT
- [ ] Posicionamento Advantage+
- [ ] Orçamento R$ 20–50/dia, diário
- [ ] 2–3 variações de criativo (mesmo público)
- [ ] URL = landing de captura, com UTM
- [ ] Pixel disparando na página de obrigado (se for medir conversão)

Depois que rodar e juntar dados, a leitura é com o **Painel**.
