---
name: turbo
description: Otimiza performance — Core Web Vitals, bundle, queries lentas. Use quando o site/app está lento, quando os números do Lighthouse/Web Vitals estão ruins, ou antes de escalar.
---

# Turbo

Acelerador de performance para apps modernos: deixa o app **rápido de verdade** — Core Web Vitals, tamanho do bundle e queries — atacando o gargalo certo, não o que parece óbvio.

> Regra de ouro: **MEÇA antes de otimizar — não chute.**
> O gargalo quase nunca é onde a intuição aponta. Otimizar no escuro custa tempo e adiciona complexidade sem mover o número. Primeiro você mede, descobre o que realmente está pesando, conserta **o de maior impacto**, e mede de novo para provar que melhorou. A decisão de onde investir o esforço é sua — mas decida com o profiler na frente.

## Visão geral

Performance é um problema de **medição**, não de adivinhação. Três coisas dominam a experiência de um app web moderno:

1. **Carregamento (Core Web Vitals)** — quão rápido a página fica visível, estável e interativa. Medido por LCP, CLS, INP, TTFB.
2. **Bundle (JavaScript)** — quanto JS o navegador precisa baixar, parsear e executar antes de a página funcionar. Bundle grande mata o tempo de interação, principalmente no celular.
3. **Dados (queries)** — quão rápido o backend devolve os dados. Queries lentas, N+1, falta de índice e ausência de cache seguram a página inteira.

O Turbo faz quatro coisas, nesta ordem, sempre:

1. **Mede** — coleta números reais (Lighthouse, Web Vitals, Network, profiler).
2. **Acha o gargalo real** — lê os números e identifica o que está dominando, não o que incomoda visualmente.
3. **Otimiza pelo de maior impacto** — um conserto por vez, começando pelo que move mais o número.
4. **Mede de novo** — confirma que melhorou (e que não piorou outra coisa).

A saída nunca é "deixei mais rápido". É **número antes → conserto aplicado → número depois**.

> Turbo é irmão do **Termômetro** (custo) na suíte Engenho. Performance e custo se cruzam o tempo todo: uma query mal feita é lenta **e** cara, egress sem cache é devagar **e** caro. Quando uma otimização também corta a fatura, vale dizer. Quando o foco for a conta, chame o Termômetro.

## Quando usar

- O site/app está **lento** — demora a aparecer, trava ao interagir, "pula" o layout.
- Os números do **Lighthouse / PageSpeed / Web Vitals** estão ruins ou no vermelho.
- **Antes de escalar** — garantir que não vai cair com mais usuários.
- O **bundle JS** cresceu e o "Time to Interactive" piorou.
- Uma **tela/lista específica** demora a carregar os dados.
- O **React re-renderiza demais** (digita num campo e a tela inteira engasga).
- Antes de uma campanha de tráfego — uma landing lenta queima dinheiro de anúncio.

## Procedimento

### 1. Medir (antes de tocar em qualquer código)

Colete números **reais**. Sem baseline, você não tem como provar que melhorou — e pode até piorar sem perceber.

Ferramentas, por camada:

- **Core Web Vitals / carregamento:**
  - **Lighthouse** (Chrome DevTools → aba Lighthouse, ou `npx lighthouse <url>`) — rode em **modo mobile** e com **throttling**, porque é onde dói. Desktop sempre parece bom.
  - **PageSpeed Insights** (pagespeed.web.dev) — dá **lab** (Lighthouse) e, melhor ainda, **field data** (CrUX) — o que usuários reais sentiram.
  - **next/web-vitals** — em Next.js, exporte a função `reportWebVitals` ou use o hook `useReportWebVitals` para mandar LCP/CLS/INP reais para o seu analytics. Field data > lab data.
- **Bundle JS:**
  - `@next/bundle-analyzer` — mostra o que está dentro do bundle (`ANALYZE=true npm run build`). Procure dependências gordas e duplicadas.
  - Aba **Coverage** do DevTools — mostra quanto do JS/CSS baixado nunca foi usado.
  - `next build` já imprime o tamanho de cada rota (First Load JS) — leia essa tabela.
- **Queries / dados:**
  - Aba **Network** do DevTools — ordene por **tempo** e por **tamanho**. Ache a request que segura a página (a "waterfall" mais longa).
  - Logs do backend / Firestore — número de leituras por tela, latência da query.
  - Para Firestore: olhe **quantos documentos** uma tela lê. 1 lista sem paginar pode ler centenas de docs.
- **Re-render do React:**
  - **React DevTools → Profiler** — grava uma interação e mostra quais componentes renderaram e quanto cada um custou. Ative "Highlight updates" para ver re-renders piscando na tela.

Anote o **baseline**: LCP, CLS, INP, TTFB, First Load JS, e o tempo/tamanho da request crítica. Esses são os números que você vai bater no fim.

### 2. Achar o gargalo real

Com os números na mão, identifique **o que domina**. Não comece pelo que te irrita visualmente — comece pelo que o profiler diz que custa mais.

- Veja `reference/web-vitals.md` para entender **o que cada métrica significa e o que normalmente a causa**. Cada Web Vital ruim aponta para uma família de problemas diferente.
- Pergunte, em ordem:
  1. Qual métrica está fora da meta? (LCP? INP? CLS? TTFB?)
  2. O que a Network mostra como **caminho crítico** — o que precisa terminar antes de a página servir?
  3. O peso está no **servidor** (TTFB/query alto) ou no **cliente** (bundle/render alto)?
- Regra prática: **um gargalo costuma dominar.** Ache o maior, conserte, remeça. Otimizar cinco coisas pequenas de uma vez te impede de saber o que funcionou.

### 3. Otimizar pelo de maior impacto

Aplique **um conserto por vez**, começando pelo de maior ROI. Use:

- `reference/otimizacoes-por-sintoma.md` — catálogo **sintoma → conserto**. Vá direto no sintoma que você mediu.
- `reference/checklist-performance.md` — checklist priorizado por impacto, específico para **Next.js / Vercel / Firebase**.

Princípios ao consertar:

- **Maior impacto primeiro.** Cortar 300KB de JS de uma rota muda mais que renomear três variáveis.
- **Não adicione complexidade que você não mediu precisar.** `memo`/`useMemo` em tudo é micro-otimização que muitas vezes não move número — e dificulta a leitura. Meça, depois aplique onde o Profiler apontou.
- **Cuidado com regressão.** Uma otimização (ex.: cache agressivo) pode quebrar correção ou frescor de dados. Performance nunca vale um bug.
- Quando o conserto também **corta custo** (query, egress), registre — é argumento extra.

### 4. Medir de novo

Rode **as mesmas medições** do passo 1, nas mesmas condições (mesmo device/throttling).

- Compare número a número: LCP antes/depois, First Load JS antes/depois, tempo da request crítica antes/depois.
- Confirme que **não piorou outra coisa** (ex.: melhorou LCP mas estourou CLS).
- Se o número não mexeu, **reverta** — você consertou o gargalo errado. Volte ao passo 2.

## Saída

Entregue sempre:

1. **Baseline → resultado** — tabela com a métrica, o número antes e o número depois.
2. **Gargalo identificado** — o que estava dominando, com a evidência (qual ferramenta, qual número).
3. **Conserto aplicado** — o que mudou e por quê, na ordem de impacto.
4. **Próximo passo** — o próximo gargalo na fila, se ainda houver. A decisão de continuar é sua.

> Lembre o usuário: as **metas** das Web Vitals (LCP < 2,5s, INP < 200ms, CLS < 0,1) são referência do Google para "bom" — buscar o número perfeito tem retorno decrescente. Performance é o que o **usuário real no celular** sente (field data), não o Lighthouse no seu desktop com fibra.
