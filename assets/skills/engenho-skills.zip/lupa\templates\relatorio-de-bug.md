# Relatório de bug

Preencha isto antes de pedir ajuda (pra IA ou pra outra pessoa). Um relatório completo é a diferença entre "resolvido em 1 tentativa" e "deu erro, arruma aí" → vai e volta infinito.

Apague as instruções entre colchetes ao preencher.

---

## Resumo em uma frase

[O que está quebrado, em uma linha. Ex.: "O botão Salvar do formulário de perfil não envia e mostra erro no console."]

---

## Passos para reproduzir

[A sequência EXATA pra fazer o erro acontecer. Numerada. Qualquer um deve conseguir repetir seguindo isto.]

1.
2.
3.

**Acontece sempre ou às vezes?** [sempre / às vezes — se às vezes, o que muda: usuário logado?, dado específico?, primeira vez?, mobile?]

---

## Esperado x Obtido

- **Esperado:** [o que deveria acontecer]
- **Obtido:** [o que acontece de verdade]

---

## Evidência (F12)

**Mensagem de erro completa (Console)** — cole o texto LITERAL e INTEIRO, com o stack trace:

```
[cole aqui — não resuma, não corte o stack]
```

**Arquivo:linha que o stack apontou:** [ex.: UserCard.jsx:12]

**Aba Network** (se for erro de requisição):
- Requisição: [método + URL — ex.: POST /api/profile]
- Status: [ex.: 403]
- Response (o que o servidor respondeu): [cole a mensagem — ex.: "permission-denied"]
- Payload (o que você mandou): [cole se relevante]

**Print / log adicional:** [se tiver]

---

## O que mudou por último

[A última coisa alterada antes de quebrar — o suspeito nº 1. Cole o `git diff`, descreva o deploy, a env var nova, o pacote instalado. Se "funcionava ontem", diga o que mudou desde ontem.]

---

## O que eu já tentei

[Pra quem for ajudar não repetir caminho. Liste tentativa → resultado.]

- Tentei: [...] → resultado: [...]
- Tentei: [...] → resultado: [...]

---

## Minha hipótese (se tiver)

[Onde você acha que está e por quê. Ex.: "Acho que o `user` chega undefined porque consultei o Firestore antes do auth carregar."]

---

## Ambiente

- Onde acontece: [local / produção (Vercel) / os dois]
- Navegador: [Chrome 120 / Safari / ...]
- Dispositivo: [desktop / mobile iOS / ...]
- Branch / commit: [se souber]
- Logado? [sim, usuário X / não]

---

> **Antes de enviar pra IA:** confira se colou a mensagem de erro INTEIRA e os passos pra reproduzir. Sem isso, a IA vai chutar — e chute não conserta bug.
