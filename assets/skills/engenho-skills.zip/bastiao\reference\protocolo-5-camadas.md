# Protocolo de 5 Camadas aplicado à Segurança — Bastião

O **Protocolo de 5 Camadas** é o método do vibecoding com engenharia para tratar código gerado por IA com rigor. Aplicado à **segurança**, vira um roteiro repetível: **Entender → Ler → Blindar → Testar → Versionar**. Use sempre que for revisar ou subir uma funcionalidade que toca dados, autorização ou rede.

> A IA acelera, mas não responde pelo risco. O protocolo garante que **você** entende e blinda antes de confiar. A decisão é sua.

---

## Camada 1 — ENTENDER
**Pergunta:** o que essa funcionalidade faz com dados, identidade e rede?

Antes de qualquer linha, mapeie a **superfície de ataque**:
- **Entrada:** de onde vem dado do usuário? (form, query, body, upload, webhook, params)
- **Identidade:** quem pode acionar isso? Precisa estar logado? Precisa ser dono/admin?
- **Dado:** tem dado pessoal/sensível envolvido? (gatilho LGPD)
- **Rede:** faz `fetch` externo? Fala com terceiros (Stripe, e-mail)?
- **Segredo:** usa chave/credencial? Onde ela vive?

Saída desta camada: uma frase do tipo *"Esta rota recebe X do usuário Y autenticado, grava em Z, e chama o serviço W."* Sem isso, não dá para proteger.

---

## Camada 2 — LER
**Pergunta:** o código realmente faz o que eu acho que faz?

Leia o que a IA gerou **linha a linha**, com olhar de segurança. Não aceite "parece certo". Procure os padrões perigosos do catálogo (`vulnerabilidades.md`):
- Regras `allow ... if true`? Checagem de auth só no client?
- Query montada com string? `req.body` salvo inteiro? `dangerouslySetInnerHTML`?
- `fetch(url)` com URL do usuário? Segredo atrás de `NEXT_PUBLIC_`?
- `console.log` de body/token? Redirect/`fs.readFile` com input?

Rode a triagem automática: `scripts/scan-basico.py` para achados óbvios (segredos, regras abertas). Marque cada achado com a **prioridade** da matriz do `SKILL.md`.

Saída: lista de riscos encontrados, classificados de 🔴 a 🟢.

---

## Camada 3 — BLINDAR
**Pergunta:** como fecho cada brecha, na ordem certa?

Corrija **do crítico ao baixo**. Use os blocos prontos de `padroes-seguros.md`. Aplique **defesa em profundidade** — mais de uma camada para o mesmo risco:

| Risco | Camada 1 | Camada 2 (backup) |
|---|---|---|
| Acesso indevido a dados | regra de banco por dono | autorização no servidor |
| Input malicioso | schema (Zod) na borda | validação na regra do banco |
| XSS | escapar/ sanitizar | CSP no header |
| Abuso de API | rate limit | WAF da Vercel |
| Segredo | fora do Git + sem NEXT_PUBLIC_ | `import 'server-only'` |

Princípios ao blindar: **negue por padrão**, **menor privilégio**, **nunca confie no cliente**.

Saída: cada risco 🔴/🟠 corrigido (ou aceito conscientemente, com o porquê registrado).

---

## Camada 4 — TESTAR
**Pergunta:** a blindagem segura na prática, não só na teoria?

Teste como um atacante testaria:
- **Auth:** acesse a API sem token (curl/Postman). Deve recusar.
- **Autorização/IDOR:** logado como usuário A, tente acessar recurso do B trocando o id. Deve dar 404.
- **Regras:** rode o **Firestore Emulator** com `@firebase/rules-unit-testing` — tente ler/escrever o que não deveria.
- **Input:** mande tipo errado, campo extra, payload gigante, `../`, `<script>`. Deve validar/recusar.
- **Segredo/bundle:** procure a chave no JS servido ao navegador. Não pode estar lá.
- **Rate limit:** dispare o login N vezes. Deve travar (429).

Automatize o que der como teste de regressão (skill **Prova** gera casos de borda). Não passou? Volte à Camada 3.

Saída: evidência de que as proteções funcionam (não só "deve funcionar").

---

## Camada 5 — VERSIONAR
**Pergunta:** o histórico está limpo e o deploy é reprodutível?

- Confirme que **nenhum segredo entra no commit** (`git ls-files`, secret scanning, push protection).
- Commite o **lockfile**; deploy com `npm ci`.
- Mensagem de commit honesta sobre o que mudou na segurança.
- Repo privado/protegido; PR com revisão na `main`.
- Se um segredo já vazou no histórico: **rotacione a chave** (primeiro) e limpe o histórico (depois).
- Rode o **checklist de produção** (`padroes-seguros.md` §12) antes do deploy final.

Saída: código versionado, sem segredo, reprodutível, pronto para produção.

---

## Resumo de bolso

```
1. ENTENDER  → mapeie entrada, identidade, dado, rede, segredo
2. LER       → leia linha a linha + scan; classifique riscos (🔴→🟢)
3. BLINDAR   → corrija do crítico ao baixo; defesa em profundidade
4. TESTAR    → ataque seu próprio código; emulator; bundle limpo
5. VERSIONAR → sem segredo no Git; lockfile; checklist de produção
```

Cada camada tem skill irmã no Engenho: **Crivo** (revisão/leitura), **Cofre** (regras Firebase), **Faro** (segredos), **Quarentena** (dependências), **Prova** (testes). O Bastião é a inteligência que orquestra as cinco em torno da segurança.
