---
name: claquete
description: Estrutura roteiros de vídeo (Reels, YouTube, Shorts) com os ganchos e a estrutura anti-hype do Rodrigo, e apoia vídeo programático. Use ao escrever roteiro de vídeo, planejar conteúdo audiovisual ou montar um vídeo.
---

# Claquete — roteiros e vídeo

Duas frentes:
- **Vídeo programático** (render por código): use a skill **`remotion`** (instale-a) — é o motor que monta vídeo com React.
- **Roteiro/estrutura:** a camada Claquete, com a estrutura e a voz do Rodrigo (`reference/estrutura-roteiro.md`).

## Quando usar
Ao escrever roteiro de Reels/Shorts/YouTube, planejar uma série de conteúdo, ou montar um vídeo programático.

## Procedimento (roteiro)
1. **Defina o gancho** (primeiros 3 segundos) — sem ele, ninguém fica.
2. **Siga a estrutura** da casa (ver `reference/estrutura-roteiro.md`): Gancho → Tensão → Método → Prova → CTA suave.
3. **Voz anti-hype:** específico, real, sem promessa milagrosa. "A decisão é sua."
4. **Entregue:** roteiro com marcação de tempo + sugestão de corte/visual por trecho.

Para renderizar por código, passe o roteiro pro `remotion`.

## Princípio
Vídeo que retém é **estrutura + verdade**, não edição frenética. Gancho honesto, método claro, prova com nome e link.
