# Estrutura de palestra — o arco narrativo detalhado

Uma palestra é uma **transformação conduzida**: a plateia entra acreditando uma coisa e sai acreditando outra. O arco abaixo é a estrada que leva ela de um ponto ao outro. Cinco partes, cada uma com um trabalho específico — pule uma e a estrada quebra.

Os tempos assumem uma palestra de **~30 minutos** (o formato mais comum). Ao lado de cada bloco há a proporção (%) para você reescalonar para qualquer duração: talk de 18 min, keynote de 45, aula de 50.

---

## Visão geral do arco

| # | Parte | Trabalho | % do tempo | ~30 min |
|---|-------|----------|-----------|---------|
| 1 | Gancho / promessa | Fisgar e prometer a transformação | 10% | ~3 min |
| 2 | Tensão / problema | Fazer a dor ser "comigo" + confissão | 20% | ~6 min |
| 3 | Virada / método | Apresentar a ideia central / a tese | 15% | ~4–5 min |
| 4 | Prova com exemplos reais | Mostrar que funciona | 40% | ~12 min |
| 5 | Chamada / próximo passo | Recapitular + 1 ação clara | 15% | ~4–5 min |

A maior fatia é a **prova**. Palestra não convence pela tese — convence pela evidência da tese. "Prova antes do discurso."

---

## 1. Gancho / promessa — ~10% (≈3 min)

**Objetivo:** nos primeiros 30–60 segundos, a plateia decide se vai te ouvir ou abrir o celular. Você fisga *antes* de se apresentar.

**O que vai aqui:**
- **A fisgada** — uma de três: uma **cena** ("Três da manhã, deploy quebrado, e o código que quebrou era meu — escrito por uma IA que eu confiei demais"), um **número** ("70% do código desse produto eu não digitei") ou uma **pergunta** que a plateia não sabe responder.
- **A promessa** — em uma frase, a transformação: "No fim, você vai saber separar o vibecoding que entrega do que te enterra em dívida técnica."
- **(Opcional) uma frase de quem é você** — *depois* da fisgada, não antes. Currículo não fisga.

**O que NÃO vai:** "Bom dia, meu nome é..., hoje vou falar sobre..., a agenda é...". Agenda mata curiosidade. Se precisar situar, faça com a promessa, não com tópicos.

**Slides:** 1 a 2. Capa (título Fraunces, fundo `ink`) e, se útil, o número-gancho em âmbar gigante.

---

## 2. Tensão / problema — ~20% (≈6 min)

**Objetivo:** a plateia precisa pensar "isso é exatamente o meu problema". Sem tensão, não há alívio — e sem alívio, a virada não tem força.

**O que vai aqui:**
- **A dor nomeada** — o problema real de quem está na sala, descrito com especificidade. Quanto mais concreto, mais a plateia se reconhece.
- **A confissão** — onde o **Rodrigo** mesmo errou, apanhou, pagou o preço. Esse é o coração da seção. Vulnerabilidade real é o que compra confiança: "Eu também caí nessa, e foi caro." Confissão > currículo.
- **O custo de não resolver** — o que acontece se nada mudar. Sobe a aposta.

**O que NÃO vai:** transformar isso em lista de bullets de "problemas do mercado". Tensão é sentida, não listada. Uma história específica vale dez estatísticas.

**Slides:** 2 a 4. Cenas, não tópicos. Uma imagem forte ou uma frase só.

---

## 3. Virada / método — ~15% (≈4–5 min)

**Objetivo:** o ponto de virada. Aqui a palestra muda de marcha — sai do problema e entra na solução. É o "e se desse pra fazer diferente".

**O que vai aqui:**
- **A ideia central** — a tese, dita de forma limpa e memorável. É a frase que você quer que a plateia repita no corredor. Uma só.
- **O método / o princípio** — o "como" em alto nível: o jeito de pensar que resolve a tensão. Ainda não é a prova; é a lógica.
- **O reframe** — mostrar o problema sob nova luz: "o problema não era a IA, era a ausência de engenharia em volta dela".

**O que NÃO vai:** detalhamento técnico exaustivo. A virada é o conceito; a prova vem depois. Não afogue a tese em passos.

**Slides:** 1 a 3. A ideia central merece um slide só pra ela — título Fraunces, palavra-chave em âmbar, nada mais.

---

## 4. Prova com exemplos reais — ~40% (≈12 min)

**Objetivo:** transformar opinião em evidência. Esta é a maior fatia da palestra de propósito. "Prova antes do discurso."

**O que vai aqui (escolha 2–3, não todos):**
- **Caso real** — antes/depois, com contexto, decisão e resultado.
- **Número / métrica** — tempo economizado, bug evitado, custo, velocidade. Específico.
- **Demonstração** — mostrar funcionando ao vivo ou em gravação curta.
- **História concreta** — o cliente, o projeto, a virada de chave. Storytelling carrega a memória.

**Estrutura de cada prova:** situação → o que se fez → resultado → o aprendizado que reforça a ideia central. Cada prova deve apontar de volta pra tese — senão é anedota solta.

**O que NÃO vai:** prova genérica ("estudos mostram que..."), nem prova demais. Três provas fortes batem dez fracas.

**Slides:** o grosso do deck. Mas ainda **1 ideia por slide**: o número grande, o gráfico simples, o print do antes/depois. A análise está na sua fala, não na tela.

---

## 5. Chamada / próximo passo — ~15% (≈4–5 min)

**Objetivo:** a plateia sai com clareza do que fazer — e com a sensação de que a escolha é dela.

**O que vai aqui:**
- **Recapitulação em uma frase** — a ideia central, repetida limpa. Feche o círculo com o gancho da abertura (volte à cena inicial: "Aquele deploy das três da manhã? Hoje ele não quebra mais — e não é porque escrevo mais código.").
- **O CTA — uma ação** — clara, do tamanho da plateia, possível de começar hoje. Não três passos: um. "Na próxima feature, escreva o teste antes de pedir o código pra IA."
- **A devolução da escolha** — "A decisão é sua." Sem empurrão, sem hype, sem desconto-relâmpago. Respeito pela plateia.

**O que NÃO vai:** encerramento morno ("é isso, obrigado"), nem CTA vago ("pensem nisso"), nem dez próximos passos.

**Slides:** 1 a 2. A frase-síntese e o CTA. Último slide pode ter só a ideia central em Fraunces sobre `ink`.

---

## Checklist do arco

- [ ] Tem **uma** ideia central — cabe em uma frase?
- [ ] A abertura fisga em 60s, sem agenda?
- [ ] A tensão tem uma **confissão** real?
- [ ] A virada apresenta a tese de forma memorável?
- [ ] A prova é a maior fatia e cada caso aponta pra tese?
- [ ] O CTA é **uma** ação, possível hoje?
- [ ] O fecho retoma o gancho e devolve a escolha?
- [ ] Uma **história real** costura o todo?
