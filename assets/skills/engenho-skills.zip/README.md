# Engenho: 50 skills para o Claude Code

Por **Rodrigo Munhoz Reis**, vibecoding com engenharia.
Página oficial e atualizações: https://rodrigomunhozreis.com.br/skills

São as skills que eu uso no dia a dia com o Claude Code: segurança, código, prompts, conteúdo, marketing e negócio. Cada uma traz o método junto, para a IA não começar do zero.

## Como instalar (1 minuto)

1. **Descompacte** este arquivo.
2. **Copie as pastas das skills** (acordo, alavanca, alicerce...) para a pasta de skills do Claude Code:
   - Windows: `C:\Users\SEU_USUARIO\.claude\skills\`
   - Mac/Linux: `~/.claude/skills/`
3. **Reinicie o Claude Code.** As skills carregam na inicialização.
4. Pronto. A skill entra sozinha quando o seu pedido combina com o que ela faz, ou você pede pelo nome (ex.: "use a Forja para montar este prompt").

> **Atenção:** cada skill precisa ficar **direto** dentro de `skills/`, assim: `~/.claude/skills/forja/SKILL.md`. Se você copiar a pasta de fora inteira (`skills/engenho-skills/forja/...`), o Claude Code não encontra.

Não precisa instalar todas. Se está começando, instale **Forja**, **Cofre** e **Tomo**, use por alguns dias e volte pelo resto.

## Skills que usam uma base

5 skills estendem uma skill pública que já existe, adicionando o método e a identidade da casa. Para usar estas, instale também a base indicada:

- **Atelier** (`atelier`) usa a base `frontend-design`
- **Cânone** (`canone`) usa a base `ui-ux-pro-max`
- **Garimpo** (`garimpo`) usa a base `deep-research`
- **Claquete** (`claquete`) usa a base `remotion`
- **Palco** (`palco`) usa a base `slides`

## Catálogo

### Segurança (8)

| Skill | Pasta | O que faz |
|---|---|---|
| **Bastião** | `bastiao` | Identifica vulnerabilidades, recomenda padrões seguros por stack e prioriza riscos do crítico ao baixo. |
| **Cofre** | `cofre` | Audita as regras do Firestore e Storage em busca de coleções abertas, validação ausente e riscos de LGPD — e entrega o conserto. |
| **Faro** | `faro` | Escaneia o repositório atrás de chaves de API e senhas vazadas, e diz como remediar. |
| **Quarentena** | `quarentena` | Audita as dependências (versões soltas, pacotes vulneráveis, supply-chain) e avalia um pacote novo antes de instalar. |
| **Crivo** | `crivo` | Revisa um código ou diff com rigor pelo Protocolo de 5 Camadas: Entender, Ler, Blindar, Testar, Versionar. |
| **Resgate** | `resgate` | Plano pra conter, comunicar e restaurar quando vaza ou quebra — e estratégia de backup pra não perder dados. |
| **Sentinela** | `sentinela` | Monta logs, captura de erros e alertas pra saber quando algo quebra em produção. |
| **Escudo** | `escudo` | Blinda a autenticação: login seguro, MFA, sessões, recuperação de senha e rate limit. |

### Desenvolvimento (13)

| Skill | Pasta | O que faz |
|---|---|---|
| **Bússola** | `bussola` | Recomenda tecnologias e arquitetura por tipo de produto, com trade-offs e perfil de custo. |
| **Planta** | `planta` | Transforma uma ideia em plano em fases e define a arquitetura antes de escrever código. |
| **Canteiro** | `canteiro` | Inicia um projeto novo já com a estrutura e os defaults de segurança certos (gitignore, env, regras fechadas, headers). |
| **Lupa** | `lupa` | Depura um erro com método: reproduz, lê o F12, isola a causa, forma hipótese e aplica o menor conserto. |
| **Prova** | `prova` | Escreve testes começando pelos casos de borda, antes de confiar que está pronto. |
| **Atelier** | `atelier` | Gera interfaces na identidade visual da marca, com acessibilidade e segurança de fábrica. |
| **Cânone** | `canone` | O padrão de boa interface — estilos, paletas, tipografia e regras de UX — aplicado à marca. |
| **Garimpo** | `garimpo` | Pesquisa multi-fonte na web com respostas e citações verificáveis — separa o ouro do ruído. |
| **Lixa** | `lixa` | Melhora a estrutura do código sem mudar o comportamento, com rede de segurança. |
| **Mudança** | `mudanca` | Conduz migrações (versão de framework, troca de stack, dados/schema) sem quebrar. |
| **Esquema** | `esquema` | Estrutura os dados (schema, relações) com foco em Firestore — modela pela query. |
| **Ponte** | `ponte` | Conecta APIs externas (pagamento, e-mail, WhatsApp, webhooks) com segurança. |
| **Turbo** | `turbo` | Otimiza Core Web Vitals, bundle e queries lentas — meça antes de otimizar. |

### Método & Prompts (6)

| Skill | Pasta | O que faz |
|---|---|---|
| **Forja** | `forja` | Constrói prompts profissionais sob medida pelo método P.R.O.M.P.T.E.R., para qualquer IA. |
| **Alicerce** | `alicerce` | Gera as instruções iniciais que ensinam a IA a trabalhar com segurança e bom design desde o primeiro comando. |
| **Lapidador** | `lapidador` | Melhora a resposta da IA por refino iterativo — diagnostica o que ficou ruim e pede o ajuste certo. |
| **Bagagem** | `bagagem` | Monta o contexto certo pra dar à IA: o que incluir, o que cortar e como organizar. |
| **Maestro** | `maestro` | Quebra uma tarefa grande em passos e os coordena — encadear, paralelizar e verificar. |
| **Síntese** | `sintese` | Resume conteúdo longo preservando o essencial — e sem inventar nada que não esteja na fonte. |

### Marketing (6)

| Skill | Pasta | O que faz |
|---|---|---|
| **Alavanca** | `alavanca` | Recomenda canal, estrutura de campanha, copy e métricas, com o método isca → e-mail → nutrição. |
| **Claquete** | `claquete` | Estrutura roteiros de vídeo (Reels, YouTube) com os ganchos e a estrutura anti-hype da casa. |
| **Ímã** | `ima` | Ajuda a escolher e criar iscas que convertem e a conectá-las ao funil. |
| **Painel** | `painel` | Lê e interpreta métricas de GA4 e anúncios e recomenda a ação. |
| **Praça** | `praca` | Escreve posts pra LinkedIn e Instagram na voz da casa, com gancho forte e sem hype. |
| **Outdoor** | `outdoor` | Estrutura anúncios pagos (Meta/Google): copy, público e orçamento de teste. |

### Conteúdo (9)

| Skill | Pasta | O que faz |
|---|---|---|
| **Tomo** | `tomo` | Cria e-books e guias em HTML no padrão editorial da casa — prontos para ler, imprimir e entregar. |
| **Vitrine** | `vitrine` | Cria landing pages de oferta única (isca + captura), feitas para tráfego pago e orgânico. |
| **Correio** | `correio` | Escreve e-mails e newsletters na voz da casa, do boas-vindas à conversão. |
| **Pena** | `pena` | Escreve posts de autoridade otimizados para SEO, ancorados no método e em notícias de IA. |
| **Palco** | `palco` | Estrutura palestras e apresentações na voz e identidade da marca — do roteiro aos slides. |
| **Baralho** | `baralho` | Estrutura carrosséis (Instagram/LinkedIn): capa-gancho, slides de desenvolvimento e CTA. |
| **Linha** | `linha` | Escreve threads (X/LinkedIn): gancho no primeiro post, um ponto por post, fechamento. |
| **Legenda** | `legenda` | Escreve legendas/captions pra posts e vídeos — primeira linha que prende, corpo e CTA. |
| **Currículo** | `curriculo` | Estrutura um curso, aula ou trilha — objetivo, módulos, progressão e prática. |

### Negócio (8)

| Skill | Pasta | O que faz |
|---|---|---|
| **Decolagem** | `decolagem` | Ajuda a escolher modelo de negócio, monetização, preço e go-to-market, com as métricas que importam. |
| **Salvaguarda** | `salvaguarda` | Mapeia dados pessoais, aponta gaps e gera Política de Privacidade e fluxo de consentimento. |
| **Termômetro** | `termometro` | Estima o custo de infra e IA por faixa de uso e sinaliza onde a conta explode antes de escalar. |
| **Acordo** | `acordo` | Cria propostas comerciais e orçamentos — problema, solução, escopo, preço e próximos passos. |
| **Pacto** | `pacto` | Rascunha contratos simples como ponto de partida (não substitui advogado). |
| **Espelho** | `espelho` | Define a persona e o cliente ideal — dor, contexto, objeções e onde encontrá-lo. |
| **Espião** | `espiao` | Analisa concorrentes (oferta, preço, posicionamento, pontos fracos) pra achar seu diferencial. |
| **Balcão** | `balcao` | Cria scripts de atendimento, vendas e suporte — primeiro contato, objeções, follow-up. |

## Uso responsável

As skills ajudam a pensar e a executar, mas não substituem revisão humana. Revise o código antes de subir, valide números antes de decidir e, em contratos ou LGPD, consulte um profissional. A Pacto e a Salvaguarda entregam ponto de partida, não parecer jurídico.

A decisão é sua.
