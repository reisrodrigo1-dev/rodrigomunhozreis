# Métricas de Negócio: o que medir, por estágio

Métrica boa é a que **muda sua próxima decisão**. Todo o resto é vaidade — dá dopamina e zero direção. Esta referência te diz **quais poucos números olhar em cada estágio** e o que cada um significa, em português, sem jargão pelo jargão.

> Princípio: não tente medir tudo. Em cada estágio há 1-3 números que importam. Olhe esses. Ignore o resto até precisar.

---

## Primeiro: métrica de verdade vs. métrica de vaidade

| Vaidade (ignore no começo) | De verdade (olhe) |
|---|---|
| Seguidores, curtidas | Clientes pagantes |
| Visitas ao site | Visitas que viraram pagamento (conversão) |
| Cadastros grátis | Quantos cadastros viram pagantes |
| Downloads | Quantos ainda usam depois de 30 dias |
| "Gente interessada" | Gente que pagou |

A pergunta-teste: *"se esse número dobrar, muda alguma decisão minha?"* Se não muda, é vaidade.

---

## Estágio VALIDAÇÃO — a única métrica que importa

Você ainda não provou que alguém paga. Esqueça dashboard. A métrica é uma só:

**Alguém pagou?** (e, em seguida, *quantos* pagaram, e *por quê*)

- Não meça tráfego, não meça engajamento. Meça **pagamentos**.
- Conte também os **"quase"**: gente que chegou perto e desistiu. Por quê desistiram é seu dado mais valioso agora.
- Sinal de validação: você consegue, repetidamente, fazer uma pessoa do nicho pagar. Mesmo que na unha.

Se ninguém paga, nenhuma outra métrica importa. Volte ao problema (ver `go-to-market.md`).

---

## Estágio TRAÇÃO — os números do negócio recorrente

Agora você tem pagantes e quer entender se isso para de pé e se repete. Aqui entram as métricas clássicas. Vou explicar cada uma como se você nunca tivesse visto.

### MRR — Receita Recorrente Mensal
*(Monthly Recurring Revenue)*

Quanto entra **todo mês de forma recorrente**. Some o valor mensal de todos os clientes ativos. É o batimento cardíaco de um negócio de assinatura.
- Anual? Divida por 12 para entrar no MRR.
- Acompanhe a **tendência**: MRR subindo mês a mês é o sinal mais importante de tração.
- ARR = MRR × 12 (a versão anual, usada para falar do tamanho do negócio).

### Churn — taxa de cancelamento

Quantos clientes (ou quanta receita) você **perde** num período, em %.
- Exemplo: 100 clientes no início do mês, 5 cancelaram → churn de 5% ao mês.
- **Por que é crítico:** churn é o ralo do balde. Você pode encher de clientes em cima, mas se vazam embaixo, nunca enche. Com 10% de churn ao mês, você troca toda a base em ~10 meses só para ficar no zero a zero.
- Churn alto = problema de **valor ou de cliente errado**. Antes de gastar mais para atrair, **tampe o ralo**. Reter é mais barato que adquirir.
- Olhe também o **motivo** dos cancelamentos — é onde está o conserto.

### Conversão

Dos que experimentam (visita, teste grátis, cadastro), quantos % viram pagantes.
- Trial → pago, visitante → comprador, etc.
- Melhorar conversão é geralmente mais barato que trazer mais gente. Se 100 entram e só 1 paga, antes de buscar mais 100, descubra por que 99 não pagaram.

---

## Estágio ESCALA — a economia da aquisição

Aqui você quer crescer **gastando para adquirir clientes**. Só faça quando já tem oferta e canal validados. As métricas que dizem se a conta fecha:

### CAC — Custo de Aquisição de Cliente
*(Customer Acquisition Cost)*

Quanto você gasta, em média, para conquistar **um** cliente pagante.
- Conta simples: tudo que gastou para atrair (anúncios, tempo, ferramentas) ÷ número de clientes que vieram disso.
- Se você gasta R$ 300 e traz 3 clientes, seu CAC é R$ 100.

### LTV — Valor do Cliente no Tempo de Vida
*(Lifetime Value)*

Quanto um cliente te paga, **somando tudo**, do começo ao fim do relacionamento.
- Estimativa simples para recorrente: valor mensal médio ÷ churn mensal. (Ex.: paga R$ 50/mês, churn 5% → LTV ≈ R$ 50 / 0,05 = R$ 1.000.)
- Quanto maior o LTV, mais você pode gastar para adquirir e mais valioso é reduzir churn (note que o churn aparece aqui também — ele afeta tudo).

### A relação LTV / CAC — a que decide se você pode escalar

Compare quanto um cliente vale (LTV) com quanto custou trazê-lo (CAC).
- Referência saudável muito usada: **LTV pelo menos ~3× o CAC**. Você ganha bem mais do que gasta para conquistar.
- LTV/CAC perto de 1 → você gasta quase tudo que ganha para adquirir: não escala, só se cansa.
- LTV/CAC alto → cada real em aquisição volta multiplicado: **acelere**.

### Payback — em quanto tempo o cliente se paga

Quantos meses até o cliente devolver o que você gastou para adquiri-lo (CAC).
- Ex.: CAC R$ 100, cliente paga R$ 50/mês → payback de 2 meses.
- Importa para o **caixa**: payback longo significa que você banca o crescimento por mais tempo antes do retorno. Payback curto deixa escalar com menos fôlego financeiro.

---

## Margem — atravessa todos os estágios

Do que o cliente paga, quanto **sobra** depois dos custos diretos de servir esse cliente.
- Produto digital costuma ter margem alta (servir mais um custa pouco) — uma das razões para esses negócios serem atraentes.
- Margem apertada limita quanto você pode investir em aquisição e em melhorar o produto. Se a margem é fina, repense preço (ver `monetizacao-e-preco.md`) antes de pensar em volume.

---

## Quadro-resumo: o que olhar em cada estágio

| Estágio | Pergunta central | Métricas que importam |
|---|---|---|
| Validação | Alguém paga? | Nº de pagantes; motivos de quem não pagou |
| Tração | Isso para de pé e se repete? | MRR (e tendência); churn; conversão |
| Escala | A conta de crescer fecha? | CAC; LTV; LTV/CAC; payback; margem |

---

## Três armadilhas comuns

1. **Medir cedo demais.** Calcular LTV/CAC quando você tem 3 clientes é teatro — os números não significam nada com amostra mínima. Na validação, só conte pagantes.
2. **Caçar vaidade.** Comemorar seguidores enquanto o churn sangra. O número bonito esconde o problema real.
3. **Atrair com o balde furado.** Gastar em aquisição com churn alto é jogar dinheiro no ralo. Conserte retenção (valor + cliente certo) antes de abrir a torneira.

Regra final: meça pouco, meça o que decide, e deixe o número apontar a próxima ação. A decisão é sua — mas decisão boa se apoia no número certo, não no número que dá orgulho.
