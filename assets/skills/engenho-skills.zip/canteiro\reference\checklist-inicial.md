# Checklist do dia zero — projeto seguro de fábrica

Use isto como porta de saída do Canteiro. Se algum item estiver desmarcado, o
canteiro ainda não está pronto. A ordem reflete o que protege o quê — não pule
para o commit antes do `.gitignore` estar certo.

## 1. Antes do primeiro commit

- [ ] `.gitignore` na raiz, baseado em `templates/gitignore.txt`.
- [ ] `.gitignore` ignora `.env`, `.env.local` e `.env*.local`.
- [ ] `.gitignore` ignora arquivos de credencial (`*firebase-adminsdk*.json`, `serviceAccount*.json`, `*.pem`, `*.key`).
- [ ] `.env.example` criado (sem valores) e este SIM vai pro Git.
- [ ] `.env.local` criado com os valores reais e NÃO aparece em `git status`.

## 2. Banco trancado antes de qualquer dado

- [ ] `firestore.rules` baseado em `templates/firestore.rules` (default `allow read, write: if false`).
- [ ] Regras publicadas: `firebase deploy --only firestore:rules`.
- [ ] Confirmado que NÃO está em "test mode" (`allow ... if true`).
- [ ] Se usar Storage: regras de Storage também fechadas por padrão.
- [ ] Cliente Firebase em `src/lib/firebase.ts` lendo só variáveis `NEXT_PUBLIC_*`.

## 3. Nenhum segredo rastreado

- [ ] `git status` limpo — nenhum `.env.local`, nenhum `.json` de service account.
- [ ] Se algo escapou: `git rm --cached <arquivo>` antes do commit.
- [ ] Nenhuma chave de Admin SDK / service account dentro do repositório.
- [ ] Nenhum valor real hardcoded no código (tudo via variável de ambiente).

## 4. Cabeçalhos de segurança

- [ ] Bloco `headers()` colado no `next.config` (ver `templates/next.config.headers.md`).
- [ ] `X-Content-Type-Options: nosniff`
- [ ] `X-Frame-Options: DENY`
- [ ] `Referrer-Policy: strict-origin-when-cross-origin`
- [ ] `Permissions-Policy` cortando câmera/microfone/geolocalização
- [ ] `Strict-Transport-Security` (HSTS) presente
- [ ] Conferido com `curl -I` que os headers aparecem.

## 5. Repositório e deploy

- [ ] Repositório criado **privado** (`gh repo create ... --private`).
- [ ] Primeiro commit já limpo de segredos.
- [ ] Variáveis cadastradas no painel da Vercel (Settings → Environment Variables).
- [ ] Valores reais existem apenas no `.env.local` e no painel da Vercel — em nenhum outro lugar.

## 6. Higiene contínua (deixar pronto pro futuro)

- [ ] Plano: abrir cada coleção do Firestore só quando tiver Auth funcionando.
- [ ] Plano: adicionar CSP depois, em report-only primeiro.
- [ ] Combinado com o time: segredo em dúvida = trata como segredo.

---

**Regra de ouro:** o que vaza no Git fica no histórico para sempre. Fechar
depois não desfaz o vazamento. Por isso o Canteiro trava tudo ANTES — não como
remendo, mas como fundação.
