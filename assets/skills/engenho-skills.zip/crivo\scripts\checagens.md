# Checagens — comandos de apoio (Camadas 4 e 5)

Comandos típicos que sustentam o "está provado" da Camada 4 (Testar) e o "commit limpo" da Camada 5 (Versionar). Stack assumida: Next.js + TypeScript + Tailwind, deploy Vercel, dados Firebase.

> Regra: nenhum veredicto **PRONTO** sai sem essas checagens rodadas. "Funcionou na tela" não substitui `typecheck` + `build` passando.

Os comandos abaixo assumem `npm`. Troque por `pnpm` / `yarn` conforme o projeto. Confira os scripts reais em `package.json` antes — nomes variam.

---

## Sequência recomendada (rápido → completo)

```bash
# 1. Lint — estilo e erros estáticos
npm run lint

# 2. Typecheck — TypeScript sem emitir build (pega o que o lint não pega)
npx tsc --noEmit

# 3. Testes — suíte automatizada
npm test            # ou: npm run test

# 4. Build — prova que compila pra produção
npm run build
```

Se qualquer um falhar, **pare** e trate antes de seguir. Falha aqui é achado da Camada 4.

---

## Lint (Camada 2 e 4)

```bash
npm run lint                 # roda o eslint do projeto (next lint, em geral)
npm run lint -- --fix        # corrige o que dá pra corrigir automaticamente
```

Sem script de lint? No Next.js:
```bash
npx next lint
```

---

## Typecheck (Camada 2 e 4)

```bash
npx tsc --noEmit             # checa tipos sem gerar arquivos
```

Por que separado do build: o `next build` pode pular checagem de tipo se `ignoreBuildErrors` estiver ligado. `tsc --noEmit` não mente. Confira se `next.config` não tem:
```js
typescript: { ignoreBuildErrors: true }   // se tiver, o build esconde erro de tipo
eslint: { ignoreDuringBuilds: true }      // idem para o lint
```

---

## Testes (Camada 4)

```bash
npm test                     # roda a suíte
npm test -- --watch          # modo watch durante o desenvolvimento
npm test -- --coverage       # relatório de cobertura
```

Vitest / Jest específicos:
```bash
npx vitest run               # vitest, uma passada
npx jest                     # jest
```

Cheque o que está coberto: cobertura alta no happy path com zero teste de erro **não** é "testado". (Geração de testes: skill **Prova**.)

---

## Build (Camada 4 e 5)

```bash
npm run build                # next build — prova que compila pra produção
```

Build local passando ≈ o que a Vercel vai rodar. Se quebra aqui, quebra no deploy.

---

## Varredura de segredos antes do commit (Camada 5)

Olhe o diff inteiro com os próprios olhos:
```bash
git diff --staged            # tudo que vai no commit
git diff --staged --stat     # visão por arquivo (pega arquivo grande/inesperado)
```

Busca rápida por padrões de segredo no que está staged:
```bash
git diff --staged | grep -nEi "api[_-]?key|secret|password|token|BEGIN .* PRIVATE KEY|service_account"
```

Confirme que arquivos sensíveis estão ignorados:
```bash
git check-ignore .env .env.local        # deve imprimir os caminhos (= ignorados)
git ls-files | grep -E "\.env"          # NÃO deve listar nenhum .env versionado
```

> Achou segredo já commitado antes? Remover num commit novo **não basta** — ele está no histórico. Rotacione a chave. (Caça a segredos: skill **Faro**.)

---

## Firebase (quando há regras/funções) (Camada 3 e 4)

```bash
firebase emulators:start                      # subir emulador pra testar regras localmente
firebase deploy --only firestore:rules --dry-run   # validar regras sem publicar
```

Auditoria das regras: skill **Cofre**.

---

## Higiene do commit (Camada 5)

```bash
git status                   # nada inesperado no stage?
git diff --staged            # revisar de novo, sem pressa
```

Caça a lixo de debug no diff:
```bash
git diff --staged | grep -nE "console\.(log|debug)|debugger|TODO|FIXME"
```

---

## Checklist mínima antes de dizer "PRONTO"

- [ ] `lint` passou
- [ ] `tsc --noEmit` passou (sem `ignoreBuildErrors`)
- [ ] testes passaram (incluindo caminho de erro, não só happy path)
- [ ] `build` passou
- [ ] `git diff --staged` revisado a olho
- [ ] nenhum segredo no diff; `.env*` ignorado
- [ ] sem `console.log`/`TODO` de debug no diff
- [ ] commit faz uma coisa só, com mensagem que explica o porquê
