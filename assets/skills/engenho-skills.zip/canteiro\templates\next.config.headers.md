# Headers de segurança no `next.config`

Cole o bloco abaixo no seu `next.config.js` (ou `next.config.mjs`). Esses headers
são aplicados a todas as rotas e cobrem os ataques mais comuns de fábrica.

> HSTS (`Strict-Transport-Security`) só tem efeito em HTTPS — em produção
> (Vercel) é exatamente o que você quer. Em `localhost` ele é ignorado pelo
> navegador, então pode deixar ligado sem dor.

## `next.config.js` (CommonJS)

```js
/** @type {import('next').NextConfig} */
const securityHeaders = [
  {
    // Impede o navegador de "adivinhar" o tipo de arquivo (anti MIME-sniffing).
    key: "X-Content-Type-Options",
    value: "nosniff",
  },
  {
    // Bloqueia o site de ser embutido em <iframe> de terceiros (anti-clickjacking).
    key: "X-Frame-Options",
    value: "DENY",
  },
  {
    // Limita o que vaza no header Referer ao navegar para fora.
    key: "Referrer-Policy",
    value: "strict-origin-when-cross-origin",
  },
  {
    // Corta acesso a recursos sensiveis por padrao. Libere o que precisar.
    key: "Permissions-Policy",
    value: "camera=(), microphone=(), geolocation=()",
  },
  {
    // Forca HTTPS por 2 anos, incluindo subdominios. So vale em producao/HTTPS.
    key: "Strict-Transport-Security",
    value: "max-age=63072000; includeSubDomains; preload",
  },
];

const nextConfig = {
  async headers() {
    return [
      {
        source: "/:path*",
        headers: securityHeaders,
      },
    ];
  },
};

module.exports = nextConfig;
```

## `next.config.mjs` (ESM)

Se o seu projeto usa `next.config.mjs`, troque a última linha por:

```js
export default nextConfig;
```

(O resto do conteúdo — `securityHeaders` e `nextConfig` — é idêntico.)

## Como conferir se funcionou

Depois de `npm run dev` (ou em produção), inspecione os headers de resposta:

```bash
curl -I http://localhost:3000
```

Você deve ver `x-content-type-options: nosniff`, `x-frame-options: DENY`, etc.

## Sobre Content-Security-Policy (CSP)

CSP é o header mais poderoso contra XSS, mas também o que mais quebra coisa se
configurado errado (bloqueia scripts inline, imagens externas, etc.). Por isso
ele **não** entra no canteiro inicial — adicione depois, com calma, medindo o
que sua aplicação realmente carrega. Comece em modo report-only
(`Content-Security-Policy-Report-Only`) para não derrubar a página enquanto ajusta.
