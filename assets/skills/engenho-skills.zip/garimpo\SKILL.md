---
name: garimpo
description: Pesquisa profunda na web com múltiplas fontes e respostas com citações verificáveis — separa o ouro do ruído. Use para pesquisar a fundo um tema, validar uma afirmação, ou comparar fontes antes de decidir.
---

# Garimpo — pesquisa profunda com fontes verificáveis

Garimpo **não reinventa** a pesquisa: ela usa a skill **`deep-research`** (instale-a — faz a busca multi-fonte, verificação adversarial e síntese com citações) e aplica os **padrões da casa**.

## Quando usar
- Pesquisar a fundo um tema (IA, vibecoding, segurança, negócio, tecnologia).
- **Validar uma afirmação** antes de publicar/decidir ("isso é verdade mesmo?").
- Comparar o que várias fontes dizem e achar o consenso (ou a divergência).

## Padrões da casa (o que Garimpo exige)
1. **Cite tudo o que importa.** Afirmação factual sem fonte verificável não entra. Linkar a origem, não "a internet diz".
2. **Verifique antes de afirmar.** Cruze pelo menos 2 fontes independentes para um dado relevante. Marque o que é consenso vs. o que é disputado.
3. **Data importa.** Em IA e tecnologia, fonte velha engana — registre a data de cada fonte.
4. **Sem hype.** Relate o que as fontes mostram, não o que soa impressionante. Separe fato de opinião.
5. **Diga o que NÃO achou.** Lacuna é informação. Não preencha buraco com suposição.

## Procedimento
1. Rode a `deep-research` com a pergunta refinada (se vaga, estreite antes).
2. Aplique os padrões da casa na síntese: cada claim relevante com fonte + data.
3. Entregue: resposta direta → evidências citadas → o que ficou incerto. A decisão é sua.
