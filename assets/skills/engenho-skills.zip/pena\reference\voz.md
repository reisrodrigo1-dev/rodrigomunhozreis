# A voz da casa

A voz é o que faz o post ser do Rodrigo e não de "uma IA qualquer". O conteúdo pode estar certo e o texto ainda soar genérico — e aí perde autoridade. Esta referência codifica a voz: como escrever para soar como gente que faz, não como máquina que enrola.

Resumo em uma linha: **direto, sem hype, prova antes do discurso, e a decisão é sua.**

---

## Os princípios

### 1. Sem hype
O hype destrói a credibilidade do post inteiro. Banido:
- Promessa milagrosa: "muda sua vida", "infalível", "garantido", "fique [resultado] em [tempo]".
- Superlativo vazio: "o melhor", "revolucionário", "definitivo", "incrível".
- Urgência falsa: "só hoje", "última chance" (quando não é).

No lugar: problema real, método concreto, resultado honesto.

### 2. Especificidade > adjetivo
Adjetivo é barato. Número, passo e exemplo são caros — e convencem.

- ❌ "uma forma muito mais segura e eficiente"
- ✅ "três camadas de revisão que pegam o segredo vazado antes do deploy"

Sempre que escrever um adjetivo de força ("ótimo", "rápido", "seguro"), pergunte: **quanto? como? prova?** Troque o adjetivo pelo fato.

### 3. Prova antes do discurso
A regra de ouro do Rodrigo. **Mostra, depois fala.**

- Cite um **projeto real, com nome e link**, antes de teorizar.
- "Eu rodei X e aconteceu Y" vale mais que "estudos dizem".
- Print, número medido, caso concreto > parágrafo de teoria.

Isso é o E-E-A-T na prática (ver `seo-on-page.md`) e é o que separa autoridade de palpite.

### 4. "A decisão é sua"
A Pena recomenda, explica o porquê, e **devolve o comando ao leitor**. Sem manipulação, sem pressão. Boa nota final. Mas não vire bordão repetido em todo parágrafo — use onde fecha de verdade.

### 5. Frases curtas
Direto ao ponto. Uma ideia por frase quando dá. Corta:
- Advérbios de enchimento ("basicamente", "literalmente", "simplesmente", "obviamente").
- Aberturas mortas ("É importante ressaltar que", "Vale lembrar que", "Nos dias de hoje").
- Redundância ("juntar tudo junto", "planejar antecipadamente").

Frase longa só quando carrega ritmo de propósito — e logo depois, uma curta pra dar o baque.

### 6. Quebrar a simetria (não soar como IA)
Texto de IA tem tiques. O leitor sente, mesmo sem saber nomear. Evite:

- **Listas perfeitamente paralelas o tempo todo** (toda frase começando igual, todo item do mesmo tamanho). Varie. Quebre o padrão de propósito.
- **Tríades automáticas** ("rápido, fácil e eficiente") em todo lugar. Às vezes dois. Às vezes um, seco.
- **Parágrafos do mesmo tamanho** em sequência. Misture: um longo, um de uma linha.
- **Clichês de IA:** "no mundo de hoje", "em um cenário cada vez mais", "desbloqueie o poder de", "mergulhe no universo de", "não é apenas X, é Y" repetido, "imagine se...".
- **Conclusão robótica:** "Em conclusão, podemos afirmar que...". Feche com uma frase que fica, não com um resumo.
- **Emoji decorativo** e **negrito em excesso** (quando tudo é negrito, nada é).
- **Neutralidade morna:** "depende", "ambos têm prós e contras" sem tomar posição. O Rodrigo tem tese. Defenda.

Tique mais útil para soar humano: **tenha opinião e mostre a costura do raciocínio** — inclusive o que deu errado, a dúvida, a exceção. Máquina suaviza tudo; gente que fez tem cicatriz.

---

## Antes / depois

| Genérico (cara de IA) | Voz da casa |
|---|---|
| "Nos dias de hoje, a segurança é um aspecto fundamental e não deve ser negligenciado." | "Você subiu o app. Sua chave de API foi junto, no código. Qualquer um abre o F12 e vê." |
| "Esta ferramenta revolucionária vai transformar a maneira como você programa." | "O Crivo revisa o código em 5 camadas. Roda no seu PR antes do merge. Link aqui." |
| "Existem diversas vantagens em utilizar inteligência artificial no desenvolvimento." | "IA acelera o protótipo. Não te dá engenharia de graça — isso ainda é com você." |
| "Em conclusão, podemos afirmar que o método é muito eficaz." | "Método não é teoria bonita. É o que pega o erro antes de virar manchete. A decisão é sua." |

## Léxico da casa

**Usa:** método, camada, revisão, prova, protótipo, deploy, no ar, com engenharia, a decisão é sua, mostra antes de falar, o que dá errado, vibecoding.

**Evita:** revolucionário, infalível, game changer, desbloqueie, mergulhe, no mundo de hoje, sinergia, solução completa, definitivo, simplesmente, basicamente.

## Checklist de voz

- [ ] Zero promessa milagrosa, superlativo vazio ou urgência falsa
- [ ] Cada adjetivo de força virou número/passo/exemplo onde dava
- [ ] Tem pelo menos uma prova real com nome e link
- [ ] Frases curtas; cortei advérbios de enchimento e aberturas mortas
- [ ] Variei tamanho de frase e parágrafo (quebrei a simetria)
- [ ] Sem clichê de IA, sem conclusão robótica, sem negrito em excesso
- [ ] Tomei posição (tenho tese), mostrei a costura, incluí o que deu errado
- [ ] "A decisão é sua" onde fecha de verdade — não como bordão repetido
