# Catálogo de Vulnerabilidades — Bastião

Catálogo de classes de vulnerabilidade relevantes ao **vibecoding** (construir com IA), com foco em **Next.js (App Router) + Firebase + Vercel + GitHub**. Para cada classe:

- **O que é** — em português simples.
- **Como aparece no vibecoding** — o padrão que a IA (ou a pressa) costuma gerar.
- **Como detectar** — o que procurar.
- **Como corrigir** — com código seguro pronto.
- **Prioridade** — 🔴 Crítico · 🟠 Alto · 🟡 Médio · 🟢 Baixo.

Índice:
1. [Regras de banco abertas/permissivas](#1) · 2. [Segredos/.env vazados](#2) · 3. [Autenticação quebrada](#3) · 4. [IDOR / quebra de autorização](#4) · 5. [Injeção (SQL/NoSQL/comando)](#5) · 6. [SSRF](#6) · 7. [Upload inseguro](#7) · 8. [XSS](#8) · 9. [Dependências vulneráveis / supply-chain](#9) · 10. [Exposição de dados pessoais / LGPD](#10) · 11. [Rate limiting ausente](#11) · 12. [CSRF](#12) · 13. [CORS mal configurado](#13) · 14. [Path traversal](#14) · 15. [Redirecionamento aberto](#15) · 16. [Logs com dados sensíveis](#16) · 17. [Headers de segurança ausentes](#17) · 18. [Mensagens de erro detalhadas / vazamento de info](#18) · 19. [Mass assignment / overposting](#19) · 20. [JWT/sessão mal validados](#20)

---

<a id="1"></a>
## 1. Regras de banco abertas / permissivas — 🔴 CRÍTICO

**O que é:** As regras do Firestore/Storage controlam quem pode ler e escrever. Se ficam abertas, **qualquer pessoa na internet** lê, edita e apaga todo o banco — sem precisar do seu app.

**Como aparece no vibecoding:** O modo de teste do Firebase cria isto, e a IA frequentemente o repete porque "funciona":

```js
// firestore.rules — PERIGO: banco totalmente aberto
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;        // qualquer um faz tudo
    }
  }
}
```
Variantes igualmente perigosas: `allow read, write;` (sem condição) ou `if request.auth != null` em coleções com dados de outros usuários (basta estar logado para ver TUDO de TODO mundo).

**Como detectar:**
- Procure `allow ...: if true` e `allow read, write;` em `*.rules`.
- Banner no Console do Firebase: "Suas regras de segurança estão... públicas".
- Teste: tente ler uma coleção de outro usuário pelo SDK estando logado como você.

**Como corrigir:** negue por padrão, autorize por dono e valide o formato.

```js
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    function signedIn() { return request.auth != null; }
    function isOwner(uid) { return signedIn() && request.auth.uid == uid; }

    match /users/{uid} {
      allow read, update, delete: if isOwner(uid);
      allow create: if isOwner(uid)
        // só permite os campos esperados, nada de extra:
        && request.resource.data.keys().hasOnly(['name','email','createdAt'])
        && request.resource.data.name is string;
    }

    match /posts/{postId} {
      allow read: if true; // posts públicos: OK ler
      allow create: if signedIn()
        && request.resource.data.authorId == request.auth.uid;
      allow update, delete: if signedIn()
        && resource.data.authorId == request.auth.uid; // só o dono edita
    }
  }
}
```
> Detalhe de `hasOnly` e validação em `padroes-seguros.md`. Auditoria automatizada: skill **Cofre**.

---

<a id="2"></a>
## 2. Segredos / .env vazados no Git ou no bundle — 🔴 CRÍTICO

**O que é:** Chaves de API, credenciais de serviço, tokens — se entram no Git ou no JavaScript enviado ao navegador, qualquer um copia e usa sua conta (e sua fatura).

**Como aparece no vibecoding:**
- `.env` ou `serviceAccountKey.json` commitado porque o `.gitignore` não cobria.
- Chave colada direto no código: `const apiKey = "sk-live_...";`.
- **Confusão fatal no Next.js:** prefixar com `NEXT_PUBLIC_` qualquer segredo. Toda variável `NEXT_PUBLIC_*` é **embutida no bundle** e visível no navegador.

```ts
// PERIGO: vai parar no JavaScript que o usuário baixa
const stripe = new Stripe(process.env.NEXT_PUBLIC_STRIPE_SECRET_KEY!);
```

**Como detectar:**
- `git log -p` / busca no histórico por `sk-`, `AKIA`, `-----BEGIN`, `PRIVATE KEY`, `password=`.
- `git ls-files | grep -E '\.env|serviceAccount'` — não pode aparecer nada.
- Procure segredos atrás de `NEXT_PUBLIC_`.
- Rode `scripts/scan-basico.py`. Caça dedicada: skill **Faro**.

**Como corrigir:**
1. `.gitignore` cobrindo `.env*`, `*serviceAccount*.json`, `*.pem`, `*.key`.
2. Segredo só em variável **sem** `NEXT_PUBLIC_`, lido **server-side**:
```ts
// server-only (route handler, server action, server component)
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!); // sem NEXT_PUBLIC_
```
3. Se já vazou: **rotacione a chave imediatamente** (gere nova, revogue a antiga). Remover do Git **não basta** — já foi clonado. Limpar histórico (`git filter-repo`/BFG) é secundário; rotacionar é primeiro.
4. `import 'server-only'` no topo de módulos que tocam segredo, para o build quebrar se vazar pro cliente.

---

<a id="3"></a>
## 3. Autenticação quebrada / rota sem proteção — 🔴 CRÍTICO

**O que é:** Áreas restritas (dashboard, admin, API) acessíveis sem login válido, ou checagem de login feita **só no cliente** (que o usuário controla).

**Como aparece no vibecoding:**
- Página `/dashboard` que só esconde o conteúdo com `if (!user) return <Login/>` no client — o dado já veio do servidor e está no Network.
- Route handler que confia num header `x-user-id` mandado pelo cliente.
- "Admin" decidido por um campo no `localStorage`.

```tsx
// PERIGO: proteção só visual; a API por trás não checa nada
'use client';
export default function Admin() {
  const { user } = useAuth();
  if (!user?.isAdmin) return null; // dá pra burlar no devtools
  return <SecretData/>;
}
```

**Como detectar:** toda rota/dado sensível: a checagem de identidade acontece **no servidor**? Tente acessar a API direto (curl/Postman) sem token.

**Como corrigir:** valide a sessão no servidor, na origem do dado.

```ts
// app/dashboard/page.tsx (Server Component) — Firebase Admin
import { cookies } from 'next/headers';
import { redirect } from 'next/navigation';
import { adminAuth } from '@/lib/firebase-admin';

export default async function Dashboard() {
  const session = (await cookies()).get('session')?.value;
  if (!session) redirect('/login');

  let user;
  try {
    user = await adminAuth.verifySessionCookie(session, true); // valida no servidor
  } catch {
    redirect('/login');
  }
  // user.uid é confiável a partir daqui
  const data = await getDataForUser(user.uid);
  return <DashboardView data={data} />;
}
```
Para route handlers, extraia e **verifique o ID token** com o Admin SDK antes de qualquer lógica. Nunca confie em id/role vindos do corpo da requisição.

---

<a id="4"></a>
## 4. IDOR / quebra de autorização — 🔴 CRÍTICO

**O que é:** Estar logado não é o mesmo que ter permissão **àquele** recurso. IDOR (Insecure Direct Object Reference) é quando o usuário A acessa dados do B só trocando um id na URL ou na query.

**Como aparece no vibecoding:**
```ts
// PERIGO: pega o pedido pelo id da URL, sem checar dono
export async function GET(req: Request, { params }: { params: { id: string }}) {
  const order = await db.collection('orders').doc(params.id).get();
  return Response.json(order.data()); // /api/orders/QUALQUER_ID
}
```
Comum também na regra do Firestore que só exige `request.auth != null`.

**Como detectar:** toda leitura/escrita por id: existe uma checagem de que o recurso **pertence** ao usuário logado? Teste trocando o id por outro.

**Como corrigir:** filtre/valide por dono no servidor **e** na regra (defesa em profundidade).

```ts
const snap = await db.collection('orders').doc(params.id).get();
const order = snap.data();
if (!order || order.ownerId !== user.uid) {
  return new Response('Não encontrado', { status: 404 }); // 404, não 403 (não revela existência)
}
return Response.json(order);
```
Na regra: `allow read: if resource.data.ownerId == request.auth.uid;`

---

<a id="5"></a>
## 5. Injeção (SQL / NoSQL / comando) — 🔴 CRÍTICO

**O que é:** Input do usuário interpretado como **comando** (de banco ou do sistema) em vez de dado. Permite ler/alterar tudo ou executar comandos no servidor.

**Como aparece no vibecoding:**
```ts
// SQL injection — string concatenada
const rows = await db.query(`SELECT * FROM users WHERE email = '${email}'`);
// NoSQL injection — objeto do usuário entra cru no filtro
const user = await collection.findOne({ email: req.body.email }); // body: {"email": {"$ne": null}}
// Command injection
exec(`convert ${req.query.file} out.png`); // file = "a.png; rm -rf /"
```

**Como detectar:** queries com `` ` `` + variável; `findOne`/`find` recebendo objeto direto do `req.body`; `exec`/`execSync`/`eval` com input.

**Como corrigir:**
```ts
// SQL: query parametrizada (placeholders)
const rows = await db.query('SELECT * FROM users WHERE email = $1', [email]);
// NoSQL: force o tipo, nunca passe o objeto cru
const email = String(req.body.email);
const user = await collection.findOne({ email });
// Comando: evite shell; use API/lib. Se inevitável, use execFile com array de args
execFile('convert', [safePath, 'out.png']);
```
Valide com schema (Zod) antes: `z.string().email().parse(input)`. Firestore SDK não monta SQL, mas **NoSQL injection** acontece quando você confia em objetos do usuário em filtros/regras.

---

<a id="6"></a>
## 6. SSRF (Server-Side Request Forgery) — 🟠 ALTO

**O que é:** Seu servidor faz um `fetch` para uma URL que o usuário escolhe. O atacante aponta para a **rede interna** ou para os **metadados da cloud** (que guardam credenciais).

**Como aparece no vibecoding:** features tipo "preview de link", "importar de URL", "webhook", proxy de imagem:
```ts
// PERIGO: usuário escolhe o destino do fetch do servidor
export async function POST(req: Request) {
  const { url } = await req.json();
  const r = await fetch(url);                 // url = http://169.254.169.254/... (metadados)
  return new Response(await r.text());
}
```

**Como detectar:** todo `fetch`/`axios` server-side cuja URL (ou parte dela) vem do usuário.

**Como corrigir:** allowlist de domínios + bloqueio de IPs privados; nunca seguir redirects cegamente.

```ts
function urlPermitida(raw: string) {
  let u: URL;
  try { u = new URL(raw); } catch { return false; }
  if (u.protocol !== 'https:') return false;
  const allow = ['api.parceiro.com', 'cdn.confiavel.com'];
  if (!allow.includes(u.hostname)) return false;
  // bloqueia loopback/privado/link-local/metadados
  if (/^(127\.|10\.|192\.168\.|169\.254\.|::1|localhost)/i.test(u.hostname)) return false;
  return true;
}
if (!urlPermitida(url)) return new Response('URL não permitida', { status: 400 });
const r = await fetch(url, { redirect: 'error' });
```

---

<a id="7"></a>
## 7. Upload de arquivo inseguro — 🟠 ALTO

**O que é:** Aceitar arquivos sem validar tipo, tamanho e como serão servidos. Riscos: SVG com script (XSS), HTML malicioso, executáveis, estouro de storage, ou servir com `Content-Type` que o navegador executa.

**Como aparece no vibecoding:** upload pro Storage confiando no nome/extensão; servir SVG inline; sem limite de tamanho; regra de Storage aberta.

**Como detectar:** rota de upload sem checagem de MIME/tamanho; SVG/HTML servidos de domínio com sessão; `storage.rules` com `allow write: if true`.

**Como corrigir:**
```js
// storage.rules
match /uploads/{uid}/{file} {
  allow read: if true;
  allow write: if request.auth.uid == uid
    && request.resource.size < 5 * 1024 * 1024            // até 5MB
    && request.resource.contentType.matches('image/(png|jpeg|webp)'); // só imagens raster
}
```
- Valide MIME pelo **conteúdo** (magic bytes), não só pela extensão.
- Sirva uploads de **outro domínio/bucket** sem cookies de sessão; force `Content-Disposition: attachment` para tipos arriscados; nunca sirva SVG enviado por usuário inline no seu domínio.
- Gere o nome do arquivo no servidor (não use o nome do usuário cru).

---

<a id="8"></a>
## 8. XSS (Cross-Site Scripting) — 🟠 ALTO

**O que é:** Conteúdo controlado pelo atacante vira `<script>` no navegador de outra vítima — roubando sessão, token, ou agindo como ela.

**Como aparece no vibecoding:** React escapa por padrão (bom!), mas fura quando:
```tsx
// PERIGO: HTML do usuário injetado cru
<div dangerouslySetInnerHTML={{ __html: comentario }} />
// PERIGO: link com javascript: ou href vindo do usuário
<a href={user.website}>site</a> // website = "javascript:fetch('/api/roubar',...)"
```
Também: gerar HTML por string no servidor; markdown renderizado sem sanitizar.

**Como detectar:** busque `dangerouslySetInnerHTML`, `innerHTML`, `href={`/`src={` com dado do usuário, `eval`.

**Como corrigir:**
```tsx
import DOMPurify from 'isomorphic-dompurify';
<div dangerouslySetInnerHTML={{ __html: DOMPurify.sanitize(comentario) }} />
```
- Prefira renderizar texto puro (deixe o React escapar). Use `dangerouslySetInnerHTML` só com HTML **sanitizado**.
- Valide URLs: aceite só `http:`/`https:`/`mailto:`.
- Reforce com **CSP** (header) — ver `padroes-seguros.md`.

---

<a id="9"></a>
## 9. Dependências vulneráveis / supply-chain — 🟠 ALTO

**O que é:** Você instala um pacote, ele puxa dezenas de outros. Uma falha (ou um pacote malicioso/typosquatting) vira sua falha. A IA às vezes sugere pacotes inexistentes ou abandonados.

**Como aparece no vibecoding:** `npm install` de pacote sugerido sem checar; `package-lock.json` não commitado; versões com `^`/`latest` que mudam sozinhas; rodar scripts de install de pacote desconhecido.

**Como detectar:**
```bash
npm audit                      # vulnerabilidades conhecidas
npm outdated                   # o que está velho
```
Confira: o pacote existe mesmo, tem downloads/manutenção, o nome está certo (typosquatting). Caça dedicada: skill **Quarentena**.

**Como corrigir:**
- Commit o **lockfile**; instale em CI com `npm ci` (instala exatamente o lockfile).
- `npm audit fix`; suba versões major com cuidado e teste.
- Habilite **Dependabot** no GitHub. Minimize dependências; desconfie de pacote novo/obscuro.
- Considere `--ignore-scripts` ao instalar pacote desconhecido.

---

<a id="10"></a>
## 10. Exposição de dados pessoais / LGPD — 🟠 ALTO

**O que é:** Vazar dados pessoais (PII: e-mail, CPF, telefone, endereço, localização, pagamento) por excesso de retorno, dado em URL, ou acesso amplo. Além do dano às pessoas, é risco legal (LGPD).

**Como aparece no vibecoding:**
- API que devolve o **documento inteiro** do usuário (com hash de senha, role, e-mail de todos) num endpoint de "perfil público".
- PII na URL/query (vai pro histórico, logs, referer).
- Coleção pública com dados sensíveis.

**Como detectar:** o JSON da resposta tem campos a mais? PII aparece em URL ou em log? Há endpoint que lista usuários sem filtro?

**Como corrigir:** devolva só o necessário (allowlist de campos).
```ts
function perfilPublico(u: User) {
  return { id: u.id, name: u.name, avatarUrl: u.avatarUrl }; // nada de email/cpf/role
}
```
- PII em corpo (POST), nunca em query string.
- Separe dados sensíveis em coleção com regra estrita.
- Detalhe legal (base legal, retenção, terceiros): `lgpd.md`. Conformidade dedicada: skill **Salvaguarda**.

---

<a id="11"></a>
## 11. Rate limiting ausente — 🟠 ALTO

**O que é:** Sem limite de requisições, atacantes fazem brute-force de senha, scraping em massa, ou estouram sua fatura de cloud/IA.

**Como aparece no vibecoding:** login, "esqueci a senha", endpoints de IA/e-mail e APIs públicas sem nenhum limite. No serverless (Vercel), cada chamada custa — abuso vira conta alta.

**Como detectar:** endpoints sensíveis sem contagem por IP/usuário; ausência de proteção em login/OTP.

**Como corrigir:** limite por IP/usuário com janela. Com Upstash (serverless-friendly):
```ts
import { Ratelimit } from '@upstash/ratelimit';
import { Redis } from '@upstash/redis';

const limiter = new Ratelimit({
  redis: Redis.fromEnv(),
  limiter: Ratelimit.slidingWindow(5, '1 m'), // 5 req/min
});

export async function POST(req: Request) {
  const ip = req.headers.get('x-forwarded-for') ?? 'anon';
  const { success } = await limiter.limit(ip);
  if (!success) return new Response('Muitas tentativas', { status: 429 });
  // ... login
}
```
Em login, some com lockout progressivo e CAPTCHA após N falhas. Reforce com WAF/Firewall da Vercel.

---

<a id="12"></a>
## 12. CSRF (Cross-Site Request Forgery) — 🟡 MÉDIO

**O que é:** Um site malicioso faz o navegador da vítima (já logada no seu app) enviar uma requisição que muda estado — usando o cookie de sessão automaticamente.

**Como aparece no vibecoding:** mutações (POST/DELETE) autenticadas **só por cookie**, sem token anti-CSRF nem `SameSite`. Apps que usam só `Authorization: Bearer` no header são naturalmente mais resistentes; o risco mora em cookies de sessão.

**Como detectar:** cookie de sessão sem `SameSite`; rotas de mutação que confiam só no cookie.

**Como corrigir:**
```ts
cookieStore.set('session', value, {
  httpOnly: true, secure: true, sameSite: 'lax', path: '/',
});
```
- `SameSite=Lax` (ou `Strict`) já barra a maioria dos CSRF.
- Para fluxos sensíveis, use **token anti-CSRF** (double-submit) ou exija header custom que cross-site não consegue forjar.
- Server Actions do Next.js já trazem proteção de origem — mantenha-a.

---

<a id="13"></a>
## 13. CORS mal configurado — 🟡 MÉDIO

**O que é:** CORS decide quais sites no navegador podem ler respostas da sua API. Configurado errado (`*` + credenciais), qualquer site lê dados autenticados dos seus usuários.

**Como aparece no vibecoding:** copiar de tutorial `Access-Control-Allow-Origin: *` para "resolver erro de CORS", às vezes junto de `Allow-Credentials: true` (combinação inválida e perigosa).

**Como detectar:** headers `Access-Control-Allow-Origin: *` em rotas autenticadas; reflexão cega da origem (`Origin` do request ecoado sem checar).

**Como corrigir:** allowlist de origens; só ecoe origem que está na lista.
```ts
const ALLOW = new Set(['https://app.seudominio.com']);
const origin = req.headers.get('origin') ?? '';
const headers = new Headers();
if (ALLOW.has(origin)) {
  headers.set('Access-Control-Allow-Origin', origin);
  headers.set('Access-Control-Allow-Credentials', 'true');
  headers.set('Vary', 'Origin');
}
```
Nunca `*` com credenciais. APIs públicas e sem dados sensíveis podem usar `*` **sem** credenciais.

---

<a id="14"></a>
## 14. Path traversal — 🟡 MÉDIO

**O que é:** Input do usuário entra num caminho de arquivo e, com `../`, escapa da pasta esperada para ler arquivos do servidor (`.env`, `/etc/passwd`).

**Como aparece no vibecoding:** endpoints de download/preview que montam caminho com nome enviado:
```ts
// PERIGO: name = "../../.env"
const file = await fs.readFile(path.join('uploads', req.query.name));
```

**Como detectar:** `fs.readFile`/`createReadStream`/`path.join` com parte vinda do usuário.

**Como corrigir:** normalize e confine à pasta base; aceite só nomes simples.
```ts
const base = path.resolve('uploads');
const target = path.resolve(base, path.basename(req.query.name)); // basename remove ../
if (!target.startsWith(base + path.sep)) return new Response('Inválido', { status: 400 });
```
Melhor ainda: referencie arquivos por **id** num banco e busque o caminho real internamente.

---

<a id="15"></a>
## 15. Redirecionamento aberto (Open Redirect) — 🟡 MÉDIO

**O que é:** Sua URL recebe um destino (`?next=...`) e redireciona sem validar. Atacantes usam **seu domínio** como trampolim de phishing.

**Como aparece no vibecoding:** pós-login `redirect(searchParams.next)` com valor cru; links de "voltar para" guardados na URL.

**Como detectar:** `redirect(...)`/`Location:` com valor vindo de query/body sem checagem.

**Como corrigir:** aceite só caminhos internos relativos.
```ts
function destinoSeguro(next: string | null) {
  if (next && next.startsWith('/') && !next.startsWith('//')) return next; // só rota interna
  return '/dashboard';
}
redirect(destinoSeguro(searchParams.next));
```
Para destinos externos legítimos, use allowlist de domínios.

---

<a id="16"></a>
## 16. Logs com dados sensíveis — 🟡 MÉDIO

**O que é:** `console.log` de senha, token, chave ou PII. Logs vão para a Vercel, ferramentas de observabilidade e, às vezes, para terceiros — virando um vazamento silencioso.

**Como aparece no vibecoding:** `console.log(req.body)`, `console.log('user', user)` (com senha/hash), logar `Authorization` no debug e esquecer.

**Como detectar:** busque `console.log`/`console.error` com `body`, `password`, `token`, `auth`, `user` inteiro.

**Como corrigir:**
```ts
const { password, token, ...safe } = req.body; // nunca logue os sensíveis
console.log('login attempt', { email: safe.email });
```
- Em produção, reduza verbosidade; redija PII/segredos.
- Nunca logue `Authorization`, cookies, ou corpo de pagamento.

---

<a id="17"></a>
## 17. Headers de segurança ausentes — 🟢 BAIXO

**O que é:** Headers como CSP, HSTS, X-Frame-Options e nosniff são camadas extras que mitigam XSS, clickjacking, downgrade e sniffing. Faltando, você perde defesa em profundidade (mas sozinhos não causam o vazamento).

**Como aparece no vibecoding:** `next.config` padrão, sem nenhum header de segurança.

**Como detectar:** inspecione headers da resposta (devtools/curl); rode um teste tipo securityheaders.com.

**Como corrigir:** ver bloco pronto de `headers()` em `padroes-seguros.md`. Mínimo: `Strict-Transport-Security`, `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY` (ou CSP `frame-ancestors`), e uma **CSP** restritiva.

---

<a id="18"></a>
## 18. Mensagens de erro detalhadas / vazamento de informação — 🟡 MÉDIO

**O que é:** Erros que mostram stacktrace, caminho de arquivos, versão de libs, query SQL ou nomes internos ajudam o atacante a mapear o sistema. Mensagens de login que distinguem "usuário não existe" de "senha errada" permitem enumerar contas.

**Como aparece no vibecoding:** devolver `error.stack`/`error.message` cru ao cliente; `NODE_ENV` não tratado; "e-mail não cadastrado" vs "senha incorreta".

**Como detectar:** route handlers que retornam o objeto de erro inteiro; respostas de auth diferentes por causa.

**Como corrigir:**
```ts
try { /* ... */ } catch (e) {
  console.error(e);                       // detalhe fica no log do servidor
  return new Response('Erro ao processar', { status: 500 }); // genérico pro cliente
}
```
Em login, use mensagem única: "E-mail ou senha inválidos". Nunca exponha stacktrace em produção.

---

<a id="19"></a>
## 19. Mass assignment / overposting — 🟡 MÉDIO

**O que é:** Salvar no banco o objeto que o usuário mandou **inteiro**. Ele inclui campos que não deveria — como `role: "admin"`, `isPremium: true` ou `balance`.

**Como aparece no vibecoding:**
```ts
// PERIGO: grava tudo que veio no body
await db.collection('users').doc(uid).set(req.body, { merge: true }); // body: {role:"admin"}
```

**Como detectar:** `set`/`update`/`create` com `req.body`/`...data` espalhado sem filtrar campos.

**Como corrigir:** allowlist de campos no servidor **e** `hasOnly` na regra.
```ts
const { name, bio } = req.body;            // só os campos editáveis
await db.collection('users').doc(uid).set({ name, bio }, { merge: true });
```
Regra Firestore: `request.resource.data.diff(resource.data).affectedKeys().hasOnly(['name','bio'])`.

---

<a id="20"></a>
## 20. JWT / sessão mal validados — 🟡 MÉDIO

**O que é:** Aceitar um token sem verificar assinatura, expiração ou emissor; ou guardar sessão de forma insegura (token JWT no `localStorage`, vulnerável a XSS).

**Como aparece no vibecoding:** decodificar o JWT (`atob`) e confiar no conteúdo **sem verificar a assinatura**; guardar token em `localStorage`; não checar `exp`.

**Como detectar:** uso de `jwt.decode` (não verifica) em vez de `jwt.verify`; token de sessão acessível por JS; ausência de checagem de expiração/revogação.

**Como corrigir:**
- **Verifique** a assinatura no servidor (Firebase: `verifyIdToken`/`verifySessionCookie`, que checam assinatura e expiração).
- Guarde sessão em cookie `httpOnly` + `Secure` + `SameSite`, não em `localStorage`.
- Para Firebase, prefira **session cookies** do Admin SDK a manter o ID token no cliente.

---

## Mapa rápido OWASP (para quem quer referência)

Estas classes cobrem o essencial do **OWASP Top 10**: A01 Broken Access Control (#1, #3, #4, #19), A02 Cryptographic/segredos (#2, #20), A03 Injection (#5, #8), A04 Insecure Design (rate limiting #11, design de auth), A05 Misconfiguration (#13, #17, #18), A06 Vulnerable Components (#9), A07 Auth Failures (#3, #11, #20), A08 Data Integrity (#9 supply-chain), A09 Logging (#16), A10 SSRF (#6). Path traversal (#14) e open redirect (#15) entram em access control/design.
