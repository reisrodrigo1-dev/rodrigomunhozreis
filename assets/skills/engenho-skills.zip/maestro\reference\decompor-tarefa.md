# Decompor uma tarefa grande

Quebrar bem é metade da orquestração. Se a decomposição estiver errada, nenhum padrão de coordenação salva — você só vai coordenar pedaços ruins. Este arquivo ajuda a decidir **por qual eixo** quebrar, **qual o tamanho ideal** de cada subtarefa e **o que conta como entregável** de cada passo.

## Princípio: cada subtarefa tem um entregável

Uma subtarefa só é um passo de verdade se você consegue responder: **"como eu sei que esse passo terminou e ficou bom?"**

- "Pesquisar o assunto" não é entregável. **"Lista de 5 fontes com a tese de cada uma"** é.
- "Mexer no backend" não é entregável. **"Endpoint POST /pedidos funcionando, com validação de payload"** é.
- "Pensar no design" não é entregável. **"3 opções de layout com prós/contras"** é.

Se você não consegue descrever o entregável em uma frase concreta, a subtarefa ainda está grande ou vaga demais. Quebre mais ou defina melhor.

## Os três eixos de decomposição

Escolha o eixo que **corta a tarefa nas juntas naturais** dela. Quase toda tarefa aceita mais de um eixo — pegue o que produz pedaços mais independentes e verificáveis.

### 1. Por etapa (fluxo no tempo)

Quebra a tarefa em **fases que acontecem em sequência**. Bom quando o trabalho tem um fluxo natural: primeiro isso, depois aquilo.

> Escrever um relatório → **pesquisar → estruturar → redigir → revisar → formatar**.

> Lançar uma feature → **especificar → modelar dados → implementar → testar → publicar**.

Use quando: existe ordem natural e cada fase produz o insumo da próxima. Tende a virar um **pipeline sequencial**.

### 2. Por componente (partes do todo)

Quebra a tarefa nas **peças que compõem o resultado**, independentes entre si. Bom quando o resultado é montado de partes que não dependem uma da outra.

> Construir uma landing page → **hero + seção de prova + FAQ + formulário + rodapé**.

> Documentar uma API → **um bloco por endpoint**.

Use quando: as partes podem ser feitas em qualquer ordem (ou ao mesmo tempo) e juntadas no fim. Tende a virar **paralelo (fan-out)**.

### 3. Por pergunta (o que precisa ser respondido)

Quebra a tarefa nas **perguntas que precisam de resposta** para o objetivo ser atingido. Bom para decisão, análise e pesquisa, onde o "trabalho" é reduzir incerteza.

> Decidir a stack de um produto → **que tipo de produto é? qual a escala esperada? que restrições (time, orçamento, prazo)? quais candidatas? qual o trade-off de cada uma?**

> Avaliar se vale construir algo → **tem demanda? sei executar? quanto custa? quanto dá pra cobrar?**

Use quando: o resultado é uma conclusão, não um artefato pronto. Cada pergunta respondida é um passo; a síntese é a decisão.

### Combinando eixos

Tarefas grandes de verdade misturam eixos: você quebra **por etapa** no topo e, dentro de uma etapa, **por componente**.

> App inteiro → por etapa (planejar → construir → testar) e, dentro de "construir", por componente (auth + pagamentos + dashboard).

Não force tudo num eixo só. Quebre no eixo que deixar cada pedaço mais independente.

## Tamanho ideal de uma subtarefa

A peça certa é **grande o bastante para valer um passo, pequena o bastante para a IA não se perder e para você conseguir verificar**.

Bons sinais de tamanho certo:

- Cabe em **uma resposta focada** da IA, sem ela ter que abraçar coisa demais.
- Tem **um único entregável**, não três.
- Você consegue **verificar em poucos minutos** se ficou bom.
- Se falhar, o estrago é **local** — não derruba o resto.

Sinais de que está **grande demais** (quebre mais):

- O entregável tem "e" no meio ("implementar o login **e** o cadastro **e** a recuperação de senha").
- Você não saberia dizer em uma frase se ficou pronto.
- A IA tende a entregar isso raso.

Sinais de que está **pequeno demais** (junte):

- O passo gera mais trabalho de coordenação do que de execução.
- São microtarefas que a IA faria juntas sem se perder.
- Você está fatiando só para parecer organizado.

Heurística: se a tarefa grande virou **mais de uns 7–8 passos no mesmo nível**, provavelmente você fatiou fino demais ou está faltando uma camada de agrupamento. Agrupe em fases.

## Checklist de uma boa decomposição

Antes de sair executando, confira:

- [ ] Cada subtarefa tem **um entregável em uma frase**.
- [ ] Dá para dizer, para cada passo, **como verificar** que ficou bom.
- [ ] As dependências estão claras (quem precisa de quem) — isso alimenta a escolha de ordem.
- [ ] Nenhuma peça está grande demais (entregaria raso) nem pequena demais (puro overhead).
- [ ] A soma dos entregáveis, integrada, **responde ao objetivo original** — não sobra nem falta.

Decomposição boa = passos com entregável claro, do tamanho certo, com dependências mapeadas. Com isso pronto, vá para `padroes-de-orquestracao.md` decidir a ordem e a verificação.
