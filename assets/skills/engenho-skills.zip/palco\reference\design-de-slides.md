# Design de slides — princípios na marca

Slide de palestra não é documento. Ninguém lê um slide projetado a dez metros enquanto te ouve falar. O slide tem **um** trabalho: dar à plateia uma âncora visual pro que você está dizendo *agora*. Tudo abaixo serve a isso.

Identidade da casa: **escuro premium + âmbar**, editorial, técnica, sem hype. Tokens em `atelier/reference/marca.md`.

---

## O princípio que comanda tudo: 1 ideia por slide

Se um slide tem duas ideias, são dois slides. Se a plateia precisa parar de te ouvir pra ler o slide, o slide falhou. A regra prática: **olhou, entendeu em 3 segundos, volta a te ouvir.**

- Um slide = uma frase-chave, ou um número, ou uma imagem, ou um gráfico simples.
- A análise, o contexto e a nuance moram na **sua fala** (nas notas), não na tela.
- Na dúvida, **divida**. Slides são de graça; atenção não.

---

## Cores (tokens da marca)

| Token | Hex | Uso no slide |
|---|---|---|
| ink | `#070608` | Fundo de quase todo slide |
| paper | `#F4EFE6` | Texto principal sobre o escuro |
| amber | `#E8A33D` | **Destaque pontual**: número-gancho, palavra-chave, CTA |
| amber-deep | `#C07F1E` | Variação escura do âmbar (detalhes) |
| amber-light | `#F0C070` | Realce de texto sobre escuro |

**Regra do âmbar:** âmbar é tempero, não prato. Um destaque por slide. Se tudo é âmbar, nada é. Texto secundário usa `paper` com opacidade (ex.: 55%).

---

## Tipografia

- **Títulos:** **Fraunces** (serifada de alto contraste), peso 500–700. É a assinatura visual. Grande.
- **Corpo:** **Inter** (sans), 400–600. Limpo, legível.
- **Acento editorial:** **Instrument Serif** em itálico, para *um* realce pontual — não o slide inteiro.
- **Tamanho:** pense no fundo da sala. Título bem grande; corpo nunca apertado. Se você precisa diminuir a fonte pra caber, é porque tem texto demais — corte o texto, não a fonte.
- **Entrelinha:** generosa (~1.4–1.5). Respiro é parte do premium.

---

## Contraste e hierarquia

- **Contraste ≥ 4.5:1** sempre. `paper` sobre `ink` resolve. Nunca cinza-sobre-cinza.
- **Hierarquia por tamanho, peso e espaço** — não só por cor (acessibilidade + legibilidade a distância).
- Muito **espaço negativo**. O fundo `ink` respirando é o que faz parecer premium, não cheio.
- Uma âncora por slide: o olho deve saber pra onde ir em meio segundo.

---

## Tipos de slide que funcionam

- **Slide-frase:** uma frase em Fraunces, palavra-chave em âmbar. Pra teses e viradas.
- **Slide-número:** o número-gancho gigante em âmbar, legenda curta embaixo. Pra prova.
- **Slide-imagem:** uma imagem forte ocupando a tela, no máximo uma frase sobreposta. Pra cenas e histórias.
- **Slide-gráfico:** um gráfico simples (Chart.js via skill `slides`), um insight só. Eixos limpos, sem poluição.
- **Slide-antes/depois:** duas colunas, contraste claro. Pra provas de transformação.
- **Slide-capa / fecho:** título em Fraunces sobre `ink`, muito respiro.

---

## Fazer

- 1 ideia por slide; muito respiro.
- Texto grande, legível do fundo da sala.
- Âmbar só no que importa (um destaque por slide).
- Fraunces nos títulos, Inter no corpo, Instrument Serif num realce pontual.
- Números grandes e específicos na prova.
- Imagem forte > três bullets.
- Contraste alto, hierarquia por tamanho/peso/espaço.
- Deixar a análise pra fala (notas), não pra tela.

## Não fazer

- **Bullet-point-soup:** slide com 5–7 bullets que você vai ler em voz alta. É o pecado capital. Vira teleprompter, mata a plateia.
- Slide como documento (parágrafos, tudo escrito).
- Fonte pequena pra "caber tudo" — corte o conteúdo, não o tamanho.
- Âmbar em tudo (perde o destaque) ou gradiente arco-íris.
- Cinza-sobre-cinza, contraste baixo, texto ilegível a distância.
- Robôzinho azul de IA, clip-art genérico, lorem ipsum entregue como final.
- Animação/transição gratuita que distrai da fala.
- Logo e rodapé poluindo todo slide.

---

## Regra de ouro

**Se a plateia consegue ler o slide inteiro, ela não precisa de você.** O slide ilumina um ponto; quem convence é você. Menos na tela, mais na boca.
