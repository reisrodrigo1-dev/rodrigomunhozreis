# Playbook de incidente — por tipo

Cada tipo tem os **primeiros 15 minutos** (o que fazer já, sem pensar) e depois os
cinco passos do método. Ache o seu tipo, execute os 15 minutos, e siga.

Regra que vale pra todos: **anote horário e ação de cada passo** num documento de
incidente. Vira a linha do tempo do post-mortem e é exigência da LGPD.

Ordem do método, sempre: **CONTER → AVALIAR → COMUNICAR → REMEDIAR → APRENDER.**

---

## 1. Segredo vazado

Chave de API, token, senha, `.env` no Git, credencial num log ou print.

### Primeiros 15 minutos

1. **Identifique qual segredo** e o que ele abre. Uma chave do Firebase Admin ou de
   gateway de pagamento é crítica; uma chave de analytics read-only, menos.
2. **Rotacione AGORA** no provedor: gere a nova credencial e **revogue/exclua a
   antiga**. Rotacionar sem revogar não contém — a velha ainda funciona.
   - Firebase: console > Configurações do projeto > Contas de serviço (gere nova,
     apague a chave comprometida).
   - Vercel/GitHub/OpenAI/Stripe: painel de tokens/API keys, revogar e recriar.
3. **Atualize o segredo** onde ele é usado (Vercel Env, `.env` local, Secrets do
   GitHub Actions) e **redeploy**.
4. **Não dê só `git rm`** no arquivo: o segredo continua no **histórico do Git**.
   Marque pra limpar o histórico na remediação (veja Faro).

### Depois

- **Avaliar:** desde quando o segredo estava exposto? Repo público ou privado?
  Quantas pessoas tiveram acesso? Há sinal de uso indevido (cobrança estranha,
  acesso de IP desconhecido)?
- **Comunicar:** se a chave dava acesso a dado pessoal e há indício de uso, pode
  virar incidente de LGPD (seção própria abaixo). Avise o provedor se for o caso.
- **Remediar:** limpe o histórico do Git (`git filter-repo` ou BFG) e force o push;
  bote o arquivo no `.gitignore`; rode o **Faro** pra confirmar que não sobrou
  outro segredo; passe segredos pra um cofre.
- **Aprender:** por que o segredo chegou onde chegou? Faltou `.gitignore`? Faltou
  hook de pré-commit? Vire ação.

---

## 2. Dado pessoal exposto

Coleção aberta, endpoint sem auth, link público com PII, dado de usuário acessível
por quem não devia. **Este é o tipo que mais aciona a LGPD — leia o passo COMUNICAR
com atenção.**

### Primeiros 15 minutos

1. **Feche o acesso AGORA.**
   - Regra de banco aberta: publique uma regra restritiva imediatamente (use o
     **Cofre**) e dê deploy (`firebase deploy --only firestore:rules,storage`).
   - Endpoint sem auth: derrube a rota, ponha um gate de autenticação, ou use
     feature flag pra desligar.
   - Arquivo/link público: torne privado o objeto no Storage.
2. **Confirme que fechou** — tente acessar de uma sessão não autenticada. Se ainda
   abre, não conteve.
3. **Preserve os logs de acesso** antes de qualquer limpeza — eles dizem se alguém
   leu de verdade.

### Depois

- **Avaliar:** **quais campos** ficaram expostos e de **quantos titulares**? Tem
  dado sensível (saúde, biometria, etc.)? Por quanto tempo? Há **acesso confirmado**
  nos logs ou só exposição? Sem log, trate como acessado.
- **Comunicar (LGPD):** se o incidente **pode acarretar risco ou dano relevante**
  aos titulares, o controlador **deve comunicar a ANPD e os titulares afetados**.
  Prazo: **3 dias úteis** do conhecimento do incidente (Resolução CD/ANPD nº
  15/2024). A comunicação inclui: natureza dos dados afetados, titulares envolvidos,
  medidas técnicas/de segurança adotadas, riscos e medidas de mitigação. Documente
  a análise de risco mesmo que conclua que não precisa comunicar — a omissão
  injustificada é o que pune. Avise os usuários com clareza: o que aconteceu, o que
  você já fez, o que eles devem fazer.
- **Remediar:** conserte a causa raiz (regra revisada com Cofre, validação no
  endpoint), adicione alerta de acesso anômalo (Sentinela), e revise as outras
  coleções/rotas atrás do mesmo padrão.
- **Aprender:** post-mortem. A regra abriu por modo de teste esquecido? Vire passo
  de revisão antes do deploy.

#### Modelo de comunicação ao usuário

> Olá, [nome]. Identificamos em [data] um incidente que pode ter exposto [quais
> dados] da sua conta. Assim que detectamos, [o que você fez: fechamos o acesso,
> rotacionamos as chaves]. Não temos indício de que seus dados foram usados
> indevidamente / Há indício de acesso, por isso recomendamos que você [troque a
> senha / fique atento a e-mails de phishing]. Estamos à disposição em [contato].
> Pedimos desculpas pelo ocorrido.

---

## 3. Conta comprometida

Login de admin invadido, sessão sequestrada, acesso indevido ao painel
(Vercel/Firebase/GitHub/gateway).

### Primeiros 15 minutos

1. **Revogue as sessões ativas** da conta comprometida (Firebase Auth: revogar
   tokens; provedores: "sign out all sessions" / "revogar sessões").
2. **Troque a senha** e **ative/force MFA** se ainda não tinha.
3. **Revogue tokens/PATs e chaves de API** que a conta podia ter criado — o invasor
   pode ter deixado uma porta dos fundos.
4. **Cheque os logs de acesso/auditoria**: de onde veio o acesso, o que foi feito,
   quando começou.

### Depois

- **Avaliar:** o que a conta acessava (dados, deploy, banco)? O invasor mudou
  alguma coisa (regra, código, dados, env)? Criou usuários/chaves novas? Há dado
  pessoal no alcance?
- **Comunicar:** se houve acesso a dado pessoal, vale a regra da LGPD (tipo 2). Se
  outros membros do time usam o mesmo sistema, avise-os.
- **Remediar:** reverta qualquer alteração maliciosa (deploy, regra, dados — via
  restore se preciso), force MFA em todas as contas com acesso, revise quem tem
  qual permissão (princípio do menor privilégio), e reforce o login (use **Escudo**).
- **Aprender:** como a credencial vazou? Phishing? Senha reusada? MFA ausente?
  Ação: MFA obrigatório, gerenciador de senhas, revisão de acessos.

---

## 4. Perda ou corrupção de dado

Delete acidental, migração que zerou coleção, bug que sobrescreveu registros,
ransomware.

### Primeiros 15 minutos

1. **PARE as escritas no dado afetado.** Cada escrita nova pode sobrescrever o que
   ainda dá pra recuperar e enterrar a evidência. Desligue a feature/job que está
   escrevendo (feature flag, modo manutenção, pausar o cron).
2. **Não mexa no que sobrou** ainda — não "tente consertar na mão" antes de ter uma
   cópia do estado atual.
3. **Localize o backup mais recente** anterior à corrupção (export agendado do
   Firestore no Storage). Anote o horário do backup — é o seu RPO efetivo neste
   incidente.

### Depois

- **Avaliar:** o que se perdeu (quais coleções/campos/registros), desde quando,
  por qual causa (delete, migração, bug, ataque). Quanto dado entre o último backup
  e agora não está coberto?
- **Comunicar:** se afeta usuários (dados deles sumiram/mudaram), avise. Se foi
  ransomware/ataque com dado pessoal, vale a regra da LGPD.
- **Remediar — o restore (siga `backup-e-restauracao.md`):**
  1. Restaure o backup para um **ambiente isolado** (outro projeto/coleção
     temporária), nunca direto por cima de produção.
  2. **Valide** que os dados voltaram íntegros e completos.
  3. **Copie o estado atual de produção** antes de promover (você pode precisar de
     dados que entraram depois do backup).
  4. Reconcilie: traga de volta o que se perdeu sem descartar o que é legítimo e
     novo. Só então promova.
- **Aprender:** o que faltou? Backup mais frequente (RPO menor)? Soft-delete em vez
  de delete físico? Confirmação em operação destrutiva? Vire ação.

---

## 5. Indisponibilidade (fora do ar)

App caído, erro 500 em massa, serviço inacessível.

### Primeiros 15 minutos

1. **Confirme o escopo:** é o seu app ou um provedor? Cheque o status da Vercel,
   Firebase e do gateway (páginas de status públicas). Se o provedor caiu, sua ação
   é comunicar e esperar — não adianta debugar o que não é seu.
2. **Se foi um deploy recente, faça rollback** pro último deploy bom (Vercel:
   promover deployment anterior). Reverter primeiro, entender depois — isso é
   contenção.
3. **Olhe os erros** (logs da Vercel, ferramenta de erro tipo Sentry) pra ver o que
   está estourando.
4. **Ponha um aviso** se a queda for longa (página de status, banner).

### Depois

- **Avaliar:** o que caiu e por quê (deploy ruim, pico de carga, quota estourada,
  banco fora, dependência de terceiro). Quantos usuários afetados, por quanto tempo.
- **Comunicar:** avise usuários se a queda for relevante. Seja honesto sobre a
  previsão de retorno.
- **Remediar:** se foi código, conserte e redeploy com calma (não no susto); se foi
  carga/quota, ajuste limites; se foi terceiro, avalie fallback/degradação graciosa.
- **Aprender:** o **Sentinela** te avisou antes do cliente? Se o cliente avisou
  primeiro, faltou um alerta de uptime — vire ação. Health check, alerta de erro em
  massa, e (se crítico) redundância.
