# Anatomia de um bom post

Um post de autoridade tem partes com função clara. Cada parte faz um trabalho. Nada de enrolação para "encher" o texto — se um bloco não serve ao leitor ou ao Google, sai.

Tamanho de referência do post: **800–1.800 palavras** para artigo de autoridade. Menos que isso costuma ser raso; mais que isso só se o tema pedir profundidade real. Tamanho não é meta — utilidade é.

---

## 1. Título (H1)

O que decide se a pessoa clica no resultado de busca e se fica.

- **Tamanho:** 50–60 caracteres (cabe no resultado do Google sem cortar).
- **Termo importante no começo**, de forma natural.
- **Específico > genérico.** Número e detalhe ganham de adjetivo.
- **Promete só o que o post entrega** (sem clickbait — quebrar isso mata SEO e confiança).
- Um título, uma ideia.

Bom x ruim:

| Ruim | Bom |
|---|---|
| "Tudo sobre segurança em IA" | "5 vazamentos de segredo que o vibecoding causa (e como blindar)" |
| "Inteligência artificial e o futuro do trabalho" | "IA não vai te substituir. Quem usa IA com método, talvez" |
| "Como fazer prompts" | "O método P.R.O.M.P.T.E.R.: 8 partes de um prompt que funciona" |
| "Notícias de IA da semana" | "O que o vazamento da [empresa] ensina sobre revisar código de IA" |

Padrões que funcionam (sem hype):
- **[Número] [coisas] para [resultado]** → "3 camadas de revisão antes de subir código gerado por IA"
- **Como [resultado] sem [dor]** → "Como tirar o protótipo do ar de teste sem virar engenheiro"
- **[Afirmação que quebra o senso comum]** → "Vibecoding não é desleixo. É engenharia com outra ferramenta"
- **O que [notícia/fato] ensina sobre [método]** → para post ancorado em notícia.

## 2. Excerpt / meta description

O convite ao clique no resultado de busca. Vai no frontmatter (`excerpt`).

- **Tamanho:** 120–155 caracteres.
- **Resume o post** com honestidade — sem prometer o que não tem.
- Pode trazer a palavra-chave de forma natural.
- Uma por post; nunca repetida entre posts.

Exemplo:
> O que o vazamento de chaves de API na [empresa] mostra na prática — e as 3 camadas de revisão que pegam esse erro antes de virar manchete.

## 3. Gancho (abertura)

As primeiras 2 a 4 linhas. Faz a pessoa continuar ou ir embora.

**Nunca** comece com rodeio genérico ("Nos dias de hoje, com o avanço da inteligência artificial..."). Isso é cara de IA e mata o leitor.

Boas aberturas:
- **Dor nomeada:** "Você vibecoda rápido. O app funciona. Aí alguém abre o F12 e acha sua chave de API no código."
- **Fato/dado:** "Em [mês/ano], a [empresa] expôs [X] por um erro que um checklist de revisão pegaria em 30 segundos."
- **Cena concreta:** "Sexta, 18h. O deploy subiu. Segunda, a conta da OpenAI veio com três zeros a mais."
- **Pergunta que incomoda:** "Você sabe o que o código que a IA escreveu ontem está fazendo com os dados do seu usuário?"
- **A notícia** (post ancorado): comece pelo acontecimento.

Regra: o gancho promete o que o corpo entrega. E entrega rápido.

## 4. Corpo (H2 / H3)

Onde mora o conteúdo. Escaneável e com hierarquia.

- **`## H2`** para cada bloco/ideia. **`### H3`** para subdivisões.
- Cada `##` entrega uma ideia e poderia ser pesquisada sozinha no Google.
- **Parágrafos curtos** (2–4 linhas). Lista quando há passos ou itens.
- **`**negrito**`** no que importa — com parcimônia, senão perde força.
- **`>` blockquote** para a frase-tese, uma citação ou o "a decisão é sua".
- **Dados com fonte.** Afirmação forte → fonte (estudo, doc oficial, ou projeto real do Rodrigo com nome e link).
- **Links internos** ao longo do corpo (posts relacionados, material/isca) com âncora descritiva.

Esqueleto típico (adapte ao tema):
```
## O problema (a dor real, com exemplo)
## Por que isso acontece (a causa, não só o sintoma)
## O método / a solução (passo a passo concreto)
## Prova (um caso/projeto real com nome e link)
## Conclusão (fecha a tese + CTA)
```

Para post ancorado em notícia, troque os dois primeiros por:
```
## O que aconteceu (a notícia, com fonte e data)
## O que isso revela (a lição por trás)
## Como o método muda esse resultado
```

## 5. Conclusão + CTA

Fecha a tese e convida — sem robotizar.

- **Não** escreva "Em conclusão,..." nem repita tudo de novo. Feche a ideia central com uma frase que fica.
- **Devolva a decisão ao leitor.** Boa nota da casa: "A decisão é sua."
- **CTA suave, único:** baixar um material, ler o próximo post, aplicar o método. Verbo + benefício. Sem urgência falsa.

Exemplo de fim:
> Código que a IA escreveu não é confiável só porque roda. É confiável quando passou pela revisão. O método das 3 camadas está no [checklist de segurança para vibecoders](/link) — baixe e rode no seu próximo deploy.
>
> A decisão é sua.

---

## Frontmatter de saída (padrão)

```markdown
---
title: O que o vazamento da [empresa] ensina sobre revisar código de IA
excerpt: O erro que virou manchete um checklist de revisão pegaria em 30s. As 3 camadas que blindam código gerado por IA antes do deploy.
tags: [seguranca-em-ia, vibecoding, revisao-de-codigo]
---

# O que o vazamento da [empresa] ensina sobre revisar código de IA

<gancho>

## O que aconteceu
...

## Conclusão
...
```

## Checklist de estrutura

- [ ] Título 50–60 car., termo no começo, específico, sem clickbait
- [ ] Excerpt 120–155 car., honesto, único
- [ ] Gancho sem rodeio, promete o que entrega
- [ ] Um H1; H2/H3 em hierarquia lógica e escaneável
- [ ] Parágrafos curtos; listas onde cabe; negrito com parcimônia
- [ ] Pelo menos uma prova com nome e link
- [ ] Links internos com âncora descritiva (post + isca)
- [ ] Conclusão fecha a tese (não resume robótico) + CTA suave único
- [ ] "A decisão é sua." quando couber
