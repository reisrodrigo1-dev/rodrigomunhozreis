# Estrutura da thread — anatomia, tamanho e encadeamento

Uma thread não é um post comprido cortado em pedaços. É uma ideia desdobrada com começo, meio e fim, onde cada peça faz uma coisa só e puxa a próxima. Esta é a anatomia que segura o leitor do post 1 ao último.

---

## A anatomia em três partes

### Post 1 — gancho + promessa (o que viraliza)

O primeiro post é a thread inteira em miniatura. Ele é o único que aparece pra quem não te segue, o único que o algoritmo testa, o único que viraliza. Os outros só existem pra quem ele convenceu.

Duas obrigações:

- **Gancho:** para o scroll. (Padrões inteiros em `ganchos-de-abertura.md`.)
- **Promessa:** diz, em uma linha, o resultado de ler até o fim — o que a pessoa vai saber ou saber fazer.

Quando couber, ancore num número que também é a moldura da thread:

> "5 erros que cometi subindo apps com IA pra produção. O terceiro vazou os dados de todo mundo. 🧵"

Isso faz três coisas: fisga (número + confissão), promete (5 erros + um clímax) e sinaliza tamanho (a pessoa sabe que vai ler 5 pontos). Sinalize que é thread — "🧵", "abaixo 👇", "vou desdobrar". Mas o sinal não salva gancho fraco.

### Corpo — uma ideia por post, encadeada

Cada post do corpo tem **um ponto só** e duas qualidades ao mesmo tempo:

- **Autocontido:** quem parar ali levou algo útil. Um conselho fechado, um erro explicado, um passo completo.
- **Encadeado:** termina com uma corda pro próximo. A pessoa não para porque você não deixou.

Se um post tem duas ideias, vira dois posts. A clareza da thread vem de cada peça fazer uma coisa.

E o corpo **cumpre a promessa do post 1**. Prometeu "5 erros"? Os posts 2 a 6 são os 5 erros, na ordem, sem desviar pro meio. Thread que muda de assunto no post 4 perde a pessoa.

### Fechamento — costura + CTA

O último post **fecha o arco**: retoma a promessa do post 1 e amarra.

> "Era isso. Os 5 erros que me custaram noites de sono e, num caso, os dados dos usuários.
> Nenhum deles é sobre saber programar. Todos são sobre desconfiar do código antes de subir.
> Se serviu, repost ajuda quem tá subindo o primeiro app agora."

Um CTA só, honesto: repost/compartilhar, puxar pro material completo, uma pergunta real, ou "a decisão é sua". Sem fechamento, a thread só para — e thread que só para parece abandonada no meio.

---

## Quantos posts?

Não existe número mágico. Existe a regra: **o número de posts = o número de pontos que o tema exige. Nem um a mais.**

Faixas que funcionam:

- **4 a 7 posts** — o ponto doce. Cabe um gancho, 3 a 5 pontos e um fechamento. Lê-se em menos de um minuto. A maioria das boas threads vive aqui.
- **8 a 12 posts** — só pra tema que aguenta: um passo a passo real, uma história em capítulos, uma lista numerada com profundidade. Cada post ainda precisa entregar — senão vira enchimento.
- **Mais de 12** — raro e arriscado. Quase sempre é um artigo disfarçado. Se chegou aqui, considere escrever no blog (**Pena**) e usar a thread só como resumo que puxa pro artigo.
- **2 a 3 posts** — sinal de alerta. Provavelmente não é thread, é um post (**Praça**). Só vale se os 3 forem mesmo etapas de uma coisa, não uma ideia esticada.

Regra prática: se você precisa **inventar** post pra "ficar maior", a thread já acabou. Pare no último ponto que entrega.

---

## Como cada post puxa o próximo

A corda entre os posts é o que impede a pessoa de parar. Padrões que funcionam:

### 1. Numeração explícita

A própria contagem é a corda. "Erro 1 de 5" cria uma promessa aritmética: faltam 4. O cérebro quer fechar a conta.

> Post 2: "Erro 1: regra de banco aberta. […]"
> Post 3: "Erro 2: chave de API no front. […]"

Funciona bem com listas. Sempre diga o total no post 1 ("5 erros") pra a contagem ter sentido.

### 2. Cliffhanger / gancho de continuidade

Termine o post com uma corda esticada — uma promessa do que vem:

- "Mas o pior erro não foi esse. (próximo)"
- "E aí descobri uma coisa que mudou tudo."
- "Tinha um detalhe que eu ainda não tinha visto."

Use com parcimônia. Cliffhanger em todo post vira manha e cansa. Um ou dois nos pontos certos — sobretudo antes do clímax.

### 3. Sequência lógica / passo a passo

Cada post é um passo, e o passo seguinte só faz sentido depois deste. A própria lógica puxa: "Feito isso, o próximo passo é…". Bom pra tutorial.

### 4. Pergunta → resposta

Um post termina numa pergunta; o próximo responde. "Como eu descobri que tinha vazado? Pela conta da nuvem." (próximo post abre com a história da conta).

> Mistura os padrões. A melhor thread usa numeração pra dar moldura **e** um cliffhanger ou dois nos momentos de virada. Variedade no encadeamento é ritmo.

---

## Erros que matam thread

### Post 1 fraco (o erro fatal)

O mais caro de todos. Post 1 que abre com rodeio ("Hoje quero compartilhar algumas reflexões sobre…"), que não promete nada claro, ou que só faz sentido depois de ler o post 2. Resultado: ninguém chega no post 2. **Toda a thread depende dele** — gaste nele mais tempo que em qualquer outro post. Teste sempre lendo o post 1 isolado.

### Post longo demais

No X, post que estoura o limite e quebra mal. No LinkedIn, post do corpo que vira um bloco de 6 linhas sem respiro. Thread cansa por densidade — cada post tem que ser leve. Um ponto, frases curtas, quebras. Se um post não cabe enxuto, é porque tem duas ideias: separa.

### Sem fechamento

A thread entrega os pontos e simplesmente para no último. Sem costurar, sem retomar a promessa, sem convite. Parece que o autor desistiu no meio. O fechamento é o que transforma uma lista de posts numa thread — e é onde mora o único CTA.

### Mais de uma ideia por post

Dois pontos no mesmo post confundem qual é a corda e qual é o conteúdo. A pessoa lê os dois pela metade. Um post, um ponto.

### Promessa furada (clickbait)

O post 1 promete "o erro que vazou os dados" e o corpo nunca chega lá, ou entrega algo morno. Fisga uma vez e queima a confiança — que é o ativo. A promessa do post 1 é um contrato; o corpo paga.

### Enchimento pra "ficar maior"

Posts que não entregam nada, só existem pra inflar a contagem. A pessoa sente. Pare no último ponto que vale. Thread curta e densa > thread longa e aguada.
