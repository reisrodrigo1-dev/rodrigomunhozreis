# Erros comuns na orquestração

As quatro armadilhas que estragam quase toda orquestração. Cada uma vem com o sintoma (como você percebe), a causa e o conserto. Se uma orquestração deu errado, comece procurando por estes.

---

## 1. Pedir tudo de uma vez

**Sintoma:** você joga a tarefa grande inteira num pedido só e recebe uma resposta **rasa** (toca em tudo, aprofunda em nada) ou a IA **se perde** (começa bem e vai esquecendo o objetivo, se contradiz, abandona partes do pedido).

**Causa:** a tarefa não cabe num pedido. A IA tenta abraçar tudo de uma vez e dilui a atenção. Quanto mais coisa no mesmo pedido, mais raso fica cada pedaço.

**Conserto:** é exatamente o que Maestro existe para fazer — **decomponha** (`decompor-tarefa.md`) e conduza passo a passo. Cada passo com um entregável, um foco. A profundidade volta quando a IA cuida de uma coisa de cada vez.

**Sinal de alerta:** se o seu pedido tem três "e" no meio ("faça X **e** Y **e** Z, considerando A **e** B"), ele provavelmente são vários passos disfarçados de um.

---

## 2. Não verificar entre passos (o erro acumula)

**Sintoma:** o resultado final está errado, mas cada passo "parecia" certo na hora. Você descobre tarde que o erro entrou lá no passo 2 e foi se propagando — o passo 5 está impecável em cima de uma base errada.

**Causa:** você usou a saída de um passo como entrada do próximo **sem checar**. Erro não verificado vira insumo e contamina tudo que vem depois. Em pipeline, isso é fatal: um erro no começo destrói o fim.

**Conserto:** **verifique entre passos, sempre.** Resultado não verificado não avança. Código → Crivo. Texto quase bom → Lapidador. Fato → confira a fonte. Se não passou, corrija **o passo que falhou**, não o próximo. Veja o padrão de verificação em `padroes-de-orquestracao.md`.

**Por que é o erro mais caro:** os outros três fazem você perder um passo. Este faz você perder a orquestração inteira, e ainda por cima esconde onde o problema começou.

---

## 3. Orquestrar o que era simples (over-engineering)

**Sintoma:** você montou 6 passos, sub-agentes, verificação entre cada um... para uma tarefa que um prompt bem-feito resolveria. Gastou mais tempo coordenando do que a tarefa valia.

**Causa:** confundir "ser organizado" com "ser eficaz". Orquestração tem custo — passos, coordenação, atenção sua. Aplicada onde não precisa, ela só atrasa.

**Conserto:** antes de orquestrar, pergunte: **"isso se perderia num pedido só?"** Se um prompt bem-feito (use Forja) entregaria bem, não orquestre. Se você já começou a quebrar e percebeu que era simples, **colapse os passos** e entregue direto. Regra: só orquestre o que se perderia sem orquestração.

**Sinal de alerta:** se o trabalho de montar o plano está maior que o trabalho de fazer a tarefa, pare e faça a tarefa.

---

## 4. Perder o contexto entre passos

**Sintoma:** o passo 3 "esqueceu" uma decisão tomada no passo 1, ou refez algo que o passo 2 já tinha feito, ou contradiz uma escolha anterior. As peças não conversam entre si.

**Causa:** uma de duas, opostas:
- **Contexto de menos** — o próximo passo não recebeu a informação que precisava (a decisão do passo 1 nunca chegou no passo 3).
- **Contexto de mais** — você despejou a resposta inteira do passo anterior no próximo, a IA se afogou no volume e perdeu o que importava.

**Conserto:** entre cada passo, monte o **pacote de contexto certo** (use **Bagagem**): extraia do passo anterior só o que o próximo precisa — nem faltando, nem inchado. Em paralelo, dê a cada parte só o contexto dela. Mantenha um "estado" curto da orquestração (objetivo + decisões já tomadas) que viaja entre os passos.

**Sinal de alerta:** se você precisa relembrar a IA do objetivo a cada passo, seu pacote de contexto está perdendo o essencial — fixe o objetivo e as decisões num resumo curto que acompanha todos os passos.

---

## Resumo

| Erro | Conserto em uma linha |
|---|---|
| Pedir tudo de uma vez | Decomponha; um entregável por passo. |
| Não verificar entre passos | Resultado não verificado não avança (Crivo/Lapidador). |
| Orquestrar o simples | Só orquestre o que se perderia sem orquestração. |
| Perder contexto | Passe o pacote certo (Bagagem): nem de menos, nem de mais. |

Os dois mais caros são o **2** (some com a orquestração toda) e o **3** (custa tempo que a tarefa não valia). Verifique sempre; orquestre só quando vale.
