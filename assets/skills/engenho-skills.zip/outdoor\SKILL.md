---
name: outdoor
description: estrutura anúncios pagos — copy, público e orçamento — para Meta Ads e Google Ads; use ao criar um anúncio, montar uma campanha de tráfego pago ou escrever copy de anúncio.
---

# Outdoor

Inteligência para **montar o anúncio pago** — a peça que vai rodar no Meta Ads ou no Google Ads. A Outdoor entrega as três coisas que decidem se um anúncio funciona: a **copy certa**, o **público certo** e um **orçamento de teste** que aprende sem queimar dinheiro.

Autor: Rodrigo Munhoz Reis — vibecoding com engenharia.

A voz é PT-BR, direta, sem hype. A skill recomenda, explica o porquê e devolve a decisão para quem está no comando: a decisão é sua.

> A Outdoor é a peça de **montagem**. Ela não decide a estratégia de canal (isso é a **Alavanca**), não cria a landing de destino (isso é a **Vitrine**), não faz a arte do criativo (isso é o **Banner**) e não lê o resultado depois que roda (isso é o **Painel**). A Outdoor pega a estratégia já definida e a transforma em um anúncio pronto para publicar: texto, segmentação e verba de teste.

## Visão geral

Um anúncio bom é uma equação de três fatores. Falha um, falha tudo:

```
oferta certa  +  público certo  +  criativo que para o dedo  =  anúncio que funciona
```

- **Oferta certa** — você está oferecendo algo que a pessoa quer, num formato de baixa fricção (um e-book grátis, não "compre meu curso de R$ 2.000" para quem nunca te viu).
- **Público certo** — a mensagem chega em quem tem o problema. No Meta isso é segmentação por interesse/comportamento; no Google é a palavra-chave que a pessoa digita.
- **Criativo que para o dedo** — a primeira linha (no feed) ou o título (na busca) faz a pessoa parar de rolar. Sem isso, oferta e público não importam, porque ninguém viu.

**Regra de ouro do destino:** o anúncio manda para uma **landing de captura** (a página da isca), **nunca** para o blog, a home ou o perfil. Tráfego pago é caro demais para jogar numa página que não captura e-mail. Quem visita e vai embora sem deixar o e-mail foi dinheiro queimado sem aprendizado. A landing é a Vitrine; a isca é o que a Alavanca chama de topo de funil.

**O anúncio não vende. O anúncio compra o clique.** O resto do funil (isca → e-mail → nutrição) é que vende. Então o trabalho da copy do anúncio é simples: prometer uma coisa específica e fazer a pessoa clicar para receber. Não é fechar a venda no anúncio.

## Quando usar esta skill

Use a Outdoor quando o usuário quiser:

- **Criar um anúncio** específico para rodar no Meta ou no Google.
- **Montar uma campanha** de tráfego pago (estrutura: campanha → conjunto → anúncio).
- **Escrever copy de anúncio** — gancho, prova, CTA, e variações para testar.
- **Definir a segmentação** — interesses no Meta, palavras-chave (e negativas) no Google.
- **Definir o orçamento de teste** — quanto por dia, por quantos dias, otimizando por quê.
- **Configurar um dark post** no Meta para não poluir o perfil orgânico.

Não use para: **escolher o canal ou a estratégia de funil** (use Alavanca), **criar a landing de destino** (Vitrine), **gerar a arte/imagem do criativo** (Banner), **ler o resultado depois de rodar** (Painel).

## Como usar a base

Esta skill é uma **base pesquisável**. Antes de montar um anúncio, leia o(s) arquivo(s) de `reference/` relevantes — eles têm os campos exatos de cada plataforma, fórmulas de copy e exemplos prontos no tema do Rodrigo.

| Arquivo | Use quando o assunto for |
|---|---|
| `reference/meta-ads.md` | Anúncio no Facebook/Instagram: objetivo (Tráfego/Leads), dark post, público por interesses, posicionamento Advantage+, orçamento de teste, e os campos do criativo (texto principal, título, descrição, CTA). |
| `reference/google-ads.md` | Anúncio de busca (Search): intenção, palavras-chave + negativas, títulos/descrições do anúncio responsivo, extensões/sitelinks. |
| `reference/copy-de-anuncio.md` | Fórmulas de copy (gancho de problema/promessa específica, prova, CTA), variações para teste A/B, voz anti-hype e exemplos. Leia em qualquer anúncio, dos dois canais. |

## PROCEDIMENTO — montar um anúncio

Siga em ordem. Cada passo alimenta o próximo. Não pule para a copy antes de saber objetivo e público.

### 1. Definir objetivo e destino
Antes de escrever uma palavra, responda:

- **Qual a ação?** Quase sempre: capturar e-mail oferecendo uma isca (e-book, checklist, mini-curso grátis).
- **Qual o destino?** A **landing de captura** da isca (Vitrine), não o blog nem a home. Confirme que essa página existe e captura e-mail. Se não existe, pare aqui — montar anúncio sem landing de captura é queimar verba (avise e mande para a Alavanca/Vitrine).
- **Qual canal?** Se isso ainda não está decidido, é trabalho da Alavanca. Resumo prático: **Meta** quando você precisa criar a demanda / interromper alguém que não está procurando; **Google Search** quando a pessoa já busca a solução (intenção alta).

Exemplo do tema: oferecer o e-book *"Vibecoding com engenharia: como construir com IA sem fazer besteira"* numa landing de captura. Destino = essa landing. Ação = baixar o e-book deixando o e-mail.

### 2. Definir o público
Depende do canal:

- **Meta (interesses):** monte 1 público por conjunto de anúncios. Combine interesses relacionados ao problema (ex.: empreendedorismo, startups, no-code, ferramentas de IA). Não empilhe interesses demais — comece amplo o suficiente para a entrega rodar e deixe o algoritmo (Advantage+) otimizar. Detalhes e tamanhos em `reference/meta-ads.md`.
- **Google (palavras-chave + negativas):** liste as palavras que alguém com o problema digitaria, agrupadas por intenção. **Sempre** monte a lista de **palavras-chave negativas** (o que você NÃO quer pagar para aparecer) — é o que protege o orçamento. Detalhes em `reference/google-ads.md`.

### 3. Criativo + copy
Estruture a mensagem em três blocos (fórmulas completas em `reference/copy-de-anuncio.md`):

- **Gancho** — a primeira linha/título. Para o dedo com um problema reconhecível ou uma promessa específica. Específico vence genérico.
- **Prova** — por que acreditar (método, número concreto, autoridade, demonstração). Sem prova, é só mais uma promessa.
- **CTA** — a ação clara e única ("Baixe o e-book grátis"). Um CTA, não três.

Escreva sempre **2 a 3 variações** de gancho para testar (mesmo público, criativos diferentes). É assim que você descobre o que para o dedo. A arte/imagem em si é trabalho do **Banner**.

### 4. Orçamento de teste
O objetivo do teste é **aprender barato**, não escalar.

- **Quanto:** comece com **R$ 20 a 50 por dia** por conjunto de anúncios. Pequeno o suficiente para não doer, grande o suficiente para gerar dados.
- **Por quanto tempo:** **3 a 7 dias** ou até juntar volume mínimo (~50 cliques) antes de julgar. Não mate no primeiro dia.
- **Otimizar por quê:** no Meta, otimize por **visualizações da página de destino** (landing page views), não por cliques no link. Isso filtra o clique acidental e conta quem realmente carregou a sua landing — é o número que se conecta ao funil.

### 5. O que medir antes de decidir
Não decida no susto nem na emoção. Antes de continuar, pausar ou escalar, junte volume e olhe:

- **CTR** (parou o dedo?) — se está baixo, o problema é o **criativo/copy**. Troque o gancho antes de culpar o público.
- **CPL / custo por lead** (a conta fecha?) — leads capturados pela verba gasta.
- **Custo por visualização da página de destino** — o tráfego está chegando na landing ou desistindo no caminho?

A **leitura e a decisão** (continuar / pausar / escalar) é trabalho do **Painel** — quando os números entrarem, mande para lá. A Outdoor monta o anúncio; o Painel lê o resultado.

## A suíte Engenho

- **Alavanca** — estratégia: qual canal, qual funil, qual prioridade.
- **Outdoor** (esta) — monta o anúncio: copy + público + orçamento de teste.
- **Banner** — cria a arte/imagem do criativo.
- **Vitrine** — cria a landing de captura (o destino do anúncio).
- **Painel** — lê o resultado depois que o anúncio roda.

---

A Outdoor monta o anúncio com método e mostra o porquê. A decisão é sua.
