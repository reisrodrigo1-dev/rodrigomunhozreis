# Padrões de orquestração

Depois de decompor (`decompor-tarefa.md`), você precisa decidir **como os passos se conectam**. Estes são os padrões. Quase toda orquestração real é uma combinação deles. Cada padrão traz: quando usar, como montar e um exemplo prático.

## Mapa rápido

| Padrão | Use quando | Forma |
|---|---|---|
| Sequencial (pipeline) | um passo depende da saída do anterior | A → B → C |
| Paralelo (fan-out e juntar) | passos são independentes | A, B, C ao mesmo tempo → juntar |
| Verificação entre passos | sempre que um erro contaminaria o resto | passo → checar → seguir |
| Loop até critério | a qualidade ainda não bateu o alvo | gerar → avaliar → repetir |
| Gerar N e escolher | há várias opções e você quer a melhor | gerar N → comparar → escolher |

---

## 1. Sequencial (pipeline)

A saída de um passo é a entrada do próximo. Use quando **há dependência real** — B não faz sentido sem o resultado de A.

**Como montar:**
- Ordene os passos pela dependência.
- Entre um passo e o outro, passe **só o contexto necessário** (Bagagem), não a resposta inteira.
- **Verifique antes de avançar** (veja padrão 3). É o pipeline que mais sofre com erro acumulado: o erro do passo 1 se propaga até o fim.

**Exemplo — escrever um artigo:**

```
1. Pesquisar      → entregável: 5 fontes + tese de cada
2. Estruturar     → entregável: outline com seções (usa as fontes)
3. Redigir        → entregável: rascunho (usa o outline)
4. Revisar        → entregável: versão final (Crivo/Lapidador no rascunho)
```

Cada seta carrega só o que o próximo passo precisa: a pesquisa vira insumo do outline, o outline vira esqueleto do texto. Não jogue as 5 fontes inteiras dentro do passo de redação — passe o outline e os trechos citáveis.

---

## 2. Paralelo (fan-out e juntar)

Passos **independentes** rodam ao mesmo tempo; no fim, você junta os resultados. Use quando nenhum passo precisa da saída do outro.

**Como montar:**
- **Fan-out:** dispare cada parte com o **mesmo padrão de instrução**, para as saídas voltarem comparáveis/encaixáveis.
- Dê a cada parte só o contexto dela (não o contexto das outras — isso só atrapalha).
- **Juntar:** um passo final integra as partes. Esse passo de junção quase sempre precisa de verificação, porque é onde aparecem sobreposição, contradição e buraco entre as peças.

**Exemplo — documentar 4 endpoints de uma API:**

```
fan-out:  [doc do GET]  [doc do POST]  [doc do PUT]  [doc do DELETE]   (em paralelo)
juntar:   consolidar num documento único, padronizar formato, remover repetição
```

**Cuidado clássico:** partes paralelas tendem a divergir no formato e a repetir contexto comum. Defina o formato de saída **antes** do fan-out e resolva as bordas no passo de junção.

---

## 3. Verificação / revisão entre passos

Não é um passo isolado — é o que você faz **entre todos os outros**. A regra: **resultado não verificado não vira insumo do próximo passo.** Erro empilhado é o jeito nº 1 de uma orquestração inteira sair errada.

**Como verificar, por tipo de saída:**

| Saída do passo | Como verificar |
|---|---|
| Código / diff | **Crivo** (Protocolo de 5 Camadas) |
| Texto quase bom, genérico ou tom errado | **Lapidador** |
| Afirmação factual / dado | conferir contra a fonte (Garimpo se precisar pesquisar) |
| Decisão / escolha | bate com os critérios definidos no passo de decomposição? |
| Entregável estruturado (JSON, tabela) | tem todos os campos? formato válido? |

**Se não passou:** corrija **antes** de avançar. Reabra o passo, não o próximo. Se o passo revelou que o entendimento da tarefa mudou, volte e replaneje os passos seguintes.

**Exemplo dentro do pipeline do artigo:** depois de "Redigir", rode Lapidador no rascunho (tom, foco, cortes) **antes** de chamar a revisão final. Assim a revisão final trabalha em cima de um texto já decente, não de um rascunho cru.

---

## 4. Loop até critério

Repita um passo até a saída bater um **critério explícito**. Use quando a primeira tentativa raramente fica boa e você consegue dizer objetivamente o que é "bom".

**Como montar:**
- Defina o **critério de parada** antes de começar (senão o loop não para nunca — ou para cedo demais).
- Cada volta: **gerar → avaliar contra o critério → ajustar**.
- Coloque um **teto de iterações**. Se não convergiu em 2–3 voltas, o problema costuma ser o critério ou a instrução, não a falta de mais uma tentativa.

**Exemplo — copy de um anúncio:**

```
gerar headline → avaliar (clareza? promessa? sem hype?) → se não passou, ajustar e repetir
parar quando: passa nos 3 critérios OU chegou na 3ª volta (aí escolhe a melhor das tentativas)
```

**Cuidado:** loop sem critério vira refino infinito (o lugar onde "quase bom" consome horas). O critério é o freio.

---

## 5. Gerar N opções e escolher

Caso especial e muito útil. Em vez de buscar a resposta "certa" de primeira, **gere várias e escolha**. Use em decisão, design, naming, copy — qualquer coisa onde variedade ajuda.

**Como montar:**
- Peça **N opções genuinamente diferentes** (não três variações da mesma ideia).
- Defina os **critérios de escolha antes** de ver as opções (evita escolher pela primeira que agrada).
- Passo de escolha: compare contra os critérios, escolha uma (ou combine pontos de duas), justifique.

**Exemplo — decidir a arquitetura:**

```
gerar 3 abordagens (monolito / serverless / serviços) com trade-off de cada
escolher: comparar contra os critérios (time, escala, custo, prazo) → decisão fundamentada
```

Repare que isso usa decomposição **por pergunta** + padrão **gerar-e-escolher**. Padrões se combinam.

---

## Sub-agentes vs um chat só

A pergunta prática: **dou cada passo para um agente/chat separado, ou conduzo tudo num chat só?**

### Use um chat só quando

- Os passos compartilham muito contexto e cabe na janela sem inchar.
- A tarefa é sequencial e curta (poucos passos).
- O custo de coordenar vários chats supera o ganho.
- Você quer ver e ajustar passo a passo, ao vivo.

É o caso mais comum. Não monte uma frota de agentes para o que um chat conduzido com método resolve.

### Use sub-agentes (ou chats separados) quando

- Os passos são **independentes** e você ganha rodando **em paralelo** (fan-out).
- Cada passo precisa de **muito contexto próprio** que poluiria os outros — separar mantém cada janela limpa e focada.
- A tarefa é longa e um chat único começaria a **perder contexto** ou se contradizer.
- Você quer **isolar a verificação**: um agente faz, outro revisa, sem o revisor "torcer" pelo que ele mesmo escreveu.

**Trade-off honesto:** sub-agentes paralelizam e isolam contexto, mas **custam coordenação** — você tem que montar a entrada de cada um e juntar as saídas no fim. Mais agentes = mais junção. Só vale quando o ganho de paralelismo ou de contexto limpo paga esse overhead.

Regra de bolso: **comece num chat só. Suba para sub-agentes quando o chat único começar a se perder ou quando o paralelismo for ganho real.**

---

## Combinando padrões (o caso real)

Orquestração de verdade encadeia padrões. Exemplo de um app:

```
1. PLANEJAR (sequencial, por pergunta) → o que construir, em que ordem
2. CONSTRUIR (paralelo, por componente) → auth | pagamentos | dashboard  (fan-out)
   ↳ cada componente verificado com Crivo antes de entrar
3. INTEGRAR (sequencial) → juntar os componentes, resolver as bordas
4. TESTAR (loop até critério) → rodar testes, corrigir, repetir até passar
5. SINTETIZAR → entregável final conferido contra o objetivo do passo 1
```

Escolha o padrão por trecho, não para a tarefa inteira. E entre cada trecho: **verifique.**
