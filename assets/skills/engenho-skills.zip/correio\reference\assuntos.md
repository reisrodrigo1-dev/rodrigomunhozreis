# Linhas de assunto

O assunto tem um trabalho só: fazer abrir. Mas com honestidade — ele promete o que o corpo entrega. Assunto bom não é o que arranca o clique; é o que arranca o clique **e cumpre**. Clickbait abre uma vez e queima a lista para sempre.

## Princípios

1. **Honestidade acima de tudo.** O assunto entrega o que o corpo cumpre. Se o e-mail não paga a promessa, troque o assunto, não o e-mail.
2. **Curiosidade, não engano.** Pode deixar uma lacuna que dá vontade de abrir — desde que o e-mail feche a lacuna de verdade.
3. **Específico ganha de genérico.** "As 3 perguntas que eu faço pro código da IA" abre mais que "Dicas de IA". Número, detalhe e concretude criam confiança.
4. **Curto, mobile-first.** Mire em ~40 caracteres. No celular o assunto corta. O essencial tem que aparecer no começo.
5. **Soa a gente, não a marketing.** Escreva como você falaria. "Te tiro da lista?" ganha de "Importante: confirme sua inscrição".
6. **Sem gatilho de spam.** Evite CAIXA ALTA, excesso de "!!!", "GRÁTIS", "URGENTE", "ÚLTIMA CHANCE" (a não ser que seja literalmente verdade e raro).
7. **Escreva o assunto depois do corpo.** Você só sabe o que prometer depois de saber o que entregou. Assunto antes do corpo vira clickbait.

## Alavancas que funcionam (sem mentir)

- **Curiosidade honesta:** abre uma lacuna que o e-mail fecha. ("O bug que a IA esconde de você")
- **Específico/numérico:** número concreto sinaliza conteúdo real. ("3 perguntas...", "em 30 segundos")
- **Pergunta direta:** a mente quer responder. ("Te tiro da lista?")
- **Contra-intuitivo:** quebra uma crença comum. ("Rodar não é estar certo")
- **Benefício claro:** o que a pessoa ganha ao abrir. ("Revise o código da IA em 30 segundos")
- **Identificação:** a pessoa se reconhece. ("Achei que era só comigo")

## 20+ exemplos com o porquê

**Curiosidade honesta**
1. **"O bug que a IA esconde de você"** — lacuna ("qual bug?") que o e-mail fecha de verdade. Não é exagero; é um problema real silencioso.
2. **"O que ninguém te conta sobre 'rodou tá certo'"** — promete uma verdade incômoda; o corpo precisa entregar essa verdade, ou vira clickbait.
3. **"A pergunta que mudou meu jeito de codar com IA"** — curiosidade + promessa de uma única coisa concreta (cumprível).

**Específico / numérico**
4. **"As 3 perguntas que eu faço pro código da IA"** — número + benefício + pessoal. Sinaliza conteúdo aplicável, não papo.
5. **"Revisão de código da IA em 30 segundos"** — benefício + tempo concreto. O número ancora a expectativa.
6. **"5 minutos pra não quebrar em produção"** — tempo curto + dor real (produção quebrando).
7. **"1 hábito que pega 80% dos erros da IA"** — número + proporção concreta. Específico vence "melhore seu código".

**Pergunta direta**
8. **"Te tiro da lista?"** — choca um pouco, soa humano, dá vontade de responder. Perfeito para reengajamento.
9. **"Você revisa o que a IA escreve?"** — a pessoa responde mentalmente e quer ver se está certa.
10. **"Já te entregaram uma bomba-relógio em código?"** — pergunta + imagem forte; o e-mail conta o caso.

**Contra-intuitivo**
11. **"Rodar não é estar certo"** — quebra a crença "se rodou, tá ok". Tensão que pede explicação.
12. **"Mais IA não te deixa mais rápido"** — afirma o oposto do esperado; o corpo precisa sustentar.
13. **"Por que eu parei de confiar no autocomplete"** — pessoal + contra-intuitivo; promete uma história real.

**Benefício claro**
14. **"Construa rápido sem rezar pra não quebrar"** — benefício + a dor que ele remove, na linguagem da pessoa.
15. **"Confie no que você entrega"** — benefício emocional concreto (parar de ter medo do próprio código).

**Identificação**
16. **"Achei que era só comigo"** — a pessoa se reconhece no perrengue; abre pra ver se é ela mesma. Ótimo para prova social.
17. **"Pra quem junta dica solta e não evolui"** — endereça um grupo específico; quem é desse grupo abre na hora.

**Entrega / boas-vindas**
18. **"Seu e-book chegou (link aqui dentro)"** — direto, cumpre na hora, zero mistério. Boas-vindas não precisa de curiosidade; precisa de clareza.
19. **"Pronto — aqui está o que você pediu"** — confirma a ação da pessoa; sensação de "deu certo".

**Oferta (com prazo real)**
20. **"Está aberto: o método completo de vibecoding com engenharia"** — direto, sem falsa urgência; diz o que é.
21. **"Fecha domingo às 23h59"** — urgência **verdadeira** (a data tem que ser real). Sem prazo real, não use.
22. **"Se 'dica solta' não basta mais, isso é pra você"** — qualifica quem deve abrir; honesto sobre para quem é.

## Exemplos ruins (e por quê)

- **"URGENTE!!! Você não vai acreditar 🤯"** — clickbait puro, CAIXA ALTA, gatilho de spam, promessa vazia. Abre uma vez, perde a confiança para sempre.
- **"Segredo revolucionário que ninguém conta"** — hype, superlativo vazio, não diz nada de concreto.
- **"Última chance!" (sem prazo real)** — urgência falsa. Quando a pessoa percebe que "a última chance" volta toda semana, para de abrir.
- **"Dicas de IA"** — genérico demais. Não dá nenhum motivo específico para abrir agora.
- **"Novidades da semana"** — fala de você, não do leitor. Sem benefício, sem curiosidade.

## Teste rápido antes de enviar

- O corpo **cumpre** o que o assunto promete? (Se não, troque o assunto.)
- Cabe e faz sentido nos primeiros ~40 caracteres (celular)?
- Soa a gente de verdade, não a robô de marketing?
- Tem CAIXA ALTA, "!!!", ou palavra de spam? (Tira.)
- É específico ou genérico? (Específico ganha quase sempre.)
- Se você recebesse isso, abriria sem se sentir enganado depois?
