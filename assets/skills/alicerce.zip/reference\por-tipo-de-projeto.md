# Ajustes das instruções por tipo de projeto

O esqueleto das instruções é o mesmo (papel, stack, segurança, design, código, nunca
faça). O que muda é o **peso** de cada seção e as regras específicas. Abaixo, o ajuste por
tipo. Pegue o seu, jogue na seção certa do template e adapte.

A decisão é sua — estes são os defaults sensatos, não dogma.

---

## Landing page / site institucional

**O que importa:** performance, SEO, conversão, acessibilidade. Pouco estado, pouca
lógica. O risco não é vazar banco — é página lenta que não converte e não rankeia.

**Ênfase nas instruções:**
- **Performance é requisito, não otimização.** Core Web Vitals (LCP, CLS, INP) verdes.
  Imagem otimizada (`next/image`), sem JS desnecessário, fonte com `display: swap`.
- **SEO de verdade:** metadata por página, Open Graph, dados estruturados quando couber,
  HTML semântico, headings em ordem.
- **Renderização estática por padrão** (SSG/ISR). Client component só onde há
  interatividade real.
- **Acessibilidade AA** — é também SEO e alcance.
- **Conversão:** CTA claro, formulário que funciona e dá feedback, sem fricção.

**Segurança (mais leve, mas existe):**
- Formulário de contato/lead: validar input no servidor, rate limit, anti-spam (honeypot
  ou captcha). Nunca mandar lead direto do client para serviço externo com chave exposta.

**Pode aliviar:** estado complexo, autenticação, regras de banco elaboradas (se não há
área logada).

**Nunca faça (específico):** carregar biblioteca pesada por um efeito visual; bloquear a
renderização com script de terceiro; quebrar o SEO com conteúdo só client-side.

---

## SaaS / app com login

**O que importa:** segurança, multi-tenancy, controle de acesso, confiabilidade. Aqui
tem dado de usuário, cobrança, e o estrago de uma falha é real.

**Ênfase nas instruções:**
- **Segurança no topo.** Todas as regras de ouro de segurança valem com força total.
- **Multi-tenant correto:** todo dado tem `orgId`/`tenantId`; toda query filtra por ele;
  as regras de banco garantem isolamento entre tenants. Vazamento entre clientes é o pior
  bug possível aqui.
- **Authz por role/plano:** o que o usuário pode fazer depende de role e do plano
  contratado. Cheque no servidor, sempre.
- **Auditoria:** ações sensíveis (mudar plano, deletar dado, convidar usuário) ficam
  logadas — quem, quando, o quê.
- **Idempotência e consistência** em operações de escrita importantes; cuidado com
  webhook duplicado (ex.: Stripe).
- **Estados de UI completos** (loading/erro/vazio) — produto pago não pode parecer quebrado.

**Segurança (crítica):**
- Isolamento de tenant nas regras de banco, testado.
- Rate limiting em endpoints sensíveis.
- Sessão e tokens tratados com cuidado; logout invalida de verdade.
- Billing nunca confia em valor vindo do client — o preço é decidido no servidor.

**Nunca faça (específico):** query sem filtro de tenant; expor dado de um cliente para
outro; confiar no front para decidir permissão ou preço; rodar migração em produção sem
backup e confirmação.

---

## E-commerce / loja

**O que importa:** segurança de pagamento, integridade de pedido e estoque, performance
de catálogo, confiança. Dinheiro troca de mãos — a barra de segurança é máxima.

**Ênfase nas instruções:**
- **Pagamento nunca passa pelo seu código sem necessidade.** Use o provedor (Stripe,
  Mercado Pago) com tokenização/checkout dele. Não toque em número de cartão — escopo PCI
  é problema do provedor, mantenha assim.
- **Preço e total são calculados no servidor.** Nunca confie no valor que vem do
  carrinho do client. Recalcule tudo no backend antes de cobrar.
- **Estoque e pedido com consistência:** evitar venda de item esgotado (concorrência);
  transação atômica ao baixar estoque; pedido idempotente.
- **Webhook de pagamento validado** (assinatura) e idempotente — webhook duplica.
- **Performance de catálogo:** listagem paginada, imagem otimizada, busca rápida, cache
  onde der.
- **Checkout sem fricção:** poucos passos, feedback claro, estados de erro de pagamento
  bem tratados.

**Segurança (máxima):**
- Verificar assinatura de todo webhook; tratar como não confiável até validar.
- Recalcular preço/frete/desconto no servidor.
- Proteger contra fraude básica (rate limit, validação de cupom no servidor).
- LGPD nos dados do cliente (endereço, histórico de compra).

**Nunca faça (específico):** confiar no preço/total vindo do client; armazenar dado de
cartão; baixar estoque sem transação; aceitar webhook sem validar assinatura; expor chave
secreta do gateway.

---

## App mobile / PWA / React Native

**O que importa:** funcionar offline/instável, performance no device, o fato de que **o
client é território hostil** — qualquer um inspeciona e modifica o app na mão dele.

**Ênfase nas instruções:**
- **Toda regra de negócio crítica fica no servidor.** O app é UI; a verdade (preço,
  permissão, validação final) é do backend. No mobile, o usuário controla o binário.
- **Nenhum segredo no app.** Chave embutida em app é chave pública — pode ser extraída.
  Use backend-for-frontend; o app fala com o seu servidor, não com serviços de terceiro
  com chave secreta.
- **Offline-first / rede instável:** trate falha de rede como normal, não exceção. Estado
  de loading/erro/retry em tudo. Cache e sincronização quando aplicável.
- **Performance no device:** lista virtualizada, imagem dimensionada, evitar re-render
  caro, cuidar do tamanho do bundle/app.
- **Armazenamento seguro:** token em storage seguro do device (Keychain/Keystore), não em
  storage comum em texto plano.

**Segurança (client hostil):**
- Validar tudo de novo no servidor — a validação do app é UX, não segurança.
- Certificate pinning / HTTPS sempre.
- Não logar PII nem token; cuidado com o que vai para crash reporter.

**Nunca faça (específico):** embutir segredo no app; confiar em validação só client-side
para algo sensível; assumir que há rede; guardar token em texto plano.

---

## Como combinar

Projetos reais misturam tipos: um SaaS com landing page de marketing, um e-commerce que é
também um app. Quando misturar:

1. Comece pelo tipo de **maior risco** (e-commerce > SaaS > app > landing) e use a barra
   de segurança dele.
2. Aplique as ênfases de performance/SEO da landing **na parte pública**, e as de
   segurança/authz **na parte logada**.
3. Se houver dúvida entre aliviar e endurecer uma regra: **endureça.** É mais barato
   relaxar depois do que descobrir o buraco em produção.

Leve os ajustes escolhidos para as seções 3, 4, 5 e 6 do template `instrucoes-projeto.md`.
