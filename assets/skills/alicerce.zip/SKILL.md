---
name: alicerce
description: Gera as instruções iniciais do projeto (a "memória" que ensina a IA a trabalhar com segurança, bom design e seus padrões desde o primeiro comando). Use ao começar um projeto ou ao configurar como a IA deve se comportar nele.
---

# Alicerce

> Antes de pedir o primeiro comando, ensine a IA a trabalhar do seu jeito.
> Por Rodrigo Munhoz Reis — vibecoding com engenharia.

## O que é o Alicerce

Alicerce gera as **instruções iniciais do projeto**: o documento que a IA lê *antes* de escrever qualquer linha de código. É a memória do projeto — papel da IA, stack, convenções, regras de segurança, padrões de design e a lista do "nunca faça".

É o `CLAUDE.md` (ou `.cursorrules`, ou as regras do projeto, ou o system prompt — o nome muda, a ideia não). O documento que padroniza a qualidade desde o comando número 1.

## Por que instruções iniciais elevam a qualidade

Sem instruções, a IA chuta. Cada chute é uma loteria: às vezes acerta o padrão da casa, às vezes inventa um do zero, às vezes vaza uma chave de API num client component. Você corrige, ela esquece no próximo chat, você corrige de novo. O custo não é o erro — é a **repetição do erro**.

Com instruções iniciais boas:

- **O comando #1 já sai no padrão.** Não tem fase de "ensinar a IA o projeto" a cada sessão. O contexto está escrito.
- **Segurança vira default, não revisão.** "Nunca expor segredo no client" deixa de ser algo que você pega no review e passa a ser algo que a IA já não faz.
- **Decisões ficam consistentes.** Mesma stack, mesmas convenções, mesmo jeito de tratar erro — em todo arquivo, em toda sessão, com qualquer pessoa do time.
- **Você revisa menos lixo.** O tempo de review vai para o que importa (lógica de negócio) em vez de para o que era pra ser automático (estilo, estrutura, segurança óbvia).

Pense assim: você não contrataria um dev sênior e o deixaria commitar sem nunca contar a stack, os padrões e o que é proibido. As instruções iniciais são o onboarding da IA — escrito uma vez, lido sempre.

A decisão final continua sua. O Alicerce não decide o projeto por você; ele captura as suas decisões num formato que a IA respeita.

## Quando usar

- **Começando um projeto novo.** Antes do primeiro `create-next-app`, monte o alicerce.
- **Herdou um projeto sem instruções.** A IA está fazendo bagunça? Documente o padrão que já existe e force a IA a seguir.
- **A IA repete o mesmo erro.** Toda vez ela esquece de validar input, ou usa `any`, ou cria um componente fora do padrão? Vira regra.
- **Entrou gente no time (humana ou IA).** O alicerce é o contrato comum.
- **Trocou de ferramenta de IA.** As instruções são portáveis — o mesmo documento serve para Claude, Cursor, Copilot.

## Procedimento

### 1. Entender o projeto

Antes de escrever uma linha de instrução, levante o terreno. Pergunte ao usuário (ou infira do código existente) e **confirme** as decisões em aberto — não chute:

**Stack e infra**
- Qual a stack? (padrão deste autor: Next.js + TypeScript + Tailwind + Firebase + Vercel)
- App Router ou Pages Router? Server Components por padrão?
- Banco: Firestore, Postgres, outro? Quem aplica as regras de acesso?
- Onde roda: Vercel, outro? Quais variáveis de ambiente existem?

**Padrões e convenções**
- Estrutura de pastas já definida? (ex.: `app/`, `components/`, `lib/`, `actions/`)
- Convenção de nomes? (componentes em PascalCase, hooks `use*`, etc.)
- Gerenciamento de estado, data fetching, tratamento de erro — tem padrão?
- Tem design system / tokens / biblioteca de UI (shadcn, etc.)?

**Segurança — o ponto que não pode escapar**
- Onde ficam os segredos? Quais variáveis são públicas (`NEXT_PUBLIC_*`) e quais são server-only?
- Quem valida input? Como se autentica e autoriza?
- As regras do banco (Firestore Rules / RLS) estão escritas? Negam por padrão?

**O que NUNCA fazer**
- Quais decisões já estão fechadas e não devem ser questionadas? (ex.: "não trocar de framework", "não adicionar dependência sem perguntar")
- Quais erros já aconteceram e não podem se repetir?

Se o usuário não souber responder algo, ofereça o default razoável da stack e **marque como decisão a confirmar**. Não invente regra de segurança crítica sem alinhar.

### 2. Montar o documento de instruções

Use `templates/instrucoes-projeto.md` como base e preencha com o que foi levantado. O documento cobre, nesta ordem:

1. **Papel da IA no projeto** — quem ela é aqui, o nível de autonomia, e a regra mestra ("a decisão é do humano; na dúvida, pergunte").
2. **Stack e convenções** — a stack exata, versões quando relevante, estrutura de pastas, nomes, padrões de data fetching / estado / erro.
3. **Regras de segurança** — segredos nunca no client, validação de todo input não confiável, regras de banco que negam por padrão, autenticação/autorização. Ver `reference/regras-de-ouro.md`.
4. **Regras de design / UX** — acessibilidade mínima, responsividade, design tokens em vez de valores soltos, estados de loading/erro/vazio, consistência visual.
5. **Padrão de código** — TypeScript estrito (sem `any` solto), funções pequenas, nomes claros, tratamento de erro explícito, sem código morto, comentar o "porquê" não o "o quê".
6. **O "nunca faça"** — a lista curta e dura. As coisas que, se a IA fizer, quebram o projeto ou a confiança.

Para ajustar o tom e o foco conforme o tipo de projeto (landing, SaaS, e-commerce, app), use `reference/por-tipo-de-projeto.md`.

Princípios ao escrever as regras:
- **Específico vence genérico.** "Valide input" é fraco. "Valide todo body de Server Action com Zod antes de tocar no banco" é instrução.
- **Diga o porquê quando não for óbvio.** A IA (e o humano) seguem melhor regras que entendem.
- **Curto e escaneável.** Bullet points, não parágrafos. O documento é lido toda sessão; respeite o tempo.
- **Mostre o certo e o errado.** Um exemplo de "faça assim / não assim" vale mais que um parágrafo de teoria.

### 3. Onde colocar

O documento gerado é a saída. Onde ele mora depende da ferramenta:

- **Claude Code / Claude.ai** → `CLAUDE.md` na raiz do projeto (ou em subpastas para regras locais).
- **Cursor** → `.cursorrules` na raiz, ou `.cursor/rules/*.mdc` para regras por escopo.
- **GitHub Copilot** → `.github/copilot-instructions.md`.
- **System prompt genérico** → cole o conteúdo como instrução de sistema do agente.
- **Time** → versione no Git. O alicerce evolui com o projeto; trate como código.

Dica: mantenha **um** documento como fonte da verdade e, se precisar, gere as variações por ferramenta a partir dele. Duplicar regras em três arquivos é garantia de desalinhar.

## Saída

O resultado é o **documento de instruções pronto**, preenchido para o projeto do usuário — copiável direto para `CLAUDE.md` (ou equivalente). Entregue o documento completo, não um esqueleto. Se faltou informação, entregue mesmo assim com as lacunas marcadas como `[CONFIRMAR: ...]` para o usuário fechar.

## Arquivos desta skill

- `templates/instrucoes-projeto.md` — modelo completo e preenchível do documento de instruções.
- `reference/regras-de-ouro.md` — regras de ouro de segurança e bom design para embutir em qualquer projeto.
- `reference/por-tipo-de-projeto.md` — ajustes das instruções por tipo de projeto.
