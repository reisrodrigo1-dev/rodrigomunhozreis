# Regras de Ouro — segurança e bom design

As regras abaixo valem para quase qualquer projeto web (Next.js / Firebase / Vercel e
parecidos). Cada uma vem com o *porquê* — instrução que se entende, se segue. Copie as
que se aplicam para dentro das instruções do projeto.

A decisão final é sua. Estas são as regras que, na prática, separam projeto que dá
trabalho de projeto que dá sustento.

---

## Segurança

### 1. Segredo nunca chega ao client
**Regra:** chave privada, service account, token de servidor e connection string ficam
server-side. No Next.js, só variáveis `NEXT_PUBLIC_*` vão para o navegador — todo o resto
fica no server. Nunca hardcode credencial; nunca logue segredo; nunca commite `.env`.

**Por quê:** tudo que vai para o client é público — basta abrir o DevTools. Uma chave
vazada é acesso direto ao seu banco, à sua conta de e-mail transacional, ao seu Stripe.
O vazamento é silencioso até a fatura (ou o incidente) chegar.

**Como aplicar:** segredos em variáveis de ambiente; `.env*` no `.gitignore`; uso só em
Server Components, Server Actions, Route Handlers e funções server. No client, fale com o
servidor, não com o serviço.

### 2. Todo input não confiável é validado antes de ser usado
**Regra:** body de request, params, query string, payload de webhook, dado vindo do
client — tudo passa por um schema (ex.: Zod) antes de tocar em banco, serviço ou lógica.

**Por quê:** o client mente. Pode ser um usuário malicioso, um bug, ou um script. Sem
validação, você abre porta para injeção, corrupção de dado, e estados impossíveis que
quebram o app lá na frente. Validar na borda é mais barato que caçar o estrago depois.

**Como aplicar:** um schema por entrada; `schema.parse(input)` como primeira linha da
action; tipo derivado do schema (`z.infer`) para não duplicar.

### 3. O banco nega por padrão
**Regra:** Firestore Security Rules / Postgres RLS começam bloqueando tudo e liberam só
o necessário — por usuário autenticado, dono do dado, com a operação certa. A regra do
banco é a fonte da verdade de segurança, não a checagem no app.

**Por quê:** a checagem no app protege o caminho feliz. Mas o banco é acessível por
outros caminhos (SDK no client, outra função, um endpoint esquecido). Se a regra do
banco for permissiva, qualquer brecha no app vira acesso total. Negar por padrão
significa que esquecer de liberar falha fechado — o erro seguro.

**Como aplicar:** comece com `allow read, write: if false;` e libere caso a caso; teste
as regras (emulador do Firebase / testes de policy); nunca dependa só do `if (user)` no
React.

### 4. Autenticação não é autorização
**Regra:** estar logado (authn) é diferente de ter permissão (authz). Toda operação
sensível verifica os dois: *quem é* e *se pode*. Cheque dono e role no servidor.

**Por quê:** o erro clássico — usuário A consegue editar o dado do usuário B só trocando
um ID na URL (IDOR). Login não basta; é preciso confirmar que *este* usuário pode tocar
*neste* recurso.

**Como aplicar:** um helper `requireAuth()` no servidor; depois dele, compare `user.id`
com o dono do recurso ou o role exigido. Faça isso no servidor, sempre — nunca confie em
esconder o botão no front.

### 5. Não exponha mais do que o necessário
**Regra:** não devolva campos sensíveis numa API que não precisa deles. Não coloque PII,
token ou ID interno em URL, em log ou em estado de client. Princípio do menor privilégio.

**Por quê:** dado que não trafega não vaza. Cada campo a mais numa resposta, cada ID em
URL compartilhável, cada token em log é superfície de ataque e risco de LGPD.

**Como aplicar:** selecione campos explicitamente (não `select *`); mascare/omita PII em
log; use POST com body em vez de query string para dado sensível.

### 6. Dependência é superfície de ataque
**Regra:** não adicione pacote por impulso. Prefira o que já está no projeto e o que é
mantido. Trave versões (lockfile commitado) e rode auditoria de vulnerabilidade.

**Por quê:** cada dependência é código de terceiro rodando com o seu privilégio.
Supply-chain attack e pacote abandonado são vetores reais. Menos dependência, menos
risco e menos peso no bundle.

**Como aplicar:** justifique cada novo pacote; cheque manutenção/downloads; `npm audit`
no CI; remova o que não usa.

### 7. Erro não vaza informação
**Regra:** mensagens de erro para o usuário são genéricas; o detalhe (stack, query, ID
interno) vai para o log do servidor, não para a tela. Nunca devolva stack trace ao client
em produção.

**Por quê:** stack trace e mensagem de banco entregam de bandeja a estrutura interna para
quem quer atacar — nomes de tabela, caminhos, versões. E confundem o usuário comum.

**Como aplicar:** `catch` que loga o detalhe server-side e retorna uma mensagem limpa;
nunca `error.message` cru do banco na UI.

---

## Bom design e qualidade

### 8. Acessibilidade é o piso, não o luxo
**Regra:** HTML semântico, `alt` em imagem, foco visível, contraste adequado (WCAG AA),
tudo navegável por teclado. `button` é botão; `a` é link; `div` não é nenhum dos dois.

**Por quê:** acessibilidade é o mesmo trabalho que SEO, performance e robustez bem
feitos. Beneficia todo mundo, é exigência legal em muitos contextos, e código semântico é
código mais fácil de manter. Pular isso é dívida que cobra juros.

**Como aplicar:** comece pelo elemento certo; teste navegando só com Tab; rode um checker
(axe / Lighthouse) e trate o que apontar.

### 9. Todo estado assíncrono é tratado
**Regra:** dado que carrega tem quatro estados — loading, erro, vazio e sucesso. Os três
primeiros não são opcionais.

**Por quê:** o caminho feliz é o fácil. O usuário lembra do app pela tela branca no
carregamento, pelo erro mudo, pela lista vazia sem explicação. Tratar os estados é a
diferença entre protótipo e produto.

**Como aplicar:** padrão de UI para cada estado; skeleton/spinner no loading; mensagem
acionável no erro; estado vazio que orienta ("nenhum item ainda — crie o primeiro").

### 10. Use o design system, não valores soltos
**Regra:** cor, espaçamento, raio, tipografia vêm dos tokens (Tailwind config / variáveis
de tema), não de `#3b82f6` e `mt-[13px]` espalhados pelo JSX.

**Por quê:** valor solto não escala. Trocar a cor da marca vira caça ao tesouro; o
espaçamento fica inconsistente; o dark mode quebra. Token centraliza a decisão num lugar.

**Como aplicar:** defina a escala uma vez; use classes/tokens semânticos
(`bg-primary`, `gap-4`); valor arbitrário só com justificativa.

### 11. Consistência vence criatividade pontual
**Regra:** botão, input, card e modal seguem o mesmo padrão no app inteiro. Componentize
antes de duplicar — a terceira repetição vira componente.

**Por quê:** consistência é o que faz a interface parecer profissional e previsível.
Cada variação ad hoc é mais código para manter e mais carga cognitiva para o usuário.

**Como aplicar:** biblioteca de componentes (ex.: shadcn/ui como base); revise antes de
criar um botão novo se já existe um.

### 12. TypeScript estrito, sem `any` de fuga
**Regra:** `strict: true`. Sem `any` para "fazer compilar" — use `unknown` + narrowing ou
tipe de verdade. `@ts-ignore`/`@ts-expect-error` só com comentário explicando.

**Por quê:** `any` desliga o compilador exatamente onde você mais precisa dele. O tipo é
documentação que não desatualiza e a primeira camada de teste — joga fora um e perde os
dois.

**Como aplicar:** ligue o modo estrito desde o início; derive tipos dos schemas de
validação; trate `unknown` na borda e tipe forte para dentro.

### 13. Nomes e funções dizem a intenção
**Regra:** nome revela propósito (`getUserInvoices`, não `getData`). Função faz uma coisa;
se faz três ou passa de ~40 linhas, quebre.

**Por quê:** código é lido muito mais do que escrito. Nome ruim e função-monstro custam
em toda leitura, todo bug, todo onboarding. Clareza é performance de equipe.

**Como aplicar:** nomeie pelo que retorna/faz; extraia subfunções com nome; evite
abreviação obscura e flag booleana que muda o comportamento da função.

### 14. Erro tratado de forma explícita
**Regra:** nada de `try/catch` vazio, nada de promessa sem `catch`. Ou trata o erro com
contexto, ou propaga com contexto. O usuário recebe feedback; o log recebe o detalhe.

**Por quê:** erro engolido é o pior tipo — o app falha silenciosamente e você descobre
pelo usuário. Tratamento explícito é o que torna o sistema depurável.

**Como aplicar:** `catch` que faz algo (loga, retorna estado de erro, mostra toast);
modele falha esperada como valor de retorno (`{ ok: false, error }`), não como exceção
silenciosa.

### 15. Deixe o código mais limpo do que achou
**Regra:** sem código morto, import não usado, `console.log` esquecido ou bloco
comentado no commit. TODO tem dono e contexto.

**Por quê:** lixo acumulado vira ruído que esconde o bug real e mina a confiança no
código. Higiene contínua é mais barata que faxina periódica.

**Como aplicar:** linter no CI; revise o diff antes de commitar; transforme TODO solto em
issue rastreável.

---

## Como usar esta lista

1. Leia tudo uma vez. Marque o que se aplica ao projeto.
2. Copie as regras escolhidas para a seção 3 (Segurança), 4 (Design) e 5 (Código) das
   instruções do projeto — adaptando à stack real.
3. Para cada regra crítica, escreva a versão *específica* do seu projeto. "Negue por
   padrão" vira "as Firestore Rules em `firestore.rules` começam com `if false` e liberam
   por `request.auth.uid == resource.data.ownerId`".
4. Revise a cada marco do projeto. Regra que não reflete a realidade vira ruído.
