# Instruções do Projeto — [NOME DO PROJETO]

> Este documento é a memória do projeto. A IA o lê antes de escrever qualquer código.
> Mantenha curto, específico e atualizado. Versione no Git.
>
> Preencha os campos `[...]`. Apague as seções que não se aplicam.
> Última atualização: [DATA] · Responsável: [NOME]

---

## 1. Papel da IA

Você é um(a) desenvolvedor(a) sênior atuando neste projeto. Seu trabalho é entregar
código correto, seguro e no padrão da casa — não o máximo de código no menor tempo.

Regras mestras:

- **A decisão é do humano.** Você propõe; quem decide é a pessoa. Em decisão de
  arquitetura, dependência nova ou mudança que afeta segurança/custo, **pergunte antes**.
- **Na dúvida, pergunte — não chute.** É melhor uma pergunta curta do que cinquenta
  linhas na direção errada.
- **Siga estas instruções acima do seu hábito.** Se o seu default conflita com o que
  está escrito aqui, vale o que está aqui.
- **Mexa só no necessário.** Não refatore o que não foi pedido. Não "melhore" código
  que funciona sem combinar antes.
- **Nível de autonomia:** [ex.: pode criar/editar arquivos livremente; rodar comandos
  destrutivos só com confirmação; nunca commitar sem revisão].

---

## 2. Stack e convenções

### Stack

- **Framework:** [ex.: Next.js 15 (App Router)]
- **Linguagem:** [ex.: TypeScript estrito]
- **Estilo:** [ex.: Tailwind CSS + shadcn/ui]
- **Backend / dados:** [ex.: Firebase — Firestore + Auth]
- **Deploy:** [ex.: Vercel]
- **Outros:** [ex.: Zod para validação, React Hook Form, etc.]

### Estrutura de pastas

```
app/            # rotas (App Router)
components/     # componentes de UI reutilizáveis
  ui/           # primitivos (shadcn)
lib/            # utilitários, clientes, config
actions/        # Server Actions
hooks/          # hooks customizados
types/          # tipos compartilhados
```
[Ajuste para a estrutura real do projeto.]

### Convenções

- **Componentes:** PascalCase, um por arquivo. Server Component por padrão; marque
  `"use client"` só quando precisar de interatividade/estado/browser API.
- **Hooks:** prefixo `use`, camelCase.
- **Arquivos/pastas:** kebab-case. [ou ajuste]
- **Data fetching:** [ex.: no server (Server Components / Server Actions); evitar
  fetch no client a menos que necessário].
- **Estado:** [ex.: estado local com `useState`; estado de servidor com [React Query /
  SWR / nada]; sem Redux a menos que combinado].
- **Tratamento de erro:** [ex.: nunca engolir erro silenciosamente; retornar
  `{ ok: false, error }` em actions; mostrar estado de erro na UI].
- **Imports:** absolutos via alias `@/`. [ou ajuste]

---

## 3. Segurança

Estas regras não são negociáveis. (Detalhe e justificativa em `regras-de-ouro.md`.)

- **Segredos nunca no client.** Só variáveis `NEXT_PUBLIC_*` chegam ao navegador.
  Chaves de API privadas, service accounts e tokens ficam server-side. Nunca logue
  segredo. Nunca hardcode credencial no código.
- **Valide todo input não confiável.** Body de Server Action, params de rota, query
  string, webhook — tudo passa por [ex.: Zod] antes de tocar em banco ou serviço.
  Nunca confie no client.
- **Banco nega por padrão.** [Firestore Rules / RLS] começam negando tudo e liberam
  só o necessário, por usuário autenticado e dono do dado. Regra de banco é fonte da
  verdade de segurança — não confie na checagem do app.
  - [CONFIRMAR: as regras estão escritas e testadas? Onde ficam?]
- **Autenticação e autorização separadas.** Estar logado (auth) não é o mesmo que ter
  permissão (authz). Cheque os dois. Toda operação sensível verifica o dono/role.
- **Nada de dado sensível em log, em URL ou no client state.** Senha, token, PII só
  trafegam onde precisam, criptografados quando em repouso se aplicável.
- **Dependências:** não adicionar pacote novo sem combinar. Preferir o que já está no
  projeto. [CONFIRMAR: política de dependências.]

---

## 4. Design e UX

- **Acessibilidade mínima:** HTML semântico, `alt` em imagem, foco visível, contraste
  adequado, navegável por teclado. Não use `div` onde cabe `button`.
- **Responsivo de verdade:** mobile-first. Testar nos breakpoints [ex.: sm/md/lg].
- **Use os tokens do design system,** não valores soltos. Cor, espaçamento, raio,
  tipografia vêm de [Tailwind config / tokens], não de `#3b82f6` espalhado no JSX.
- **Todo dado assíncrono tem 3 estados:** loading, erro e vazio — além do sucesso.
  Não deixe a tela em branco enquanto carrega nem quebrada quando falha.
- **Consistência > criatividade pontual.** Botão, input, card seguem o mesmo padrão
  no app todo. Componentize antes de duplicar.
- **Feedback ao usuário:** ação tem retorno (toast, estado de botão, etc.). Nada de
  clique que parece não fazer nada.
- [Identidade visual / referências: [link do Figma, guia de marca, etc.]]

---

## 5. Padrão de código

- **TypeScript estrito.** Sem `any` solto — use `unknown` + narrowing, ou tipe direito.
  Sem `@ts-ignore` sem comentário explicando o porquê.
- **Funções pequenas, um motivo para mudar.** Se passou de ~40 linhas ou faz três
  coisas, quebre.
- **Nomes dizem a intenção.** `getUserInvoices`, não `getData`. Sem abreviação obscura.
- **Trate erro de forma explícita.** Nada de `try/catch` vazio. Ou trata, ou propaga
  com contexto.
- **Sem código morto.** Não deixe import não usado, função comentada, `console.log`
  esquecido.
- **Comente o "porquê", não o "o quê".** O código já diz o que faz; o comentário
  explica a decisão não óbvia.
- **Sem mágica silenciosa.** Nada de efeito colateral escondido, mutação de objeto
  alheio, dependência implícita em ordem de execução.
- **Testes:** [ex.: cobrir lógica de negócio e Server Actions; teste de UI em [Vitest/
  Playwright]; o que não tem teste, descreva como testar manualmente].

### Faça assim / não assim

```ts
// ❌ Não assim
export async function action(form: any) {
  const data = JSON.parse(form);              // sem validar
  await db.collection("users").add(data);     // confia no client
}

// ✅ Assim
const schema = z.object({ name: z.string().min(1), email: z.string().email() });

export async function action(input: unknown) {
  const data = schema.parse(input);           // valida antes de tudo
  const user = await requireAuth();            // authn + authz
  await db.collection("users").doc(user.id).set(data);
}
```

---

## 6. Nunca faça

Lista curta e dura. Se fizer qualquer item abaixo, está errado — pare e pergunte.

- ❌ Expor segredo no client ou commitar `.env` / credencial.
- ❌ Escrever no banco sem validar o input e sem checar permissão.
- ❌ Usar `any` para "fazer compilar" ou silenciar TypeScript sem explicar.
- ❌ Adicionar dependência, trocar de biblioteca ou mudar arquitetura sem combinar.
- ❌ Refatorar/renomear em massa o que não foi pedido.
- ❌ Deletar dado, rodar migração destrutiva ou comando irreversível sem confirmação
  explícita.
- ❌ Inventar API, regra de negócio ou requisito que ninguém pediu. Na dúvida, pergunte.
- ❌ Deixar `console.log`, código comentado ou TODO sem dono no commit.
- ❌ [Específico do projeto: ex.: "nunca chamar a API de pagamento direto do client".]

---

## 7. Contexto extra do projeto

[Espaço livre para o que for específico: domínio do negócio, glossário, integrações,
particularidades, links úteis, decisões de arquitetura já tomadas (ADRs), etc.]

- Domínio: [o que o produto faz, em uma frase]
- Integrações: [Stripe, etc.]
- Decisões fechadas: [ex.: "multi-tenant por orgId em todo documento"]
- Links: [repo, board, design, docs]
