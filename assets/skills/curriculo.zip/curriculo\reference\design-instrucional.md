# Design instrucional — os princípios que fazem alguém aprender

Design instrucional parece coisa de academia, mas o miolo é simples: **como você organiza uma experiência para que outra pessoa saia sabendo fazer o que não sabia.** Quatro princípios sustentam tudo o que a Currículo faz. Se você acertar esses quatro, o curso funciona — mesmo sem produção bonita. Se errar, nenhuma edição salva.

---

## 1. Objetivo de aprendizagem: o verbo de ação manda

Todo curso, todo módulo, toda aula começa por uma frase:

> **Ao fim, você consegue ___.**

O que preenche o espaço é um **verbo de ação observável** — algo que dá pra ver a pessoa fazendo. Esse é o teste: se você não consegue olhar e dizer "pronto, ele fez", o objetivo está vago.

**Verbos que não servem** (estados mentais invisíveis):

- entender, compreender, conhecer, saber sobre, aprender sobre, ter noção, ficar por dentro, familiarizar-se.

Ninguém consegue ver "entender". E porque é invisível, o aluno acha que entendeu (assistiu, fez sentido na hora) sem saber fazer nada. É a armadilha clássica.

**Verbos que servem** (ação visível):

- **fazer/produzir:** publicar, configurar, escrever, construir, montar, implementar, depurar, escrever um prompt que…
- **decidir/avaliar:** escolher entre A e B justificando, identificar o erro em, revisar e apontar, comparar e recomendar.
- **explicar pra valer:** explicar com as próprias palavras por que, ensinar a outra pessoa a.

Exemplo do mundo do Rodrigo:

| Vago (não serve) | Objetivo de ação (serve) |
|---|---|
| "Entender Next.js" | "Publicar no ar um app Next.js com uma página protegida por login" |
| "Conhecer prompt engineering" | "Escrever um prompt pelo método P.R.O.M.P.T.E.R. que produz o resultado esperado em até 2 tentativas" |
| "Saber sobre segurança em IA" | "Revisar um código gerado por IA e apontar 3 riscos antes de subir pra produção" |

### Níveis de objetivo (do raso ao profundo)

Você não precisa decorar a taxonomia de Bloom, mas vale saber que há **níveis** — e que a maioria dos cursos amadores para no primeiro:

1. **Lembrar** — repetir o que ouviu. (Quase nunca é o objetivo de verdade.)
2. **Entender** — explicar com as próprias palavras.
3. **Aplicar** — usar numa situação igual à do exemplo.
4. **Fazer/analisar** — usar numa situação nova, decidir, depurar.
5. **Criar** — produzir algo próprio do zero.

Um bom curso prático mira do nível 3 pra cima. "Aplicar", "fazer" e "criar" são onde mora o "sabe fazer". Escreva o objetivo no nível mais alto que o curso realmente entrega — e então projete a prática pra chegar lá.

---

## 2. Progressão: uma escada, do concreto ao abstrato

Aprender é subir uma escada. Cada degrau apoia no anterior. Dois erros quebram a escada:

- **Degrau alto demais:** a aula 2 exige algo que só seria ensinado na 5. O aluno trava e não sabe por quê.
- **Pular pro abstrato cedo demais:** começar pela teoria/definição antes de a pessoa ter visto a coisa acontecer.

### Do concreto ao abstrato

O cérebro aprende do exemplo para a regra, não o contrário. A ordem que funciona:

1. **Concreto primeiro:** mostre **um caso real**, específico, acontecendo. "Olha esse app aqui, ele faz login. Vamos ver como."
2. **Padrão depois:** quando a pessoa já viu, extraia a regra. "Repara que todo login precisa destas três coisas…"
3. **Abstração por último:** só então o conceito geral, o nome, a teoria. Agora ele tem onde pendurar.

Começar pela definição ("autenticação é o processo pelo qual…") é o jeito mais rápido de perder a sala. Definição é o **fim** da escada, não o começo.

### Do simples ao composto

Ensine as peças isoladas antes da combinação. Uma habilidade composta (ex.: "publicar um app com login e banco") é feita de habilidades simples (criar projeto, criar uma página, conectar o banco, adicionar login). Ensine cada peça com a sua própria prática, depois junte. Nunca peça o composto antes das partes.

### Carga cognitiva: um conceito novo por vez

A pessoa só aguenta poucas coisas novas ao mesmo tempo. Se uma aula introduz um conceito novo **e** uma ferramenta nova **e** uma sintaxe nova, ela sobrecarrega e não fixa nenhum. Regra prática: **um conceito difícil novo por aula.** O resto da aula usa coisas que ela já domina, pra sobrar cabeça para o que é novo.

---

## 3. Prática deliberada: aprender é fazer

Prática deliberada não é "fazer um monte de exercício". É uma prática com três características:

1. **Mira no que é difícil.** Pratica exatamente o degrau que custa, não o que já é fácil. Se o difícil é conectar o banco, a prática é conectar o banco — não escrever um `console.log`.
2. **Tem feedback rápido.** O aluno descobre logo se acertou ou errou. Sem feedback, ele repete o erro e fixa o errado. O feedback pode ser: o resultado aparece na tela (ou não), um teste que passa, um gabarito comentado, uma checklist.
3. **Repete com variação.** Faz de novo num caso ligeiramente diferente, até virar automático.

### Como é uma boa prática

- **Reproduz a coisa real.** O aluno faz uma versão pequena do que vai fazer na vida real — não responde uma pergunta sobre isso. Quer ensinar a publicar um app? A prática é publicar um app (mínimo), não um quiz sobre deploy.
- **Tem enunciado claro e fechado.** "Crie uma página `/sobre` que mostra seu nome e some no ar." O aluno sabe exatamente o que entregar.
- **É factível com o que a aula deu.** Nada de prática que precisa de algo não ensinado.
- **Tem critério de pronto.** "Você terminou quando, ao abrir a URL, aparece seu nome." (Isso já é o marco — ver princípio 4.)

### Escala de "fazer" (do leve ao pesado)

Nem toda prática é um projeto grande. Use a mais leve que ainda obriga a pensar:

- **Acompanhar fazendo** (o aluno repete o que você demonstrou, ao vivo) — bom para a primeira exposição.
- **Variação guiada** (faz de novo mudando um detalhe) — fixa.
- **Desafio aberto** (resolve um problema novo com o que aprendeu) — testa de verdade.
- **Projeto** (junta várias aulas numa entrega) — o marco do curso.

Suba a escala conforme o aluno ganha autonomia.

---

## 4. Por que assistir ≠ aprender

Esse é o ponto que mais gente ignora — e o que separa um curso que funciona de um carrossel de vídeos.

Quando alguém **assiste** uma aula bem-dada, três coisas acontecem que **enganam**:

- **Fluência ilusória.** O professor faz parecer fácil. O cérebro confunde "vi alguém fazer com facilidade" com "eu sei fazer". São coisas diferentes.
- **Reconhecimento ≠ recordação.** Reconhecer a resposta quando você a vê ("ah sim, é isso") é fácil. Produzir a resposta do zero, sem ver, é difícil. Só a segunda é saber.
- **Sem esforço, sem fixação.** A memória se forma no esforço de recuperar e aplicar. Vídeo passivo não gera esse esforço. Por isso a pessoa "aprende" na aula e esquece tudo na semana seguinte.

O antídoto é desconfortável de propósito: **fazer o aluno produzir, do zero, logo.** O esforço de tentar — e errar, e corrigir — é o que grava. Um curso pode ter ótimo vídeo, mas é a **prática** que ensina. O vídeo prepara; o fazer fixa.

Consequência prática para o design:

- Não termine aula em "agora pratique em casa" (vira opcional, ninguém faz). Coloque a prática **dentro** da experiência.
- Prefira o aluno fazendo cedo, mesmo que imperfeito, a ele assistindo muito antes de tocar.
- Meça o curso pelo que os alunos **conseguem produzir** no fim, não pelo que assistiram.

---

## Checklist do design instrucional

Antes de fechar um curso ou aula, passe por aqui:

- [ ] O objetivo está escrito como **"ao fim, você consegue + verbo de ação"**?
- [ ] O verbo é **observável** (dá pra ver acontecer)?
- [ ] A progressão é uma **escada** — cada aula apoia na anterior, do concreto ao abstrato, do simples ao composto?
- [ ] Cada aula introduz **um conceito novo difícil por vez**?
- [ ] Toda aula tem **prática que reproduz a coisa real**, com enunciado claro e critério de pronto?
- [ ] A prática tem **feedback rápido** (o aluno sabe logo se acertou)?
- [ ] Existe um **marco objetivo** por aula e um **projeto/entrega** que prova a transformação no fim?
- [ ] Cortei tudo o que **não move o aluno** do A para o B?
