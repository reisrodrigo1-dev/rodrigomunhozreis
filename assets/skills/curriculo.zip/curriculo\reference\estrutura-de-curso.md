# Estrutura de curso — do curso à aula

Este arquivo é sobre **arquitetura**: como um curso se organiza por dentro, do mapa geral até o minuto a minuto de uma aula. O `design-instrucional.md` cuida do *por quê* (objetivo, progressão, prática). Aqui é o *como montar*.

A hierarquia é simples:

```
Curso  →  Módulos  →  Aulas  →  (dentro da aula) o arco
```

Cada nível tem o seu objetivo de ação. O objetivo do curso é a soma dos objetivos dos módulos; o do módulo, a soma das aulas. Se as peças não somam no resultado prometido, falta peça ou sobra peso.

---

## O curso

O curso é a **transformação inteira**: do ponto A (o que o aluno sabe ao entrar) ao ponto B (o que ele sabe fazer ao sair). Defina, no topo:

- **Transformação:** "Ao fim, o aluno consegue ___." (verbo de ação)
- **Para quem / ponto de partida:** quem é o aluno e o que ele já tem.
- **Pré-requisito:** o mínimo para acompanhar.
- **Marco final:** o projeto/entrega que prova que a transformação aconteceu.
- **Duração total estimada:** soma realista das aulas (ver "Duração", abaixo).

Tamanho de um curso: o suficiente para a transformação, nem mais. Um "mini-curso" honesto de 5 aulas que entrega uma habilidade bate qualquer "curso completo" de 80 aulas que ninguém termina. Prefira **escopo apertado e concluído** a abrangente e abandonado.

---

## Os módulos

Módulo é um **agrupamento de aulas que entrega uma sub-habilidade**. É o degrau grande da escada. Regras:

- **Cada módulo tem o seu objetivo de ação.** "Ao fim do Módulo 2, o aluno consegue conectar e ler dados de um banco."
- **Os módulos estão em ordem de dependência.** O Módulo 3 só usa o que os módulos 1 e 2 deram. Reordene até a dependência ficar limpa.
- **3 a 7 módulos** é uma faixa saudável para um curso. Mais que isso, provavelmente dá pra agrupar; menos, talvez nem precise de módulos (só aulas).
- **Um módulo pode terminar num mini-marco** (uma entrega parcial), o que dá ao aluno a sensação de progresso — combustível pra continuar.

### Como sequenciar módulos

Três jeitos de ordenar, do mais comum ao mais específico:

1. **Por dependência técnica** (o mais usado): A é pré-requisito de B. Criar o projeto antes de adicionar login antes de proteger rotas.
2. **Por fluxo do trabalho real:** siga a ordem em que a coisa acontece na vida real (ex.: ideia → protótipo → segurança → publicar).
3. **Espiral:** volte ao mesmo tema em profundidade crescente (visão geral simples no início, detalhe no fim). Bom quando o tema é grande e o aluno precisa de um "mapa" antes de mergulhar.

Na dúvida, dependência técnica. É o que menos trava o aluno.

---

## A aula

A aula é a unidade onde o aluno **aprende a fazer uma coisa**. Uma aula, um resultado. Se a aula tem dois objetivos de ação, são duas aulas.

### O arco de uma aula

Toda aula segue o mesmo arco. É a forma que respeita como a pessoa aprende (concreto → abstrato, do `design-instrucional.md`) e que garante prática.

**gancho → conceito → demonstração → prática → resumo**

#### 1. Gancho (abre — segundos)
Por que essa aula importa **agora**. Uma dor, uma pergunta, um "olha o que vamos construir". Mostra o resultado final da aula logo no começo, pra dar destino. Sem rodeio ("nesta aula nós vamos falar sobre…" mata o gancho). Exemplo: "Seu app tá no ar, mas qualquer um acessa a área logada. No fim desta aula, só quem tem conta entra."

#### 2. Conceito (a ideia — curto)
A teoria mínima necessária pra fazer. **Mínimo** é a palavra: só o que o aluno precisa pra executar a prática. Concreto antes de abstrato — mostre o caso, depois nomeie a regra. Resista a despejar tudo o que você sabe; o que não serve à prática desta aula vai pra outra aula ou pro lixo.

#### 3. Demonstração (você faz — o aluno vê)
Você executa na frente do aluno, passo a passo, com o resultado à vista. É o modelo que ele vai imitar. Mostre inclusive um erro e a correção, quando couber — ver alguém depurar ensina muito. A demonstração é concreta e completa: do início ao resultado funcionando.

#### 4. Prática (o aluno faz — o coração da aula)
Agora o aluno faz sozinho. Enunciado claro, fechado, factível com o que a aula deu, com critério de pronto. É aqui que o aprendizado acontece (ver "assistir ≠ aprender" no `design-instrucional.md`). **Nenhuma aula está pronta sem esta etapa.** Prefira o aluno fazendo uma variação do que você demonstrou — perto o bastante pra conseguir, diferente o bastante pra ter que pensar.

#### 5. Resumo (fecha — segundos)
O que ele agora sabe fazer (em uma frase, ligada ao objetivo), e o gancho para a próxima aula ("agora que você protege uma rota, no próximo passo a gente guarda os dados desse usuário"). Recupera o resultado da prática como prova: "se apareceu X na sua tela, você fez."

### Duração de uma aula

- **Vídeo/exposição:** curto. Atenção cai rápido; 6 a 12 minutos de explicação por aula é uma boa faixa. Se passar muito disso, provavelmente há mais de um objetivo na aula — quebre.
- **Prática:** pode (e deve) durar mais que a explicação. O tempo do aluno está no fazer.
- **Regra de ouro:** o aluno deve passar **mais tempo fazendo do que assistindo**. Se o curso é 90% vídeo e 10% prática, está invertido.

---

## Formato e ritmo

- **Mais marcos, menos vídeo.** Cada aula que termina num "consegui, apareceu na tela" segura o aluno. Sensação de progresso é o que vence a desistência.
- **Cedo e pequeno.** Coloque o aluno fazendo algo já na primeira aula, por menor que seja. Quem produz algo no dia 1 volta no dia 2.
- **Um caminho claro.** O aluno nunca deve se perguntar "e agora?". Cada aula aponta pra próxima.

---

## Esqueleto de saída

```markdown
# <Nome do curso>

**Transformação:** Ao fim, o aluno consegue <verbo de ação>.
**Para quem:** <ponto de partida> · **Pré-requisito:** <mínimo>
**Marco final:** <projeto/entrega que prova a transformação>
**Duração estimada:** <total realista>

## Módulo 1 — <nome>
*Ao fim, o aluno consegue <sub-habilidade>.*
- **Aula 1.1 — <título>**
  - Gancho: <por que importa>
  - Conceito: <teoria mínima>
  - Demonstração: <o que você faz na frente dele>
  - Prática: <o que o aluno faz, com enunciado>
  - Marco: <como sei que aprendeu>
- **Aula 1.2 — ...**

## Módulo 2 — ...
```
