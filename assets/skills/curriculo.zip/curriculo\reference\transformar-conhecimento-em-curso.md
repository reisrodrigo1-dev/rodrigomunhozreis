# Transformar conhecimento em curso — tirar o que está na cabeça e virar trilha

Quem sabe fazer raramente sabe **ensinar**, e não é falta de didática — é a maldição do conhecimento. Você faz tantas coisas no automático que esqueceu que um dia precisou aprendê-las. Para o iniciante, justamente essas coisas automáticas são o degrau onde ele trava. Este arquivo é o processo de **extração**: pegar a competência que vive na sua cabeça e transformá-la numa trilha que outra pessoa consegue subir.

São quatro passos: **mapear → ordenar → cortar → empacotar.**

---

## Passo 0 — Ancorar na transformação (antes de tudo)

Antes de mapear qualquer coisa, fixe a transformação (ver `design-instrucional.md`):

> **Ao fim, o aluno consegue ___.**

Essa frase é o filtro de tudo o que vem depois. Cada conhecimento que você for extrair vai ser testado contra ela: *isso ajuda o aluno a conseguir fazer X?* Se não, fica de fora — não importa quão valioso o conhecimento seja em abstrato.

---

## Passo 1 — Mapear o que você faz no automático

O objetivo aqui é **externalizar** — botar pra fora tudo o que você faz quando executa a tarefa, inclusive (principalmente) o que você nem percebe que faz.

Três técnicas, da mais simples à mais reveladora:

### a) Faça a tarefa narrando em voz alta
Execute a coisa real (publicar um app, escrever um prompt, revisar um código) e **narre cada decisão**, inclusive as bobas: "abro o terminal — ah, primeiro confiro em que pasta estou — rodo tal comando — espero, isso aqui sempre demora — se der esse erro, é porque…". Grave ou anote. O ouro está nas microdecisões automáticas: são exatamente o que o iniciante não sabe.

### b) Dump bruto, sem ordem
Despeje numa lista tudo o que vem à cabeça sobre o tema: conceitos, passos, erros comuns, ferramentas, atalhos, "pegadinhas". Não organize ainda. Quantidade primeiro; ordem depois.

### c) Caça aos "óbvios" (o passo que mais rende)
Releia o dump e marque tudo que você escreveu pressupondo que "todo mundo sabe". *Todo mundo sabe abrir o terminal? Todo mundo sabe o que é uma variável de ambiente?* Não sabe. Esses **óbvios escondidos** são os degraus que faltam na escada do iniciante — e a causa nº 1 de aluno que desiste sem entender por quê. Transforme cada óbvio num passo explícito (ou num pré-requisito declarado).

> Teste rápido: se você consegue fazer a tarefa enquanto pensa em outra coisa, ela está no automático — e provavelmente está invisível no seu material. Procure esses pontos de propósito.

---

## Passo 2 — Ordenar (transformar a lista numa escada)

Você tem um monte de peças soltas. Agora vira escada.

1. **Marque os pré-requisitos.** Para cada item, pergunte: "o que o aluno **precisa saber antes** pra isso fazer sentido?" Isso cria as dependências.
2. **Ordene por dependência.** Coloque na sequência em que cada peça apoia na anterior (ver sequenciamento em `estrutura-de-curso.md`). Do simples ao composto, do concreto ao abstrato.
3. **Agrupe em módulos.** Peças que entregam juntas uma sub-habilidade viram um módulo. Dê a cada módulo um objetivo de ação.
4. **Tire o teste da escada quebrada:** percorra a ordem fingindo ser o iniciante. Em algum ponto você precisa de algo que ainda não foi ensinado? Achou um degrau faltando — aquele "óbvio" do passo 1. Insira-o.

O sinal de uma boa ordem: um iniciante consegue seguir do primeiro ao último item **sem nunca precisar de algo que ainda não veio.**

---

## Passo 3 — Cortar o que não serve ao objetivo

Aqui dói, e é onde o curso fica bom. Você vai querer ensinar tudo o que sabe. Não ensine. Para **cada** peça, faça a pergunta-filtro:

> **Isso ajuda o aluno a conseguir fazer [a transformação]?**

- **Sim, direto:** fica.
- **É interessante, mas não move o aluno:** corta (ou guarda para um curso avançado / um material à parte / uma nota "pra quem quiser ir além").
- **É contexto que faz a peça principal fazer sentido:** mantém o mínimo, sem inflar.

Três armadilhas para cortar sem dó:

- **A enciclopédia:** "já que estou ensinando, vou explicar tudo sobre o tema". O aluno não quer tudo; quer chegar no B. Profundidade é dívida — só pague a que serve ao objetivo.
- **A vaidade técnica:** aquele detalhe avançado e elegante que prova que você manja. Se não serve à transformação deste curso, é peso. Guarde para outro.
- **A teoria órfã:** conceito que não vira prática nenhuma. Se o aluno não vai **fazer** nada com aquilo, provavelmente não precisa saber agora.

Depois de cortar, releia: o que sobrou é o **caminho mais curto do A ao B**. É isso que vira a trilha.

---

## Passo 4 — Empacotar em aulas com prática

Pegue a escada enxuta e transforme cada degrau em aula, usando o arco do `estrutura-de-curso.md` (gancho → conceito → demonstração → prática → resumo). Em particular:

- **Cada degrau vira o "fazer" de uma prática.** Aquilo que você mapeou narrando em voz alta no Passo 1 é, literalmente, a sua demonstração — e a prática é o aluno refazendo.
- **Cada "óbvio escondido" vira um passo explícito ou um pré-requisito declarado.** Não deixe nenhum no automático.
- **Cada módulo ganha um marco.** Como o aluno (e você) sabe que aquele degrau foi subido.

---

## Da palestra/e-book existente pro curso

Se o Rodrigo já tem uma **palestra** (Palco) ou um **e-book** (Tomo) sobre o tema, metade do trabalho está feito — mas atenção à diferença de formato:

- Palestra e e-book são feitos para **assistir/ler**; curso é feito para **fazer**.
- O conteúdo deles vira o **conceito + demonstração** das aulas. O que falta — e é o que transforma material em curso — é a **prática e o marco** de cada parte.
- Percorra o material e, a cada ideia, pergunte: "qual o exercício que faz o aluno **fazer** isso?". Esse exercício é a peça nova que o curso exige.

Caminho rápido: pegue o sumário do e-book/da palestra → vire módulos → para cada seção, escreva uma prática e um marco → confira a escada (Passo 2) e corte o que não serve (Passo 3).

---

## Checklist de extração

- [ ] A transformação está fixada (verbo de ação) e serve de filtro?
- [ ] Mapeei o que faço **no automático** (narrando em voz alta)?
- [ ] Cacei os **"óbvios escondidos"** e os transformei em passos ou pré-requisitos?
- [ ] Ordenei por dependência, numa escada sem degrau faltando?
- [ ] Cortei a enciclopédia, a vaidade técnica e a teoria órfã?
- [ ] Cada degrau virou uma aula com **prática** (não só conceito)?
- [ ] Cada módulo tem um **marco**?
