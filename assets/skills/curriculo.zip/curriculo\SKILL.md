---
name: curriculo
description: estrutura um curso, aula ou trilha de aprendizado — objetivo, módulos, progressão e prática; use ao planejar um curso, montar uma aula, organizar uma trilha de ensino ou transformar conhecimento em material didático.
---

# Currículo — desenhar um curso, uma aula ou uma trilha de ensino

A Currículo ajuda o Rodrigo Munhoz Reis a transformar o que ele sabe fazer em **algo que outra pessoa aprende a fazer**. É design instrucional simples e prático: nada de jargão acadêmico, nenhum modelo teórico pesado. O foco é o resultado — o aluno termina **sabendo fazer** o que não sabia antes.

A voz é PT-BR, direta, sem hype. Promete o que entrega. E devolve o comando para quem ensina: **a decisão é sua.**

A Currículo é uma das skills da suíte **Engenho**. Suas irmãs cuidam de outros formatos de conhecimento:
- **Tomo** — e-book / guia / material rico em HTML.
- **Palco** — palestra e slides.
- **Pena** — artigo / post de blog de autoridade.
- **Currículo** (esta) — **curso, aula ou trilha de aprendizado**.

Se o pedido é "ensinar de forma estruturada, com começo, meio e fim, e a pessoa pratica", é Currículo. Se é "dar uma palestra de 40 minutos", é Palco. Se é "escrever um guia para a pessoa ler", é Tomo.

## Visão geral

Existem dois erros que matam quase todo curso amador.

O primeiro é **começar pelo conteúdo**. A pessoa abre uma lista de tudo o que sabe sobre o tema e tenta despejar. Vira uma enciclopédia desorganizada. Ensinar não é transferir conteúdo — **é levar alguém de um ponto A a um ponto B.** Você começa pela transformação: onde o aluno está hoje, onde ele vai estar no fim, e o que muda nele. O conteúdo é só o caminho entre os dois pontos. Conteúdo que não move o aluno do A para o B é peso morto — corta.

O segundo erro é confundir **assistir com aprender**. Aula gravada, slide bonito e voz confiante dão ao aluno a sensação de que entendeu. Mas entender não é saber fazer. **Aprender é fazer.** Quem só assiste esquece; quem pratica, retém. Por isso toda aula desta skill termina em prática — não em "agora é com você", e sim num exercício concreto, com enunciado claro e um jeito de saber se acertou.

Resumo da filosofia:
- **Comece pela transformação, não pelo conteúdo.** "Ao fim, o aluno consegue ___."
- **Progressão do simples ao composto.** Uma escada, um degrau de cada vez.
- **Aprender é fazer.** Toda unidade tem prática, não só teoria.
- **Marco de aprendizagem.** Sempre há um jeito objetivo de saber que o aluno chegou no B.

## Quando usar esta skill

Use a Currículo quando o pedido for:

- **Planejar um curso** (do zero ou a partir de material existente).
- **Montar uma aula** com começo, meio e fim — gancho, conceito, prática, fechamento.
- **Organizar uma trilha de aprendizado** (sequência de módulos/aulas com progressão).
- **Transformar conhecimento em material didático** — pegar o que está na cabeça e virar uma trilha ensinável.
- **Revisar um curso/aula existente** que está "só teoria", desorganizado ou sem objetivo claro.

Não use para: palestra de palco / slides de evento (use **Palco**), e-book ou guia para leitura (use **Tomo**), artigo de blog (use **Pena**), ou prompt (use **Forja**). Curso e palestra se parecem, mas a diferença é o **aluno pratica e é avaliado** — se não há prática nem marco, provavelmente é Palco ou Tomo.

## Como usar a base

Antes de desenhar, **leia os arquivos de `reference/` relevantes**. Eles têm os princípios, a anatomia de uma aula e o passo a passo de extração de conhecimento, com exemplos.

| Arquivo | Use quando |
|---|---|
| `reference/design-instrucional.md` | Escrever o objetivo de aprendizagem (verbo de ação), montar a progressão (escada do concreto ao abstrato), desenhar a prática deliberada e entender por que assistir ≠ aprender. Leia em TODO curso. |
| `reference/estrutura-de-curso.md` | Ir do curso à aula: módulos, o arco de uma aula (gancho → conceito → demonstração → prática → resumo), duração e como sequenciar. |
| `reference/transformar-conhecimento-em-curso.md` | Tirar o que está na cabeça e virar trilha: mapear o que você faz no automático, ordenar e cortar o que não serve ao objetivo. |

## PROCEDIMENTO

Siga na ordem. Não pule a etapa 1: sem a transformação definida, o resto é só conteúdo solto.

### 1. Definir a transformação (o que o aluno vai SABER FAZER no fim)

Antes de pensar em módulo, aula ou slide, escreva uma frase:

> **Ao fim deste curso, o aluno consegue ___.**

Com um **verbo de ação observável** — algo que dá pra ver acontecer. "Consegue publicar um app Next.js no ar com login funcionando" é uma transformação. "Entende Next.js" não é — não dá pra ver "entender". Veja a lista de verbos e os níveis (lembrar → fazer → criar) em `design-instrucional.md`.

Pergunte (ou defina): o que o aluno **não consegue** hoje e **vai conseguir** depois? Esse delta é o curso. Tudo o que não serve a ele sai.

### 2. Pré-requisito e ponto de partida

Defina os dois lados da escada:

- **Ponto de partida (A):** o que o aluno já sabe/tem quando começa. Seja honesto — supor conhecimento que ele não tem é a causa nº 1 de aluno que desiste.
- **Pré-requisito:** o mínimo necessário para acompanhar. Declare explícito ("você precisa saber criar uma pasta e abrir um terminal"). Se o pré-requisito é grande, ou você ensina antes, ou aceita que esse não é o seu aluno.

Quanto menor a distância entre o pré-requisito real e o ponto de partida assumido, menos gente trava. (`transformar-conhecimento-em-curso.md`)

### 3. Quebrar em módulos / aulas com progressão (do simples ao composto)

Pegue a transformação e quebre nos **degraus** que levam do A ao B. Cada degrau é um módulo ou uma aula.

- **Progressão real:** cada aula usa o que a anterior ensinou. Do simples ao composto, do concreto ao abstrato. Nunca exija na aula 2 algo que só vem na aula 5.
- **Um resultado por aula:** ao fim de cada aula o aluno sabe fazer **uma coisa** a mais. Se a aula tem três objetivos, são três aulas.
- **Corte sem dó:** todo módulo que não move o aluno em direção ao B sai — por mais interessante que seja. (`estrutura-de-curso.md`, `design-instrucional.md`)

### 4. Cada aula com prática (não só teoria)

Toda aula entrega uma teoria **e** um fazer. Use o arco da aula (detalhado em `estrutura-de-curso.md`):

**gancho → conceito → demonstração → prática → resumo**

- **Demonstração:** você faz na frente do aluno (passo a passo, com o resultado à vista).
- **Prática:** o aluno faz sozinho, com enunciado claro, num exercício que reproduz a coisa real — não uma pergunta de múltipla escolha. Prática deliberada: foca no que é difícil, dá feedback rápido, repete. (`design-instrucional.md`)
- Regra dura: **se a aula não tem o aluno fazendo algo, ela não está pronta.**

### 5. Avaliação / marco (como saber que aprendeu)

Para cada aula e para o curso, defina o **marco**: o sinal objetivo de que o aluno chegou.

- **Marco de aula:** "o aluno conseguiu rodar o exercício e viu X na tela." Pequeno, verificável, ligado ao objetivo da aula.
- **Marco do curso:** um **projeto final** ou entrega que só existe se a transformação aconteceu. Se o aluno consegue produzir aquilo, ele aprendeu — não precisa de prova teórica.
- O marco fecha o ciclo: ele confirma que o aluno saiu do A e chegou no B. (`design-instrucional.md`)

### Saída

Entregue o desenho do curso pronto, neste formato:

```markdown
# <Nome do curso>

**Transformação:** Ao fim, o aluno consegue <verbo de ação + resultado>.
**Para quem:** <ponto de partida> · **Pré-requisito:** <mínimo necessário>
**Marco final:** <projeto/entrega que prova a transformação>

## Módulo 1 — <nome> (objetivo: ao fim, o aluno consegue ___)
- Aula 1.1 — <título> · prática: <o que o aluno faz> · marco: <como sei que aprendeu>
- Aula 1.2 — ...

## Módulo 2 — ...
```

Para uma **aula isolada**, entregue o arco completo (gancho → conceito → demonstração → prática → resumo) com a prática e o marco escritos por extenso.

## Regras da casa (resumo)

- **Transformação antes de conteúdo.** Comece pelo "ao fim, consegue fazer ___".
- **Verbo de ação, sempre.** Objetivo que dá pra ver acontecer; nada de "entender", "conhecer", "saber sobre".
- **Escada, não pilha.** Progressão do simples ao composto; cada aula apoia na anterior.
- **Aprender é fazer.** Toda aula tem prática real, não só teoria.
- **Marco objetivo.** Sempre existe um jeito de saber que o aluno chegou no B.
- **Corte o que não move o aluno.** Conteúdo legal mas inútil ao objetivo é peso — tira.
- **Sem hype.** "Domine X em 7 dias" não; promessa honesta do que o aluno vai conseguir, sim.

---

Ensinar é levar alguém de um ponto A a um ponto B. Defina o B, monte a escada, faça a pessoa praticar cada degrau — e o curso se desenha sozinho. A decisão é sua.
