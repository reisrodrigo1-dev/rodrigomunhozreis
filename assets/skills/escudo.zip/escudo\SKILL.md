---
name: escudo
description: Endurece a autenticação — login seguro, MFA, sessões, recuperação de senha, rate limit. Use ao implementar/revisar login, cadastro ou acesso.
---

# Escudo — blindar a autenticação

A porta de entrada é o alvo número 1. Antes de roubar dados, mudar preços ou apagar um banco, o atacante precisa entrar. Por isso a autenticação é onde o esforço de ataque se concentra: credenciais vazadas, força-bruta, enumeração de usuário, sessão roubada, "admin" que se promove sozinho. Se a porta cede, nada do que está atrás dela importa.

Escudo cuida de **quem entra e como entra**. É uma das skills da suíte **Engenho**:

- **Escudo** (esta) — autenticação: provar quem você é (login, MFA, sessão, senha).
- **Bastião** — segurança geral do código por stack (Next.js, Firebase, Vercel).
- **Cofre** — regras de segurança do Firebase (Firestore/Storage): quem pode ler/escrever cada dado.

**Autenticação ≠ autorização.** Autenticação é provar que você é o Rodrigo. Autorização é decidir se o Rodrigo pode apagar a coleção `pedidos`. Escudo trata das duas, porque na prática elas falham juntas — mas elas são camadas distintas e você nunca pode confundi-las. Um usuário autenticado não é um usuário autorizado.

A decisão é sua. Esta skill aponta o que blindar e por quê; você decide o nível de rigor que cada projeto pede.

## Quando usar

Use o Escudo quando você for:

- Implementar login, cadastro (sign-up) ou logout.
- Revisar um fluxo de acesso existente antes de ir para produção.
- Adicionar MFA / verificação em duas etapas.
- Construir "esqueci minha senha" / recuperação de conta.
- Criar uma área de admin ou qualquer rota protegida.
- Decidir como guardar e expirar sessões / tokens.
- Responder "esse endpoint está protegido de verdade?".

Stack de referência: **Next.js + Firebase Auth**. O site usa Firebase Auth com **custom claim `admin`** para distinguir administradores. Os padrões aqui assumem esse setup, mas os princípios valem para qualquer stack.

## Procedimento

Trabalhe na ordem. Cada etapa tem um arquivo de referência com detalhe e exemplos.

### 1. Autenticação forte

Provar a identidade de quem entra, sem inventar criptografia própria.

- [ ] **Use um provedor de identidade, não rode senha na mão.** Firebase Auth cuida de hashing, salt, reset, tokens. Não armazene senha você mesmo. Reimplementar isso é onde a maioria dos vazamentos nasce.
- [ ] **Senha forte como política, não como sugestão.** Mínimo 8 caracteres (NIST recomenda permitir até 64+), bloqueie senhas conhecidamente vazadas (Have I Been Pwned / lista comum). Não force "1 maiúscula + 1 símbolo" rígido — isso piora as senhas na prática. Comprimento > complexidade.
- [ ] **Verifique o e-mail** antes de liberar acesso a recursos sensíveis (`emailVerified`).
- [ ] **MFA quando o risco justifica.** Obrigatório para admins e contas com acesso a dados de terceiros / dinheiro. Opcional, mas incentivado, para o resto. Firebase Auth suporta MFA por SMS e TOTP.
- [ ] **Login social (Google/etc.)** reduz superfície de senha — mas continue verificando o e-mail e tratando autorização separadamente.

Detalhe: `reference/checklist-auth.md` e `reference/padroes-firebase-auth.md`.

### 2. Sessões

Quem provou identidade fica logado de forma controlada — não para sempre.

- [ ] **Sessão expira.** ID token do Firebase dura ~1h e renova sozinho; se você usa **session cookies**, defina expiração explícita (ex.: 5 dias, máx. 14) e force re-login depois.
- [ ] **Token no lugar certo.** Em SSR/Next.js, prefira **session cookie `httpOnly` + `secure` + `sameSite`** em vez de guardar token em `localStorage` (que é acessível por JS e vulnerável a XSS).
- [ ] **Revogação funciona.** Logout deve invalidar a sessão no servidor (`revokeRefreshTokens`), não só apagar o cookie no browser. Tenha um caminho para "deslogar de todos os dispositivos".
- [ ] **Cheque a sessão no servidor** a cada request sensível (`verifySessionCookie` / `verifyIdToken`), não confie no estado do client.

Detalhe: `reference/padroes-firebase-auth.md` (seção Sessões).

### 3. Recuperação de senha segura

O fluxo de reset é uma porta dos fundos. Trate como tal.

- [ ] **Link com expiração curta** (Firebase já expira; mantenha curto, tipo 1h) e **uso único**.
- [ ] **Não vaze se o e-mail existe.** A resposta para "esqueci a senha" é sempre a mesma: *"Se houver uma conta com esse e-mail, enviamos um link"* — independente de o e-mail existir ou não. Caso contrário, vira um oráculo de enumeração de usuários.
- [ ] **Rate limit no envio** de e-mail de reset (por e-mail e por IP) para não virar ferramenta de spam/flood.
- [ ] **Invalide sessões ativas** após troca de senha (a senha pode ter sido trocada porque a conta foi comprometida).

Detalhe: `reference/checklist-auth.md` (seção Recuperação) e `reference/erros-comuns.md`.

### 4. Anti-força-bruta

Tornar caro tentar adivinhar credenciais.

- [ ] **Rate limit nas tentativas de login** por IP e por conta. Firebase Auth já tem proteção interna, mas qualquer endpoint próprio (API, server action) precisa do seu próprio limite.
- [ ] **Lockout / backoff progressivo** após N tentativas falhas — atraso crescente é melhor que bloqueio fixo (que vira ferramenta de DoS contra o usuário legítimo).
- [ ] **CAPTCHA / App Check** em pontos sensíveis para barrar automação.
- [ ] **Monitore e alerte** picos de falha de login (sinal de ataque em andamento).

Detalhe: `reference/checklist-auth.md` (seção Anti-força-bruta).

### 5. Autorização ≠ autenticação

Estar logado não é estar autorizado. Esta é a falha que mais derruba apps de vibecoding.

- [ ] **Papéis por custom claim**, não por campo editável no client. No nosso caso: `admin: true` setado via Admin SDK no servidor.
- [ ] **Cheque a permissão no servidor**, sempre. Esconder o botão no front é UX, não segurança. A regra real vive na API/route/regra do Firestore.
- [ ] **Negue por padrão.** Toda rota nasce fechada; você abre explicitamente o que cada papel pode.
- [ ] **Menor privilégio.** Cada usuário recebe só o necessário. Admin é exceção, não default.
- [ ] **Custom claim não atualiza sozinho no client** — o token precisa ser renovado (`getIdToken(true)`) para refletir uma claim recém-setada.

Detalhe: `reference/padroes-firebase-auth.md` (seção Autorização) e `reference/erros-comuns.md`.

## Saída esperada

Ao aplicar o Escudo, entregue:

1. **Diagnóstico** — o que está blindado e o que está exposto, item a item do checklist.
2. **Prioridade** — do crítico (admin checado só no front, sessão eterna) ao baixo (política de senha frouxa).
3. **Conserto concreto** — código/config para a stack, não conselho genérico.
4. **A decisão é sua** — quando houver trade-off (ex.: MFA obrigatório atrita o cadastro), aponte os dois lados e deixe o autor decidir.

## Referências

- `reference/checklist-auth.md` — checklist item a item, com o porquê de cada um.
- `reference/padroes-firebase-auth.md` — padrões práticos de Firebase Auth com exemplos.
- `reference/erros-comuns.md` — erros típicos e o conserto.
