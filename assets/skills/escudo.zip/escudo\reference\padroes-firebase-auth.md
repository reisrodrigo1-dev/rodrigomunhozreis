# Padrões práticos com Firebase Auth

Padrões testados para Next.js + Firebase Auth, com o **custom claim `admin`** como o site usa. O fio condutor: **o client autentica, o servidor decide**.

Exemplos em TypeScript. Adapte nomes ao seu projeto.

---

## Visão geral do fluxo

```
[Browser]                          [Servidor / Next.js]              [Firebase]
  signInWithEmailAndPassword  ───────────────────────────────────►  valida credencial
         ◄─── ID token (JWT, ~1h) ──────────────────────────────────────
  POST /api/session (ID token)  ──►  cria session cookie
         ◄─── Set-Cookie httpOnly secure ──
  request a rota protegida      ──►  verifySessionCookie + checa claim ──►
```

Regra: o ID token nasce no client, mas **quem cria sessão e quem autoriza é o servidor**.

---

## 1. Autenticação no client (mínimo necessário)

O client só faz uma coisa: provar identidade ao Firebase e mandar o ID token para o servidor montar a sessão.

```ts
// client
import { getAuth, signInWithEmailAndPassword } from "firebase/auth";

async function login(email: string, password: string) {
  const auth = getAuth();
  const cred = await signInWithEmailAndPassword(auth, email, password);
  const idToken = await cred.user.getIdToken();

  // troca o ID token por uma sessão server-side (cookie httpOnly)
  const res = await fetch("/api/session", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ idToken }),
  });
  if (!res.ok) throw new Error("Falha ao criar sessão");
}
```

Não guarde o ID token em `localStorage`. Ele vira o session cookie e some.

---

## 2. Sessões — session cookie httpOnly (SSR)

Em vez de carregar o ID token no front, troque-o por um **session cookie** assinado pelo Firebase Admin. É o padrão recomendado para Next.js com SSR.

```ts
// app/api/session/route.ts  (Next.js App Router)
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { adminAuth } from "@/lib/firebase-admin"; // Admin SDK

const FIVE_DAYS = 60 * 60 * 24 * 5 * 1000; // máx. 14 dias no Firebase

export async function POST(req: Request) {
  const { idToken } = await req.json();

  // opcional: rejeita token velho (força login recente para criar sessão longa)
  const decoded = await adminAuth.verifyIdToken(idToken);
  if (Date.now() / 1000 - decoded.auth_time > 5 * 60) {
    return NextResponse.json({ error: "Faça login novamente" }, { status: 401 });
  }

  const sessionCookie = await adminAuth.createSessionCookie(idToken, {
    expiresIn: FIVE_DAYS,
  });

  (await cookies()).set("session", sessionCookie, {
    httpOnly: true,             // JS não lê -> imune a roubo via XSS
    secure: true,               // só HTTPS
    sameSite: "lax",            // mitiga CSRF
    maxAge: FIVE_DAYS / 1000,
    path: "/",
  });

  return NextResponse.json({ ok: true });
}
```

**Verificar a sessão no servidor** (em toda rota/page protegida):

```ts
// lib/auth.ts
import { cookies } from "next/headers";
import { adminAuth } from "@/lib/firebase-admin";

export async function getCurrentUser() {
  const cookie = (await cookies()).get("session")?.value;
  if (!cookie) return null;
  try {
    // checkRevoked: true -> respeita revokeRefreshTokens (logout real)
    const decoded = await adminAuth.verifySessionCookie(cookie, true);
    return decoded; // contém uid, email, e custom claims (ex.: admin)
  } catch {
    return null; // expirado, revogado ou inválido
  }
}
```

**Logout que revoga de verdade:**

```ts
// app/api/logout/route.ts
import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { adminAuth } from "@/lib/firebase-admin";

export async function POST() {
  const cookie = (await cookies()).get("session")?.value;
  if (cookie) {
    try {
      const decoded = await adminAuth.verifySessionCookie(cookie);
      // mata TODAS as sessões do usuário (todos os dispositivos)
      await adminAuth.revokeRefreshTokens(decoded.sub);
    } catch {}
  }
  (await cookies()).delete("session");
  return NextResponse.json({ ok: true });
}
```

> Apagar só o cookie não basta: se o token vazou, ele segue válido até expirar. `revokeRefreshTokens` + `verifySessionCookie(cookie, true)` é o par que faz o logout valer no servidor.

---

## 3. Autorização — custom claim `admin`

Autenticar diz *quem é*. A claim diz *o que pode*. Ela é setada **só no servidor**, via Admin SDK — nunca por um campo que o client escreve.

**Setar a claim** (script administrativo / Cloud Function protegida):

```ts
// scripts/set-admin.ts  — rode no servidor, nunca exposto ao client
import { adminAuth } from "@/lib/firebase-admin";

export async function tornarAdmin(uid: string) {
  await adminAuth.setCustomUserClaims(uid, { admin: true });
  // o usuário precisa renovar o token para a claim aparecer (ver abaixo)
}
```

**Checar a claim no servidor** (a verdade vive aqui):

```ts
// lib/auth.ts
import { getCurrentUser } from "@/lib/auth";

export async function requireAdmin() {
  const user = await getCurrentUser();
  if (!user || user.admin !== true) {
    throw new Response("Acesso negado", { status: 403 });
  }
  return user;
}
```

**Proteger uma rota de API:**

```ts
// app/api/admin/relatorio/route.ts
import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/auth";

export async function GET() {
  const user = await getCurrentUser();
  if (!user?.admin) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 });
  }
  // ...lógica de admin
  return NextResponse.json({ dados: "..." });
}
```

**Proteger uma página (Server Component) e o middleware:**

```ts
// app/admin/page.tsx
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";

export default async function AdminPage() {
  const user = await getCurrentUser();
  if (!user?.admin) redirect("/login"); // gate de UX
  return <Painel />;
}
```

```ts
// middleware.ts — primeira barreira (não substitui a checagem na rota)
import { NextResponse, type NextRequest } from "next/server";

export function middleware(req: NextRequest) {
  const hasSession = req.cookies.has("session");
  if (!hasSession && req.nextUrl.pathname.startsWith("/admin")) {
    return NextResponse.redirect(new URL("/login", req.url));
  }
  return NextResponse.next();
}
export const config = { matcher: ["/admin/:path*"] };
```

> O middleware no Edge não roda o Admin SDK, então ele só checa **presença** de sessão (barreira barata). A verificação real da claim acontece na page/route com `verifySessionCookie`. Nunca dependa só do middleware.

**Esconder o botão no front é UX, não segurança:**

```tsx
// client — opcional, melhora a experiência, NÃO protege nada
{user?.admin && <LinkParaAdmin />}
```

A proteção de verdade é o `403` no servidor acima. Quem chamar `/api/admin/...` via curl pula a UI inteira.

**Custom claim recém-setada não aparece sozinha:**

```ts
// client — forçar renovação do token para refletir a nova claim
import { getAuth } from "firebase/auth";
await getAuth().currentUser?.getIdToken(true); // true = força refresh
```

Sem esse refresh (ou aguardar até ~1h de expiração natural), o usuário promovido a admin continua "não-admin" para o sistema.

---

## 4. MFA com Firebase Auth

Para contas críticas (admins, acesso a dinheiro/dados de terceiros). Firebase suporta **TOTP** (app autenticador) e **SMS**. Prefira TOTP — SMS é vulnerável a SIM swap.

```ts
// client — inscrição em MFA por TOTP (resumo do fluxo)
import {
  multiFactor,
  TotpMultiFactorGenerator,
  TotpSecret,
} from "firebase/auth";

async function inscreverTotp(user) {
  const session = await multiFactor(user).getSession();
  const secret = await TotpMultiFactorGenerator.generateSecret(session);

  // mostre o QR code para o usuário escanear no app autenticador:
  const qrUri = secret.generateQrCodeUrl(user.email, "MeuApp");
  // ...exibir QR...

  // o usuário digita o código gerado no app:
  const code = "123456"; // input do usuário
  const assertion = TotpMultiFactorGenerator.assertionForEnrollment(secret, code);
  await multiFactor(user).enroll(assertion, "Authenticator");
}
```

No login, quando a conta tem MFA, o Firebase lança `auth/multi-factor-auth-required`; você trata resolvendo o segundo fator. Habilite MFA no Console do Firebase (Authentication > Sign-in method) antes.

---

## 5. Anti-força-bruta nos seus próprios endpoints

Firebase Auth protege o login dele. Mas suas APIs (reset customizado, server actions) precisam do seu próprio limite.

```ts
// lib/rate-limit.ts — exemplo com Upstash Ratelimit (serverless-friendly)
import { Ratelimit } from "@upstash/ratelimit";
import { Redis } from "@upstash/redis";

export const loginLimiter = new Ratelimit({
  redis: Redis.fromEnv(),
  // 5 tentativas a cada 60s por chave (IP+email), depois bloqueia
  limiter: Ratelimit.slidingWindow(5, "60 s"),
});
```

```ts
// uso na rota
const ip = req.headers.get("x-forwarded-for") ?? "anon";
const { success } = await loginLimiter.limit(`login:${ip}:${email}`);
if (!success) {
  return NextResponse.json({ error: "Muitas tentativas. Aguarde." }, { status: 429 });
}
```

Some **App Check** para barrar bots batendo direto na API, e logue picos de `429` / falha de login para alerta.

---

## Resumo dos padrões

| Tema | Padrão certo | Anti-padrão |
|------|--------------|-------------|
| Token | session cookie `httpOnly secure sameSite` | token em `localStorage` |
| Logout | `revokeRefreshTokens` no servidor | só apagar cookie no front |
| Verificação | `verifySessionCookie(cookie, true)` por request | confiar no estado do client |
| Papel admin | custom claim setada via Admin SDK | campo `isAdmin` no Firestore editável |
| Autorização | checar claim no servidor (`403`) | esconder botão no front e parar aí |
| MFA | TOTP para contas críticas | SMS como único fator |
| Rate limit | limitar seus endpoints por IP+conta | confiar só na proteção do Firebase |
