# Erros comuns de autenticação (e o conserto)

Os furos que mais aparecem em app feito rápido com IA. Cada um tem o **sintoma**, o **porquê é perigoso** e o **conserto**. Se você está revisando um login, procure por estes primeiro.

---

## 1. Confiar no client para autorizar

**Sintoma:** a permissão é decidida no front — `if (user.isAdmin) mostraBotao()` — e a API por trás aceita qualquer um logado.

**Por que é perigoso:** o front é território do atacante. Ele abre o DevTools, troca `isAdmin` para `true`, ou simplesmente chama `POST /api/admin/deletar` direto com curl/Postman, sem nunca tocar na sua UI. Esconder o botão não protege o endpoint.

**Conserto:** decida no servidor, sempre. O front só dá dicas de UX.

```ts
// ERRADO — proteção só no front
{user.isAdmin && <BotaoApagarTudo />}   // some o botão, API segue aberta

// CERTO — servidor é a verdade
export async function POST() {
  const user = await getCurrentUser();
  if (user?.admin !== true) {
    return NextResponse.json({ error: "Acesso negado" }, { status: 403 });
  }
  // ...
}
```

---

## 2. Enumeração de usuário

**Sintoma:** o sistema responde de forma diferente para e-mail que existe vs. não existe. Ex.: login diz "senha incorreta" (e-mail válido) vs. "usuário não encontrado"; reset diz "enviamos o link" vs. "e-mail não cadastrado".

**Por que é perigoso:** vira um oráculo. O atacante roda uma lista de e-mails e descobre exatamente quem tem conta no seu sistema — alvos prontos para phishing e credential stuffing.

**Conserto:** resposta idêntica nos dois casos.

```ts
// ERRADO
if (!userExiste) return "E-mail não cadastrado";
if (senhaErrada) return "Senha incorreta";

// CERTO — login
return "E-mail ou senha inválidos"; // sempre igual

// CERTO — reset (a mensagem não muda, exista ou não a conta)
return "Se houver uma conta com esse e-mail, enviamos um link de recuperação.";
```

> Cuidado também com **timing**: se o caminho do e-mail inexistente é muito mais rápido, dá para inferir. Mantenha o tempo de resposta parecido.

---

## 3. Sessão eterna

**Sintoma:** o token/sessão não expira, ou expira em meses; logout só apaga o cookie no browser; não existe "sair de todos os dispositivos".

**Por que é perigoso:** um token roubado (XSS, máquina compartilhada, log vazado) vale para sempre. O usuário "sai", mas o token continua aceito no servidor.

**Conserto:** expiração explícita + revogação no servidor.

```ts
// CERTO — sessão com prazo
await adminAuth.createSessionCookie(idToken, { expiresIn: 60*60*24*5*1000 }); // 5 dias

// CERTO — logout que revoga de verdade
await adminAuth.revokeRefreshTokens(uid);   // mata todas as sessões
cookies().delete("session");

// CERTO — verificação respeita revogação
await adminAuth.verifySessionCookie(cookie, true); // checkRevoked = true
```

---

## 4. Token em localStorage

**Sintoma:** o ID token / JWT é guardado em `localStorage` ou `sessionStorage` e lido por JS a cada request.

**Por que é perigoso:** qualquer XSS (um `<script>` injetado, uma dependência comprometida) lê o `localStorage` e exfiltra o token. Não há como impedir JS de ler o que está lá.

**Conserto:** session cookie `httpOnly` — inacessível por script.

```ts
// ERRADO
localStorage.setItem("token", idToken);

// CERTO
cookies().set("session", sessionCookie, {
  httpOnly: true,   // JS não lê
  secure: true,     // só HTTPS
  sameSite: "lax",  // mitiga CSRF
});
```

---

## 5. Senha fraca aceita

**Sintoma:** o cadastro aceita `123456`, `senha`, ou qualquer coisa com 4 caracteres. Ou o oposto: regra de complexidade tão rígida que o usuário usa `Senha123!` em todo lugar.

**Por que é perigoso:** senha curta/comum cai em segundos por força-bruta ou está numa lista de vazamento (credential stuffing). E regra decorativa não ajuda — gera senhas previsíveis.

**Conserto:** comprimento mínimo razoável + bloqueio de senhas vazadas/comuns.

```ts
// CERTO
if (password.length < 8) erro("Use pelo menos 8 caracteres.");
if (await senhaJaVazou(password)) erro("Essa senha apareceu em vazamentos. Escolha outra.");
// permita frases longas; não force "1 símbolo obrigatório"
```

> Use a API k-anonymity do Have I Been Pwned: você envia só os 5 primeiros caracteres do hash SHA-1, nunca a senha.

---

## 6. Admin checado só no front

**Sintoma:** o papel de admin vem de um campo no Firestore/perfil que o client lê (e às vezes pode escrever), e a rota de admin só verifica esse campo no React.

**Por que é perigoso:** é o caso 1 na sua forma mais letal. Se `users/{uid}.role = "admin"` é gravável pelo client (regra do Firestore frouxa), o usuário se promove sozinho. E mesmo que não seja gravável, checar só no front deixa a API aberta.

**Conserto:** papel via **custom claim** setada no servidor + checagem no servidor.

```ts
// ERRADO — papel em doc editável + checagem no front
const role = (await getDoc(doc(db,"users",uid))).data().role; // client lê/escreve?
if (role === "admin") { /* libera */ }

// CERTO — claim setada só pelo Admin SDK
await adminAuth.setCustomUserClaims(uid, { admin: true });   // servidor

// CERTO — checagem no servidor
const user = await getCurrentUser();
if (user?.admin !== true) return new Response("403", { status: 403 });
```

E feche a regra do Firestore para o campo de papel (ver skill **Cofre**): ninguém escreve seu próprio `role`.

---

## 7. Sem rate limit no login / reset

**Sintoma:** o endpoint de login ou de "esqueci a senha" aceita requisições ilimitadas.

**Por que é perigoso:** login sem limite = força-bruta de senha à vontade. Reset sem limite = ferramenta de spam contra a caixa de qualquer e-mail, e canal de enumeração.

**Conserto:** rate limit por IP + por conta, backoff progressivo, App Check.

```ts
const { success } = await loginLimiter.limit(`login:${ip}:${email}`);
if (!success) return NextResponse.json({ error: "Muitas tentativas." }, { status: 429 });
```

> Prefira **backoff progressivo** a lockout fixo: bloqueio rígido após N falhas vira DoS — o atacante tranca a conta da vítima de propósito.

---

## 8. Não invalidar sessões após troca de senha

**Sintoma:** o usuário troca a senha (talvez porque a conta foi invadida), mas as sessões antigas continuam ativas.

**Por que é perigoso:** se o atacante estava logado, ele continua logado mesmo depois de o dono trocar a senha. A troca não expulsou ninguém.

**Conserto:** revogue os tokens na troca de senha.

```ts
await adminAuth.revokeRefreshTokens(uid); // após confirmar a troca
```

---

## 9. Segredo de admin / chave de serviço exposta

**Sintoma:** a chave da conta de serviço do Firebase Admin SDK está no client, no repositório, ou numa env var pública (`NEXT_PUBLIC_...`).

**Por que é perigoso:** a chave do Admin SDK ignora todas as regras de segurança — quem a tem é dono do projeto inteiro. `NEXT_PUBLIC_` vai para o bundle do browser, ou seja, vaza para todo mundo.

**Conserto:** chave de serviço só no servidor, em env var sem `NEXT_PUBLIC_`, fora do Git.

```ts
// ERRADO
NEXT_PUBLIC_FIREBASE_ADMIN_KEY=...   // vai para o browser

// CERTO
FIREBASE_ADMIN_KEY=...               // só servidor, no .gitignore
```

> Para varredura de segredos vazados, use a skill **Faro**. Para o setup seguro de env/.gitignore, use **Canteiro**.

---

## Mapa rápido: erro -> skill irmã

- Regra do Firestore que deixa o client escrever o próprio papel -> **Cofre**
- Chave/segredo no repositório -> **Faro**
- Setup inicial seguro (env, .gitignore, headers) -> **Canteiro**
- Revisão de segurança ampla por stack -> **Bastião**
