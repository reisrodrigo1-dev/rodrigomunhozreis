# Checklist de autenticação segura

Item a item, com o porquê. Use como lista de verificação antes de subir qualquer fluxo de acesso para produção. Marque o que está feito; o que sobrar é dívida de segurança.

A regra de ouro que atravessa tudo: **nunca confie no client**. Tudo que decide acesso roda — ou é re-verificado — no servidor.

---

## 1. Autenticação forte

### [ ] Não implemente senha na mão — use um provedor
**Por quê:** hashing seguro (bcrypt/scrypt/argon2 com salt e custo certos), rotação, reset, proteção contra timing attack — tudo isso é fácil de errar e difícil de testar. Firebase Auth, Auth0, etc. já resolveram. Senha salva por você é candidata a virar manchete de vazamento.

### [ ] Política de senha por comprimento, não por complexidade decorativa
**Por quê:** "1 maiúscula + 1 número + 1 símbolo" produz senhas como `Senha123!` — fáceis para máquina, chatas para humano. O NIST recomenda mínimo 8, permitir frases longas (64+), e **bloquear senhas vazadas/comuns**. Comprimento e originalidade vencem complexidade artificial.

### [ ] Bloqueie senhas conhecidamente vazadas
**Por quê:** credential stuffing usa listas de senhas reais. Se você aceita `123456` ou uma senha que já vazou em outro site, o atacante nem precisa de força-bruta. Cheque contra uma lista comum ou a API k-anonymity do Have I Been Pwned.

### [ ] Verifique o e-mail antes de liberar acesso sensível
**Por quê:** sem verificação, qualquer um cadastra com o e-mail de terceiros, e você não tem canal confiável para reset. Use `emailVerified` como gate para recursos que importam.

### [ ] MFA para contas críticas
**Por quê:** senha sozinha cai com phishing ou vazamento. MFA (TOTP/SMS) corta a esmagadora maioria dos sequestros de conta. Torne **obrigatório para admins** e contas com acesso a dinheiro/dados de terceiros; ofereça opcional ao resto.

### [ ] Não exponha qual campo falhou no login
**Por quê:** "senha incorreta" (com e-mail válido) confirma que o e-mail existe. Use uma mensagem genérica: *"E-mail ou senha inválidos"*. Mesmo motivo da regra de enumeração no reset.

---

## 2. Sessões

### [ ] Toda sessão tem prazo de validade
**Por quê:** sessão eterna = token roubado vale para sempre. ID token do Firebase já expira em ~1h. Se usar session cookie, defina expiração explícita (ex.: 5 dias) e force re-login.

### [ ] Token guardado em cookie httpOnly, não em localStorage
**Por quê:** `localStorage` é lido por qualquer JS na página — um XSS rouba o token na hora. Cookie `httpOnly` não é acessível por script. Some `secure` (só HTTPS) e `sameSite=lax/strict` (mitiga CSRF).

### [ ] Logout revoga no servidor, não só apaga o cookie
**Por quê:** apagar o cookie só esconde o token do browser atual. Se o token vazou, continua válido. `revokeRefreshTokens` no servidor mata as sessões de verdade.

### [ ] Existe "deslogar de todos os dispositivos"
**Por quê:** quando o usuário suspeita de invasão, ele precisa de um botão de pânico. Revogar refresh tokens cobre isso.

### [ ] Cada request sensível re-verifica a sessão no servidor
**Por quê:** o estado de "logado" no client é só uma dica de UX. A verdade é o token verificado no servidor a cada chamada que muda dados ou expõe algo privado.

---

## 3. Recuperação de senha

### [ ] Link de reset expira rápido e é de uso único
**Por quê:** link que não expira é credencial permanente esperando vazar (histórico de browser, log de e-mail, screenshot). Uso único impede replay.

### [ ] A resposta não revela se o e-mail existe
**Por quê:** *"Se houver uma conta com esse e-mail, enviamos um link"* — sempre igual. Se você responde "e-mail não encontrado", virou um oráculo: o atacante descobre quais e-mails têm conta no seu sistema (enumeração).

### [ ] Rate limit no pedido de reset
**Por quê:** sem limite, o endpoint vira ferramenta de spam (floodar a caixa de alguém) e de enumeração via timing. Limite por e-mail e por IP.

### [ ] Trocar a senha invalida as sessões ativas
**Por quê:** se a conta foi comprometida e o dono troca a senha, as sessões do atacante precisam morrer junto. Revogue tokens na troca.

### [ ] Não envie a nova senha por e-mail
**Por quê:** e-mail é canal inseguro e persistente. Envie um **link para o usuário definir** a senha, nunca a senha em si.

---

## 4. Anti-força-bruta

### [ ] Rate limit em tentativas de login (por IP e por conta)
**Por quê:** sem limite, o atacante testa milhões de senhas. Limitar por conta barra ataque dirigido; por IP barra varredura. Firebase Auth tem proteção interna — mas endpoints próprios (suas APIs/server actions) não, então adicione você.

### [ ] Backoff progressivo em vez de bloqueio fixo
**Por quê:** bloqueio rígido após N falhas vira DoS: o atacante trava a conta da vítima de propósito. Atraso crescente (1s, 2s, 4s…) frustra a máquina sem trancar o usuário legítimo para fora.

### [ ] CAPTCHA / App Check em pontos sensíveis
**Por quê:** separa humano de script. Firebase App Check atesta que a requisição veio do seu app de verdade, não de um bot batendo na API.

### [ ] Monitoramento e alerta de picos de falha
**Por quê:** um surto de logins falhos é a assinatura de um ataque em andamento. Sem alerta, você descobre depois do estrago. Logue tentativas e dispare alerta em anomalia.

---

## 5. Autorização (≠ autenticação)

### [ ] Papel vem de custom claim setada no servidor
**Por quê:** se "is admin" é um campo no Firestore ou no perfil que o client pode editar, qualquer usuário se promove. Custom claim só é setada pelo Admin SDK, no servidor.

### [ ] Permissão é checada no servidor, sempre
**Por quê:** esconder o botão de admin no front é UX. O atacante chama a API direto (curl, Postman) e pula a UI inteira. A regra real vive na route/API/regra do Firestore.

### [ ] Negação por padrão
**Por quê:** rota nova nasce fechada. Você abre explicitamente o que cada papel acessa. O contrário — abrir tudo e fechar exceções — sempre deixa um buraco.

### [ ] Menor privilégio
**Por quê:** cada conta recebe só o que precisa. Admin é exceção rara, não o default. Quanto menos gente com poder, menor o estrago de uma conta comprometida.

---

## Prioridade quando o tempo é curto

Se você só pode consertar três coisas hoje, nesta ordem:

1. **Admin/permissão checada no servidor** (não só no front) — crítico, é entrada de invasor.
2. **Sessão com expiração + token em cookie httpOnly** — corta roubo de sessão.
3. **Enumeração de usuário** no login e no reset — fecha o oráculo de contas.

O resto é importante, mas esses três são os que costumam estar abertos em app feito rápido.
