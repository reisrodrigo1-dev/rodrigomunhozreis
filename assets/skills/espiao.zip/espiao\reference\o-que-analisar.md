# O que analisar em cada concorrente

As dimensões abaixo são o checklist para olhar um concorrente. Não precisa preencher todas para todos — comece pela oferta, preço, posicionamento e pontos fracos (o resto refina). Para cada dimensão: **o que olhar** e **o que isso revela**.

---

## 1. Oferta / escopo

**O que olhar:**
- O que exatamente eles entregam (produto, serviço, features principais)?
- O que está **incluído** e o que fica **de fora** (ou é cobrado à parte)?
- Para quem é grande demais e para quem é pequeno demais?
- O que eles fazem que parece complicado, inchado ou "feature por feature"?

**O que revela:** onde a oferta deles é larga demais (genérica, dá pra ser mais focado) ou estreita demais (deixa um pedaço do problema sem resolver). Os dois são gaps.

---

## 2. Preço / modelo

**O que olhar:**
- Quanto custa, em todos os planos? (anote os números, não "tem vários planos")
- Como cobram: assinatura mensal/anual, pagamento único, por uso, por assento, freemium, comissão?
- Onde está o "pulo do gato" do preço — o que destrava o plano caro?
- Tem custo escondido, taxa de setup, fidelidade, multa de cancelamento?
- É transparente (preço no site) ou "fale com vendas"?

**O que revela:** se há espaço por baixo (alguém quer mais simples e barato) ou por cima (alguém quer premium e ninguém atende bem). Preço opaco do concorrente costuma ser uma fraqueza explorável — transparência vira diferencial.

---

## 3. Posicionamento / promessa

**O que olhar:**
- Para quem eles dizem ser? (o público que a comunicação mira)
- Qual a promessa central — a frase que aparece no topo do site?
- Qual problema eles dizem resolver, e qual eles ignoram?
- Onde eles se ancoram: preço? qualidade? velocidade? facilidade? status?

**O que revela:** o eixo em que ele compete. Se todos competem no mesmo eixo (ex.: "o mais completo"), há espaço num eixo oposto (ex.: "o mais simples"). Posicionamento bom é contraste, não superlativo.

---

## 4. Voz / marca

**O que olhar:**
- Como falam: técnico, divertido, corporativo, popular, premium, próximo?
- Linguagem que usam (e a que evitam)?
- Identidade visual: sóbria, colorida, minimalista, agressiva?
- Que sentimento a marca passa — confiança, modernidade, economia, exclusividade?

**O que revela:** a "vibe" que domina o mercado. Se todo mundo fala igual (ex.: jargão corporativo), uma voz diferente (direta, humana, sem hype) já é diferenciação percebida antes mesmo do produto.

---

## 5. Canais

**O que olhar:**
- Onde eles aparecem: Google, Instagram, LinkedIn, YouTube, indicação, parcerias?
- Onde investem em anúncios (e onde estão ausentes)?
- Como o cliente chega até eles — busca, conteúdo, tráfego pago, boca a boca?

**O que revela:** canais lotados são caros e disputados; canais que o concorrente ignora podem ser sua entrada mais barata. Onde eles não estão também é informação.

---

## 6. Prova social

**O que olhar:**
- Quantos clientes/avaliações têm e o que dizem os depoimentos?
- Que tipo de cliente eles exibem (logos, cases)?
- Têm autoridade real (imprensa, números, comunidade) ou só promessa?
- A prova é específica (resultado medido) ou genérica ("recomendo!")?

**O que revela:** o tamanho real do concorrente (não o que ele aparenta) e que tipo de cliente confia nele. Se a prova social deles é fraca ou genérica, prova específica e honesta vira seu diferencial de confiança.

---

## 7. Pontos fracos (a dimensão mais importante)

**O que olhar:**
- O que se repete nas **avaliações ruins** (1–3 estrelas) e reclamações públicas?
- Queixas sobre: preço, suporte, complexidade, bugs, falta de feature, atendimento, entrega?
- O que prometem e não cumprem (gap entre marketing e realidade)?
- O que eles assumem como "do jeito que é" e poderia ser diferente?

**O que revela:** o diferencial mora aqui. Uma queixa isolada é ruído; a **mesma queixa repetida por clientes diferentes** é uma dor de mercado não atendida. Anote frases literais — elas viram a copy da sua página depois.

---

## Como usar as dimensões

1. Preencha uma linha por concorrente na `templates/matriz-concorrencia.md`.
2. Olhe **na coluna** (não só na linha): onde todos os concorrentes são iguais ou fracos? Aí está o eixo livre.
3. Lacuna que você não achou → escreva "não achei". Não invente.
4. Leve os pontos fracos repetidos para o passo 4 do procedimento (cruzar com o ICP do Espelho).
