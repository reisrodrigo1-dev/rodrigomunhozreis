# Matriz de concorrência

Preencha uma linha por concorrente. Cubra as três camadas (direto, indireto, "fazer na mão / não fazer"). O que não achar, escreva "não achei" — lacuna é informação. No fim, preencha **"onde eu ganho"**: esse é o entregável.

> Dica de leitura: depois de preenchida, olhe **na coluna**, não só na linha. Onde todos os concorrentes são iguais ou fracos = o eixo livre pro seu diferencial.

---

## Quadro comparativo

| Dimensão | Concorrente A | Concorrente B | Concorrente C | "Fazer na mão / não fazer" |
|---|---|---|---|---|
| **Tipo** (direto/indireto/não-consumo) | | | | não-consumo |
| **Oferta / escopo** (o que entrega; o que fica de fora) | | | | |
| **Preço / modelo** (quanto e como cobra) | | | | custo ~zero, mas custa tempo/erro |
| **Posicionamento / promessa** (pra quem; promessa central) | | | | |
| **Voz / marca** (como fala; que vibe passa) | | | | |
| **Canais** (onde aparece; onde anuncia) | | | | |
| **Prova social** (clientes, avaliações, autoridade) | | | | |
| **Pontos fracos** (queixas repetidas; o que promete e não cumpre) | | | | atrito, retrabalho, sem suporte |
| **Fonte + data** (links consultados) | | | | |

*(Adicione colunas se tiver mais concorrentes. 3 a 6 no total é o ideal — mais que isso dispersa.)*

---

## Leitura da matriz — o gap

Responda depois de preencher o quadro (cruzando com o ICP do **Espelho**):

- **Em que todos os concorrentes são iguais?** (eixo lotado — não compita aqui)
  > 

- **Qual a queixa que mais se repete entre os clientes deles?** (frases literais)
  > 

- **O que o meu cliente (ICP/Espelho) valoriza e nenhum deles entrega bem?** (interseção = gap)
  > 

- **O que todos eles assumem como verdade que eu poderia desafiar?** (reposicionamento)
  > 

---

## ONDE EU GANHO (o entregável)

- **Meu diferencial (1 frase, verdadeiro e defensável):**
  > 

- **Pra quem eu sou a melhor escolha, e por quê (em contraste com a alternativa atual deles):**
  > 

- **Onde eu deliberadamente NÃO compito (do que eu abro mão):**
  > 

- **Prova de que o diferencial é real (não é só slogan):**
  > 

---

*Leve "onde eu ganho" para a Decolagem (preço e modelo) e para a sua página de vendas. A decisão é sua.*
