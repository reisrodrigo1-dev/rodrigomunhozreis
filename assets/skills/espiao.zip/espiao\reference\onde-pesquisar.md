# Onde pesquisar (e como pesquisar com ética)

Tudo o que o Espião precisa está em fontes **públicas**. Não é espionagem — é leitura atenta do que o concorrente já mostra para o mundo. Abaixo, onde achar cada coisa.

> **Ressalva ética (leia antes):** pesquise apenas o que é público. Vale ler site, redes, avaliações, anúncios e tabela de preços publicada. **Não vale** invadir sistema, criar conta falsa para enganar, se passar por cliente para extrair informação confidencial, comprar dados vazados, raspar dados protegidos por login/contrato, ou qualquer coisa ilegal. Inteligência de mercado é pública e honesta. Se você precisaria esconder como conseguiu a informação, não consiga.

---

## 1. Site do concorrente

A fonte mais rica e mais ignorada. Olhe:
- **Home** → a promessa central e para quem é (posicionamento).
- **Página de preços** → modelo e valores; se for "fale com vendas", isso já é um dado.
- **Página de features / produto** → escopo, o que está dentro e fora.
- **Sobre / cases / clientes** → tamanho real, tipo de cliente, prova social.
- **Blog / central de ajuda** → o que eles acham que o cliente precisa saber (e onde o produto é complicado).

Dica: o rodapé e a FAQ revelam mais que a home — é onde estão preço, política, limites e as dúvidas reais.

---

## 2. Redes sociais

- **Instagram / TikTok / YouTube** → voz, identidade visual, frequência, o que engaja.
- **LinkedIn** → posicionamento B2B, tamanho da equipe, contratações (pra onde estão crescendo).
- **Comentários e respostas** → como tratam o público e onde ele reclama na cara deles.

Olhe não só o que postam, mas o que o **público responde** — é onde aparece dor não atendida.

---

## 3. Avaliações e reclamações (o ouro)

Aqui você acha os pontos fracos do passo 3 do procedimento. Foque nas notas **1 a 3 estrelas**:
- **Google Meu Negócio / Maps** → para negócios locais e com presença física.
- **Reclame Aqui** (Brasil) → reclamações, padrão de resposta e o que a empresa não resolve.
- **Trustpilot, G2, Capterra** → para SaaS e ferramentas; avaliações detalhadas e comparativos.
- **App Store / Google Play** → se o concorrente tem app, as reviews ruins são detalhadas.
- **Reddit, grupos, fóruns, comentários de YouTube** → opinião sem filtro, sem o cliente saber que a marca lê.

Procure o **padrão**: a mesma queixa repetida por gente diferente. Anote frases literais.

---

## 4. Anúncios (biblioteca da Meta e afins)

- **Biblioteca de Anúncios da Meta** (Facebook/Instagram Ad Library) → pública e gratuita. Mostra **todos os anúncios ativos** de qualquer página: a copy, a oferta, o criativo, há quanto tempo rodam. Anúncio que roda há muito tempo geralmente está convertendo — é a oferta que funciona pra eles.
- **Google** → pesquise o termo do seu mercado e veja quem anuncia, com qual chamada.
- **Páginas de captura / landing pages** dos anúncios → a promessa e a isca que eles usam.

Isso revela a **mensagem que vende** no seu mercado — e o ângulo que ninguém está usando.

---

## 5. Preços

- Página de preços do site (quando pública).
- Tabela em PDF, propostas comentadas em fóruns, prints em grupos.
- Se for "fale com vendas", a opacidade já é uma fraqueza — e pedir proposta como empresa real (você é uma) é legítimo; criar identidade falsa não é.

---

## 6. Pesquisa profunda → use o Garimpo

Quando a análise precisar de **dados de mercado, tamanho, tendências, números do setor ou validação de uma afirmação**, não improvise: chame a skill **Garimpo**. Ela faz busca multi-fonte com citações verificáveis e separa o que é consenso do que é boato. Para "qual o tamanho desse mercado?" ou "isso é tendência mesmo?", é Garimpo, não achismo.

---

## Como organizar o que achar

1. Uma aba/nota por concorrente; cole o link de cada fonte (rastreabilidade).
2. Registre a **data** — em mercado de tecnologia, informação velha engana.
3. Jogue tudo para a `templates/matriz-concorrencia.md`, uma linha por concorrente.
4. O que não achou em fonte pública fica "não achei" — não preencha com suposição.
