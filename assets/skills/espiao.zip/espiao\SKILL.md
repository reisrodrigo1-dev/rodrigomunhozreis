---
name: espiao
description: analisa a concorrência — oferta, preço, posicionamento e pontos fracos — pra achar seu diferencial; use ao estudar concorrentes, posicionar seu produto ou entender o mercado.
---

# Espião — análise de concorrência para achar o seu diferencial

Olhar para o concorrente serve para achar **o espaço que ninguém ocupa** — não para virar uma cópia pior. Quem copia o concorrente entra na briga no terreno dele, no preço dele, com a mensagem dele, e perde por ser o segundo a chegar. O objetivo do Espião é o contrário: entender bem o que os outros fazem para descobrir **o que eles não fazem** — porque o seu diferencial mora exatamente aí, nos pontos fracos e nas reclamações dos clientes deles.

Autor: Rodrigo Munhoz Reis — vibecoding com engenharia.

> Esta skill é INTELIGÊNCIA, não execução. Ela ajuda você a **enxergar o mercado e decidir seu posicionamento**. A decisão é sua, sempre. Aqui não tem "destrua a concorrência" nem espionagem de filme — tem pesquisa pública, leitura honesta do mercado e o raciocínio que transforma o que os outros fazem mal no motivo de alguém escolher você.

## A suíte Engenho (onde o Espião encaixa)

O Espião é uma das skills da suíte **Engenho**. As irmãs cuidam de partes vizinhas da mesma jornada — referencie e combine:

- **Decolagem** — estratégia de **negócio**: modelo, monetização, preço, go-to-market. O posicionamento que você define aqui no Espião alimenta as decisões da Decolagem.
- **Espelho** — entendimento do **cliente** (ICP, dores, linguagem). O Espião cruza com o Espelho para achar o gap: o que o seu cliente quer **e** o concorrente não entrega.
- **Garimpo** — **pesquisa profunda** com fontes verificáveis. Quando a análise precisar de dados de mercado, tamanho, tendências ou fatos checados, chame o Garimpo.

Regra prática: **Espião lê os concorrentes; Espelho lê o cliente; o diferencial é o cruzamento dos dois.** Concorrência fraca em algo que o seu cliente valoriza = seu posicionamento.

## Quando usar esta skill

Ative o Espião quando o empreendedor estiver lidando com qualquer uma destas situações:

- "Já existe gente fazendo isso. Por que alguém escolheria eu?"
- "Como eu me posiciono sem ser só mais um do mesmo?"
- "Quero estudar os concorrentes antes de definir meu preço / minha oferta."
- "O mercado tá cheio. Tem espaço pra mim?"
- "O que esses caras fazem mal que eu poderia fazer bem?"
- "Não sei nem quem são meus concorrentes de verdade."
- "Estou montando minha página/pitch e preciso saber contra o que estou competindo."

Se a conversa é sobre **estudar concorrentes, entender o mercado ou definir posicionamento e diferencial**, é Espião.

## Como consultar a base

A inteligência está em dois arquivos de referência e um template. Não despeje tudo de uma vez — leia o que a etapa pede:

| Se a pergunta é sobre... | Use |
|---|---|
| O que olhar em cada concorrente (quais dimensões analisar e o que extrair de cada uma) | `reference/o-que-analisar.md` |
| Onde achar a informação (site, redes, avaliações, anúncios, preço) e a ética da pesquisa | `reference/onde-pesquisar.md` |
| Registrar e comparar tudo lado a lado, e marcar onde você ganha | `templates/matriz-concorrencia.md` |

## PROCEDIMENTO

Cinco passos. A ordem importa: você só sabe qual é o seu diferencial depois de ver o mercado **e** o seu cliente.

### 1. Mapear os concorrentes — diretos, indiretos e o "não-consumo"

Antes de analisar, liste contra quem você compete de verdade. Três camadas, e a maioria esquece as duas últimas:

- **Diretos** — resolvem o mesmo problema, do mesmo jeito, para o mesmo público. O óbvio.
- **Indiretos** — resolvem o mesmo problema de um jeito diferente (uma planilha em vez do seu app, uma agência em vez do seu SaaS, um curso em vez da sua ferramenta).
- **Fazer na mão / não fazer / improvisar** — a alternativa mais comum e mais subestimada: o cliente continua resolvendo no Excel, no caderno, no WhatsApp, ou simplesmente convive com o problema. Esse "concorrente" costuma ser o maior de todos. Se o seu produto não vence o "deixar como está", preço e feature não importam.

Liste de 3 a 6 concorrentes no total, cobrindo as três camadas. Mais que isso vira dispersão; menos que isso cega.

### 2. Analisar cada um: oferta, preço, posicionamento e voz

Para cada concorrente, extraia as dimensões de `reference/o-que-analisar.md`. O mínimo viável:

- **Oferta / escopo** — o que entregam, o que está dentro e o que está fora.
- **Preço / modelo** — quanto e como cobram (assinatura, único, por uso, freemium).
- **Posicionamento / promessa** — para quem dizem ser, e a promessa central.
- **Voz / marca** — como falam (técnico, divertido, premium, popular).

Registre cada um na linha dele em `templates/matriz-concorrencia.md`. Se faltar um dado, escreva "não achei" — lacuna é informação, não preencha com suposição.

### 3. Achar os pontos fracos e as reclamações dos clientes deles

Aqui mora o ouro. O diferencial raramente está no que o concorrente faz bem — está no que ele faz mal e nos clientes insatisfeitos.

- Leia as **avaliações** (1 a 3 estrelas são as mais úteis), reclamações públicas, comentários, respostas em redes.
- Procure o padrão: a mesma queixa repetida por gente diferente é uma dor de mercado, não um caso isolado.
- Anote frases literais dos clientes ("é caro demais", "o suporte some", "complicado de usar"). Linguagem real vale mais que adjetivo seu.

Use `reference/onde-pesquisar.md` para saber onde caçar isso — e respeite a ética: **pesquisa pública, nada de espionagem ilegal.**

### 4. Cruzar com o seu ICP para achar o gap (link Espelho)

Uma reclamação só vira oportunidade se for sobre algo que **o seu cliente valoriza**. Pegue o ICP e as dores do **Espelho** e cruze:

- O que o seu cliente quer **e** nenhum concorrente entrega bem? → gap.
- A queixa repetida dos clientes deles bate com uma dor do seu ICP? → diferencial em potencial.
- O que todos os concorrentes assumem como verdade e poderia ser desafiado? → reposicionamento.

O gap não é "o que falta no mercado" em abstrato — é a interseção entre **fraqueza do concorrente** e **prioridade do seu cliente**.

### 5. Definir o seu diferencial e o seu posicionamento

Feche com uma decisão concreta, não com um relatório bonito:

- **Diferencial** — em uma frase: o que você faz melhor/diferente que o seu cliente valoriza e o concorrente não entrega. Tem que ser verdadeiro e defensável, não slogan.
- **Posicionamento** — para quem você é a melhor escolha, e por quê, em contraste explícito com a alternativa atual deles.
- **Onde você NÃO compete** — diga também o que você deliberadamente não faz. Posicionamento é tanto sobre o que você abre mão quanto sobre o que você promete.

Preencha o campo **"onde eu ganho"** da matriz com isso. Esse é o entregável do Espião — e ele alimenta a Decolagem (preço, modelo) e a página de vendas.

## Tom

Direto, PT-BR, sem hype. Nada de "esmague seus concorrentes". Relate o que a pesquisa mostra, separe fato de impressão, e marque o que ficou incerto. Concorrente forte é forte — diga. O objetivo não é se convencer de que você é melhor; é achar onde você realmente é. Termine lembrando: **a decisão é sua.**
