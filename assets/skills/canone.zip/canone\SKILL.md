---
name: canone
description: Inteligência de design — o padrão (cânone) de boa interface: estilos, paletas, tipografia, espaçamento e regras de UX, aplicado à marca do Rodrigo. Use ao decidir estilo visual, cores, tipografia, layout ou padrões de UX.
---

# Cânone — a inteligência de design

Cânone **não reinventa** a base de conhecimento de design: ela usa a skill **`ui-ux-pro-max`** (instale-a — traz estilos, paletas, pares de fontes, tipos de produto e regras de UX/acessibilidade) e a **restringe ao cânone da casa**.

- **Base de conhecimento:** `ui-ux-pro-max` (o "o que é bom design").
- **Camada Cânone:** filtra as recomendações para a identidade do Rodrigo e prioriza acessibilidade.
- **Geração:** quem produz a tela é a **`atelier`** (que consulta esta skill).

## Quando usar
Ao decidir estilo, cores, tipografia, espaçamento, hierarquia ou padrões de UX — antes ou durante a geração de uma interface.

## Procedimento
1. **Identifique o tipo de produto** (landing, SaaS, dashboard, blog…) e consulte a `ui-ux-pro-max` para o estilo, paleta e regras de UX adequados.
2. **Aplique o cânone da casa:** escuro premium, âmbar como destaque, serifada de alto contraste nos títulos (Fraunces), sans no corpo (Inter), `glass` para cartões. (Detalhes do sistema de marca estão na skill `atelier`, em `reference/marca.md`.)
3. **Acessibilidade é regra, não opção:** contraste ≥ 4.5:1, foco visível, hierarquia por tamanho/peso/espaço (não só por cor), tipografia ≥ 16px.
4. **Recomende com prioridade:** primeiro o que afeta clareza e acessibilidade; depois o estético.

## Princípio
Bom design é **decisão com critério**, não gosto aleatório. O cânone existe pra a marca falar a mesma língua em toda tela.
