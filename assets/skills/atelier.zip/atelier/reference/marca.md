# Sistema de marca — Rodrigo Munhoz Reis

Identidade: **teal escuro + azul**, editorial, sofisticada, técnica. Sem hype visual.
(Até 10/2026 a marca era escuro + âmbar. Não use mais âmbar, dourado ou laranja.)

## Cores
| Token | Hex | Uso |
|---|---|---|
| fundo | `#081A23` | Fundo base (teal quase preto) |
| fundo-gradiente | `#081A23` → `#0B2B3A` → `#0E3C50` | Gradiente do fundo (110°, escurece à esquerda) |
| paper | `#F1F6F8` | Texto principal |
| destaque | `#38BDF8` | Destaque, CTA, kicker, números-gancho, palavra-chave do título |
| destaque-hover | `#7DD3FC` | Hover do CTA |
| destaque-base | `#0EA5E9` | Bordas e preenchimentos sutis (`/10`, `/30`), anel de foco |
| destaque-deep | `#0369A1` | Variação escura; texto de destaque sobre fundo claro |
| ink | `#0B1E27` | Texto sobre o botão azul; texto em fundo claro |
| muted | `#8AA2AD` | Texto secundário sobre escuro |

Texto secundário também pode ser `paper` com opacidade (ex.: `text-paper/55`, `/40`).
Contraste conferido: `#38BDF8` sobre `#081A23` e `#0B1E27` sobre `#38BDF8` passam de 4.5:1.

> **No código do site (Tailwind):** o token de destaque ainda se chama `amber` por motivo histórico.
> `text-amber-light` = `#38BDF8`, `bg-amber` = `#0EA5E9`, `amber-deep` = `#0369A1`.
> Use as classes existentes; não crie um token novo nem hex solto.

## Fundo (assinatura visual)
- Gradiente teal acima + **brilho azul** desfocado no canto superior direito (`#38BDF8` a ~15–20%).
- **Grade técnica** de 54px, linhas brancas a ~3% de opacidade, sumindo para baixo.
- Nada de preto puro chapado: o fundo sempre tem o gradiente.

## Tipografia
- **Títulos:** serifada de alto contraste (**Fraunces**), pesos 500–700.
- **Corpo:** sans (**Inter**), 400–600.
- **Acento/itálico:** **Instrument Serif** (itálico) para realces editoriais, na cor de destaque.
- Mínimo 16px no corpo; entrelinha ~1.5.
- Artes para redes sociais: sans em negrito (Inter/Segoe UI), título em duas linhas com a segunda em `#38BDF8`.

## Efeitos / utilitários (Tailwind do projeto)
- `glass` / `glass-hover` — cartão de vidro fosco com borda sutil.
- `text-grad` — gradiente sutil no texto de título.
- `accent` — aplica a fonte de acento + cor de destaque (azul).
- `kicker-d` — "kicker" (rótulo pequeno, caixa alta, azul, tracking largo).
- `btn-glow` — botão azul com brilho (CTA principal), texto `ink`.
- `btn-dark-ghost` — botão fantasma sobre fundo escuro (CTA secundário).
- Chips/etiquetas: fundo branco a ~5%, borda branca a ~13%; o item em destaque ganha fundo e borda azuis.
- Bordas suaves: `rounded-xl`/`rounded-2xl`. Sombras discretas.

## Voz (microcopy)
Direta, sem hype, sem promessa milagrosa. "A decisão é sua." Português do Brasil. Frases curtas. Especificidade > adjetivo.

## Não fazer
- Clichê visual de IA: robô, cérebro brilhante, circuito, mão robótica de banco de imagem.
- Azul "corporativo de banco" chapado: o azul da marca é destaque sobre teal, não fundo inteiro.
- Voltar ao âmbar/dourado da identidade antiga.
- Cinza-de-protótipo, lorem ipsum entregue como final.
- Gradiente arco-íris, neon, excesso de sombra, "glassmorphism" gratuito.
- Texto cinza-sobre-cinza (contraste baixo).
