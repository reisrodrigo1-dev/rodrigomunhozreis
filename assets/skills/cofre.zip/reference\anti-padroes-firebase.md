# Anti-padrões de regras do Firebase

Catálogo de referência. Cada item tem: o que é, por que é perigoso, o exemplo
INSEGURO e a versão SEGURA. Use no passo 2 da auditoria.

Premissa: `rules_version = '2';` em todos os arquivos. A v2 muda a semântica de
`read`/`write` em wildcards recursivos (`{document=**}`) — sem ela, regras se
comportam diferente do esperado.

---

## 1. `allow read, write: if true;` (porta escancarada)

O pior caso. Libera leitura e escrita pra qualquer um, autenticado ou não. É o
"banco aberto" dos vazamentos de 2026. Costuma vir da IA "pra funcionar enquanto
desenvolve" e nunca é removido.

**INSEGURO**
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /{document=**} {
      allow read, write: if true;
    }
  }
}
```

**SEGURO** — feche tudo por padrão e libere caso a caso:
```
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // nega tudo que não tiver regra explícita abaixo
    match /{document=**} {
      allow read, write: if false;
    }

    match /posts/{postId} {
      allow read: if true; // leitura pública é uma decisão consciente
      allow create: if isSignedIn() && validPost();
    }
  }
}
```

---

## 2. Regra de modo de teste esquecida em produção

O modo de teste do Console gera uma regra com prazo de validade. Enquanto a data
não passa, é `if true` disfarçado. Some na correria e vai pra produção.

**INSEGURO**
```
match /{document=**} {
  // expira em 30 dias — mas até lá está TUDO aberto
  allow read, write: if request.time < timestamp.date(2026, 7, 1);
}
```

**SEGURO** — remova a regra de teste e substitua por regras reais. Nunca confie
em data como mecanismo de segurança.
```
match /{document=**} {
  allow read, write: if false;
}
// + regras específicas por coleção abaixo
```

---

## 3. `allow write` sem validar os campos do documento

Permitir escrita só checando login deixa o cliente gravar qualquer payload:
campos a mais, tipos errados, `isAdmin: true` injetado no próprio doc.

**INSEGURO**
```
match /users/{uid} {
  allow write: if request.auth != null; // grava o que quiser
}
```

**SEGURO** — valide dono, campos permitidos e tipos:
```
match /users/{uid} {
  allow create: if isSignedIn()
                && request.auth.uid == uid
                && request.resource.data.keys().hasOnly(['nome', 'email', 'criadoEm'])
                && request.resource.data.nome is string
                && isEmail(request.resource.data.email);
  allow update: if isSignedIn()
                && request.auth.uid == uid
                && request.resource.data.diff(resource.data).affectedKeys()
                     .hasOnly(['nome']); // só deixa mudar o nome
}
```

---

## 4. `match` sem `hasOnly([...])` (injeção de campos)

Sem `hasOnly`, mesmo validando os campos que você espera, o cliente pode mandar
campos extras que você não previu — incluindo flags de privilégio (`role`,
`isAdmin`, `saldo`) que outra parte do código lê confiando que vieram do servidor.

**INSEGURO**
```
match /pedidos/{id} {
  allow create: if isSignedIn()
                && request.resource.data.valor is number;
  // o cliente também pode enviar { status: "pago", desconto: 999 }
}
```

**SEGURO**
```
match /pedidos/{id} {
  allow create: if isSignedIn()
                && request.resource.data.keys().hasOnly(['valor', 'itens', 'criadoEm'])
                && request.resource.data.valor is number
                && request.resource.data.valor > 0;
}
```

`hasOnly` define a lista branca de campos. Tudo fora dela é rejeitado.

---

## 5. `update` / `delete` públicos ou só com `request.auth != null`

Create costuma receber atenção; update e delete ficam esquecidos. Resultado:
qualquer usuário logado edita ou apaga o documento de qualquer outro.

**INSEGURO**
```
match /comentarios/{id} {
  allow create: if isSignedIn();
  allow update, delete: if isSignedIn(); // edito/apago o comentário alheio
}
```

**SEGURO** — chece a posse do recurso existente (`resource.data`):
```
match /comentarios/{id} {
  allow create: if isSignedIn()
                && request.resource.data.autorId == request.auth.uid;
  allow update, delete: if isSignedIn()
                && resource.data.autorId == request.auth.uid;
}
```

`resource.data` = documento atual no banco. `request.resource.data` = o que está
chegando. Para update/delete, valide contra o `resource.data`.

---

## 6. Validação de tipo e formato ausente

`is string`, `is number`, `is timestamp`, faixa de tamanho e formato de e-mail
evitam lixo no banco e abuso (string de 5MB, número negativo onde só cabe
positivo).

**INSEGURO**
```
match /perfis/{uid} {
  allow create: if isSignedIn()
                && request.resource.data.keys().hasOnly(['email', 'idade', 'bio']);
  // email pode ser número, idade pode ser "abc", bio pode ter 10MB
}
```

**SEGURO**
```
match /perfis/{uid} {
  allow create: if isSignedIn()
                && request.resource.data.keys().hasOnly(['email', 'idade', 'bio'])
                && isEmail(request.resource.data.email)
                && request.resource.data.idade is int
                && request.resource.data.idade >= 0
                && request.resource.data.idade <= 130
                && request.resource.data.bio is string
                && request.resource.data.bio.size() <= 500;
}

// função reutilizável de e-mail:
function isEmail(s) {
  return s is string && s.matches('^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$');
}
```

---

## 7. Storage com leitura pública de tudo

Equivalente do `if true` no Storage. Expõe todo arquivo do bucket — incluindo
documentos, comprovantes, fotos de perfil privadas — a quem tiver a URL.

**INSEGURO**
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read: if true;      // qualquer arquivo, pra qualquer um
      allow write: if request.auth != null;
    }
  }
}
```

**SEGURO** — segmente por dono, valide tipo e tamanho do upload:
```
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /{allPaths=**} {
      allow read, write: if false; // padrão fechado
    }

    // avatar: público pra ler, só o dono escreve, só imagem até 5MB
    match /avatars/{uid}/{arquivo} {
      allow read: if true;
      allow write: if request.auth != null
                   && request.auth.uid == uid
                   && request.resource.size < 5 * 1024 * 1024
                   && request.resource.contentType.matches('image/.*');
    }

    // documentos privados: só o dono lê e escreve
    match /docs/{uid}/{arquivo} {
      allow read, write: if request.auth != null
                         && request.auth.uid == uid;
    }
  }
}
```

---

## 8. Ausência de checagem de `request.auth`

Regra que não checa `request.auth` trata anônimo e autenticado igual. Para
qualquer dado que não seja explicitamente público, isso é leitura/escrita não
autenticada.

**INSEGURO**
```
match /mensagens/{id} {
  allow read: if true; // mensagens privadas lidas por anônimo
}
```

**SEGURO**
```
match /mensagens/{id} {
  allow read: if isSignedIn()
              && request.auth.uid in resource.data.participantes;
}

function isSignedIn() {
  return request.auth != null;
}
```

Regra prática: `if true` só em dado que você publicaria num cartaz na rua. Todo o
resto começa em `isSignedIn()` e aperta a partir daí.

---

## 9. Confiar em campo de privilégio gravável pelo cliente

Checar `isAdmin` lendo um campo do próprio documento que o cliente pode escrever
é circular: o atacante grava `isAdmin: true` em si mesmo e vira admin.

**INSEGURO**
```
function isAdmin() {
  // lê o doc do próprio usuário, que ele mesmo pode editar
  return get(/databases/$(database)/documents/users/$(request.auth.uid)).data.isAdmin == true;
}
match /users/{uid} {
  allow update: if isSignedIn(); // permite escrever isAdmin
}
```

**SEGURO** — fonte de verdade do privilégio fora do alcance do cliente
(custom claims do Auth), e o campo de role nunca é gravável pelo cliente:
```
function isAdmin() {
  return request.auth != null && request.auth.token.admin == true; // custom claim
}
match /users/{uid} {
  allow update: if isSignedIn()
                && request.auth.uid == uid
                && !request.resource.data.diff(resource.data)
                      .affectedKeys().hasAny(['role', 'isAdmin']); // role é intocável pelo cliente
}
```

Custom claims se definem no servidor (Admin SDK), não pelo cliente. Esse é o
lugar certo pra "quem é admin".

---

## Checklist rápido

- [ ] `rules_version = '2';` presente em todos os arquivos.
- [ ] Nenhum `if true` em escrita; em leitura, só dado realmente público.
- [ ] Nenhuma regra de modo de teste (`request.time < timestamp...`).
- [ ] `match /{document=**}` fecha com `if false` por padrão.
- [ ] Todo `create`/`update` valida `hasOnly([...])` + tipos.
- [ ] `update`/`delete` checam posse via `resource.data`.
- [ ] Storage: sem `read: if true` em `{allPaths=**}`; uploads com limite de
      tamanho e `contentType`.
- [ ] Admin via custom claim (`request.auth.token.admin`), nunca campo gravável.
- [ ] Coleções com dado pessoal nunca têm leitura aberta (LGPD).
- [ ] Regras publicadas no Console batem com o arquivo do repositório.
