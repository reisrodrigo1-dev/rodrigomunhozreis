---
name: cofre
description: Audita as regras de segurança do Firebase (Firestore e Storage) em busca de coleções abertas, validação ausente e riscos de LGPD, e entrega o conserto. Use ao revisar a segurança do Firebase ou antes de subir um app que usa Firebase.
---

# Cofre

Auditoria de segurança de regras do Firebase para apps Next.js. Acha coleção
aberta, escrita sem validação e exposição de dado pessoal — e devolve o conserto,
não só o diagnóstico.

Autor: Rodrigo Munhoz Reis — vibecoding com engenharia.

## Por que isso existe

A IA gera o backend rápido. E rápido demais ela deixa o banco com permissão
aberta "pra funcionar enquanto desenvolve". Esse `allow read, write: if true;`
sobe pra produção. Foi assim que nasceram os vazamentos de "banco aberto" de
2026: qualquer pessoa com a URL do projeto lendo e escrevendo na base inteira,
sem login, sem validação, com CPF e e-mail de todo mundo dentro.

Firestore e Storage começam fechados, mas o modo de teste (regra `if request.time
< ...`) e os atalhos de desenvolvimento abrem tudo. Regra de segurança é a única
camada que separa o dado do mundo — não existe firewall "do lado de fora" pra
salvar. Se a regra está errada, o dado está exposto. Ponto.

O Cofre lê suas regras, cruza com o código pra saber o que está em risco de
verdade, e entrega regras seguras prontas pra publicar.

## Quando usar

Use o Cofre quando:

- For revisar a segurança de um app que usa Firebase (Firestore e/ou Storage).
- Estiver prestes a subir pra produção um app com Firebase.
- Herdou um projeto e não sabe o estado das regras.
- A IA gerou as regras e você quer um segundo par de olhos antes de confiar.
- Suspeita que ficou regra de modo de teste esquecida.

Não precisa usar pra: configurar Auth, escrever a primeira versão das regras do
zero (use os templates direto), ou debugar erro de permissão legítimo no app.

## Procedimento de auditoria

Siga na ordem. Não pule o passo 3 — é nele que o risco vira prioridade.

### 1. Localizar e ler as regras

Procure os arquivos de regras no projeto. Nomes e locais comuns:

- `firestore.rules` (raiz ou `config/`)
- `storage.rules`
- caminho declarado em `firebase.json` nas chaves `firestore.rules` e
  `storage.rules` — sempre confira aí, pode estar com nome custom.

```bash
# achar os arquivos
find . -name "*.rules" -not -path "*/node_modules/*"
# confirmar quais arquivos o deploy usa de verdade
cat firebase.json
```

Leia cada arquivo inteiro. Confirme que existe `rules_version = '2';` no topo — a
v1 tem semântica diferente de `read`/`write` recursivo e é fonte de erro.

Se **não houver** arquivo de regras no repo, isso já é um achado de severidade
ALTA: as regras vivem só no console, ninguém revisa, e provavelmente estão em
modo de teste. Recomende versionar as regras no repositório.

### 2. Detectar anti-padrões em cada match

Para cada bloco `match` e cada `allow`, passe a lista de anti-padrões de
`reference/anti-padroes-firebase.md`. Os principais a caçar:

- `allow read, write: if true;` ou qualquer `if true` — porta escancarada.
- regra de modo de teste esquecida (`allow ... : if request.time < timestamp...`).
- `allow write` (ou create/update) sem validar os campos do documento.
- `match` sem `hasOnly([...])` — deixa o cliente injetar campos extras.
- `update`/`delete` públicos ou só checando `request.auth != null`.
- ausência de validação de tipo/formato (e-mail, string, número).
- Storage com `allow read: if true` em `{allPaths=**}`.

Use `scripts/auditar.py` pra fazer a primeira varredura mecânica (acha `if true`,
write sem condição e match sem `hasOnly`). O script é o filtro grosso; a leitura
manual com a referência é o filtro fino.

```bash
python scripts/auditar.py caminho/para/firestore.rules
python scripts/auditar.py caminho/para/storage.rules
```

### 3. Cruzar com o código — o que é dado pessoal (LGPD)

Achado técnico sem contexto não prioriza. Uma coleção `feature_flags` aberta pra
leitura é chata; uma coleção `users` aberta pra leitura é incidente de LGPD.

Para cada coleção/bucket com anti-padrão, vá ao código do app e descubra o que
ela guarda. Procure as referências:

```bash
# onde cada coleção é lida/escrita no código
grep -rn "collection('users')" src/ app/
grep -rni "doc(db, " src/ app/
# campos que indicam dado pessoal
grep -rniE "cpf|email|telefone|phone|endereco|address|nascimento|rg|cep" src/ app/
```

Marque como **dado pessoal / LGPD** qualquer coleção que armazene: nome, e-mail,
CPF/RG, telefone, endereço, data de nascimento, dados de pagamento, localização,
ou qualquer identificador de pessoa natural. Coleção com dado pessoal + leitura
aberta = severidade CRÍTICA, sempre.

LGPD (Lei 13.709/2018) responsabiliza o controlador por vazamento. Regra aberta
sobre dado pessoal é falha de "medida de segurança" do art. 46 — não é só bug, é
exposição legal.

### 4. Lembrar: regra só vale depois de PUBLICADA

O arquivo `.rules` no repositório **não protege nada** por si só. As regras que
estão valendo são as **publicadas no Firebase Console** (ou via
`firebase deploy --only firestore:rules,storage`).

Sempre avise no relatório:

> Estas correções só têm efeito após o deploy. Edite o arquivo, rode
> `firebase deploy --only firestore:rules` (e `storage`), e confirme no Console
> em Firestore > Regras que a versão publicada bate com o arquivo. Use o
> simulador de regras do Console pra testar antes de confiar.

Um app pode ter um `firestore.rules` perfeito no Git e estar com modo de teste
aberto em produção porque ninguém deu deploy. Verifique a data de "última
publicação" no Console se tiver acesso.

### 5. Gerar o relatório: risco + conserto por regra

Entregue um relatório direto. Para cada achado:

```
[SEVERIDADE] arquivo:linha — nome do anti-padrão
  Coleção/path: <qual>
  Dado pessoal? <sim/não — o que guarda>
  Risco: <o que um atacante faz com isso, 1 frase>

  INSEGURO (atual):
    <trecho>

  SEGURO (conserto):
    <trecho corrigido>
```

Ordene por severidade: CRÍTICA (dado pessoal exposto) > ALTA (escrita/leitura
aberta sem dado pessoal, modo de teste) > MÉDIA (validação parcial, falta
hasOnly) > BAIXA (melhoria defensiva).

Feche com:

1. Um patch consolidado das regras corrigidas (use `templates/firestore.rules` e
   `templates/storage.rules` como base, adaptando às coleções reais do projeto).
2. O lembrete de publicar (passo 4).
3. Próximos passos: testar no simulador, dar deploy, reauditar.

## Arquivos da skill

- `reference/anti-padroes-firebase.md` — catálogo de anti-padrões com exemplo
  inseguro e a versão segura de cada um.
- `templates/firestore.rules` — modelo de regras seguras de Firestore.
- `templates/storage.rules` — modelo de regras seguras de Storage.
- `scripts/auditar.py` — varredura mecânica de um arquivo `.rules`.
