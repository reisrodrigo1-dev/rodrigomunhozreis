#!/usr/bin/env python3
"""
auditar.py — Cofre / Rodrigo Munhoz Reis (vibecoding com engenharia).

Varredura mecânica de um arquivo .rules do Firebase (Firestore ou Storage).
É o filtro grosso da auditoria: acha os anti-padrões detectáveis por padrão de
texto e imprime linha + severidade. A leitura manual com
reference/anti-padroes-firebase.md continua sendo necessária pro filtro fino.

Detecta:
  - allow ... : if true               (porta escancarada)            -> CRITICA
  - regra de modo de teste (request.time < timestamp...)             -> CRITICA
  - allow write/create/update sem condição (sem "if")                -> ALTA
  - allow só com request.auth != null, sem mais validação            -> MEDIA
  - bloco allow create/update/write sem hasOnly() no match           -> MEDIA
  - ausência de rules_version = '2'                                  -> ALTA

Uso:
  python auditar.py firestore.rules
  python auditar.py storage.rules firestore.rules     # vários arquivos
  python auditar.py --strict firestore.rules          # sai com cod 1 se houver achado

Código de saída: 0 = sem achados (ou sem --strict); 1 = achados com --strict;
2 = erro de uso/arquivo.
"""

import re
import sys

SEV_ORDER = {"CRITICA": 0, "ALTA": 1, "MEDIA": 2, "BAIXA": 3}

# Padrões de linha única.
RE_COMMENT = re.compile(r"^\s*//")
RE_ALLOW = re.compile(r"\ballow\b\s+([a-z,\s]+?)\s*:\s*(.*)$")
RE_IF_TRUE = re.compile(r":\s*if\s+true\s*;?\s*$")
RE_TEST_MODE = re.compile(r"request\.time\s*<\s*timestamp")
RE_ONLY_AUTH = re.compile(
    r":\s*if\s+request\.auth\s*!=\s*null\s*;?\s*$"
)
RE_NO_IF = re.compile(r":\s*(true|false)?\s*;?\s*$")  # allow sem "if"
RE_MATCH = re.compile(r"\bmatch\s+(\S+)")
RE_VERSION = re.compile(r"rules_version\s*=\s*'2'")

WRITE_VERBS = ("write", "create", "update")


class Achado:
    def __init__(self, sev, line, kind, snippet, path=None):
        self.sev = sev
        self.line = line
        self.kind = kind
        self.snippet = snippet.strip()
        self.path = path

    def __str__(self):
        loc = f"L{self.line}"
        ctx = f" [match {self.path}]" if self.path else ""
        return f"  [{self.sev}] {loc}{ctx} — {self.kind}\n      {self.snippet}"


def strip_comment(line):
    """Remove comentário de fim de linha (simplificado, sem entrar em strings)."""
    idx = line.find("//")
    return line[:idx] if idx != -1 else line


def auditar(path):
    try:
        with open(path, encoding="utf-8") as f:
            raw_lines = f.readlines()
    except OSError as e:
        print(f"ERRO: não consegui ler {path}: {e}", file=sys.stderr)
        return None

    achados = []
    texto = "".join(raw_lines)

    # Storage não tem campos de documento, então hasOnly() não se aplica lá.
    is_storage = "firebase.storage" in texto

    # 1) rules_version
    if not RE_VERSION.search(texto):
        achados.append(
            Achado("ALTA", 1, "falta rules_version = '2'",
                   "arquivo sem rules_version = '2'; semântica de read/write fica ambígua")
        )

    # Pilha de blocos match para saber se o match atual tem hasOnly().
    # Estratégia simples por chaves: rastreia o match mais recente aberto e se
    # já vimos hasOnly dentro dele.
    match_stack = []  # cada item: {"path", "depth", "has_only", "needs_only"}
    depth = 0

    for i, raw in enumerate(raw_lines, start=1):
        line = strip_comment(raw)
        stripped = line.strip()
        if not stripped:
            depth += raw.count("{") - raw.count("}")
            continue

        # registra hasOnly (ou o wrapper only(...)) visto em qualquer match aberto
        if ("hasOnly" in line or re.search(r"\bonly\s*\(", line)) and match_stack:
            match_stack[-1]["has_only"] = True

        m_match = RE_MATCH.search(line)
        if m_match:
            match_stack.append({
                "path": m_match.group(1),
                "depth": depth,
                "has_only": False,
                "needs_only": False,
            })

        m_allow = RE_ALLOW.search(line)
        if m_allow:
            verbs = m_allow.group(1)
            cur_path = match_stack[-1]["path"] if match_stack else None

            # if true
            if RE_IF_TRUE.search(line):
                if any(v in verbs for v in WRITE_VERBS):
                    sev = "CRITICA"
                    kind = "allow de escrita com 'if true' (porta escancarada)"
                else:
                    sev = "ALTA"
                    kind = "allow read com 'if true' (leitura pública — ok só se o dado for público)"
                achados.append(Achado(sev, i, kind, stripped, cur_path))

            # modo de teste
            elif RE_TEST_MODE.search(line):
                achados.append(
                    Achado("CRITICA", i,
                           "regra de modo de teste (request.time < timestamp) — aberta até a data",
                           stripped, cur_path)
                )

            # allow ... ; sem "if" algum
            elif "if" not in line and RE_NO_IF.search(line):
                achados.append(
                    Achado("ALTA", i,
                           "allow sem condição 'if' — permissão incondicional",
                           stripped, cur_path)
                )

            # só request.auth != null
            elif RE_ONLY_AUTH.search(line):
                if any(v in verbs for v in WRITE_VERBS):
                    achados.append(
                        Achado("MEDIA", i,
                               "escrita só com 'request.auth != null' — sem validar campos/posse",
                               stripped, cur_path)
                    )
                else:
                    achados.append(
                        Achado("MEDIA", i,
                               "leitura só com 'request.auth != null' — sem checar posse do recurso",
                               stripped, cur_path)
                    )

            # marca que esse match precisa de hasOnly (tem write/create/update)
            if any(v in verbs for v in WRITE_VERBS) and match_stack:
                match_stack[-1]["needs_only"] = True

        # fecha blocos conforme as chaves
        opened = raw.count("{")
        closed = raw.count("}")
        depth += opened - closed
        while match_stack and depth <= match_stack[-1]["depth"]:
            blk = match_stack.pop()
            if (not is_storage and blk["needs_only"] and not blk["has_only"]
                    and blk["path"] != "/{document=**}"):
                achados.append(
                    Achado("MEDIA", i,
                           f"match com escrita sem hasOnly([...]) — cliente pode injetar campos extras",
                           f"match {blk['path']} {{ ... }}", blk["path"])
                )

    return achados


def main(argv):
    args = [a for a in argv[1:] if not a.startswith("-")]
    strict = "--strict" in argv[1:]

    if not args:
        print(__doc__)
        return 2

    total = 0
    pior = None
    for path in args:
        achados = auditar(path)
        if achados is None:
            return 2
        print(f"\n=== {path} ===")
        if not achados:
            print("  OK — nenhum anti-padrão detectado na varredura mecânica.")
            print("  (Ainda assim, revise manualmente com a referência.)")
            continue
        achados.sort(key=lambda a: (SEV_ORDER.get(a.sev, 9), a.line))
        for a in achados:
            print(a)
            if pior is None or SEV_ORDER[a.sev] < SEV_ORDER[pior]:
                pior = a.sev
        total += len(achados)

    print(f"\n--- Resumo: {total} achado(s)" +
          (f", pior severidade: {pior}" if pior else "") + " ---")
    if total:
        print("Lembre: regra só vale DEPOIS de publicada "
              "(firebase deploy --only firestore:rules,storage).")

    if strict and total:
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv))
