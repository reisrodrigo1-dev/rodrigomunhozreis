# Tipos de migração

Três tipos cobrem quase tudo. Cada um tem riscos próprios e um processo concreto. Em todos, os princípios da skill valem: backup antes, incremental, reversível, validar a cada passo.

---

## (a) Versão de dependência / framework

Subir uma versão major de algo que sustenta o projeto: Next.js, React, o Firebase SDK, Node, uma lib crítica.

### Riscos

- **Breaking changes** — APIs que sumiram, mudaram de assinatura, ou mudaram de comportamento sem mudar de nome (o pior tipo: compila, roda, e faz a coisa errada).
- **Cascata de peer dependencies** — subir o Next pode exigir subir o React, que exige subir outra coisa. Um update vira dez.
- **Deprecation silenciosa** — funciona hoje com warning, quebra na próxima.
- **Pular versões** — ir de 13 direto pro 15 sem passar pelo 14 esconde os passos intermediários e mistura mudanças.

### Processo

1. **Leia o guia oficial de upgrade da SUA versão.** Frameworks sérios publicam *upgrade guide* + lista de *breaking changes* por versão. Para Next.js e React, existe `@next/codemod` / `npx codemod` que reescrevem boa parte do código automaticamente.
2. **Backup:** commit limpo + branch dedicada (`migracao/next-15`). Nunca na main.
3. **Uma versão por vez.** 13→14, valida, 14→15, valida. Cada salto tem o seu guia e os seus codemods.
4. **Rode os codemods** que o framework oferece e **revise o diff** — codemod erra em casos de borda. O que ele não cobriu, ajuste à mão usando a lista de breaking changes.
5. **Atualize as peer deps** que o novo major exige, juntas, no mesmo passo. Confira com `npm ls` / o erro de peer que o install reclama.
6. **Valide:** `npm run build` limpo (sem warnings novos de deprecation), testes verdes, smoke test dos fluxos críticos.
7. **Rollback** = voltar pra branch anterior e redeployar o deploy anterior.

> Antes de adotar a versão de destino, vale passar pela **Quarentena** — checar se a versão nova não introduz uma dependência transitiva problemática.

---

## (b) Dados / schema no Firestore

Mudar a forma dos dados: adicionar/renomear/remover campo, mudar o tipo ou formato de um campo, reestruturar ou mover documentos entre coleções.

Aqui o risco é o mais sério da skill: **dado perdido não volta.** Firestore não tem "schema" no sentido relacional, então a "migração de schema" é, na prática, reescrever documentos — e cada documento reescrito errado é um dado corrompido em produção.

### Riscos

- **Perda irreversível de dados** se o script erra e não havia backup.
- **Script que roda pela metade** (timeout, erro no meio do lote) e deixa o banco num estado misto — parte migrado, parte não.
- **Rodar duas vezes** e duplicar/corromper o que já foi migrado (script não-idempotente).
- **App lendo o formato antigo** enquanto a migração ainda roda → erro pra usuário em produção.
- **Custo/quota** — varrer uma coleção grande consome leituras e escritas; um update ingênuo pode estourar quota ou a conta.

### Processo

1. **BACKUP primeiro, com a Resgate.** Export do Firestore que você **já testou restaurar**. Sem isso, não comece.
2. **Entenda o estado real.** Amostre documentos de verdade — não confie no que você acha que está lá. Conte quantos documentos a migração vai tocar.
3. **Campo novo com fallback (aditivo, não destrutivo):** adicione o campo novo **sem apagar o antigo**. No código de leitura, leia o novo com fallback pro antigo:
   ```js
   const nome = doc.nomeCompleto ?? doc.nome ?? "";
   ```
   Assim documentos ainda não migrados continuam funcionando. Esse é o padrão mais seguro e cobre a maioria dos casos.
4. **Dual-write quando preciso:** se há escrita acontecendo durante a migração, escreva nos **dois** formatos (antigo e novo) enquanto a migração roda. Ninguém quebra. Você só remove a escrita antiga depois que tudo migrou e o novo provou funcionar.
5. **Script de migração idempotente e em lote** — pode rodar de novo sem estragar o já feito, processa em batches (não um update gigante), com log de progresso e **dry-run**. Modelo pronto em `../templates/script-migracao-dados.md`.
6. **Rode o dry-run primeiro**, confira a contagem e amostre o que ele *faria*. Só então rode pra valer.
7. **Valide:** contagem antes/depois bate, amostre documentos migrados, app lê o novo formato sem erro.
8. **Só então** (passo destrutivo, opcional, e bem depois): remova o campo antigo / o fallback / o dual-write — quando o novo provou estar de pé por tempo suficiente.
9. **Rollback** = restaurar o backup da Resgate, *ou* (se você foi aditivo/dual-write) continuar lendo o campo antigo. Migração aditiva quase não precisa de rollback — esse é o ponto dela.

---

## (c) Trocar de provedor / ferramenta

Sair de um serviço para outro: trocar de host (ex.: Vercel → outro), de banco, de provedor de e-mail/pagamento/auth, de um SDK por outro equivalente.

### Riscos

- **Lock-in escondido** — você descobre tarde que dependia de um recurso específico do provedor antigo que o novo não tem igual.
- **Paridade de configuração** — variáveis de ambiente, domínios, webhooks, regras, redirects: esquecer um quebra em produção.
- **Janela de indisponibilidade** se você desliga o antigo antes do novo estar pronto.
- **Dados/estado presos** no provedor antigo (sessões, filas, dados que só existem lá).

### Processo (coexistência / strangler)

1. **Backup:** anote/exporte toda a config do provedor antigo — envs, domínios, webhooks, regras, secrets. Você vai precisar replicar e, no rollback, voltar.
2. **Suba o novo AO LADO do antigo.** Não desligue nada ainda. Configure o novo provedor por completo num ambiente paralelo (staging ou domínio de teste).
3. **Paridade:** replique config item a item e confirme. Faça um checklist do que o antigo tinha e marque cada um no novo.
4. **Mova o tráfego aos poucos** quando der (DNS gradual, feature flag, % de usuários). Em alguns casos é um corte único — então faça em **janela de baixo tráfego** e com rollback no gatilho.
5. **Valide no novo** com fluxos reais antes de cortar o antigo: login, pagamento, o core do produto.
6. **Só desligue o antigo** depois do novo provado por tempo suficiente. Até lá, o rollback é apontar o tráfego/DNS de volta — barato e rápido **porque o antigo ainda está de pé.**

A regra de ouro da troca de provedor: **o antigo continua ligado até o novo provar que funciona.** Quem desliga primeiro fica sem rede.
