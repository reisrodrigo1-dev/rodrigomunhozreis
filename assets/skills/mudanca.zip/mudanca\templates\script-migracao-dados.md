# Template — script de migração de dados (Firestore)

Modelo de script para migrar dados/schema no Firestore com segurança. As quatro propriedades inegociáveis:

1. **Idempotente** — rodar de novo não estraga o que já foi migrado (pula o que já está no formato novo).
2. **Em lote (batch)** — processa em blocos, não um update gigante; não estoura quota nem memória.
3. **Log de progresso** — você vê quanto já foi, quanto falta, quantos erros.
4. **Dry-run** — roda sem escrever nada e mostra o que *faria*. Sempre rode o dry-run primeiro.

> **Antes de rodar isto: backup com a Resgate, testado que restaura.** Este script reescreve documentos de produção. Sem backup, não rode.

Rode com o **Admin SDK** (Node, em máquina/ambiente confiável com service account), **não** no client. Migração de dados é operação administrativa.

## Pré-requisitos

```bash
npm install firebase-admin
# Service account: defina GOOGLE_APPLICATION_CREDENTIALS apontando pro JSON da chave,
# ou passe o caminho via initializeApp. NUNCA commite o JSON da service account.
```

## Script

```js
// migracao.js
// Uso:
//   node migracao.js            -> DRY-RUN (não escreve nada, só mostra o que faria)
//   node migracao.js --execute  -> executa de verdade
//
// Exemplo de migração: criar o campo `nomeCompleto` a partir de `nome` + `sobrenome`,
// SEM apagar os campos antigos (aditivo / com fallback). Ajuste a função `migrar()`.

const admin = require("firebase-admin");

admin.initializeApp(); // usa GOOGLE_APPLICATION_CREDENTIALS
const db = admin.firestore();

// ---- Configuração ----
const COLECAO = "usuarios";
const TAMANHO_LOTE = 400;          // < 500 (limite de writes por batch do Firestore)
const DRY_RUN = !process.argv.includes("--execute");

// ---- Regra de migração de UM documento ----
// Retorna o objeto de campos a atualizar, ou `null` se o doc já está migrado (idempotência).
function migrar(data) {
  // Idempotência: se já tem o campo novo, não mexe.
  if (data.nomeCompleto !== undefined) return null;

  const nome = data.nome ?? "";
  const sobrenome = data.sobrenome ?? "";
  const nomeCompleto = `${nome} ${sobrenome}`.trim();

  if (!nomeCompleto) return null; // nada pra montar; pula

  // Aditivo: cria o campo novo, NÃO apaga `nome`/`sobrenome`.
  return { nomeCompleto };
}

async function run() {
  console.log(`\n=== Migração da coleção "${COLECAO}" ===`);
  console.log(DRY_RUN ? ">> DRY-RUN (nada será escrito)\n" : ">> EXECUTANDO (escrevendo de verdade)\n");

  let processados = 0;
  let migrados = 0;
  let pulados = 0;
  let erros = 0;

  // Paginação por documento (escala melhor que ler tudo de uma vez).
  let ultimoDoc = null;

  while (true) {
    let q = db.collection(COLECAO).orderBy("__name__").limit(TAMANHO_LOTE);
    if (ultimoDoc) q = q.startAfter(ultimoDoc);

    const snap = await q.get();
    if (snap.empty) break;

    const batch = db.batch();
    let escritasNoLote = 0;

    for (const doc of snap.docs) {
      processados++;
      try {
        const update = migrar(doc.data());
        if (update === null) {
          pulados++;
          continue;
        }
        if (DRY_RUN) {
          console.log(`  [dry-run] ${doc.id} ->`, JSON.stringify(update));
        } else {
          batch.update(doc.ref, update);
          escritasNoLote++;
        }
        migrados++;
      } catch (e) {
        erros++;
        console.error(`  ERRO em ${doc.id}:`, e.message);
      }
    }

    if (!DRY_RUN && escritasNoLote > 0) {
      await batch.commit();
    }

    ultimoDoc = snap.docs[snap.docs.length - 1];
    console.log(`... progresso: ${processados} processados | ${migrados} migrados | ${pulados} pulados | ${erros} erros`);
  }

  console.log(`\n=== Fim ===`);
  console.log(`Total processados: ${processados}`);
  console.log(`Migrados:          ${migrados}`);
  console.log(`Pulados (já ok):   ${pulados}`);
  console.log(`Erros:             ${erros}`);
  if (DRY_RUN) console.log(`\n>> Foi DRY-RUN. Rode com --execute para aplicar.`);
}

run().then(() => process.exit(0)).catch((e) => {
  console.error("Falha fatal:", e);
  process.exit(1);
});
```

## Como usar (na ordem)

1. **Backup com a Resgate** e confirme que restaura.
2. **Dry-run:** `node migracao.js` — leia a saída, confira a contagem total e amostre o que ele *faria*. Bateu com o esperado?
3. **Execute:** `node migracao.js --execute`.
4. **Valide:** contagem de migrados/pulados/erros faz sentido; amostre documentos no console do Firebase; confirme que a aplicação lê o novo formato (com o fallback do passo seguinte).
5. **Se errou:** o script é idempotente — conserte a função `migrar()` e rode de novo; ele pula o que já ficou certo. Se corrompeu, restaure o backup da Resgate.

## Leitura com fallback (no app, durante a transição)

Enquanto nem todo documento foi migrado, leia o novo campo com fallback pro antigo, pra ninguém quebrar:

```js
const nome = doc.nomeCompleto ?? `${doc.nome ?? ""} ${doc.sobrenome ?? ""}`.trim();
```

## Adaptações comuns

- **Migração destrutiva (renomear de fato):** só **depois** que o aditivo rodou, validou e a leitura com fallback está no ar há tempo suficiente. Use `admin.firestore.FieldValue.delete()` no `update` para remover o campo antigo — e ainda assim com backup.
- **Dual-write:** se há escrita acontecendo durante a migração, garanta no código da aplicação que toda escrita grava nos dois formatos até a migração terminar.
- **Coleção grande (centenas de milhares+):** considere rodar por janelas, com `where()` pra fatiar, e atenção a custo de leituras/escritas (quota e conta).
- **Subcoleções:** use `collectionGroup()` se o campo está em subcoleções espalhadas.
- **Filtrar só o que falta:** se houver um campo marcador, adicione um `.where()` no query pra ler só os não-migrados e economizar leituras.
