# Processo seguro — checklist de migração

Use como checklist concreto. Não pule o BACKUP. Marque cada item antes de avançar.

## Antes de começar (preparação)

- [ ] **Vale a pena migrar?** O ganho justifica o risco? Ficar na versão atual é uma opção válida. A decisão é sua — só não decida no automático.
- [ ] **Li o changelog / guia de upgrade oficial** da minha versão de origem até a de destino (sem pular versões intermediárias sem ler).
- [ ] **Listei por escrito o que muda no MEU projeto** — quais APIs/campos/configs, em quais arquivos, quantos lugares.
- [ ] **Existe codemod/ferramenta oficial** de migração? Anotei pra usar (e revisar o diff).
- [ ] **Sei como reverter** cada tipo de passo que vou dar.

## BACKUP (inegociável — pare se algum faltar)

- [ ] **Git limpo:** nada pendente, tudo commitado.
- [ ] **Branch dedicada** criada (ex.: `migracao/<o-que>`). NÃO migrando na main/master.
- [ ] **Dados com backup restaurável** (se a migração toca dados) — feito com a skill **Resgate** e **testado que restaura**. "Tenho um export" não conta.
- [ ] **Config/envs do estado atual** anotadas/exportadas (Vercel, Firebase, provedor antigo).
- [ ] **Deploy anterior identificado** (no Vercel, sei qual é o deploy pra promover de volta).

## Plano incremental

- [ ] Migração quebrada em **passos pequenos**, não big-bang.
- [ ] Cada passo é **validável isoladamente**.
- [ ] Cada passo é **reversível por conta própria**.
- [ ] Versão: **uma de cada vez** (13→14→15, não 13→15 direto).
- [ ] Dados: estratégia **aditiva** (campo novo + fallback) ou **dual-write** definida — não destrutiva de cara.
- [ ] Provedor: novo entra **ao lado** do antigo; antigo só desliga depois.

## Rollback pronto — ANTES de executar

- [ ] Para **cada passo**, sei: "se quebrar em produção, como volto e em quanto tempo?"
- [ ] **Código:** voltar branch/commit + redeploy do deploy anterior — testado mentalmente.
- [ ] **Dados:** restaurar backup da Resgate *ou* continuar lendo campo antigo (se aditivo/dual-write).
- [ ] **Provedor:** apontar tráfego/DNS de volta; antigo ainda ligado.
- [ ] Nenhum passo **destrutivo** (apagar campo, desligar provedor) acontece antes do novo estar provado.

## Janela e execução

- [ ] Executando em **janela de baixo tráfego** (madrugada / fim de semana / horário de menor uso), especialmente se houver corte único.
- [ ] **Dados: dry-run primeiro.** Conferi contagem e amostra do que o script *faria* antes de rodar pra valer.
- [ ] Avisei quem precisa saber (time, e usuários se houver indisponibilidade prevista).

## Validar a cada passo

- [ ] **Testes automatizados** verdes (skill **Prova** se a cobertura é fraca).
- [ ] **Build limpo** — sem warnings novos de deprecation ignorados.
- [ ] **Smoke test manual** dos fluxos críticos (login, criar/editar dado principal, pagamento — o core).
- [ ] **Dados:** contagem antes/depois bate; amostrei documentos migrados; app lê o novo formato sem erro.
- [ ] **Pós-deploy:** observando logs e erros (skill **Sentinela**) na janela seguinte ao deploy.
- [ ] Só avancei pro próximo passo com o atual **verde**.

## Fechamento

- [ ] Migração validada em produção por tempo suficiente.
- [ ] **Passos destrutivos** (remover campo antigo, fallback, dual-write, desligar provedor antigo) executados **só agora**, com o novo provado.
- [ ] Branch de migração mergeada; código revisado (skill **Crivo**).
- [ ] Backups e config antiga guardados por um período de segurança antes de descartar.
- [ ] Documentei o que mudou (pra próxima migração e pra quem herdar o projeto).
