---
name: mudanca
description: conduz migrações com segurança — versão de framework/dependência, troca de stack ou migração de dados/schema; use ao atualizar uma versão grande, trocar de ferramenta/provedor ou migrar dados.
---

# Mudança

Conduz migrações sem quebrar o que já funciona: subir uma versão major de framework, trocar de stack/ferramenta/provedor, ou migrar dados e schema.

## Visão geral: toda migração é arriscada

Migrar é mexer no que já está de pé e funcionando. O sistema atual, por mais feio que seja, tem uma virtude inegociável: **ele funciona agora, em produção, com usuários reais.** Qualquer migração começa em desvantagem — você está trocando uma certeza por uma promessa.

Por isso a regra desta skill não é "migre rápido", é **migre de um jeito que dê pra voltar atrás.** Três princípios sustentam tudo:

- **Incremental, não big-bang.** Migração de uma tacada só é a que mais quebra e a mais difícil de debugar — quando dá errado, você não sabe qual das cinquenta mudanças foi. Quebre em passos pequenos, cada um validável e reversível por conta própria.
- **Reversível.** Antes de dar um passo, você precisa saber como desfazê-lo. Se não há rollback, não é um passo de migração — é uma aposta.
- **Backup antes.** Código no Git (commit limpo, branch dedicada) e dados com cópia restaurável **antes de tocar em qualquer coisa.** Isso não é opcional. Migração de dados sem backup é a forma mais rápida de perder dados de cliente de maneira irreversível.

A decisão de migrar é sua — talvez o ganho não justifique o risco, e ficar na versão atual seja a escolha certa. Esta skill não te empurra a migrar; ela garante que, **quando** você migrar, seja com rede de segurança.

> **Antes de migrar dados, use a Resgate.** A skill irmã Resgate cuida de backup restaurável (não só "exportei um JSON" — backup que você já testou que **restaura**). Migração de dados sem backup validado pela Resgate não deveria começar.

## Quando usar

- **Subir uma versão major** de framework ou dependência crítica (ex.: Next.js 14 → 15, React 18 → 19, Firebase SDK v9 → v10, Node 18 → 22).
- **Trocar de stack, ferramenta ou provedor** (ex.: sair do Vercel para outro host, trocar de banco, migrar de um SDK para outro, trocar provedor de e-mail/pagamento).
- **Migrar dados ou schema** — adicionar/renomear/remover campo no Firestore, mudar formato de um campo, reestruturar uma coleção, mover dados entre coleções.
- **Consolidar ou dividir** projetos, monorepos, ambientes.

Se a mudança é pequena e isolada (um patch, uma dependência sem breaking change), você não precisa de todo o procedimento — mas o reflexo de **backup + branch** vale sempre.

## Procedimento

Cinco passos, em ordem. Não pule o 2.

### 1. Entender o que muda

Antes de tocar em código, leia o que a migração realmente exige. Migração às cegas é a que mais quebra.

- **Leia o changelog e o guia de upgrade oficial.** Frameworks sérios publicam um *upgrade guide* e uma lista de *breaking changes* por versão. Leia a da SUA versão de origem até a de destino — não pule versões intermediárias sem ler o que mudou em cada salto.
- **Liste o que quebra no SEU projeto.** Nem todo breaking change te afeta. Procure no seu código pelas APIs que mudaram. Anote uma lista concreta: "uso X em N lugares, vira Y".
- **Existe codemod?** Muitos frameworks (Next.js, React) fornecem *codemods* — scripts que reescrevem o seu código automaticamente para a API nova. Use, mas **revise o diff** que ele gera; codemod não é mágica e erra em casos de borda.
- **Para dados/schema:** entenda o estado atual (quantos documentos, qual o formato real dos campos — não o que você *acha* que é) e o estado de destino. Veja `reference/tipos-de-migracao.md`.

Saída deste passo: uma lista escrita do que precisa mudar e onde. Sem ela, você está chutando.

### 2. BACKUP antes

Inegociável. Antes de qualquer alteração:

- **Código no Git.** Commit limpo do estado atual (nada pendente), e crie uma **branch dedicada** para a migração (ex.: `migracao/next-15`). Nunca migre na `main`/`master`. Assim o rollback do código é um `git checkout`.
- **Dados com backup restaurável.** Se a migração toca dados (Firestore, qualquer banco), faça backup **antes** — e confirme que ele restaura. Use a skill **Resgate**. "Tenho um export" não conta enquanto você não testou a restauração.
- **Variáveis de ambiente e config.** Anote/exporte as envs atuais (Vercel, Firebase) antes de trocar provedor ou versão. Trocar de host sem ter as envs do antigo é dor de cabeça garantida.

Sem backup, **pare aqui.** Os outros passos pressupõem que existe pra onde voltar.

### 3. Plano incremental (passo a passo, não big-bang)

Quebre a migração em passos pequenos, cada um:
- pequeno o suficiente pra você entender o que ele muda,
- validável isoladamente (passo 5),
- reversível por conta própria (passo 4).

Padrões que tornam a migração incremental:

- **Uma versão por vez.** Pra subir do Next 13 ao 15, suba 13→14, valide, depois 14→15. Não pule. Cada salto tem o seu guia.
- **Dual-write / leitura com fallback** (dados): durante a transição, escreva nos dois formatos e leia o novo com fallback pro antigo. Ninguém quebra enquanto a migração roda. Detalhes em `reference/tipos-de-migracao.md`.
- **Migrar em lote** (dados): nunca um update gigante de uma vez. Processe em batches, com log de progresso, idempotente. Veja `templates/script-migracao-dados.md`.
- **Strangler / coexistência** (troca de provedor): o novo provedor entra ao lado do antigo, você move o tráfego aos poucos, e só desliga o antigo quando o novo provou estar de pé.

Big-bang ("desliga tudo, troca, liga") só se justifica em projeto pequeno, sem usuários, ou quando a coexistência é tecnicamente impossível — e mesmo aí, com janela e rollback prontos.

### 4. Ter rollback pronto — ANTES de executar

Para cada passo, responda **antes** de executá-lo: "se isso der errado em produção, como eu volto, em quanto tempo?"

- **Código:** rollback é voltar pra branch/commit anterior e redeployar. Tenha o deploy anterior identificado (no Vercel, o deploy anterior fica a um clique de "Promote to Production").
- **Dados:** rollback é restaurar o backup do passo 2 — *ou*, se você usou dual-write, simplesmente continuar lendo o campo antigo. Migração destrutiva (apagar o campo velho) só **depois** que o novo provou funcionar por tempo suficiente.
- **Provedor:** não desligue o antigo até o novo estar validado. O rollback é apontar o DNS/tráfego de volta.

Se um passo não tem rollback claro, ele não está pronto pra executar. Volte e quebre mais.

### 5. Validar a cada passo

Depois de cada passo, **valide antes de seguir.** O ponto de ser incremental é poder validar incremental.

- **Testes automatizados** rodando verde (use a skill **Prova** se a cobertura é fraca — migração é exatamente quando você quer testes).
- **Build limpo** — sem warnings novos de deprecation que você ignorou.
- **Smoke test manual** dos fluxos críticos: login, criar/editar o dado principal, pagamento, o que for core do produto. Clique de verdade.
- **Dados:** valide contagem (quantos documentos antes/depois), formato (amostre alguns documentos migrados), e que a aplicação lê o novo formato sem erro.
- **Em produção:** observe logs e erros depois do deploy (skill **Sentinela**), numa janela de baixo tráfego.

Só avance pro próximo passo quando o atual estiver verde. Se quebrou, rollback (passo 4), entenda, conserta, repete.

## Arquivos de apoio

- `reference/tipos-de-migracao.md` — os três tipos (versão de dependência/framework; dados/schema no Firestore; troca de provedor/ferramenta), cada um com riscos e processo concreto.
- `reference/processo-seguro.md` — o checklist de migração segura (backup, branch, incremental, rollback, validação, janela).
- `templates/script-migracao-dados.md` — modelo de script de migração de dados no Firestore: idempotente, em lote, com log de progresso e dry-run.

## Skills irmãs (suíte Engenho)

- **Resgate** — backup restaurável antes de migrar dados. **Comece por ela** em qualquer migração de dados.
- **Quarentena** — auditar dependências; útil ao avaliar o pacote/versão de destino antes de adotar.
- **Prova** — escrever testes; sua rede de segurança pra validar cada passo.
- **Crivo** — revisar o diff da migração (inclusive o gerado por codemod) antes de subir.
- **Sentinela** — observabilidade pra acompanhar a saúde do sistema depois do deploy da migração.
