# O que incluir — os tipos de contexto que ajudam

Contexto útil é o que **muda a resposta** desta tarefa. Cada tipo abaixo melhora uma coisa específica. A pergunta-filtro pra qualquer candidato é: **"se eu tirar isso, a resposta piora?"** Se não piora, não inclua.

Esta referência cobre os seis tipos que mais valem a pena. Você quase nunca precisa dos seis de uma vez — pegue os que a tarefa pede.

---

## 1. Objetivo — o que você quer, e pra quê

**O que é:** o resultado que você espera no fim, e a razão por trás dele.

**O que melhora:** direção. Sem objetivo, o modelo escolhe um padrão genérico. Com objetivo, ele otimiza pro seu alvo. E o "pra quê" é o que mais ajuda — quando a IA sabe a intenção, ela acerta escolhas que você nem pensou em pedir.

**Genérico vs. com objetivo:**
- Fraco: "Revisa esse e-mail."
- Forte: "Revisa esse e-mail pra soar mais firme — o cliente está enrolando o pagamento há duas semanas e eu quero cobrar sem queimar a relação."

A segunda versão deixa a IA escolher palavras que firmam sem agredir. A primeira deixa ela adivinhar se você quer mais formal, mais curto, mais simpático.

**Quando incluir:** sempre. É o único tipo que nunca sobra.

---

## 2. Público / destinatário — pra quem é a saída

**O que é:** quem vai ler ou usar o resultado.

**O que melhora:** tom, profundidade e vocabulário. A mesma explicação muda completamente se é pra um diretor, pra um cliente leigo ou pra um dev sênior.

**Exemplo:**
- "Explica isso." → resposta de tamanho e profundidade aleatórios.
- "Explica isso pra um cliente que não é técnico, em até um parágrafo." → resposta calibrada.

**Quando incluir:** sempre que a saída vai ser lida por alguém. Se é só pra você consumir, pode pular.

---

## 3. Restrições — os limites duros

**O que é:** o que não pode ser quebrado. Tamanho ("máximo 200 palavras"), formato ("em tabela", "em JSON", "em tópicos"), o que não pode aparecer ("sem jargão", "não cite concorrentes"), prazo, plataforma, regra do negócio.

**O que melhora:** ajuste à realidade. Restrição transforma uma resposta "tecnicamente certa mas inútil" numa resposta usável. De nada adianta o texto perfeito se ele tem o triplo do tamanho que cabe no espaço.

**Exemplo:**
- Sem restrição: a IA escreve três parágrafos quando você precisava de uma frase.
- Com restrição: "Em uma frase, sem usar a palavra 'inovador'." → você recebe exatamente o que cabe.

**Quando incluir:** sempre que existir um limite real. Restrição não-dita é restrição que a IA vai violar.

---

## 4. Exemplos do que deu certo — a amostra do que você quer

**O que é:** uma amostra concreta do tom, formato ou padrão que você busca. Um e-mail antigo que funcionou, um trecho de código no estilo do seu projeto, um título que você curtiu.

**O que melhora:** precisão de estilo, mais que qualquer descrição. **Um exemplo vale mais que três parágrafos explicando o exemplo.** "Quero um tom assim:" + a amostra ensina o modelo o que "firme mas cordial" significa *pra você* — algo que adjetivos não conseguem transmitir.

**Cuidado:** o exemplo tem que ser do que deu *certo*. Se você colar um exemplo ruim "pra ela não fazer assim", deixe isso explícito ("evite este estilo") — senão a IA imita.

**Quando incluir:** sempre que tom ou formato importam e você tem uma amostra à mão. É o tipo de contexto mais subutilizado e um dos mais poderosos.

---

## 5. Dados / arquivos relevantes — o material do seu caso

**O que é:** o texto, a planilha, o código, os números que a IA precisa olhar pra responder *sobre o seu caso* e não sobre o caso médio.

**O que melhora:** especificidade. É a diferença entre "como reduzo custo?" (conselho de revista) e "olha esses números de gasto, onde eu corto?" (análise do seu caso).

**A armadilha:** aqui é onde "mais contexto" engana. Você não precisa do documento *inteiro* — precisa do *trecho relevante*. Mandar 40 páginas quando 2 resolvem é o erro clássico: enterra o sinal no ruído e ainda gasta janela. Traga o pedaço que a tarefa exige, não o arquivo todo "por garantia".

**Quando incluir:** sempre que a tarefa é *sobre* algo concreto que você tem. Filtre antes (ver `o-que-cortar.md`).

---

## 6. Histórico relevante — o que já rolou

**O que é:** decisões já tomadas, tentativas que falharam, abordagens descartadas, o estado atual de algo.

**O que melhora:** evita que a IA sugira o que você já tentou e descartou, e a mantém alinhada com decisões anteriores.

**O filtro crítico — "relevante":** histórico é o tipo que mais vira entulho. A regra: só inclua o histórico que **muda a resposta agora**. "Já tentamos X e não funcionou por causa de Y" é ouro. "A reunião começou às 14h e o João estava atrasado" é ruído. Conte o que importa pra decisão, não a novela inteira.

**Quando incluir:** quando ignorar o passado faria a IA repetir um erro ou contradizer uma decisão. Caso contrário, deixe de fora.

---

## Tabela de bolso

| Tipo | O que melhora | Inclua quando |
|---|---|---|
| Objetivo | Direção | Sempre |
| Público | Tom, profundidade, vocabulário | A saída tem leitor |
| Restrições | Ajuste à realidade (cabe, serve) | Existe limite real |
| Exemplos | Precisão de tom/formato | Tom/formato importam e você tem amostra |
| Dados/arquivos | Especificidade ao seu caso | A tarefa é sobre algo concreto seu |
| Histórico | Não repetir erro, não contradizer | O passado muda a resposta agora |

**Regra que vale pra todos:** inclua o tipo *e* mantenha cada item enxuto. Incluir "objetivo" não é despejar três parágrafos de contexto de vida — é uma frase clara. O próximo passo é cortar (`o-que-cortar.md`).
