# O que cortar — o ruído que atrapalha

Incluir contexto é metade do trabalho. A outra metade — a que quase todo mundo pula — é **cortar**. Contexto demais não é generosidade com a IA; é enterrar o que importa.

## Por que cortar melhora a resposta

O modelo trabalha com tudo que você entrega ao mesmo tempo. Ele não tem um filtro "isso aqui é importante, isso é só de fundo". Quando você cola dez páginas e só duas importam, as outras oito **competem** pela atenção do modelo. O resultado:

- ele pode se agarrar no trecho errado e responder sobre o que não interessava;
- a informação que importa fica diluída e perde peso;
- você gasta janela de contexto à toa (e pode até estourar o limite).

A régua que organiza tudo: **menos-porém-certo > muito-porém-bagunçado.** Uma bagagem enxuta e limpa produz resposta melhor que uma bagagem completa e caótica. Sempre.

A pergunta-tesoura pra cada pedaço: **"se eu cortar isso, a resposta piora?"** Se a resposta não piora, corte sem dó.

---

## Os quatro tipos de ruído

### 1. Texto irrelevante pra ESSA tarefa

O maior volume de entulho. São as seções, parágrafos, e-mails e anexos que não mudam a resposta da tarefa em questão.

O documento pode ser todo importante *pra você* — mas pra *esta tarefa* só um pedaço importa. Revisar a cláusula 8 de um contrato não exige mandar as cláusulas 1 a 7. Resumir a decisão de uma reunião não exige a transcrição inteira com os "ahn" e as conversas paralelas.

**Como cortar:** isole o trecho que a tarefa toca. Se você precisa de contexto de fundo, dê uma frase ("este é um contrato de prestação de serviço; foque na cláusula de rescisão abaixo") em vez de colar tudo.

### 2. Repetição

A mesma informação dita três vezes não vale por três. Vale por uma — e ocupa o espaço de três, e ainda faz o modelo achar que aquilo é mais importante do que é só porque apareceu muito.

Repetição entra sorrateira quando você junta material de várias fontes (o e-mail repete o que está no documento, que repete o que você já escreveu no pedido). 

**Como cortar:** diga cada coisa **uma vez**, no lugar mais claro. Se já está no seu pedido, não precisa estar de novo no material colado.

### 3. Contexto contraditório

O mais perigoso, porque não só ocupa espaço — ele **engana**. Quando o material diz uma coisa e o pedido diz outra, ou quando você cola duas versões do mesmo documento, a IA precisa escolher qual obedecer. E ela escolhe sozinha, nem sempre o que você queria.

Exemplos: a versão antiga e a nova do texto coladas juntas; uma instrução no começo que briga com outra no fim; dados de duas fontes que discordam.

**Como cortar:** escolha **uma** versão e cole só ela. Se as duas precisam ir (raro), diga explicitamente qual vale: "use os números da planilha B; a A está desatualizada e está aqui só pra referência."

### 4. Dado sensível e desnecessário

Dado que a tarefa **não precisa** e que você não devia expor: CPF, dado de cartão, senha, chave de API, dado de cliente, e-mail de terceiros, segredo de negócio, prontuário.

Dois motivos pra cortar: (1) o que você cola pode sair do seu controle — sair do seu computador, ser logado, ser usado pra treino dependendo da ferramenta; (2) na maioria dos casos a tarefa funciona igual sem o dado real.

**Proteção do P.R.O.M.P.T.E.R. — o ritual antes de colar:**

1. **Pergunte:** "essa tarefa precisa do dado *real* pra funcionar?" Quase nunca precisa.
2. **Se não precisa, anonimize:** troque o real por um marcador. `Maria Silva` vira `[CLIENTE]`, `R$ 47.320,00` vira `[VALOR]`, `maria@email.com` vira `[EMAIL]`. A estrutura fica, o dado sai.
3. **Se nem anonimizado precisa, corte.** Tabela de 5 mil clientes pra IA "entender o contexto"? Não precisa. Mande a estrutura e um exemplo fake.

A regra: **só vai o que precisa ir.** Necessidade, não conveniência, decide o que entra.

---

## Tabela de bolso

| Ruído | Por que atrapalha | Como cortar |
|---|---|---|
| Texto irrelevante | Dilui o sinal, gasta janela | Isole o trecho da tarefa; resuma o fundo numa frase |
| Repetição | Ocupa espaço, infla a importância falsa | Diga cada coisa uma vez |
| Contradição | Engana — a IA escolhe e erra | Cole uma versão; se duas, diga qual vale |
| Sensível desnecessário | Risco de exposição, e não agrega | Anonimize com marcadores, ou corte |

**Depois de cortar, sobra o material certo — mas ainda bruto.** O próximo passo é organizar pra IA achar o que importa: `estruturar-contexto.md`.
