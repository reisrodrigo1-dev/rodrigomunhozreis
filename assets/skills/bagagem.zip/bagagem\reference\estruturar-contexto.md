# Estruturar o contexto — pra IA achar o que importa

Você já incluiu o certo e cortou o ruído. Falta a parte que transforma material bom em resposta boa: **organização.** Um amontoado de texto correto, sem estrutura, faz a IA se perder do mesmo jeito que o ruído faria. Estruturar é dar mapa.

## Por que estrutura importa

O modelo lê tudo de uma vez, mas não trata tudo igual. Material rotulado, separado e bem ordenado ele navega com facilidade — sabe o que é instrução, o que é dado, o que é exemplo. Material num bloco amorfo ele tem que adivinhar — e adivinha errado. O erro mais comum e mais caro: a IA confunde o seu **dado** com a sua **instrução**, e tenta "executar" um pedaço do texto que você só queria que ela lesse.

---

## As quatro regras de estrutura

### 1. Rótulos e seções — diga o que cada bloco é

Dê um nome a cada parte. A IA usa o rótulo pra saber o papel daquele bloco.

```
## Objetivo
Reescrever o e-mail abaixo pra soar mais firme.

## Público
Cliente que está atrasando o pagamento há duas semanas.

## Restrições
Máximo 4 linhas. Sem ameaça. Manter a cordialidade.

## E-mail atual
[cola aqui]

## Exemplo do tom que quero
[cola aqui um e-mail antigo que funcionou]
```

Cabeçalhos com `##`, títulos em maiúsculas, ou só uma linha em branco entre blocos rotulados — qualquer um funciona. O que não funciona é tudo grudado.

### 2. Delimitadores — separe o material colado do seu pedido

Quando você cola um texto pra IA trabalhar em cima, **marque onde ele começa e termina.** Sem isso, a IA não sabe onde acaba o dado e começa a instrução.

Use um cabeçalho claro ("Texto a revisar abaixo:") seguido do material, ou aspas triplas, ou uma cerca:

```
Revise o texto entre as marcas, sem revisar nada fora delas:

<<<
[o texto que vai ser revisado]
>>>
```

Isso resolve o problema clássico de a IA "obedecer" a uma frase que estava dentro do documento.

### 3. Ordem importa — o que vem primeiro pesa

A ordem não é neutra. Em geral:

- **Instrução e objetivo primeiro.** O modelo lê a tarefa antes do material e já sabe o que procurar enquanto lê.
- **Dado de apoio depois.** Material longo no meio/fim, já com a tarefa em mente.
- **Não enterre o que importa no meio.** O começo e o fim de um bloco longo recebem mais atenção que o miolo. Se uma informação é crítica, ela não pode estar na página 7 de 14 sem destaque — puxe pro começo ou repita perto do pedido.

Um padrão que funciona bem: **instrução no topo → dados no meio → instrução repetida no fim** (em material longo, reafirmar o pedido depois do dado ajuda a IA a não "esquecer" o que tinha que fazer).

### 4. Separe instrução de dado — explicite o que é comando

Deixe inequívoco o que é **comando** ("faça X") e o que é **material** ("aqui está o texto"). É o erro nº 1 e o mais fácil de evitar. Não escreva:

> Melhora isso reduza para R$ 50 o cliente reclamou do prazo segue o contrato cláusula 8...

Escreva:

> **Tarefa:** revisar a cláusula 8 do contrato abaixo, ajustando o prazo de entrega.
> **Contrato (só leia, não altere o resto):**
> [texto]

---

## Lidar com contexto longo

Mesmo enxuto e organizado, às vezes o material é grande demais pra janela — ou grande o bastante pra IA "perder o fio". Duas saídas:

### Resumir

Troque o material longo pelo **resumo dos pontos que importam pra tarefa.** Dez páginas de transcrição viram cinco bullets com as decisões. O resumo bem feito preserva o essencial e não inventa nada — pra isso, use a skill **Síntese**, que existe exatamente pra resumir conteúdo longo sem distorcer.

Use quando: o material é texto corrido longo (transcrição, artigo, reunião) e a tarefa precisa do *conteúdo*, não do texto literal.

### Dividir

Quebre a tarefa em partes e mande o contexto de cada parte **na sua vez**, em vez de tudo de uma vez. Revisar um documento de 50 páginas? Faça por capítulo. Analisar 12 meses de dados? Faça por trimestre e junte no fim.

Use quando: a tarefa é naturalmente fatiável e cada fatia tem contexto próprio, ou quando nem o resumo cabe.

### Resumir ou dividir? — regra rápida

- Precisa do **panorama geral** mas não dos detalhes literais → **resuma**.
- Precisa trabalhar o **detalhe de cada parte**, uma de cada vez → **divida**.
- Tá perto do limite mas cabe → não faça nem um nem outro; só corte mais ruído (`o-que-cortar.md`).

---

## Tabela de bolso

| Regra | O que evita |
|---|---|
| Rótulos e seções | IA não saber o papel de cada bloco |
| Delimitadores | IA confundir dado com instrução |
| Ordem (importante no topo/fim) | Informação crítica diluída no meio |
| Separar instrução de dado | IA "executar" o que era só pra ler |
| Resumir / dividir | Estourar a janela ou perder o fio no longo |

Modelo mínimo que cobre quase tudo: **Objetivo → Público → Restrições → [delimitador] Dados [delimitador] → Exemplo.** Comece por aí e ajuste pra tarefa.
