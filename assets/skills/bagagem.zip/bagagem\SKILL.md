---
name: bagagem
description: ajuda a montar o contexto certo pra dar à IA — o que incluir, o que cortar e como organizar — pra ela responder pro SEU caso; use quando a resposta da IA está genérica por falta de contexto, ao trabalhar com documentos/dados longos, ou ao preparar o material pra uma tarefa.
---

# Bagagem — o contexto que você entrega junto

Você não viaja sem bagagem. Também não devia pedir nada sério pra uma IA sem levar o contexto certo. **Bagagem** é a skill que te ajuda a montar o material que vai *junto* com o pedido: o que incluir, o que cortar, e como organizar pra IA achar o que importa.

A skill é do autor **Rodrigo Munhoz Reis**, referência em *vibecoding com engenharia*. Voz: PT-BR, direta, sem hype. Você ajuda a montar a bagagem, mostra o que sobra e o que falta, e no fim lembra: **a decisão é sua** — quem escolhe o que entra é você.

Faz parte da suíte **Engenho**. As irmãs cuidam de outras partes do mesmo trabalho:

- **Forja** monta o *prompt* — o pedido em si (o que você quer).
- **Bagagem** (esta) monta o *contexto* — o material que vai junto do pedido (o que a IA precisa saber pra responder pro seu caso).
- **Lapidador** refina a *saída* depois que a resposta veio.
- **Alicerce** monta as *instruções do projeto* — o contexto fixo que vale pra todas as conversas daquele projeto.

Regra de divisão: se a dúvida é "como peço?", é Forja. Se é "o que eu mando junto pra ela acertar?", é Bagagem.

## A ideia central

Contexto é o que separa uma resposta genérica de uma resposta sob medida. A mesma pergunta — "como melhoro meu texto?" — vira conselho de revista quando você não dá contexto, e vira edição cirúrgica quando você cola o texto, diz pra quem é, e mostra um exemplo do tom que você quer.

O modelo não sabe nada do seu caso além do que você entrega na conversa. Ele não está na sua cabeça, não viu seu projeto, não conhece seu público. Tudo que ele tem pra trabalhar é (1) o pedido e (2) a bagagem. Se a bagagem está vazia, ele preenche o vazio com média — o resultado mais provável pra uma pergunta vaga. E média é justamente o que você não quer.

Mas tem um porém que quase todo mundo erra: **mais contexto nem sempre é melhor.** Despejar tudo que você tem — o documento inteiro, o histórico todo, três versões contraditórias — não ajuda, atrapalha. Ruído compete com sinal. Quando você enterra a informação que importa no meio de dez páginas irrelevantes, o modelo tem mais chance de se agarrar no pedaço errado. Contexto contraditório é pior ainda: se o material diz uma coisa e o seu pedido diz outra, a IA escolhe — e nem sempre escolhe o que você queria.

O alvo não é *muito* contexto. É o contexto **certo, limpo e organizado**. Pouco-porém-certo ganha de muito-porém-bagunçado, sempre.

## QUANDO usar esta skill

Use Bagagem quando:

- a resposta da IA veio **genérica, óbvia, "serve pra qualquer um"** — e o motivo provável é que ela não sabia nada do seu caso;
- você vai trabalhar com um **documento, transcrição, planilha ou base de dados longa** e precisa decidir o que mandar;
- você está **preparando o material** pra uma tarefa (revisar um contrato, resumir uma reunião, gerar código que conversa com o seu sistema, escrever em cima de um texto que já existe);
- o pedido **estourou a janela de contexto** ou ficou perto disso e você precisa enxugar;
- você tem **muito material** e não sabe o que é relevante pra essa tarefa específica;
- você quer **proteger dado sensível** que não precisa ir junto.

Use também quando o usuário disser coisas como: *"a IA não entende meu caso", "como mando meus arquivos pra ela?", "que parte do documento eu colo?", "tá dando resposta genérica", "como organizo tudo isso pra IA?", "é muito texto, não cabe".*

**Não** use Bagagem quando o problema é o pedido em si (aí é **Forja**) ou quando a resposta já veio e só precisa de ajuste (aí é **Lapidador**). E não use pra montar o contexto *fixo* de um projeto inteiro — isso é **Alicerce**.

## O PROCEDIMENTO

Montar a bagagem tem cinco passos. Você não pula a triagem (passo 1) — é ela que evita os outros quatro virarem trabalho à toa.

### Passo 1 — Definir o que a IA PRECISA saber pra ESSA tarefa

Antes de juntar qualquer coisa, responda: **o que essa tarefa específica exige que a IA saiba?** Contexto não é tudo que existe sobre o assunto — é só o que muda a resposta *desta* tarefa.

Passe por estas categorias e marque o que se aplica:

- **Objetivo** — o que você quer no fim, e pra quê. ("Reescrever esse e-mail pra soar mais firme, porque o cliente está enrolando.")
- **Público / destinatário** — pra quem é a saída. Muda tom, profundidade e vocabulário.
- **Restrições** — limites duros: tamanho, formato, prazo, o que não pode aparecer, regras que não dá pra quebrar.
- **Exemplos do que deu certo** — uma amostra do tom, formato ou padrão que você quer. Um exemplo vale mais que três parágrafos de descrição.
- **Dados / arquivos relevantes** — o texto, a planilha, o código, os números que a IA precisa olhar pra responder *sobre o seu caso* e não sobre o caso médio.
- **Histórico relevante** — o que já foi decidido, tentado ou descartado, *se* isso muda a resposta agora.

Para cada categoria, pergunte: **"se eu tirar isso, a resposta piora?"** Se não piora, não é contexto — é entulho. Detalhe de cada tipo e o que ele melhora em `reference/o-que-incluir.md`.

### Passo 2 — Reunir o material certo

Agora vá buscar o que o passo 1 marcou. Junte na forma mais útil: o trecho do documento que importa (não o documento inteiro), o exemplo concreto (não a descrição do exemplo), os números relevantes (não a planilha toda).

A pergunta que guia: **"o modelo consegue fazer a tarefa só com isso?"** Se falta uma peça pra ele não ter que adivinhar, traga. Se você está trazendo "por garantia", segura — isso é o passo 3.

### Passo 3 — Cortar o ruído e o que for sensível e desnecessário

Esse é o passo que quase todo mundo pula, e é o que mais melhora a resposta. Olhe o que você reuniu e **corte**:

- **Texto irrelevante pra ESSA tarefa** — seções, e-mails, parágrafos que não mudam a resposta.
- **Repetição** — a mesma informação dita três vezes não vale por três; vale por uma e ocupa três.
- **Contexto contraditório** — duas versões do mesmo documento, instruções que brigam entre si. Escolha uma, ou diga explicitamente qual vale.
- **Dado sensível e desnecessário** — CPF, dado de cartão, senha, dado de cliente, segredo de negócio que a tarefa **não precisa**. Não exponha o que não agrega.

Sobre o dado sensível, aplique a **Proteção do P.R.O.M.P.T.E.R.**: antes de colar, pergunte "isso é necessário pra tarefa?". Se não for, **corte ou anonimize** (troque nomes e números reais por marcadores como `[CLIENTE]`, `[VALOR]`). Lembre que o que você cola pode sair do seu controle — só vai o que precisa ir. Detalhe do que cortar e por quê em `reference/o-que-cortar.md`.

A régua de toda essa etapa: **menos-porém-certo > muito-porém-bagunçado.**

### Passo 4 — Estruturar pra IA achar o que importa

Mesmo o material certo vira ruído se vier num bloco amorfo. Organize pra IA navegar:

- **Rótulos e seções** — diga o que cada bloco é: `## Objetivo`, `## Dados`, `## Exemplo do tom que quero`.
- **Delimitadores** — separe o material colado do seu pedido (use marcadores claros, aspas triplas, ou um cabeçalho tipo "Texto a revisar abaixo:"). Sem isso, a IA confunde o seu dado com a sua instrução.
- **Ordem importa** — instrução e objetivo primeiro; dado de apoio depois; o que é mais importante perto do começo ou do fim, não enterrado no meio.
- **Separe instrução de dado** — deixe explícito o que é comando ("faça X") e o que é material ("aqui está o texto"). É o erro mais comum e o mais fácil de evitar.

Modelos de estrutura prontos em `reference/estruturar-contexto.md`.

### Passo 5 — Caber na janela

A janela de contexto é finita. Se o material certo, já cortado e estruturado, ainda é grande demais, você tem duas saídas:

- **Resumir o longo** — troque dez páginas pelo resumo dos pontos que importam pra tarefa. Pra resumir sem perder o essencial nem inventar, use a skill **Síntese**.
- **Dividir** — quebre a tarefa em partes e mande o contexto de cada parte na sua vez, em vez de tudo de uma vez.

Como decidir entre resumir e dividir, e como lidar com contexto longo sem o modelo "esquecer" o começo, em `reference/estruturar-contexto.md`.

Feche lembrando ao usuário: bagagem é escolha, e **quem decide o que entra é ele**.

## Como consultar as referências

Leia o arquivo de referência **sob demanda**, conforme o passo — não carregue tudo de uma vez.

| Quando | Arquivo |
|---|---|
| Decidir o que incluir e entender o que cada tipo de contexto melhora | `reference/o-que-incluir.md` |
| Decidir o que cortar (ruído, sensível, contraditório, repetição) e por quê | `reference/o-que-cortar.md` |
| Organizar o material (rótulos, delimitadores, ordem) e lidar com contexto longo | `reference/estruturar-contexto.md` |

Fluxo típico: defina o que a tarefa exige (passo 1) → abra `o-que-incluir.md` pra checar os tipos → reúna → abra `o-que-cortar.md` pra enxugar → abra `estruturar-contexto.md` pra organizar e fazer caber.
